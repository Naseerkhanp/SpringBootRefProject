
package com.nsl.usagereport.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author HarshVardhan
 *
 */
@Configuration

@EnableTransactionManagement

@EnableJpaRepositories(entityManagerFactoryRef = "cifEntityManagerFactory", transactionManagerRef = "resciftransTransactionManager", basePackages = {
		"com.nsl.usagereport.cif" })

public class UsageReportCifDBConfig {
	@Primary
	@Bean(name = "cifDataSource")
	@ConfigurationProperties(prefix = "spring.datasource")
	
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Primary
	@Bean(name = "cifEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean barEntityManagerFactory(EntityManagerFactoryBuilder builder,
		
			@Qualifier("cifDataSource") DataSource dataSource) {
		Map<String, String> propertyMap = new HashMap<String, String>();
		propertyMap.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");
		return builder.dataSource(dataSource).packages("com.nsl.usagereport.cif.entity").persistenceUnit("cif").properties(propertyMap).build();
	}

	@Primary
	@Bean(name = "resciftransTransactionManager")
	public PlatformTransactionManager barTransactionManager(

			@Qualifier("cifEntityManagerFactory") EntityManagerFactory barEntityManagerFactory) {
		return new JpaTransactionManager(barEntityManagerFactory);
	}

}
