package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String rabbitListenerContainer;

	private String cbrssuspendQueue;

	private String cbrssuspendExchange;

	private String cbrsrestoreQueue;

	private String cbrsrestoreExchange;

	private String cbrsdeleteQueue;

	private String cbrsdeleteExchange;

	private String prepareprofilemustangQueue;

	private String prepareprofilemustangExchange;

	private String cbrsserviceQueue;

	private String cbrsserviceExchange;
}
