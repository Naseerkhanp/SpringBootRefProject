pipeline {
    agent any
	
	tools { 
        maven 'Maven-3.3.9' 
        jdk 'jdk-11.0.9' 
    }	
	
    stages {
        
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-devqar2-CICD@excelacom.in',
			to: 'nsl_devops@excelacom.in',
			subject: "NSL devqar2 framework-authorization Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }

		stage('NSL devqar2 - EKS POD Deploy') {
			steps {
			echo 'framework-authorization POD Deployment has been started...'
			sh 'cat devqar2-framework-authorization-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f devqar2-framework-authorization-service.yaml'
			sh 'kubectl apply -f devqar2-framework-authorization-config.yaml'
			sh 'kubectl rollout restart deployment framework-authorization-deployment'
			//sh 'kubectl apply -f devqar2-framework-authorization-apm.yaml'
                  }
        }
		stage('NSL devqar2 - EKS POD Status') {
		    steps {
			echo 'framework-authorization POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep framework-authorization-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 framework-authorization Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 framework-authorization Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }
