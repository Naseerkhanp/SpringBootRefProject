/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nsl.managelines.batch.bean.OutboundRequest.Feature;
import com.nsl.managelines.batch.bean.OutboundRequest.Lnp;
import com.nsl.managelines.batch.bean.OutboundRequest.NextAvailableMDN;
import com.nsl.managelines.batch.bean.OutboundRequest.SubscriberGroup;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class OutboundData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String mdn;

	public String deviceId;

	public String iccid;

	@JsonProperty("MPNPoolName")
	public String mPNPoolName;

	@JsonProperty("SubOrgID")
	public String subOrgID;

	@JsonProperty("DPFOResetDay")

	public String dPFOResetDay;

	public String planCode;

	public Lnp lnp;

	public NextAvailableMDN nextAvailableMDN;

	public ArrayList<Feature> feature;

	public SubscriberGroup subscriberGroup;

}
