package com.nsl.usagereport.cif.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.cif.entity.TransFailureLog;
@Transactional
@Repository
public interface TransFailureLogRepository  extends JpaRepository<TransFailureLog, Integer>{

}
