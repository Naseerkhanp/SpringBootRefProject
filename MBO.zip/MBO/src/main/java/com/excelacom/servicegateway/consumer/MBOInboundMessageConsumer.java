package com.excelacom.servicegateway.consumer;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.service.ExternalServiceClient;

/**
 * The Class InboundMessageConsumer.
 */
@Component
public class MBOInboundMessageConsumer {

	/** The transaction service. */
	@Autowired
	ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(MBOInboundMessageConsumer.class);
	
	@RabbitListener(queues = "#{inboundQueueProperties.getEmmCreateSubscriberQueue()}", containerFactory = "emmCreaterabbitListenerContainerFactory")
	public Message EMMCreateSubscriberResponse(Message msg) {
		LOGGER.info("Inside EMMCreateSubscriberResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.EMMCREATESUBSCRIBER_SERVICENAME;
		String operationName = Constants.EMMCREATESUBSCRIBER_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String source="RestClient";
			LOGGER.info("Request for EMMCreateSubscriber Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "EmmCreateSubscriber",
					"MBO", "POST", source);
			
			
			// For invoking flow-through
			if(request.contains("&")) {
				request=request.replaceAll("&", "u+00000026");	}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getEmmUpdateSubscriberQueue()}", containerFactory = "emmUpdaterabbitListenerContainerFactory")
	public Message EMMUpdateSubscriberResponse(Message msg) {
		LOGGER.info("Inside EMMUpdateSubscriberResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.EMMUPDATESUBSCRIBER_SERVICENAME;
		String operationName = Constants.EMMUPDATESUBSCRIBER_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Request for EMMUpdateSubscriber Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			String source="RestClient";
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "UpdateSubscriber",
					"MBO", "POST", source);
			
			// For invoking flow-through
			if(request.contains("&")) {
				  request=request.replaceAll("&", "u+00000026");}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	  @RabbitListener(queues ="#{inboundQueueProperties.getEmmGetSubscriberQueue()}", containerFactory ="emmGetsubscriberrabbitListenerContainerFactory") 
	  public Message EMMGetSubscriberResponse(Message msg) {
			  LOGGER.info("Inside EMMGetSubscriberResponse"); 
			  String response = null;
			  String entityId = "0"; 
			  String transId = null; 
			  String serviceName = Constants.EMMGETSUBSCRIBER_SERVICENAME; 
			  String operationName = Constants.EMMGETSUBSCRIBER_OPERATIONNAME; 
			  UUID uuid = null; 
			  String responseId = null; 
			  try {
				  	byte[] body = msg.getBody(); 
				  String request = new String(body);
				  LOGGER.info("Request for EMMGetSubscriber Service : " + request); 
				  uuid =UUID.randomUUID(); 
				  transId = uuid.toString(); 
				  String source="RestClient";
				  
				  responseId = transactionDAO.insertMNONBTransaction(request, entityId,transId, "GetSubscriber", "MBO", "POST", source);
				  if(request.contains("&")) {
					  request=request.replaceAll("&", "u+00000026");	
							}
				  response = externalServiceClient.getResponseFromClient(request, transId, responseId,serviceName, operationName); } catch (Exception e) {
				  LOGGER.error(e.getMessage(), e); 
			  }
			  return  MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build(); 
	  }
	 
	
	@RabbitListener(queues = "#{inboundQueueProperties.getEmmUsageinquiryQueue()}", containerFactory = "emmUsageinquiryrabbitListenerContainerFactory")
	public Message EMMUsageinquiryResponse(Message msg) {
		LOGGER.info("Inside EMMCreateSubscriberResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.EMMUSAGEINQUIRY_SERVICENAME;
		String operationName = Constants.EMMUSAGEINQUIRY_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String source="RestClient";
			LOGGER.info("Request for EMMUsageinquiry Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "UsageInquiry",
					"MBO", "POST", source);
			// For invoking flow-through
			if(request.contains("&")) {
				request=request.replaceAll("&", "u+00000026");	}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getEmmChangemdnsubscriberQueue()}", containerFactory = "emmChangemdnsubscriberrabbitListenerContainerFactory")
	public Message EMMChangemdnsubscriberResponse(Message msg) {
		LOGGER.info("Inside EMMCreateSubscriberResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.EMMCHANGEMDNSUBSCRIBER_SERVICENAME;
		String operationName = Constants.EMMCHANGEMDNSUBSCRIBER_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String source="RestClient";
			LOGGER.info("Request for EMMChangemdnsubscriber Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "changemdnsubscriber",
					"MBO", "POST", source);
			// For invoking flow-through
			if(request.contains("&")) {
				request=request.replaceAll("&", "u+00000026");	}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
}
