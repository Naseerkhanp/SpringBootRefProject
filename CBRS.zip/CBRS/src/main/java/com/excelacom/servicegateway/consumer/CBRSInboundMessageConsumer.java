package com.excelacom.servicegateway.consumer;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.service.ExternalServiceClient;

/**
 * The Class InboundMessageConsumer.
 */
@Component
public class CBRSInboundMessageConsumer {

	/** The transaction service. */
	@Autowired
	ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(CBRSInboundMessageConsumer.class);

	@RabbitListener(queues = "#{inboundQueueProperties.getCbrssuspendQueue()}", containerFactory = "CbrsSuspendrabbitListenerContainerFactory")
	public Message CBRSSuspendserviceResponse(Message msg) {
		LOGGER.info("Inside CBRSSuspendserviceResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.CBRSSUSPEND_SERVICENAME;
		String operationName = Constants.CBRSSUSPEND_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Request for CBRSSuspend Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "CbrsSuspendService",
					"CBRS");
			// For invoking flow-through
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getCbrsrestoreQueue()}", containerFactory = "CbrsRestorerabbitListenerContainerFactory")
	public Message CBRSRestoreserviceResponse(Message msg) {
		LOGGER.info("Inside CBRSRestoreserviceResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.CBRSRESTORE_SERVICENAME;
		String operationName = Constants.CBRSRESTORE_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Request for CBRSRestore Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "CbrsRestoreService",
					"CBRS");
			// For invoking flow-through
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getCbrsdeleteQueue()}", containerFactory = "CbrsDeleterabbitListenerContainerFactory")
	public Message CBRSDeleteserviceResponse(Message msg) {
		LOGGER.info("Inside CBRSDeleteserviceResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.CBRSDELETE_SERVICENAME;
		String operationName = Constants.CBRSDELETE_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Request for CBRSDelete Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "CbrsDeleteService",
					"CBRS");
			// For invoking flow-through
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getPrepareprofilemustangQueue()}", containerFactory = "PrepareProfileMustangrabbitListenerContainerFactory")
	public Message PrepareProfileResponse(Message msg) {
		LOGGER.info("Inside PrepareProfileResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.PREPAREPROFILEMUSTANG_SERVICENAME;
		String operationName = Constants.PREPAREPROFILEMUSTANG_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Request for prepareprofilemustang Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			String source = "RestClient";
			/*
			 * responseId = transactionDAO.insertNorthBoundTransaction(request, entityId,
			 * transId, "CbrsDeleteService", "CBRS");
			 */
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "ActivateService", "CBRS",
					"POST", source);

			// For invoking flow-through
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
}
