package com.nsl.usagereport.transaction.dao.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.transaction.entity.RefFileUpload;

@Component
public class RefFileUploadDaoImpl {
	@Autowired
	private RefFileUploadRepository refFileUploadRepository;

	@Transactional
	public RefFileUpload getRefFileUploadDetail(String fileName) throws Exception {
		return refFileUploadRepository.findByFilterID(fileName).stream().findFirst().map(e -> (RefFileUpload) e)
				.orElseThrow(Exception::new);
	}

	@Transactional
	public List<RefFileUpload> getRefFileUploadDetails(String fileName) {
		List<RefFileUpload> refFileUploadLST = refFileUploadRepository.findByFilterID(fileName);
		return refFileUploadLST;
	}
	
	@Transactional
	public RefFileUpload getRefFileUploadDetailByFilterValue(String fileName,long filterValue) throws Exception {
		return refFileUploadRepository.findByFilterValue(fileName,filterValue);
	}

}
