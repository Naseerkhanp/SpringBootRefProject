spool 01_cif_dml_service_info_MOB_1_2.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;  

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,SERVICE_REQUEST,TYPE,ACTION,RETRYLIMIT,TIMEDELAY,SERVER,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP,SERVICE_DESCRIPTION,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (3026,'updateport_URL','http://mobile-1-2-stub-service:8084/api/hotline/subscriber',null,null,null,'OUTBOUND',null,null,null,null,null, EMPTY_CLOB(),null,null,'3',3000,'NSL_UPG','SUCCESS',null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

commit;
spool off;
