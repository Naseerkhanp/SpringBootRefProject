package com.excelacom.servicegateway.bean;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Component
public class LineHistory {

	private Integer lineHistoryId;

	private String lId;

	private String eLineId;

	private String accountNumber;

	private String acctStatus;

	private String lineStatus;

	private String oldValue;

	private String newValue;

	private String fieldType;

	private String ordType;

	private String startDate;

	private String endDate;

	private Integer version;

	private String agentId;

	private String createdDate;

	private String createdBy;

	private String modifiedBy;

	private String modifiedDate;

	private String transactionId;

	private String mdn;
	
	@JsonProperty(value = "queryString")
	private List<String> queryString;

	public Integer getLineHistoryId() {
		return lineHistoryId;
	}

	public String getlId() {
		return lId;
	}

	public String geteLineId() {
		return eLineId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getAcctStatus() {
		return acctStatus;
	}

	public String getLineStatus() {
		return lineStatus;
	}

	public String getOldValue() {
		return oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public String getFieldType() {
		return fieldType;
	}

	public String getOrdType() {
		return ordType;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public Integer getVersion() {
		return version;
	}

	public String getAgentId() {
		return agentId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getMdn() {
		return mdn;
	}

	public String getTransactionType() {
		return transactionType;
	}

	private String transactionType;

	public void setLineHistoryId(Integer lineHistoryId) {
		this.lineHistoryId = lineHistoryId;
	}

	public void setlId(String lId) {
		this.lId = lId;
	}

	public void seteLineId(String eLineId) {
		this.eLineId = eLineId;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setAcctStatus(String acctStatus) {
		this.acctStatus = acctStatus;
	}

	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public void setOrdType(String ordType) {
		this.ordType = ordType;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setTransactionId(String transId) {
		this.transactionId = transId;
	}

	public void setMdn(String string) {
		this.mdn = string;
	}

	public String setTransactionType(String transactionType) {
		return this.transactionType = transactionType;
	}
}
