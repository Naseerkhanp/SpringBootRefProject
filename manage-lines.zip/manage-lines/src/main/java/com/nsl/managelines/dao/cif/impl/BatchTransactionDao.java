/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import com.nsl.managelines.dao.cif.entity.BatchTransaction;

/**
 * @author Dhayanand.B
 *
 */
public interface BatchTransactionDao {

	BatchTransaction saveBatchTransaction(BatchTransaction batchTransaction);

	int findCountByExternalValue1(String externalValue);

}
