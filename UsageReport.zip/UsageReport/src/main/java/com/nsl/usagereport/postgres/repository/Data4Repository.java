package com.nsl.usagereport.postgres.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.postgres.entity.Data4;


@Repository
public interface Data4Repository extends JpaRepository<Data4, Integer> {

}
