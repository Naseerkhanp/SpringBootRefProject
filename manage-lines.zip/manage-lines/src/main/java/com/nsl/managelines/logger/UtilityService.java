/**
 * 
 */
package com.nsl.managelines.logger;

import org.apache.logging.log4j.ThreadContext;
import org.json.JSONException;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.nsl.managelines.batch.bean.ErrorCodes;

import io.opentracing.Span;
import io.opentracing.util.GlobalTracer;
import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */
@Component
@Log4j2
public class UtilityService {

	public static void addTraceDetails(String transationId, String referenceNumber, String transactionType) {
		try {
			String traceId = "t-" + transationId + " : r-" + referenceNumber;
			ThreadContext.put("trackId", traceId);
			if (transationId != null || transactionType != null || referenceNumber != null) {
				final Span span = GlobalTracer.get().activeSpan();
				if (span != null && transationId != null) {
					span.setTag("transationId", transationId);
				}
				if (span != null && transactionType != null) {
					span.setTag("transationType", transactionType);
				}
				if (span != null && referenceNumber != null) {
					span.setTag("referenceNumber", referenceNumber);
				}
			}
		} catch (Exception e) {
			log.error("ErrorCode : "+ErrorCodes.CECC0015+" : Exception - {}", e);
		}
	}

	public static void updateTrace(String transationId, String referenceNumber, String transactionType) {
		try {
			if (transationId != null && referenceNumber != null) {
				String traceId = "t-" + transationId + " : r-" + referenceNumber;
				ThreadContext.put("trackId", traceId);
			}
			if (transationId != null || transactionType != null || referenceNumber != null) {
				final Span span = GlobalTracer.get().activeSpan();
				if (span != null && transationId != null) {
					span.setTag("transationId", transationId);
				}
				if (span != null && transactionType != null) {
					span.setTag("transationType", transactionType);
				}
				if (span != null && referenceNumber != null) {
					span.setTag("referenceNumber", referenceNumber);
				}
			}
		} catch (Exception e) {
			log.error("ErrorCode : "+ErrorCodes.CECC0015+" : Exception - {}", e);
		}
	}

	public static void removeTrace() {
		try {
			ThreadContext.remove("trackId");
		} catch (Exception e) {
			log.error("ErrorCode : "+ErrorCodes.CECC0015+" : Exception :", e);
		}
	}

	public LinkedTreeMap<?, ?> jsonToMap(String jsonString) throws JSONException {
		Gson gson = new Gson();
		LinkedTreeMap<?, ?> map = null;
		try {
			if (isJSONValid(jsonString)) {
				map = gson.fromJson(jsonString, LinkedTreeMap.class);
			}
		} catch (Exception e) {
			log.error("ErrorCode : "+ErrorCodes.CECC0016+" : Invalid JSON:" + e.getMessage());
		}
		return map;
	}

	public static boolean isJSONValid(String jsonInString) {
		try {
			Gson gson = new Gson();
			gson.fromJson(jsonInString, Object.class);
			return true;
		} catch (com.google.gson.JsonSyntaxException ex) {
			log.error("ErrorCode : "+ErrorCodes.CECC0007+" : Exception - "+ex);
			return false;
		}
	}
	
	public String getReferenceNumber(String jsonString) {
		String referenceNumber = null;
		try {
			LinkedTreeMap<?, ?> requestMap = jsonToMap(jsonString);
			if (requestMap != null && requestMap.containsKey("messageHeader")) {
				LinkedTreeMap<?, ?> messageHeader = (LinkedTreeMap<?, ?>) requestMap.get("messageHeader");
				if (messageHeader.containsKey("referenceNumber") && messageHeader.get("referenceNumber") != null) {
					log.debug("referenceNumber :" + messageHeader.get("referenceNumber"));
					referenceNumber = (String) messageHeader.get("referenceNumber");
				}
			}
		} catch (Exception e) {
			log.error("ErrorCode : "+ErrorCodes.CECC0016+" : Exception - {} ", e);
		}
		return referenceNumber;
	}
}
