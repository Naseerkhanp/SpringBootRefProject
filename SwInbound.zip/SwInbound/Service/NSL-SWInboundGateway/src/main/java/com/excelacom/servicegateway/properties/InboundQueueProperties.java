package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String rabbitListenerContainer;

	private String changenetworkQueue;

	private String changenetworkExchange;

	private String wifiQueue;

	private String wifiExchange;

	private String updateWifiQueue;

	private String updateWifiExchange;

	private String validateWifiQueue;

	private String validateWifiExchange;
	
	private String swWearableQueue;

	private String swWearableExchange;
	
    private String ChangeEsimQueue;
	
	private String ChangeEsimExchange;
	
	private String swRetrieveDeviceQueue;
	
	private String swRetrieveDeviceExchange;

	private String transferWearableQueue;
	
	private String transferWearableExchange;
	
	private String transferWearableAsyncQueue;
	
	private String transferWearableAsyncExchange;
	
	private String loginauthwsQueue;
	
	private String loginauthwsExchange;
	
	private String searchEnvironmentQueue;
	
	private String searchEnvironmentExchange;
	
	private String searchEnvironmentWaitQueue;
	
	private String searchEnvironmentWaitExchange;
	
	private String searchEnvWaitTopicExchange;
}
