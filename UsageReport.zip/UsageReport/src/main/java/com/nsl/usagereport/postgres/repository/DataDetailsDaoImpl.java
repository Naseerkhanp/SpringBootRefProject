package com.nsl.usagereport.postgres.repository;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.postgres.entity.DataDetails;
import com.nsl.usagereport.uio.DataDetailsUIO;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("DataDetailsDaoImpl")
public class DataDetailsDaoImpl implements NslDao {
	@Autowired
	DataDetailsRepository dataDetailsRepository;
	@Autowired
	private Environment env;

	@Override
	public void save(List<Object> dataDetailsList) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<DataDetails> dataDetails = dataDetailsList.stream().map(s -> (DataDetails) s)
					.collect(Collectors.toList());
			dataDetailsRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

	@Transactional
	public void deleteData(GetUsageReportDetails dataUsageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		Date startDate = null;
		Date endDate = null;
		try {
			if (dataUsageReportDetails.getStartDate() != null && dataUsageReportDetails.getEndDate() != null) {
				startDate = NslFileUploadUtils.convertStringToDate1(dataUsageReportDetails.getStartDate());
				endDate = NslFileUploadUtils.convertStringToDate1(dataUsageReportDetails.getEndDate());
			}
			dataDetailsRepository.deleteDataByDate(startDate, endDate);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " deleteData method end .");
	}

	@Transactional
	public List<DataDetailsUIO> getDataDetails(GetUsageReportDetails dataUsageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		List<DataDetails> dataDetailsLst = null;
		List<DataDetailsUIO> dataDetailsUIOLST = null;
		Date startDate = null;
		Date enddate = null;
		try {
			if (dataUsageReportDetails.getStartDate() != null && dataUsageReportDetails.getEndDate() != null) {
				startDate = NslFileUploadUtils.convertStringToDate1(dataUsageReportDetails.getStartDate());
				enddate = NslFileUploadUtils.convertStringToDate1(dataUsageReportDetails.getEndDate());
			}
			if (dataUsageReportDetails.getStartDate() == null && dataUsageReportDetails.getEndDate() == null
					&& dataUsageReportDetails.getImsi() == null) {
				dataDetailsLst = dataDetailsRepository
						.findDataByWithOutStartEnddateAndImsi(dataUsageReportDetails.getMdn().toString());
			} else if (dataUsageReportDetails.getImsi() == null) {
				dataDetailsLst = dataDetailsRepository
						.findDataByDateWithOutOptional(dataUsageReportDetails.getMdn().toString(), startDate, enddate);
			} else if (dataUsageReportDetails.getStartDate() == null && dataUsageReportDetails.getEndDate() == null) {
				dataDetailsLst = dataDetailsRepository.findDataByMdnAndImsi(dataUsageReportDetails.getMdn().toString(),
						dataUsageReportDetails.getImsi().toString());
			} else {
				dataDetailsLst = dataDetailsRepository.findDataByDate(dataUsageReportDetails.getMdn().toString(),
						startDate, enddate, dataUsageReportDetails.getImsi().toString());
			}
			/*
			 * dataDetailsLst = ((dataUsageReportDetails.getImsi() == null) ?
			 * dataDetailsRepository.findDataByDateWithOutOptional(
			 * String.valueOf(dataUsageReportDetails.getMdn()), startDate, enddate) :
			 * dataDetailsRepository.findDataByDate(String.valueOf(dataUsageReportDetails.
			 * getMdn()), startDate, enddate, dataUsageReportDetails.getImsi().toString()));
			 */
			dataDetailsUIOLST = dataDetailsLst.stream().map(dataDetails -> {
				String convertedendDate =null;
				DataDetailsUIO dataDetailsUIO = new DataDetailsUIO();
				String convertedDate = NslFileUploadUtils.convertLongToDate(dataDetails.getStartDateTime().getTime());
				dataDetailsUIO.setEventStart(convertedDate);
				log.info(dataDetails.getEndDateTime() + " dataDetails.getEndDateTime() .");
				if(dataDetails.getEndDateTime() !=null) {
					log.info(dataDetails.getEndDateTime().getTime() + " dataDetails.getEndDateTime().getTime().");
				convertedendDate = NslFileUploadUtils.convertLongToDate(dataDetails.getEndDateTime().getTime());
				}
				dataDetailsUIO.setEventStop(convertedendDate);
				dataDetailsUIO.setTimeZone(dataDetails.getGmtOffset());
				dataDetailsUIO.setTechType(dataDetails.getEventType());
				dataDetailsUIO.setDataUsed(dataDetails.getTotalKbUnits());
				dataDetailsUIO.setFootPrint(dataDetails.getFootprintCode());
				dataDetailsUIO.setCountry(dataDetails.getCountryCd());
				dataDetailsUIO.setRecordType(dataDetails.getRecordType());
				dataDetailsUIO.setdSource(dataDetails.getDsource());
				return dataDetailsUIO;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " getDataDetails method end .");
		return dataDetailsUIOLST;
	}

}
