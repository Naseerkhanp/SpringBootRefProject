package com.excelacom.servicegateway.bean;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component
public class Sim {

	private Integer simId;

	private String eLineId;

	private String simType;

	private String iccid;

	private String imsi;

	private String simStatus;

	private String matchingID;

	private String activationDate;

	private String deactivationDate;

	private String firstActivatedNetwork;

	private String startDate;

	private String endDate;

	private String createdDate;

	private String createdBy;

	private String modifiedBy;

	private String modifiedDate;

	private String lastUpdated;

	public void setSimId(Integer simId) {
		this.simId = simId;
	}

	public void seteLineId(String eLineId) {
		this.eLineId = eLineId;
	}

	public void setSimType(String simType) {
		this.simType = simType;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	public void setMatchingID(String matchingID) {
		this.matchingID = matchingID;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}

	public void setDeactivationDate(String deactivationDate) {
		this.deactivationDate = deactivationDate;
	}

	public void setFirstActivatedNetwork(String firstActivatedNetwork) {
		this.firstActivatedNetwork = firstActivatedNetwork;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Integer getSimId() {
		return simId;
	}

	public String geteLineId() {
		return eLineId;
	}

	public String getSimType() {
		return simType;
	}

	public String getIccid() {
		return iccid;
	}

	public String getImsi() {
		return imsi;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public String getMatchingID() {
		return matchingID;
	}

	public String getActivationDate() {
		return activationDate;
	}

	public String getDeactivationDate() {
		return deactivationDate;
	}

	public String getFirstActivatedNetwork() {
		return firstActivatedNetwork;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	@Override
	public String toString() {
		return "Sim [simId=" + simId + ", eLineId=" + eLineId + ", simType=" + simType + ", iccid=" + iccid + ", imsi="
				+ imsi + ", simStatus=" + simStatus + ", matchingID=" + matchingID + ", activationDate="
				+ activationDate + ", deactivationDate=" + deactivationDate + ", firstActivatedNetwork="
				+ firstActivatedNetwork + ", startDate=" + startDate + ", endDate=" + endDate + ", createdDate="
				+ createdDate + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + ", modifiedDate="
				+ modifiedDate + ", lastUpdated=" + lastUpdated + ", getSimId()=" + getSimId() + ", geteLineId()="
				+ geteLineId() + ", getSimType()=" + getSimType() + ", getIccid()=" + getIccid() + ", getImsi()="
				+ getImsi() + ", getSimStatus()=" + getSimStatus() + ", getMatchingID()=" + getMatchingID()
				+ ", getActivationDate()=" + getActivationDate() + ", getDeactivationDate()=" + getDeactivationDate()
				+ ", getFirstActivatedNetwork()=" + getFirstActivatedNetwork() + ", getStartDate()=" + getStartDate()
				+ ", getEndDate()=" + getEndDate() + ", getCreatedDate()=" + getCreatedDate() + ", getCreatedBy()="
				+ getCreatedBy() + ", getModifiedBy()=" + getModifiedBy() + ", getModifiedDate()=" + getModifiedDate()
				+ ", getLastUpdated()=" + getLastUpdated() + "]";
	}

}
