package com.nsl.usagereport.constants;

public interface NslFileUploadConstants {

	public static final String UTF8 = "UTF-8";
	public static final String ID_3 = "3";
	public static final String ID_4 = "4";
	public static final String ID_5 = "5";
	public static final String EMPTY = "";
	public static final String SUCCESS = "Success";
	public static final String SPACE = " ";
	public static final String SPECIAL = "<";
	public static final String DEFAULT_VLAUE = "-999";
	public static final String DOWNLOAD_STATUS_SUCCESS = "Y";
	public static final String DOWNLOAD_STATUS_INPROGRESS = "P";
	public static final String DOWNLOAD_STATUS_FAILED = "N";
	public static final String PARSED_STATUS_SUCCESS = "SUCCESS";
	public static final String PARSED_STATUS_INPROGRESS = "INPROGRESS";
	public static final String PARSED_STATUS_FAILED = "FAILED";
	public static final String NSL = "NSL";
	public static final String PRR = "nsl.sftp.path.prr";
	public static final String AAA = "nsl.sftp.path.aaa";
	public static final String SMB = "nsl.sftp.path.smb";
	public static final String BATCH_SIZE = "spring.jpa.properties.hibernate.jdbc.batch_size";
	public static final String PIPE = "/";
	public static final String NULL = "null";
	public static final String EXTENSION = ".gz";
	public static final String DOT = ".";
	public static final String HANDLER = "Handler";
	public static final String DAO_IMPL = "DaoImpl";
	public static final String CSV = "nsl.sftp.csvfile";
	public static final long DEFAULT_LONG = 1l;
	public static final long TWO_FIFTY_FIVE = 255;
	public static final long ROW_COUNT_CHECK = 50001;
	public static final long INTIALVALUE = 0;
	public static final int FAILURECODE = 0;
	public static final String TOTALRECORDSPRCESSD = "TOTAL_RECORDS_PROCESSED";
	public static final String TOTALRECORDSFAILED = "Duplicate records";
	public static final String DUPLICATE_ERROR_CODE = "ERR05";
	public static final int MACCOLUMN = 3;
	public static final int RESOURCECOLUMN = 2;
	public static final int THREAD_SIZE = 1;
	public static final String IOSL14_CHK = "IOSL14_CHK";
	public static final String GET_IOS_DEVICE = "GET_IOS_DEVICE";
	public static final String IOS = "IOS";
	public static final String IOS_VERSION_UPLOAD_REPORT= "IOS_VERSION_UPLOAD_REPORT";
	
	public static final String DELTA ="~";
	
	public static final String EMPTYDATA ="[]";
	
	/** The Constant EMPTYSTRING. */
	public static final String EMPTYSTRING = "";

	/** The Constant ENDPOINTURL. */
	public static final String ENDPOINTURL = "EndpointURL";

	/** The Constant SOAPACTION. */
	public static final String SOAPACTION = "soapAction=";

	/** The Constant JSON. */
	public static final String JSON = "json=";

	/** The Constant DESTNAME. */
	public static final String DESTNAME = "destName=";

	/** The Constant ENTITYID. */
	public static final String ENTITYID = "entityId=";

	/** The Constant DESTINATION. */
	public static final String DESTINATION = "destination=";

	/** The Constant ENDPOINTURLEQ. */
	public static final String ENDPOINTURLEQ = "EndpointURL=";

	/** The Constant ENDPOINTOPERATION. */
	public static final String ENDPOINTOPERATION = "EndpointOperation=";

	/** The Constant REQUESTJSON. */
	public static final String REQUESTJSON ="requestJson=";
	
	/** The Constant RESPONSEID. */
	public static final String RESPONSEID = "responseId=";
	
	/** The Constant EQUALTO. */
	public static final String EQUALTO = "=";
	
	/** The Constant AMP. */
	public static final String AMP = "&";
	
	
	/** The Constant USERNAME. */
	public static final String USERNAME ="UserName";
	
	/** The Constant ENDPOINTSERVICETYPE. */
	public static final String ENDPOINTSERVICETYPE="endpointServiceType";
	
    /** The Constant STATUS. */
    public static final String STATUS ="status";
    
    /** The Constant FILE_FORMAT. */
    public static final String FILE_FORMAT ="PRR_[0-9]+_[0-9]+_[0-9]+_[0-9]+_V+[0-9]+.dat.gz";
    
    /** The Constant CBRS_ACC. */
    public static final String CBRS_ACC ="3292";
    
    /** The Constant CBRS. */
    public static final String CBRS ="CBRS";
    
    /** The Constant PRR. */
    public static final String PRR_FILE ="PRR";
    
    public static final String UPDATE_SUCCESS_TRANSACTION ="update transaction_details set RESPONSE_MSG = :RESPONSE_MSG where transaction_uid = :TRANSACTION_ID";
    
    public static final String TRANSACTION_ID ="TRANSACTION_ID";
    
    public static final String FILETYPE_AAA = "AAA";
    
	
}
