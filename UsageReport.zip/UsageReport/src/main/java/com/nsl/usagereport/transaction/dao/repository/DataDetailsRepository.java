package com.nsl.usagereport.transaction.dao.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.DataDetails;

@Repository("datadao")
public interface DataDetailsRepository extends JpaRepository<DataDetails, Integer> {

	@Query("select d from Data_Details d where d.minNum = :minNum and d.startDateTime BETWEEN :startDate AND :endDate AND  d.imsi = :imsi")
	List<DataDetails> findDataByDate(@Param("minNum") String minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") String imsi);

	@Query("select d from Data_Details d where d.minNum = :minNum and d.startDateTime BETWEEN :startDate AND :endDate")
	List<DataDetails> findDataByDateWithOutOptional(@Param("minNum") String minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);
	
	@Query("select d from Data_Details d where d.minNum = :minNum")
	List<DataDetails> findDataByWithOutStartEnddateAndImsi(@Param("minNum") String minNum);

	@Query("select d from Data_Details d where d.minNum = :minNum AND  d.imsi = :imsi")
	List<DataDetails> findDataByMdnAndImsi(@Param("minNum") String minNum, @Param("imsi") String imsi);

}
