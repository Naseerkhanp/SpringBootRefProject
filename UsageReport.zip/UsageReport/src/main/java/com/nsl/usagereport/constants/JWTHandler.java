package com.nsl.usagereport.constants;

import java.util.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.cif.dao.repository.TransactionDaoImpl;





@Component
public class JWTHandler {

	@Autowired
	TransactionDaoImpl transactionDAO;

	private static final Logger LOGGER = LogManager.getLogger(JWTHandler.class);

	public boolean validateToken(String token) {
		String subject = "HACKER";
		boolean tokenRresp = false;
		try {

			String tokenCheckStatus = transactionDAO.tokenCheck(token);
			if (tokenCheckStatus.contains("success")) {
				String[] parts = token.split("\\.");
				LOGGER.info("parts::1 " + parts[1] + " " + parts[2] + " " + parts[0]);
				JSONObject payload = new JSONObject(decode(parts[1]));
				LOGGER.debug("payload" + payload.getLong("exp"));
				LOGGER.debug("p time" + System.currentTimeMillis());
				if (payload.getString("sub") != null) {
					LOGGER.debug("Matches:::" + payload.getString("sub"));
				}
				if (payload.getLong("exp") > (System.currentTimeMillis() / 1000)) {
					LOGGER.debug("Not Expired");
					tokenRresp = true;
				} else {
					LOGGER.debug("Expired");
				}
			} else {
				LOGGER.debug("Token is not there in database");
			}
			return tokenRresp;
		} catch (Exception e) {
			LOGGER.error("Exception in validateToken " , e);
		}
		return tokenRresp;
	}

	private String decode(String encodedString) {
		return new String(Base64.getUrlDecoder().decode(encodedString));
	}
}
