package com.excelacom.servicegateway.constants;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import javax.ws.rs.core.MediaType;
import java.util.Base64;
import org.json.JSONObject;

@Component
public class UtilityClass {

	Logger LOGGER = LoggerFactory.getLogger(UtilityClass.class);

	public String invalidToken(String token) {
		String msg = Constants.INVALID_TOKEN_1 + token + Constants.INVALID_TOKEN_2;
		return msg;
	}

	public String unavailableToken() {
		String msg = Constants.INVALID_TOKEN_1 + Constants.TOKEN_UNAVAILABLE + Constants.INVALID_TOKEN_2;
		return msg;
	}

	public boolean isEmpty(String str){
		boolean valRet=true;
		if(str!=null && str.trim().length()>0){
			valRet= false;
		}
		return valRet;
	}
	
	public String movedPermanentlyMessage(String msg) {
		String returnMsg = Constants.MOVED_PERMANENTLY_1 + msg + Constants.MOVED_PERMANENTLY_2;
		return returnMsg;
	}
	
	/**
	 * This method is used for invoking the rest api
	 * @param request
	 * @param url
	 * @return String response
	 */
	public String callRestAPI(String request,String url){
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		try {
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		LOGGER.info("callRestAPI :: outputString :: "+outputString);
		return outputString;
	}
	
	
	public String splitterRequestValidation(String request, String screenName,String url) {
		HttpURLConnection conn = null;
		String outputString = Constants.EMPTYSTRING;
		try {
			LOGGER.info("url ::: " + url );
			 if(request.contains("&")) {
				 request=request.replaceAll("&", "u+00000026");	
					}
			request = "json=" + request + "&screenName=" + screenName;
			LOGGER.info("request in splitterRequestValidation:::" + request);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			LOGGER.info("outputString in splitterRequestValidation:::" + outputString);
			isr.close();
			os.close();

		} catch (Exception e) {
			LOGGER.error("Exception in getResponseFromClient method::" + e.getMessage());
			//e.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return outputString;
	}
	
	public String batchProcessingResponseFromClient(String requestJson, String ServerURL, String OauthUrl, String ServiceURL) {
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection serviceConn = null;
		String request = "grant_type=client_credentials";
		String tokenCode = "";
		String finResponse = "";
		String soapAction = Constants.EMPTYSTRING;
		URL url;
		try {
			if (requestJson.contains("&")) {
				requestJson = requestJson.replaceAll("&", "u+00000026");
			}
			
			url = new URL(OauthUrl + "?" + request);
			System.out.println("OAUTH CONNECTION"+url);
			String username = "manage-subcriber-user";
			System.out.println("grant_type:::" + request);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			String encoded = Base64.getEncoder().encodeToString((username + ":" + "welcome123").getBytes("UTF-8"));
			conn.setRequestProperty("Authorization", "Basic " + encoded);
			conn.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
			conn.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
			conn.setRequestProperty("SOAPAction", soapAction);
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(60000);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				finResponse = finResponse + responseString;
			}
			if (!"".equalsIgnoreCase(finResponse)) {
				JSONObject obj = new JSONObject(finResponse);
				tokenCode = obj.getString("access_token");
				System.out.println("tokenCode:::" + tokenCode);
			}
			if (!"".equalsIgnoreCase(tokenCode)) {

				url = new URL(ServerURL+ServiceURL);
                 LOGGER.info("url:::" +url);
				serviceConn = (HttpURLConnection) url.openConnection();
				serviceConn.setRequestProperty("Content-Length", String.valueOf(requestJson.getBytes().length));
				serviceConn.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
				serviceConn.setRequestProperty("SOAPAction", soapAction);
				serviceConn.setRequestProperty("Authorization", tokenCode);
				serviceConn.setRequestMethod("POST");
				serviceConn.setConnectTimeout(60000);
				serviceConn.setDoOutput(true);
				serviceConn.setDoInput(true);
				OutputStream out = serviceConn.getOutputStream();
				out.write(requestJson.getBytes());
				out.close();
				BufferedReader reader = null;
				if (serviceConn.getResponseCode() == 200) {
					reader = new BufferedReader(new InputStreamReader(serviceConn.getInputStream()));
					LOGGER.info("Response code:::" + serviceConn.getResponseCode());
				} else {
					LOGGER.info("Response code:::" + serviceConn.getResponseCode());
					reader = new BufferedReader(new InputStreamReader(serviceConn.getErrorStream()));
				}
				String responseString1 = null;
				while ((responseString1 = reader.readLine()) != null)
					outputString = outputString + responseString1;
				LOGGER.info("Response outputString::" + outputString);
			}
		}

		catch (Exception e) {
			LOGGER.error("Exception in getResponseFromClient method::" + e.getMessage());
		} finally {
			if (serviceConn != null) {
				serviceConn.disconnect();
			}
		}
		return outputString;

	}
	
	public String batchSchedulerResponseFromClient(String request,String ServerURL) {
		HttpURLConnection conn = null;
		String outputString = Constants.EMPTYSTRING;
		String batchSchedulerurl=ServerURL;
		try {
			LOGGER.info("url ::: " + batchSchedulerurl );
			LOGGER.info("request in batchSchedulerResponseFromClient:::" + request);
			URL serviceUrl = new URL(batchSchedulerurl);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			conn.setRequestProperty("Content-Length", String.valueOf(request.getBytes().length));
			conn.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
			conn.setRequestProperty("SOAPAction", "");
			//conn.setRequestProperty("charset", "utf-8");
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStream os = conn.getOutputStream();
			os.write(request.getBytes());
			os.close();
			BufferedReader reader = null;
				reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String responseString1 = null;
			while ((responseString1 = reader.readLine()) != null)
				outputString = outputString + responseString1;
			LOGGER.info("Response outputString::" + outputString);
		} catch (Exception e) {
			LOGGER.error("Exception in batchSchedulerResponseFromClient method::" + e.getMessage());
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return outputString;
	}
	
	public void callSchedulerRestAPI(String request, String url) {
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		try {
			URL schedulerurl = new URL(url);
			LOGGER.info("inside try :: " + request + " schedulerurl :: " + schedulerurl);
			conn = (HttpURLConnection) schedulerurl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
		}
		catch (Exception e) {
			//CenturyLogger.error("Exception in getSchedulerCall method::" + e.getMessage());
			LOGGER.error("Exception in getSchedulerCall method::" + e.getMessage(), e);
		}
		finally
		{
			if(conn!=null) {
				conn.disconnect();
			}
		}
		
	}
}
