/**
 * 
 */
package com.excelacom.servicegateway.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Dhayanand.B
 *
 */
@Service
public class RabbitQueueServiceImpl implements RabbitQueueService {

	@Autowired
	private RabbitAdmin serchEnvWaitRabbitAdmin;

	@Autowired
	private TopicExchange searchEnvironmentWaitTopicExchange;

	Logger LOGGER = LoggerFactory.getLogger(RabbitQueueServiceImpl.class);

	@Override
	public Boolean addNewQueue(String queueName, String routingKey) {
		LOGGER.info("Creating Queue : " + queueName);
		Boolean queueCreated = Boolean.FALSE;
		try {
			Queue queue = new Queue(queueName, false, false, true);
			Binding binding = BindingBuilder.bind(queue).to(searchEnvironmentWaitTopicExchange).with(routingKey);
			serchEnvWaitRabbitAdmin.declareQueue(queue);
			serchEnvWaitRabbitAdmin.declareBinding(binding);
			queueCreated = Boolean.TRUE;
		} catch (Exception e) {
			LOGGER.error("Error Creating Queue :" + queueName + ":", e);
		}
		return queueCreated;
	}

}