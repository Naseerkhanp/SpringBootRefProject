package com.nsl.managelines.batch.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class OutboundRequest  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public OutboundData data;

	@Setter
	@Getter
	@ToString
	public class LnpName {
		public String business;
	}

	@Setter
	@Getter
	@ToString
	public class NextAvailableMDN {
		public String zipCode;
	}

	@Setter
	@Getter
	@ToString
	public class Address {
		public String addressLine1;
		public String addressLine2;
		public String city;
		public String state;
		public String zip;
	}

	@Setter
	@Getter
	@ToString
	public class Lnp {
		public String authorizedSigner;
		public String authorizationStatus;
		public String directionalIndicator;
		public String phoneUserName;
		public String ospAccountNo;
		public String hotCut;
		public String pin;
		public String remark;
		public LnpName lnpName;
		public Address address;
	}

	@Setter
	@Getter
	@ToString
	public class Feature {
		public String featureCode;
		public String subscribe;
	}

	@Setter
	@Getter
	@ToString
	public class SubscriberGroup {
		public String subscriberGroupCd;
		public String subscriberGroupTypeCd;
	}


}
