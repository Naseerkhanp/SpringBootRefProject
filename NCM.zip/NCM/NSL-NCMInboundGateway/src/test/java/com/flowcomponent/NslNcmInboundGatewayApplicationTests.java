package com.flowcomponent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NslNcmInboundGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
