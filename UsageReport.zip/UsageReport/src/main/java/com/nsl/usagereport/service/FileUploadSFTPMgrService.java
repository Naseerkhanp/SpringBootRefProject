package com.nsl.usagereport.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.cif.entity.TransactionFileLog;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.nbos.dao.repository.WibInfoDaoImpl;
import com.nsl.usagereport.nbos.entity.WibInfo;
import com.nsl.usagereport.postgres.repository.NslDao;
import com.nsl.usagereport.transaction.dao.repository.RefFileUploadDaoImpl;
import com.nsl.usagereport.transaction.dao.repository.ResourceInfoDaoImpl;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.transaction.entity.ResourceInfo;
import com.nsl.usagereport.util.NslBeanManagerUtil;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public abstract class FileUploadSFTPMgrService implements NslFileuploadService {
	@Autowired
	NslDataHandler nslDataHandler;
	@Autowired
	private RefFileUploadDaoImpl refFileUploadDaoImpl;
	@Autowired
	private NslBeanManagerUtil nslBeanManagerUtil;
	@Autowired
	private Environment env;
	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;

	@Autowired
	private WibInfoDaoImpl wibInfoDaoImpl;
	
	@Autowired
	private ResourceInfoDaoImpl resourceInfoDaoImpl;

	private Map<Long, RefFileUpload> refFileUploadMap = null;

	private Map<String, Map<Object, Long>> statusMap = null;

	public Map<Long, RefFileUpload> getRefFileUploadMap() {
		return refFileUploadMap;
	}

	public void setRefFileUploadMap(Map<Long, RefFileUpload> refFileUploadMap) {
		this.refFileUploadMap = refFileUploadMap;
	}

	@Retryable(value = { FileSystemException.class }, maxAttempts = 3)
	public void downloadFromSFTP(UsageReportDetails usageReportDetails) throws Exception, FileSystemException {
		log.info(this.getClass() + " Connecting to SFTP.... ");
		String getfilesurl = null;
		StandardFileSystemManager manager = new StandardFileSystemManager();

		try {

			try {
				manager.init();
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze VFS ::", e);
				throw new FileSystemException(" Internal Error: Unable to iniatilze VFS ::", e.getCause());
			}
			FileSystemOptions opts = new FileSystemOptions();

			try {
				SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze StrictHostKeyChecking ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException(" Internal Error: Unable to iniatilze StrictHostKeyChecking ::",
						e.getCause());
			}
			SftpFileSystemConfigBuilder.getInstance().setConnectTimeoutMillis(opts, 100000);
			String host = usageReportDetails.getHost();
			String user = usageReportDetails.getUserName();
			String password = usageReportDetails.getPassword();
			String port = usageReportDetails.getPort();
			String url = usageReportDetails.getSftpFolderPath();

			StaticUserAuthenticator auth = new StaticUserAuthenticator(host, user, password);
			usageReportDetails.setSftpFolderPath(usageReportDetails.getSftpFolderPath()
					.replace(NslFileUploadConstants.PIPE, NslFileUploadConstants.EMPTY));
			try {
				DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(opts, auth);
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException("  Internal Error: Invalid SFTP Details ::", e.getCause());
			}
			// TODO need to Remove
			String sftpurl = "sftp://" + user + ":" + password + "@" + host + "/" + url + "/"
					+ usageReportDetails.getReportsFileName();

			try {
				getfilesurl = "sftp://" + host + ":" + port + "/" + url + "/";
				manageUsageReportDetails(manager, getfilesurl, opts, usageReportDetails);

			} catch (Exception e) {
				log.error(this.getClass() + " Error RemotefileDeatils ::", e);
				throw new FileSystemException("  Internal Error: Error RemotefileDeatils ::", e.getCause());
			}

		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::", e);
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}

	}

	/*
	 * below method used for download data from the file from sftp
	 */
	public void manageUsageReportDetails(StandardFileSystemManager manager, String getfilesurl, FileSystemOptions opts,
			UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " manageUsageReportDetails method called .");
		FileObject remoteFile = null;
		Boolean isSuccess = Boolean.FALSE;
		FileObject folderPath = null;
		byte[] filePutputCon = null;
		FileObject[] fileObjectArray = null;
		String fileName = NslFileUploadConstants.EMPTY;
		TransactionFileLog transactionFileLog = null;
		try {
			folderPath = manager.resolveFile(getfilesurl, opts);
			fileObjectArray = folderPath.getChildren();
			for (FileObject fileObj : fileObjectArray) {
				fileName = fileObj.getName().getBaseName();
				log.info("File Name ::" + fileName);
				String extension = fileName.substring(fileName.lastIndexOf(NslFileUploadConstants.DOT));
				if (NslFileUploadConstants.EXTENSION.equalsIgnoreCase(extension)) {
					transactionFileLog = transactionFileLogDaoImpl.findByFileName(fileName);
					log.info(fileName + " file not found in DB.....Stareded ahead on Download part....");

					if (transactionFileLog != null) {
						if (transactionFileLog.getStatus()
								.equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_FAILED)) {
							remoteFile = manager.resolveFile(getfilesurl + fileObj.getName().getBaseName(), opts);
							if (remoteFile == null) {
								transactionFileLogDaoImpl.updateTransactionDetails(
										NslFileUploadConstants.PARSED_STATUS_FAILED, NslFileUploadConstants.FAILURECODE,
										NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE,
										fileName, statusMap, "FileNotFoundException",usageReportDetails,null);
								throw new FileNotFoundException();
							}
							filePutputCon = remoteFile.getContent().getByteArray();
							log.info(this.getClass() + " file downloaded from sftp server .");
							saveTransactionDetails(usageReportDetails, fileName, extension,
									NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
							isSuccess = extractDataFrmFile(filePutputCon, usageReportDetails, fileName, extension);
							if (!isSuccess)
								throw new Exception("Data not Extracted from file");
						}
					} else if (transactionFileLog == null) {
						remoteFile = manager.resolveFile(getfilesurl + fileObj.getName().getBaseName(), opts);
						if (remoteFile == null) {
							transactionFileLogDaoImpl.updateTransactionDetails(
									NslFileUploadConstants.PARSED_STATUS_FAILED, NslFileUploadConstants.FAILURECODE,
									NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE, fileName,
									statusMap, "FileNotFoundException",usageReportDetails,null);
							throw new FileNotFoundException();
						}
						filePutputCon = remoteFile.getContent().getByteArray();
						log.info(this.getClass() + " file downloaded from sftp server .");
						saveTransactionDetails(usageReportDetails, fileName, extension,
								NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
						isSuccess = extractDataFrmFile(filePutputCon, usageReportDetails, fileName, extension);
						if (!isSuccess)
							throw new Exception("Data not Extracted from file");
					}
				} else {
					transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
							NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE,
							NslFileUploadConstants.FAILURECODE, fileName, statusMap, "ERR05 – Fileformat is invalid",usageReportDetails,null);
					log.error(this.getClass() + " Unsupported file Format::");
				}
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::" + e);
			if (manager != null) {
				manager.close();
			}
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}
	}

	/*
	 * below method used for extracting data from the file and store the processed
	 * and failure records in DB
	 */
	public Boolean extractDataFrmFile(byte[] fileData, UsageReportDetails usageReportDetails, String fileName,
			String extension) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		Boolean isSuccess = Boolean.TRUE;
		BufferedReader in = null;
		// this map is built to store processed records in DB
		Map<Long, List<Object>> detailsBuiler = new HashMap<Long, List<Object>>();
		// this map is built to store failure records info in DB
		Map<String, Map<Object, Long>> recordsStatus = new HashMap<String, Map<Object, Long>>();
		intializeDefaultValues(recordsStatus);
		try {
			// extracting gzip file use this
			in = new BufferedReader(new InputStreamReader(new GZIPInputStream(new ByteArrayInputStream(fileData))));
			// in = new BufferedReader(new InputStreamReader(new
			// ByteArrayInputStream(fileData)));
			detailsBuiler = buildExtractedDataFrmFile(in, usageReportDetails, detailsBuiler, fileName, refFileUploadMap,
					extension, recordsStatus);
			refFileUploadMap = getRefFileUploadMap();
			saveFileDataToDB(detailsBuiler, usageReportDetails, fileName, refFileUploadMap, extension, recordsStatus);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception(e.getMessage());
		} finally {
			try {
				if(in!=null)
				in.close();
			} catch (IOException e) {
				log.error(this.getClass() + " Exception thrown ::", e);
			}

		}
		log.info(this.getClass() + " extractDataFrmFile method end called .");
		return isSuccess;
	}

	public boolean saveFileDataToDB(Map<Long, List<Object>> detailsBuiler, UsageReportDetails usageReportDetails,
			String fileName, Map<Long, RefFileUpload> refFileUploadMap, String extension,
			Map<String, Map<Object, Long>> recordsStatus) throws Exception {
		log.info(this.getClass() + " saveFileDataToDB method called .");
		ExecutorService executor = null;
		Boolean isSuccess = Boolean.TRUE;
		try {
			if (detailsBuiler.size() >= NslFileUploadConstants.DEFAULT_LONG) {
				executor = Executors.newFixedThreadPool(detailsBuiler.size());
			}
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				RefFileUpload refFileUpload = refFileUploadDaoImpl
						.getRefFileUploadDetail(usageReportDetails.getSftpFolderPath());
				for (Entry<Long, List<Object>> data : detailsBuiler.entrySet()) {
					uploadData(executor, nslBeanManagerUtil.getDaoImpl(refFileUpload.getDescription()), data, fileName,usageReportDetails);
				}
				transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
						(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
								+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, recordsStatus,
						NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);

				return isSuccess;
			}

			for (Entry<Long, List<Object>> dataDetails : detailsBuiler.entrySet()) {
				String id = dataDetails.getKey() + "";
				uploadData(executor,
						nslBeanManagerUtil.getDaoImpl(refFileUploadMap.get(dataDetails.getKey()).getDescription()),
						dataDetails, fileName,usageReportDetails);
				Thread.sleep(500);
				System.out.println("completed inserting for id:-" + id);
			}
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
					(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
							+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, recordsStatus,
					NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);
		} catch (Exception e) {
			isSuccess = Boolean.FALSE;
			log.error(this.getClass() + " Internal Error: Unable to extract data from file ::", e);
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
					(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
							+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, recordsStatus,
					e.getMessage(),usageReportDetails,null);
			throw new Exception("  Internal Error: Unable to extract data from file ::", e.getCause());
		} finally {
			if (detailsBuiler.size() > NslFileUploadConstants.DEFAULT_LONG) {
				executor.shutdown();
			}
		}
		log.info(this.getClass() + " extractDataFrmFile method called .");
		return isSuccess;
	}

	public void uploadData(ExecutorService executor, NslDao nslDao, Entry<Long, List<Object>> data, String fileName,UsageReportDetails usageReportDetails)
			throws Exception {
		executor.submit(() -> {
			try {
				nslDao.save(data.getValue());
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Unable to save data into DB ", e);
				try {
					transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
							NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE,
							NslFileUploadConstants.FAILURECODE, fileName, statusMap, e.getMessage(),usageReportDetails,null);
				} catch (Exception e1) {
					log.error(this.getClass() + " Internal Error: Unable to update data into DB ::", e);
				}
			}
		});
	}

	public Boolean processDataFrmFile(byte[] fileData, UsageReportDetails usageReportDetails, String fileName,
			String extension) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		Boolean isSuccess = Boolean.TRUE;
		BufferedReader in = null;
		// this map is built to store processed records in DB
		Map<Long, List<Object>> detailsBuiler = new HashMap<Long, List<Object>>();
		// this map is built to store failure records info in DB
		Map<String, Map<Object, Long>> recordsStatus = new HashMap<String, Map<Object, Long>>();
		intializeDefaultValues(recordsStatus);
		List<String> rowsLst = null;
		List<RefFileUpload> refFileUploadColumnsLST = null;
		List<RefFileUpload> fileUploadLst = null;
		RefFileUpload refFileUpload = null;
		Set<String> existingRouterIds = null;
		ExecutorService executor = Executors.newFixedThreadPool(NslFileUploadConstants.THREAD_SIZE);
		try {
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				in = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(fileData)));
			} else {
				// extracting gzip file use this
				in = new BufferedReader(new InputStreamReader(new GZIPInputStream(new ByteArrayInputStream(fileData))));
			}
			rowsLst = extractedDataFrmFile(in);
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))
					&& rowsLst.size() < 2) {
				log.error(this.getClass() + " file does not contain data  ::");
				throw new Exception("ERR03 – Data is empty");
			}
			fileUploadLst = refFileUploadDaoImpl.getRefFileUploadDetails(usageReportDetails.getFileType());
			refFileUploadMap = fileUploadLst.stream().collect(Collectors.toMap(RefFileUpload::getFilterValue,
					Function.identity(), (getFilterValue, getFilterValue1) -> getFilterValue1));
			log.info(this.getClass() + " converted reffileUpload to map based on key");
			setRefFileUploadMap(refFileUploadMap);
			refFileUpload = refFileUploadDaoImpl.getRefFileUploadDetail(usageReportDetails.getFileType());
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				refFileUploadColumnsLST = fileUploadLst.stream()
						.sorted(Comparator.comparing(RefFileUpload::getColumnIndex)).collect(Collectors.toList());
				log.info(this.getClass() + " sorted reffileUploadLST  based on filter column index");
				nslDataHandler.smbChecks(nslDataHandler.divideColumns(usageReportDetails, rowsLst.get(0)),
						refFileUploadColumnsLST);
			}

			executor.submit(new FileUploadExecutorMgr(usageReportDetails, detailsBuiler, refFileUploadMap,
					refFileUploadColumnsLST, refFileUpload, recordsStatus, existingRouterIds, fileUploadLst,
					nslDataHandler, refFileUploadDaoImpl, wibInfoDaoImpl, rowsLst, env, transactionFileLogDaoImpl,
					fileName, extension, nslBeanManagerUtil,resourceInfoDaoImpl));
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			buildTransFailuerLogErrorData(recordsStatus, e.getMessage(),usageReportDetails);
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED, 0, 0, 1,
					fileName, recordsStatus, e.getMessage(),usageReportDetails,null);
			throw new Exception(e.getMessage());
		} finally {
			try {
				if(in!=null)
				in.close();
				executor.shutdown();
			} catch (IOException e) {
				log.error(this.getClass() + " Exception thrown ::", e);
			}

		}
		log.info(this.getClass() + " extractDataFrmFile method end called .");
		return isSuccess;
	}

	private void buildTransFailuerLogErrorData(Map<String, Map<Object, Long>> recordsStatus, String error, UsageReportDetails usageReportDetails) {
		if(usageReportDetails.getFileType().equalsIgnoreCase("NBOP")) {
			ResourceInfo resourceInfo = new ResourceInfo();
			resourceInfo.setErrorCode("ERR05");
			resourceInfo.setErrorMsg(error);
			Map<Object, Long> entry = new HashMap<Object, Long>();
			entry.put(resourceInfo, (long) 2);
			recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, entry);
		}else {
		WibInfo wibInfo = new WibInfo();
		wibInfo.setErrorCode("ERR05");
		wibInfo.setErrorMsg(error);
		Map<Object, Long> entry = new HashMap<Object, Long>();
		entry.put(wibInfo, (long) 1);
		recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, entry);
		}
	}

	public List<String> extractedDataFrmFile(BufferedReader in) throws Exception {
		String content = NslFileUploadConstants.EMPTY;
		long lineNumber = 0;
		List<String> rowsLST = new ArrayList<String>();
		try {
			while ((content = in.readLine()) != null) {
				if (lineNumber > NslFileUploadConstants.ROW_COUNT_CHECK) {
					throw new Exception("ERR05 – File has more than max count");
				}
				if (!content.trim().isEmpty()) {
					rowsLST.add(content);
				}
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception(e.getMessage());
		}
		log.info(this.getClass() + " buildExtractedDataFrmFile method called .");
		return rowsLST;
	}

	public Map<Long, List<Object>> buildExtractedDataFrmFile(BufferedReader in, UsageReportDetails usageReportDetails,
			Map<Long, List<Object>> detailsBuiler, String fileName, Map<Long, RefFileUpload> refFileUploadMap,
			String extension, Map<String, Map<Object, Long>> recordsStatus) throws Exception {
		log.info(this.getClass() + " buildExtractedDataFrmFile method called .");
		String content = NslFileUploadConstants.EMPTY;
		long lineNumber = 0;
		List<RefFileUpload> refFileUploadColumnsLST = null;
		List<RefFileUpload> fileUploadLst = null;
		RefFileUpload refFileUpload = null;
		Set<String> existingRouterIds = null;
		try {
			fileUploadLst = refFileUploadDaoImpl.getRefFileUploadDetails(usageReportDetails.getSftpFolderPath());
			refFileUploadMap = fileUploadLst.stream().collect(Collectors.toMap(RefFileUpload::getFilterValue,
					Function.identity(), (getFilterValue, getFilterValue1) -> getFilterValue1));
			log.info(this.getClass() + " converted reffileUpload to map based on key");
			setRefFileUploadMap(refFileUploadMap);
			refFileUpload = refFileUploadDaoImpl.getRefFileUploadDetail(usageReportDetails.getSftpFolderPath());
			Long longValue = new Long(refFileUpload.getFilterColumnIndex());
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				refFileUploadColumnsLST = fileUploadLst.stream()
						.sorted(Comparator.comparing(RefFileUpload::getColumnIndex)).collect(Collectors.toList());
				log.info(this.getClass() + " sorted reffileUploadLST  based on filter column index");
				existingRouterIds = wibInfoDaoImpl.getRouterIds();
				log.info(this.getClass() + " existingRouterIds::" + existingRouterIds);
			}
			while ((content = in.readLine()) != null) {
				lineNumber++;
				if (!content.trim().isEmpty()) {
					nslDataHandler.buildData(usageReportDetails, detailsBuiler, content, longValue, refFileUploadMap,
							refFileUploadColumnsLST, lineNumber, refFileUpload, recordsStatus, existingRouterIds,
							fileUploadLst);
				}
			}
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))
					&& lineNumber < 2) {
				log.error(this.getClass() + " file does not contain data  ::");
				throw new Exception("ERR03 – Data is empty");
			}
			System.out.println(lineNumber);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
					(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
							+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, null,
					e.getMessage(),usageReportDetails,null);
			throw new Exception(e.getMessage());
		}
		log.info(this.getClass() + " buildExtractedDataFrmFile method called .");
		return detailsBuiler;
	}

	public void saveTransactionDetails(UsageReportDetails usageReportDetails, String fileName, String extension,
			String status) {
		transactionFileLogDaoImpl.saveTransactionDetails(usageReportDetails, fileName, extension, status);
	}

	public Map<String, Map<Object, Long>> intializeDefaultValues(Map<String, Map<Object, Long>> recordsStatus) {
		recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, new HashMap<Object, Long>());
		recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, new HashMap<Object, Long>());
		return recordsStatus;
	}
}
