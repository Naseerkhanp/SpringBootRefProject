package com.excelacom.servicegateway.bean;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Component
public class LinePlan {

	private String linePlanId;

	private String eLineId;

	private Integer lId;

	private String whsPlan;

	private String retailPlan;

	private String startDate;

	private String endDate;

	private Integer dataLimit;

	private String isGfPlan;

	private String createdDate;

	private String modifiedDate;

	private String createdBy;

	private String modifiedBy;

	public void setLinePlanId(String linePlanId) {
		this.linePlanId = linePlanId;
	}

	public void seteLineId(String eLineId) {
		this.eLineId = eLineId;
	}

	public void setlId(Integer lId) {
		this.lId = lId;
	}

	public void setWhsPlan(String whsPlan) {
		this.whsPlan = whsPlan;
	}

	public void setRetailPlan(String retailPlan) {
		this.retailPlan = retailPlan;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setDataLimit(Integer dataLimit) {
		this.dataLimit = dataLimit;
	}

	public void setIsGfPlan(String isGfPlan) {
		this.isGfPlan = isGfPlan;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
