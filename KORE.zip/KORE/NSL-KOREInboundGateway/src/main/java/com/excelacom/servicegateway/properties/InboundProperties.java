package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String authserver;

	private String routerserviceurl;

	private String authchecktoken;

	private String credentials;

	private String hmnoendpoint;

	private String smbendpoint;

	private String cbrspcrfendpoint;

	private String mobile1endpoint;

	private String mobile2endpoint;

	private String disconnectDevice;
	
	private String getquerydeviceurl;
	
	private String getquerydevicedetailsexturl;
	
	private String ModifyDeviceFeaturesurl;
	
	private String RestoreDevicesurl;
	
	private String SimChangeDeviceurl;

	private String applicationName;

	private String accounturl;

	private String groupurl;

	private String targetFirmwareurl;

	private String producturl;

	private String routerurl;

	private String appVersionurl;

	private String locationurl;
	
	private String KoreQuerygetEapCodeServiceurl;
	
	private String KoreQuerygetEapDetailsServiceurl;
	
	private String KoreQueryPlanCodeNextPeriodurl;
	
	private String KoreSIMRadiusQueryurl;
	
	private String activatedeviceurl;
	
	private String activatetostateurl;
	
	private String simAssociateToGroupUrl;
	
	private String changemsisdnurl;
	
	private String deactivatedeviceurl;
	
	private String getModifyDeviceThresholdurl;
	
	private String getPingurl;
	
	private String NCMModifyDevicePlanForNxtPrdurl;
	
	private String getcostcentersurl;
	
	private String mdcustominfourl;
	
	private String getquerydeviceusagebysimurl;
	
	private String getqueryfeaturecodesurl;
	
	private String getquerydeviceusageurl;
	
	private String queryrequeststatusurl;
	
	private String queryservicetypecodesurl;
	
	private String getqueryalldevicesurl;
	
	private String reactivatedeviceurl;
	private String Korechangesimstatusurl;
	
	private String Korequeryavailablereportfilesurl;
	
	private String koreUnbarToStateCallurl;

	private String suspendDevice;
	
	private String downloadReporting;
	
	private String reportingPing;
	
	private String acknowledgealertsbygroupurl;
	
	private String removeSimAssociation;
	
	private String getRetrieveGroupByCompanyIdurl;
	
	private String getalertsbysimidurl;
	
	private String acknowlegdeAlertBySimAndRule;
	
	private String getalertbycompanyidgroupidurl;
	
	private String sendAsyncAcknowledgeurl;
	
	private String asyncServiceURL;


}
