package com.nsl.usagereport.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.vfs2.FileObject;

import com.nsl.usagereport.transaction.entity.RefFileUpload;

public class ReportDetails {
	private String fileName;
	private String extension;
	private FileObject fileObject;
	private Map<Long, List<Object>> detailsBuiler = new HashMap<Long, List<Object>>();
	private Map<String, Map<Object, Long>> recordsStatus = new HashMap<String, Map<Object, Long>>();
	private Map<Long, RefFileUpload> refFileUploadMap = new HashMap<Long, RefFileUpload>();

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public Map<Long, RefFileUpload> getRefFileUploadMap() {
		return refFileUploadMap;
	}

	public void setRefFileUploadMap(Map<Long, RefFileUpload> refFileUploadMap) {
		this.refFileUploadMap = refFileUploadMap;
	}

	public Map<String, Map<Object, Long>> getRecordsStatus() {
		return recordsStatus;
	}

	public void setRecordsStatus(Map<String, Map<Object, Long>> recordsStatus) {
		this.recordsStatus = recordsStatus;
	}

	public Map<Long, List<Object>> getDetailsBuiler() {
		return detailsBuiler;
	}

	public void setDetailsBuiler(Map<Long, List<Object>> detailsBuiler) {
		this.detailsBuiler = detailsBuiler;
	}

	public FileObject getFileObject() {
		return fileObject;
	}

	public void setFileObject(FileObject fileObject) {
		this.fileObject = fileObject;
	}

}
