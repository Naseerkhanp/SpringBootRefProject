package com.nsl.usagereport.nbos.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.nbos.entity.WibInfo;
@Repository
public interface WibInfoRepository extends JpaRepository<WibInfo, Integer> {

}
