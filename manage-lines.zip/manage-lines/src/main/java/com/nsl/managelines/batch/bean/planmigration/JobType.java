/**
 * 
 */
package com.nsl.managelines.batch.bean.planmigration;

/**
 * @author Dhayanand.B
 *
 */
public enum JobType {

	PREPARE_PM_DATA, START_PLAN_MIRGATION, STOP_PLAN_MIRGATION

}
