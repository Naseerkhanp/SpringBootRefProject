package com.flowcomponent.pcrfInBoundGateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.util.ErrorHandler;

import com.flowcomponent.pcrfInBoundGateway.exception.CustomFatalExceptionStrategy;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundQueueProperties;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;
	
	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;
	
	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}
	
    @Bean
	public ErrorHandler errorHandler() {
	    return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}
	 
	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
	    return new CustomFatalExceptionStrategy();
	}

		
	@Bean
	public Queue getPcrfQueue() {
		
		return QueueBuilder.durable(inboundQueueProperties.getGetPcrfQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange getPcrfExchange() {
		return new DirectExchange(inboundQueueProperties.getGetPcrfExchange());
	}

	@Bean
	Binding getPcrfBinding() {
		return BindingBuilder.bind(getPcrfQueue()).to(getPcrfExchange())
				.with(inboundQueueProperties.getGetPcrfQueue());
	}
	@Bean
	public Queue deletePcrfQueue() {
		
		return QueueBuilder.durable(inboundQueueProperties.getDeletePcrfQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange deletePcrfExchange() {
		return new DirectExchange(inboundQueueProperties.getDeletePcrfExchange());
	}

	@Bean
	Binding deletePcrfBinding() {
		return BindingBuilder.bind(deletePcrfQueue()).to(deletePcrfExchange())
				.with(inboundQueueProperties.getDeletePcrfQueue());
	}
	@Bean
	public Queue createPcrfQueue() {
		
		return QueueBuilder.durable(inboundQueueProperties.getCreatePcrfQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange createPcrfExchange() {
		return new DirectExchange(inboundQueueProperties.getCreatePcrfExchange());
	}

	@Bean
	Binding createPcrfBinding() {
		return BindingBuilder.bind(createPcrfQueue()).to(createPcrfExchange())
				.with(inboundQueueProperties.getCreatePcrfQueue());
	}
	
	@Bean
	public Queue updatePcrfQueue() {
		
		return QueueBuilder.durable(inboundQueueProperties.getUpdatePcrfQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange updatePcrfExchange() {
		return new DirectExchange(inboundQueueProperties.getUpdatePcrfExchange());
	}

	@Bean
	Binding updatePcrfBinding() {
		return BindingBuilder.bind(updatePcrfQueue()).to(updatePcrfExchange())
				.with(inboundQueueProperties.getUpdatePcrfQueue());
	}
	
		
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	/*
	 * @Bean(name = "ConnectionFactory") public ConnectionFactory
	 * rabbitMQConnectionFactory() { CachingConnectionFactory connectionFactory =
	 * new CachingConnectionFactory(host);
	 * connectionFactory.setPort(Integer.parseInt(port));
	 * connectionFactory.setUsername(username);
	 * connectionFactory.setPassword(password);
	 * connectionFactory.setConnectionTimeout(30000); return connectionFactory; }
	 */
	
	@Bean(name = "getPcrfConnectionFactory")
	@Primary
	public ConnectionFactory getPcrfrabbitMQConnectionFactory() {
		CachingConnectionFactory getPcrfconnectionFactory = new CachingConnectionFactory(host);
		getPcrfconnectionFactory.setPort(Integer.parseInt(port));
		getPcrfconnectionFactory.setUsername(username);
		getPcrfconnectionFactory.setPassword(password);
		getPcrfconnectionFactory.setConnectionTimeout(30000);
		return getPcrfconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getPcrfRabbitAdmin(){
        return new RabbitAdmin(getPcrfrabbitMQConnectionFactory());
    }
	
	@Bean(name = "deletePcrfConnectionFactory")
	public ConnectionFactory deletePcrfrabbitMQConnectionFactory() {
		CachingConnectionFactory deletePcrfconnectionFactory = new CachingConnectionFactory(host);
		deletePcrfconnectionFactory.setPort(Integer.parseInt(port));
		deletePcrfconnectionFactory.setUsername(username);
		deletePcrfconnectionFactory.setPassword(password);
		deletePcrfconnectionFactory.setConnectionTimeout(30000);
		return deletePcrfconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin deletePcrfRabbitAdmin(){
        return new RabbitAdmin(deletePcrfrabbitMQConnectionFactory());
    }
	
	@Bean(name = "createPcrfConnectionFactory")
	public ConnectionFactory createPcrfrabbitMQConnectionFactory() {
		CachingConnectionFactory createPcrfconnectionFactory = new CachingConnectionFactory(host);
		createPcrfconnectionFactory.setPort(Integer.parseInt(port));
		createPcrfconnectionFactory.setUsername(username);
		createPcrfconnectionFactory.setPassword(password);
		createPcrfconnectionFactory.setConnectionTimeout(30000);
		return createPcrfconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin createPcrfRabbitAdmin(){
        return new RabbitAdmin(createPcrfrabbitMQConnectionFactory());
    }
	
	@Bean(name = "updatePcrfConnectionFactory")
	public ConnectionFactory updatePcrfrabbitMQConnectionFactory() {
		CachingConnectionFactory updatePcrfconnectionFactory = new CachingConnectionFactory(host);
		updatePcrfconnectionFactory.setPort(Integer.parseInt(port));
		updatePcrfconnectionFactory.setUsername(username);
		updatePcrfconnectionFactory.setPassword(password);
		updatePcrfconnectionFactory.setConnectionTimeout(30000);
		return updatePcrfconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin updatePcrfRabbitAdmin(){
        return new RabbitAdmin(updatePcrfrabbitMQConnectionFactory());
    }

	/*
	 * @Bean("customSimpleRabbitListenerContainer") public
	 * SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory() {
	 * SimpleRabbitListenerContainerFactory factory = new
	 * SimpleRabbitListenerContainerFactory();
	 * factory.setConnectionFactory(rabbitMQConnectionFactory());
	 * factory.setReceiveTimeout((long) 30000); return factory; }
	 */
	
	@Bean("getPcrfrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getPcrfrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getPcrffactory = new SimpleRabbitListenerContainerFactory();
		getPcrffactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getPcrffactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getPcrffactory.setPrefetchCount(1);
		getPcrffactory.setReceiveTimeout((long) 50000);
		getPcrffactory.setConnectionFactory(getPcrfrabbitMQConnectionFactory());
		getPcrffactory.setErrorHandler(errorHandler());
		return getPcrffactory;
	}
	
	@Bean("deletePcrfrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory deletePcrfrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory deletePcrffactory = new SimpleRabbitListenerContainerFactory();
		deletePcrffactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		deletePcrffactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		deletePcrffactory.setPrefetchCount(1);
		deletePcrffactory.setReceiveTimeout((long) 50000);
		deletePcrffactory.setConnectionFactory(deletePcrfrabbitMQConnectionFactory());
		deletePcrffactory.setErrorHandler(errorHandler());
		return deletePcrffactory;
	}
	
	@Bean("createPcrfrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory createPcrfrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory createPcrffactory = new SimpleRabbitListenerContainerFactory();
		createPcrffactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		createPcrffactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		createPcrffactory.setPrefetchCount(1);
		createPcrffactory.setReceiveTimeout((long) 50000);
		createPcrffactory.setConnectionFactory(createPcrfrabbitMQConnectionFactory());
		createPcrffactory.setErrorHandler(errorHandler());
		return createPcrffactory;
	}
	
	@Bean("updatePcrfrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory updatePcrfrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory updatePcrffactory = new SimpleRabbitListenerContainerFactory();
		updatePcrffactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		updatePcrffactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		updatePcrffactory.setPrefetchCount(1);
		updatePcrffactory.setReceiveTimeout((long) 50000);
		updatePcrffactory.setConnectionFactory(updatePcrfrabbitMQConnectionFactory());
		updatePcrffactory.setErrorHandler(errorHandler());
		return updatePcrffactory;
	}

	/*
	 * @Bean() public RabbitTemplate customRabbitTemplate() { RabbitTemplate
	 * rabbitTemplate = new RabbitTemplate();
	 * rabbitTemplate.setReplyTimeout(30000L);
	 * rabbitTemplate.setMessageConverter(jsonMessageConverter());
	 * rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory()); return
	 * rabbitTemplate; }
	 */
	
	@Bean()
	@Primary
	public RabbitTemplate getPcrfcustomRabbitTemplate() {
		RabbitTemplate getPcrfrabbitTemplate = new RabbitTemplate();
		getPcrfrabbitTemplate.setReplyTimeout(30000L);
		getPcrfrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getPcrfrabbitTemplate.setConnectionFactory(getPcrfrabbitMQConnectionFactory());
		return getPcrfrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate deletePcrfcustomRabbitTemplate() {
		RabbitTemplate deletePcrfrabbitTemplate = new RabbitTemplate();
		deletePcrfrabbitTemplate.setReplyTimeout(30000L);
		deletePcrfrabbitTemplate.setMessageConverter(jsonMessageConverter());
		deletePcrfrabbitTemplate.setConnectionFactory(deletePcrfrabbitMQConnectionFactory());
		return deletePcrfrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate createPcrfcustomRabbitTemplate() {
		RabbitTemplate createPcrfrabbitTemplate = new RabbitTemplate();
		createPcrfrabbitTemplate.setReplyTimeout(30000L);
		createPcrfrabbitTemplate.setMessageConverter(jsonMessageConverter());
		createPcrfrabbitTemplate.setConnectionFactory(createPcrfrabbitMQConnectionFactory());
		return createPcrfrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate updatePcrfcustomRabbitTemplate() {
		RabbitTemplate updatePcrfrabbitTemplate = new RabbitTemplate();
		updatePcrfrabbitTemplate.setReplyTimeout(30000L);
		updatePcrfrabbitTemplate.setMessageConverter(jsonMessageConverter());
		updatePcrfrabbitTemplate.setConnectionFactory(updatePcrfrabbitMQConnectionFactory());
		return updatePcrfrabbitTemplate;
	}
}