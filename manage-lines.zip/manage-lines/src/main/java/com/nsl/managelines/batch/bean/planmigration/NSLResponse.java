/**
 * 
 */
package com.nsl.managelines.batch.bean.planmigration;

import java.util.ArrayList;

import com.nsl.managelines.batch.bean.MessageHeader;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Getter
@Setter
@ToString
public class NSLResponse {

	public MessageHeader messageHeader;

	public Data data;
	
	@Getter
	@Setter
	@ToString
	public class Message {
		public String responseCode;
		public String description;
	}

	@Getter
	@Setter
	@ToString
	public class Data {
		public String transactionId;
		public String code;
		public String reason;
		public ArrayList<Message> message;
	}
}
