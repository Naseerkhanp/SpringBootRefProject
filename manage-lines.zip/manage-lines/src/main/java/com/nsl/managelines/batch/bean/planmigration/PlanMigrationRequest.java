/**
 * 
 */
package com.nsl.managelines.batch.bean.planmigration;

import java.io.Serializable;

import com.nsl.managelines.batch.bean.Data;
import com.nsl.managelines.batch.bean.MessageHeader;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Getter
@Setter
@ToString
public class PlanMigrationRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public Data data;

	private JobType jobType;

}
