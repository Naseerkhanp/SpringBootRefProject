/**
 * 
 */
package com.nsl.managelines.batch.bean.planmigration;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Getter
@Setter
@ToString
public class PlanMigrationEligibilityOutput {

	String inputrow;

	String eLineId;

	String mdn;

	String eligibleFormigration;

	String status;

	String errorMessage;

	String result;

}
