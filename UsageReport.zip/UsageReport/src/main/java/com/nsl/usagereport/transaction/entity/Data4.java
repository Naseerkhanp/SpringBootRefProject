package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "DATA4")
@Table(name = "DATA4")
public class Data4 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DATA4_ID")
	private Integer id;

	@Column(name = "ACCT_STATUS_TYPE")
	private Long acctStatusType;

	@Column(name = "CALLING_STATION_ID")
	private String callingStationId;

	@Column(name = "FRAMED_IP_ADDRESS")
	private String framedIpAddress;

	@Column(name = "USER_NAME")
	private String userName;

	@Column(name = "ACCT_SESSION_ID")
	private String acctSessionId;

	@Column(name = "GPP2_CORRELATION_ID")
	private String gpp2CorrelationId;

	@Column(name = "GPP2_SERVICE_OPTION")
	private Long gpp2ServiceOption;

	@Column(name = "GPP2_FOREIGN_AGENT_ADDRESS")
	private String gpp2ForeignAgentAddress;

	@Column(name = "ACCT_OUTPUT_OCTETS")
	private Long acctOutputOctets;

	@Column(name = "ACCT_INPUT_OCTETS")
	private Long acctInputOctets;

	@Column(name = "ACCT_OUTPUT_GIGAWORDS")
	private Long acctOutputGigawords;

	@Column(name = "ACCT_INPUT_GIGAWORDS")
	private Long acctInputGigawords;

	@Column(name = "EVENT_TIMESTAMP")
	private Date event_timestamp;

	@Column(name = "CLASS")
	private String data4_class;
	@Column(name = "CREATED_DATE")
	private Date created_date;// = new java.sql.Date(new java.util.Date().getTime());;

	@Column(name = "CREATED_BY")
	private String created_by;
	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modified_date;// = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "MODIFIED_BY")
	private String modified_by;

}
