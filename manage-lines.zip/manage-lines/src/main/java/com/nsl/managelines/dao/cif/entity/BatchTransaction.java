package com.nsl.managelines.dao.cif.entity;

import java.io.Serializable;
import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "RH_BATCH_TRANSACTION")
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BatchTransaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3245598052741951577L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rh_id_gen")
	@SequenceGenerator(name = "rh_id_gen", sequenceName = "RH_ID_SEQ", allocationSize = 1)
	@Column(name = "ID")
	private Long id;

	@Column(name = "EXT_BATCH_ID")
	private String extBatchId;

	@Column(name = "BATCH_TYPE")
	private String batchType;

	@Column(name = "TRANSACTION_ID")
	private Long transactionId;

	@Column(name = "BATCH_ID")
	private Long batchId;

	@Column(name = "MDN")
	private String mdn;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "EXC_TIMESTAMP")
	private ZonedDateTime excTimestamp;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private ZonedDateTime createdDate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@LastModifiedDate
	@Column(name = "MODIFIED_DATE")
	private ZonedDateTime modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "SYNC")
	private String sync;

	@Column(name = "CHANNEL_ID")
	private String channelId;

	@Column(name = "SERVICE_TYPE")
	private String serviceType;

	@Column(name = "BATCH_UPDATE_STATUS")
	private String batchUpdateStatus;

	@Column(name = "BATCH_ITEM_ID")
	private Long batchItemId;

	@Column(name = "BATCH_STATUS")
	private String batchStatus;

	@Column(name = "DEVICE_TYPE")
	private String deviceType;

	@Column(name = "DEVICE_ID")
	private Long deviceId;

	@Column(name = "NEXT_BCD")
	private String nextBcd;

	@Column(name = "RESPONSE_MSG")
	@Lob
	private String responseMsg;

	@Column(name = "REQUEST_MSG")
	@Lob
	private String requestMsg;

	@Column(name = "EXTERNAL_VALUE_1")
	private String externalValue1;

	@Column(name = "EXTERNAL_VALUE_2")
	private String externalValue2;

	@Column(name = "EXTERNAL_VALUE_3")
	private String externalValue3;
	
	@Column(name = "reference_Number")
	private String referenceNumber;

}
