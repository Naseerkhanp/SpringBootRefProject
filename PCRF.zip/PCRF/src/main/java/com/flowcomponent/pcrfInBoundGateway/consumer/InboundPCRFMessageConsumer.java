package com.flowcomponent.pcrfInBoundGateway.consumer;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.flowcomponent.pcrfInBoundGateway.constants.Constants;
import com.flowcomponent.pcrfInBoundGateway.dao.TransactionDAO;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundProperties;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundQueueProperties;
import com.flowcomponent.pcrfInBoundGateway.service.ExternalServiceClient;

/**
 * The Class InboundMessageConsumer.
 */
@Component
public class InboundPCRFMessageConsumer {

	/** The transaction service. */
	@Autowired
	private ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(InboundPCRFMessageConsumer.class);

	
	@RabbitListener(queues = "#{inboundQueueProperties.getGetPcrfQueue()}",containerFactory = "getPcrfrabbitListenerContainerFactory")
	public Message getPcrfResponse(Message msg) {
		LOGGER.info("Inside getPcrfServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.GETPCRF_SERVICENAME;
		String operationName = Constants.GETPCRF_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "GetPcrfService","PCRF");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}	

	@RabbitListener(queues = "#{inboundQueueProperties.getDeletePcrfQueue()}", containerFactory = "deletePcrfrabbitListenerContainerFactory")
	public Message deletePcrfResponse(Message msg) {
		LOGGER.info("Inside deletePcrfServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			String serviceName = Constants.DELETEPCRF_SERVICENAME;
			String operationName = Constants.DELETEPCRF_OPERATIONNAME;
			
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "DeletePcrfService","PCRF");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			
		} catch (Exception e) {
			
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getCreatePcrfQueue()}",containerFactory = "createPcrfrabbitListenerContainerFactory")
	public Message createPcrfResponse(Message msg) {
		LOGGER.info("Inside createPcrfServiceCall method::::");
		String response = null;
	    String entityId = "0";
		String transId = null;
		String serviceName = Constants.CREATEPCRF_SERVICENAME;
		String operationName = Constants.CREATEPCRF_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "CreatePcrfService","PCRF");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			
			
		} catch (Exception e) {
			
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		}
	@RabbitListener(queues = "#{inboundQueueProperties.getUpdatePcrfQueue()}", containerFactory = "updatePcrfrabbitListenerContainerFactory")
	public Message updatePcrfResponse(Message msg) {
		LOGGER.info("Inside UpdatePcrfService method::::");
		String response = null;
	    String entityId = "0";
		String transId = null;
		String serviceName = Constants.UPDATEPCRF_SERVICENAME;
		String operationName = Constants.UPDATEPCRF_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {
			
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "UpdatePcrfService","PCRF");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			
		} catch (Exception e) {
			
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	



}
