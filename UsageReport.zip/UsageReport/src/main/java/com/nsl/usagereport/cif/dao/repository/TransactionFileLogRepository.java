package com.nsl.usagereport.cif.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.cif.entity.TransactionFileLog;

@Transactional
@Repository
public interface TransactionFileLogRepository extends JpaRepository<TransactionFileLog, Integer> {
	@Query("select d from TRANSACTION_FILE_LOG d where d.fileName = :fileName and d.status = :status")
	TransactionFileLog findByFileName(@Param("fileName") String fileName, @Param("status") String status);

	@Query("select d from TRANSACTION_FILE_LOG d where d.fileName = :fileName")
	TransactionFileLog findByFileName(@Param("fileName") String fileName);

	@Modifying
	@Query("update TRANSACTION_FILE_LOG u set u.status = :status, u.totalRecords = :totalRecords, u.totalRecordsProcessed = :totalRecordsProcessed, u.totalRecordsfailed = :totalRecordsfailed where u.fileName = :fileName")
	void updateFileDataByName(@Param("status") String status, @Param("totalRecords") Long totalRecords,
			@Param("totalRecordsProcessed") Long totalRecordsProcessed,
			@Param("totalRecordsfailed") Long totalRecordsfailed, @Param("fileName") String fileName);
}
