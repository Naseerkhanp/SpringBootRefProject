package com.excelacom.servicegateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;

import com.excelacom.servicegateway.properties.InboundQueueProperties;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;

	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}

	@Bean
	public Queue EmmCreateSubscriberQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getEmmCreateSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange EmmCreateSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getEmmCreateSubscriberExchange());
	}

	@Bean
	Binding EmmCreateSubscriberBinding() {
		return BindingBuilder.bind(EmmCreateSubscriberQueue()).to(EmmCreateSubscriberExchange())
				.with(inboundQueueProperties.getEmmCreateSubscriberQueue());
	}

	@Bean
	public Queue EmmUpdateSubscriberQueue() {

		return QueueBuilder.durable(inboundQueueProperties.getEmmUpdateSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange EmmUpdateSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getEmmUpdateSubscriberExchange());
	}

	@Bean
	Binding EmmUpdateSubscriberBinding() {
		return BindingBuilder.bind(EmmUpdateSubscriberQueue()).to(EmmUpdateSubscriberExchange())
				.with(inboundQueueProperties.getEmmUpdateSubscriberQueue());
	}

	@Bean
	public Queue EmmUsageinquiryQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getEmmUsageinquiryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange EmmUsageinquiryExchange() {
		return new DirectExchange(inboundQueueProperties.getEmmUsageinquiryExchange());
	}

	@Bean
	Binding EmmUsageinquiryBinding() {
		return BindingBuilder.bind(EmmUsageinquiryQueue()).to(EmmUsageinquiryExchange())
				.with(inboundQueueProperties.getEmmUsageinquiryQueue());
	}

	@Bean
	public Queue EmmChangemdnsubscriberQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getEmmChangemdnsubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange EmmChangemdnsubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getEmmChangemdnsubscriberExchange());
	}

	@Bean
	Binding EmmChangemdnsubscriberBinding() {
		return BindingBuilder.bind(EmmChangemdnsubscriberQueue()).to(EmmChangemdnsubscriberExchange())
				.with(inboundQueueProperties.getEmmChangemdnsubscriberQueue());
	}

	
	  @Bean
	  public Queue EmmGetSubscriberQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getEmmGetSubscriberQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	  }
	  
	  @Bean 
	  public DirectExchange EmmGetSubscriberExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getEmmGetSubscriberExchange()); 
	  }
	  
	  @Bean
	  Binding EmmGetSubscriberBinding() {
		  return BindingBuilder.bind(EmmGetSubscriberQueue()).to(EmmGetSubscriberExchange()).with(inboundQueueProperties.getEmmGetSubscriberQueue()); 
	  }
	  
	 
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	@Bean(name = "ConnectionFactory")
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}

	@Bean()
	RabbitAdmin rabbitAdmin() {
		return new RabbitAdmin(rabbitMQConnectionFactory());
	}

	@Bean(name = "emmCreateConnectionFactory")
	public ConnectionFactory emmCreaterabbitMQConnectionFactory() {
		CachingConnectionFactory emmCreateconnectionFactory = new CachingConnectionFactory(host);
		emmCreateconnectionFactory.setPort(Integer.parseInt(port));
		emmCreateconnectionFactory.setUsername(username);
		emmCreateconnectionFactory.setPassword(password);
		emmCreateconnectionFactory.setConnectionTimeout(30000);
		return emmCreateconnectionFactory;
	}

	@Bean()
	RabbitAdmin emmCreateRabbitAdmin() {
		return new RabbitAdmin(emmCreaterabbitMQConnectionFactory());
	}

	@Bean(name = "emmUpdateConnectionFactory")
	public ConnectionFactory emmUpdaterabbitMQConnectionFactory() {
		CachingConnectionFactory emmUpdateconnectionFactory = new CachingConnectionFactory(host);
		emmUpdateconnectionFactory.setPort(Integer.parseInt(port));
		emmUpdateconnectionFactory.setUsername(username);
		emmUpdateconnectionFactory.setPassword(password);
		emmUpdateconnectionFactory.setConnectionTimeout(30000);
		return emmUpdateconnectionFactory;
	}

	@Bean()
	RabbitAdmin emmUpdateRabbitAdmin() {
		return new RabbitAdmin(emmUpdaterabbitMQConnectionFactory());
	}

	@Bean(name = "emmUsageinquiryConnectionFactory")
	public ConnectionFactory emmUsageinquiryrabbitMQConnectionFactory() {
		CachingConnectionFactory emmUsageinquiryconnectionFactory = new CachingConnectionFactory(host);
		emmUsageinquiryconnectionFactory.setPort(Integer.parseInt(port));
		emmUsageinquiryconnectionFactory.setUsername(username);
		emmUsageinquiryconnectionFactory.setPassword(password);
		emmUsageinquiryconnectionFactory.setConnectionTimeout(30000);
		return emmUsageinquiryconnectionFactory;
	}

	@Bean()
	RabbitAdmin emmUsageinquiryRabbitAdmin() {
		return new RabbitAdmin(emmUsageinquiryrabbitMQConnectionFactory());
	}

	@Bean(name = "emmChangemdnsubscriberConnectionFactory")
	public ConnectionFactory emmChangemdnsubscriberrabbitMQConnectionFactory() {
		CachingConnectionFactory emmChangemdnsubscriberconnectionFactory = new CachingConnectionFactory(host);
		emmChangemdnsubscriberconnectionFactory.setPort(Integer.parseInt(port));
		emmChangemdnsubscriberconnectionFactory.setUsername(username);
		emmChangemdnsubscriberconnectionFactory.setPassword(password);
		emmChangemdnsubscriberconnectionFactory.setConnectionTimeout(30000);
		return emmChangemdnsubscriberconnectionFactory;
	}

	@Bean()
	RabbitAdmin emmChangemdnsubscriberRabbitAdmin() {
		return new RabbitAdmin(emmUsageinquiryrabbitMQConnectionFactory());
	}

	@Bean(name = "emmGetsubscriberConnectionFactory")
	public ConnectionFactory emmGetsubscriberrabbitMQConnectionFactory() {
		CachingConnectionFactory emmGetsubscriberconnectionFactory = new CachingConnectionFactory(host);
		emmGetsubscriberconnectionFactory.setPort(Integer.parseInt(port));
		emmGetsubscriberconnectionFactory.setUsername(username);
		emmGetsubscriberconnectionFactory.setPassword(password);
		emmGetsubscriberconnectionFactory.setConnectionTimeout(30000);
		return emmGetsubscriberconnectionFactory;
	}

	@Bean()
	RabbitAdmin emmGetsubscriberRabbitAdmin() {
		return new RabbitAdmin(emmGetsubscriberrabbitMQConnectionFactory());
	}
	
	@Bean("customSimpleRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
			@Qualifier("ConnectionFactory") ConnectionFactory ConnectionFactory) {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(rabbitMQConnectionFactory());
		/*
		 * factory.setConcurrentConsumers(200); factory.setMaxConcurrentConsumers(250);
		 */
		factory.setReceiveTimeout((long) 30000);
		return factory;
	}

	@Bean("emmCreaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory emmCreaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory emmCreatefactory = new SimpleRabbitListenerContainerFactory();
		emmCreatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		emmCreatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		emmCreatefactory.setPrefetchCount(1);
		emmCreatefactory.setReceiveTimeout((long) 50000);
		emmCreatefactory.setConnectionFactory(emmCreaterabbitMQConnectionFactory());
		return emmCreatefactory;
	}

	@Bean("emmUpdaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory emmUpdaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory emmUpdatefactory = new SimpleRabbitListenerContainerFactory();
		emmUpdatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		emmUpdatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		emmUpdatefactory.setPrefetchCount(1);
		emmUpdatefactory.setReceiveTimeout((long) 50000);
		emmUpdatefactory.setConnectionFactory(emmUpdaterabbitMQConnectionFactory());
		return emmUpdatefactory;
	}

	@Bean("emmUsageinquiryrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory emmUsageinquiryrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory emmUsageinquiryfactory = new SimpleRabbitListenerContainerFactory();
		emmUsageinquiryfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		emmUsageinquiryfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		emmUsageinquiryfactory.setPrefetchCount(1);
		emmUsageinquiryfactory.setReceiveTimeout((long) 50000);
		emmUsageinquiryfactory.setConnectionFactory(emmUsageinquiryrabbitMQConnectionFactory());
		return emmUsageinquiryfactory;
	}

	@Bean("emmChangemdnsubscriberrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory emmChangemdnsubscriberrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory emmChangemdnsubscriberfactory = new SimpleRabbitListenerContainerFactory();
		emmChangemdnsubscriberfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		emmChangemdnsubscriberfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		emmChangemdnsubscriberfactory.setPrefetchCount(1);
		emmChangemdnsubscriberfactory.setReceiveTimeout((long) 50000);
		emmChangemdnsubscriberfactory.setConnectionFactory(emmChangemdnsubscriberrabbitMQConnectionFactory());
		return emmChangemdnsubscriberfactory;
	}
	
	@Bean("emmGetsubscriberrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory emmGetsubscriberrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory emmGetsubscriberfactory = new SimpleRabbitListenerContainerFactory();
		emmGetsubscriberfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		emmGetsubscriberfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		emmGetsubscriberfactory.setPrefetchCount(1);
		emmGetsubscriberfactory.setReceiveTimeout((long) 50000);
		emmGetsubscriberfactory.setConnectionFactory(emmGetsubscriberrabbitMQConnectionFactory());
		return emmGetsubscriberfactory;
	}

	@Bean
	@Primary
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}

	@Bean
	public RabbitTemplate emmCreatecustomRabbitTemplate() {
		RabbitTemplate emmCreaterabbitTemplate = new RabbitTemplate();
		emmCreaterabbitTemplate.setReplyTimeout(30000L);
		emmCreaterabbitTemplate.setConnectionFactory(emmCreaterabbitMQConnectionFactory());
		emmCreaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		return emmCreaterabbitTemplate;
	}

	@Bean
	public RabbitTemplate emmUpdatecustomRabbitTemplate() {
		RabbitTemplate emmUpdaterabbitTemplate = new RabbitTemplate();
		emmUpdaterabbitTemplate.setReplyTimeout(30000L);
		emmUpdaterabbitTemplate.setConnectionFactory(emmUpdaterabbitMQConnectionFactory());
		emmUpdaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		return emmUpdaterabbitTemplate;
	}

	@Bean
	public RabbitTemplate emmUsageinquirycustomRabbitTemplate() {
		RabbitTemplate emmUsageinquiryrabbitTemplate = new RabbitTemplate();
		emmUsageinquiryrabbitTemplate.setReplyTimeout(30000L);
		emmUsageinquiryrabbitTemplate.setConnectionFactory(emmUsageinquiryrabbitMQConnectionFactory());
		emmUsageinquiryrabbitTemplate.setMessageConverter(jsonMessageConverter());
		return emmUsageinquiryrabbitTemplate;
	}

	@Bean
	public RabbitTemplate emmChangemdnsubscribercustomRabbitTemplate() {
		RabbitTemplate emmChangemdnsubscriberrabbitTemplate = new RabbitTemplate();
		emmChangemdnsubscriberrabbitTemplate.setReplyTimeout(30000L);
		emmChangemdnsubscriberrabbitTemplate.setConnectionFactory(emmChangemdnsubscriberrabbitMQConnectionFactory());
		emmChangemdnsubscriberrabbitTemplate.setMessageConverter(jsonMessageConverter());
		return emmChangemdnsubscriberrabbitTemplate;
	}
	
	@Bean
	public RabbitTemplate emmGetsubscribercustomRabbitTemplate() {
		RabbitTemplate emmGetsubscriberrabbitTemplate = new RabbitTemplate();
		emmGetsubscriberrabbitTemplate.setReplyTimeout(30000L);
		emmGetsubscriberrabbitTemplate.setConnectionFactory(emmGetsubscriberrabbitMQConnectionFactory());
		emmGetsubscriberrabbitTemplate.setMessageConverter(jsonMessageConverter());
		return emmGetsubscriberrabbitTemplate;
	}

}
