package com.nsl.usagereport.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.vfs2.FileObject;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.cif.entity.TransFailureLog;
import com.nsl.usagereport.cif.entity.TransactionFileLog;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.properties.UsuageReportProperties;
import com.nsl.usagereport.transaction.dao.repository.ResourceInfoDaoImpl;
import com.nsl.usagereport.transaction.entity.ResourceInfo;
import com.nsl.usagereport.util.UtilityServiceClass;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class ProcessIOSDevices {
	@Autowired
	private ResourceInfoDaoImpl resourceInfoDaoImpl;

	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;

	@Autowired
	private UtilityServiceClass utilityServiceClass;

	@Autowired
	private UsuageReportProperties usuageReportProperties;

	@Async(value = "AsyncTaskExecutor")
	//@Transactional
	void processIOSDeviceDetails(FileObject fileDetails, UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " processIOSDeviceDetails called");
		String iosDeviceList[] = new String(fileDetails.getContent().getByteArray()).split("\r\n");
		int noOfFailureRecords = 0;
		int noOfSuccessRecords = 0;
		boolean skipHeaderRow = true;
		String fileName = fileDetails.getName().getBaseName();
		String extension = fileName.substring(fileName.lastIndexOf(NslFileUploadConstants.DOT));
		usageReportDetails.setFileType(NslFileUploadConstants.IOS);
		TransactionFileLog transactionFileLog = transactionFileLogDaoImpl.saveTransactionDetails(usageReportDetails,
				fileName, extension, NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
		//File output csv generation headers.
		String fileContent = "IMEI,Model,IOSVersion,Result\n";
		Long transactionId = transactionFileLog.getTransactionId();
		log.info(this.getClass() +" Current processing transactionId : "+transactionId +" ,FileName : "+fileName);
		try {
			List<ResourceInfo> resourceInfoList = new ArrayList<ResourceInfo>();
			List<Object> transFailureList = new ArrayList<Object>();

			// Clear resource_info as file containing master data always.
			resourceInfoDaoImpl.deleteResourceInfo(NslFileUploadConstants.IOSL14_CHK);

			log.info("FileName " + fileName + " Total iosDevice Records to be processed " + (iosDeviceList.length - 1)
					+ " TransactionId : " + transactionId);
			for (String iosDevice : iosDeviceList) {
				if (skipHeaderRow) {
					// Skip header
					skipHeaderRow = false;
					continue;
				}
				String deviceDetails[] = iosDevice.split(",");
				String IMEI="";
				String iosVersion="";
				String productModel="";
				if(deviceDetails.length>2)
					IMEI= deviceDetails[2];
				if(deviceDetails.length>6)
					iosVersion = deviceDetails[6];
				if(deviceDetails.length>3)
					productModel = deviceDetails[3];
				String result = "";
				if (IMEI.isEmpty()) {
					result = "IMEI number is missing";
				} else if (IMEI.length() < 14 || IMEI.length() > 16) {
					result = "Invalid IMEI length";
				}
				if (iosVersion.isEmpty()) {
					result += (result.isEmpty() ? "" : " ## ") + "iosVersion is missing";
				} 
				

				if (!result.isEmpty()) {
					TransFailureLog transFailureLog = new TransFailureLog();
					transFailureLog.setTransactionId(transactionId);
					transFailureLog.setStatus(NslFileUploadConstants.PARSED_STATUS_FAILED);
					transFailureLog.setErrorMsg(NslFileUploadConstants.IOSL14_CHK);
					transFailureLog.setModifiedBy(transactionFileLog.getCreatedBy());
					transFailureLog.setCreatedBy(transactionFileLog.getCreatedBy());
					JSONObject request = new JSONObject();
					request.put("imei", IMEI);
					request.put("iosVersion", iosVersion);
					request.put("productModel", productModel);
					request.put("failureReason", result);
					transFailureLog.setErrorDetails(request.toString());
					transFailureList.add(transFailureLog);
					noOfFailureRecords++;
				} else {
					result = "Success";
					ResourceInfo resourceInfo = new ResourceInfo();
					resourceInfo.setCreatedBy(usageReportDetails.getUserID());
					resourceInfo.setResourceSubtype(NslFileUploadConstants.IOSL14_CHK);
					resourceInfo.setResourceType("IMEI");
					resourceInfo.setResourceValue(IMEI);
					resourceInfo.setExternalValue1(productModel);
					resourceInfo.setExternalValue2(iosVersion);
					resourceInfoList.add(resourceInfo);
					noOfSuccessRecords++;
				}
				fileContent += IMEI + "," + productModel + "," + iosVersion + "," + result + "\n";
			}
			if (resourceInfoList.size() > 0) {
				resourceInfoDaoImpl.insertResourceInfoList(resourceInfoList);
			}
			if (transFailureList.size() > 0) {
				transactionFileLogDaoImpl.saveFailureLogs(transFailureList);
			}

			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
					(noOfFailureRecords + noOfSuccessRecords), noOfSuccessRecords, noOfFailureRecords, fileName, null,
					null, usageReportDetails, fileContent);
			// Call Reportmanagement to generate output csv.
			JSONObject request = constructRequest(transactionId);
			utilityServiceClass.callRestAPI(request.toString(), usuageReportProperties.getGenerateReportsServiceUrl());
			log.info("FileName " + fileName + " iosDevice process completed and output file generation in progress "
					+ " TransactionId : " + transactionId);
		} catch (Exception e) {
			log.error(" Internal Error while processing iosdevice list: ", e);
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
					(noOfFailureRecords + noOfSuccessRecords), noOfSuccessRecords, noOfFailureRecords, fileName, null,
					e.getMessage(), usageReportDetails, null);
		}
	}

	private JSONObject constructRequest(Long transactionId) {
		JSONObject request = new JSONObject();
		JSONObject queryString = new JSONObject();
		queryString.put("TRANSACTION_ID", transactionId);
		request.put("queryString", queryString);
		JSONObject data = new JSONObject();
		data.put("transactionTimeStamp", new SimpleDateFormat("yyyy-dd-MM'T'HH:mm:ss'Z'").format(new Date()));
		data.put("jobName", NslFileUploadConstants.IOS_VERSION_UPLOAD_REPORT);
		data.put("reportType", NslFileUploadConstants.IOS_VERSION_UPLOAD_REPORT);
		request.put("data", data);
		return request;
	}
}
