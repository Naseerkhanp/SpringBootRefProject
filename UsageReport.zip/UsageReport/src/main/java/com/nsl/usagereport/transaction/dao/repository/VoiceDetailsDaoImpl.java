package com.nsl.usagereport.transaction.dao.repository;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.transaction.entity.VoiceDetails;
import com.nsl.usagereport.uio.VoiceDetailsUIO;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component()
public class VoiceDetailsDaoImpl implements NslDao {
	@Autowired
	VoiceDetailsRepository voiceDetailsRepository;

	@Transactional
	@Override
	public void save(List<Object> voiceDetailsList) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<VoiceDetails> dataDetails = voiceDetailsList.stream().map(s -> (VoiceDetails) s)
					.collect(Collectors.toList());
			voiceDetailsRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

	@Transactional
	public List<VoiceDetailsUIO> getVoiceDetails(GetUsageReportDetails voiceUsageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		List<VoiceDetails> voiceDetailsLst = null;
		List<VoiceDetailsUIO> voiceDetailsUIOLST = null;
		Date startDate =null;
		Date enddate =null;
		try {
			if (voiceUsageReportDetails.getStartDate() != null && voiceUsageReportDetails.getEndDate() != null) {
				startDate = NslFileUploadUtils.convertStringToDate1(voiceUsageReportDetails.getStartDate());
				enddate = NslFileUploadUtils.convertStringToDate1(voiceUsageReportDetails.getEndDate());
			}
			if (voiceUsageReportDetails.getStartDate() == null && voiceUsageReportDetails.getEndDate() == null
					&& voiceUsageReportDetails.getImsi() == null) {
				voiceDetailsLst = voiceDetailsRepository
						.findDataByWithOutStartEnddateAndImsi(voiceUsageReportDetails.getMdn());
			} else if (voiceUsageReportDetails.getImsi() == null) {
				voiceDetailsLst = voiceDetailsRepository.findDataByDateWithOutOptional(voiceUsageReportDetails.getMdn(),
						startDate, enddate);
			} else if (voiceUsageReportDetails.getStartDate() == null && voiceUsageReportDetails.getEndDate() == null) {
				voiceDetailsLst = voiceDetailsRepository.findDataByMdnAndImsi(voiceUsageReportDetails.getMdn(),
						voiceUsageReportDetails.getImsi());
			} else {
				voiceDetailsLst = voiceDetailsRepository.findDataByDate(voiceUsageReportDetails.getMdn(), startDate,
						enddate, voiceUsageReportDetails.getImsi());
			}					
			/*voiceDetailsLst = ((voiceUsageReportDetails.getImsi() == null)
					? voiceDetailsRepository.findDataByDateWithOutOptional(voiceUsageReportDetails.getMdn(), startDate,
							enddate)
					: voiceDetailsRepository.findDataByDate(voiceUsageReportDetails.getMdn(), startDate, enddate,
							voiceUsageReportDetails.getImsi()));
			
			voiceDetailsLst = ((voiceUsageReportDetails.getStartDate() == null && voiceUsageReportDetails.getEndDate() == null )
					? voiceDetailsRepository.findDataByWithOutStartEnddate(voiceUsageReportDetails.getMdn())
					: voiceDetailsRepository.findDataByDate(voiceUsageReportDetails.getMdn(), startDate, enddate,
							voiceUsageReportDetails.getImsi()));*/			
			voiceDetailsUIOLST = voiceDetailsLst.stream().map(voiceDetails -> {
				VoiceDetailsUIO voiceDetailsUIO = new VoiceDetailsUIO();
				String convertedDate=NslFileUploadUtils.convertLongToDate(voiceDetails.getLocalCallStartDatetime().getTime());
				voiceDetailsUIO.setCallStart(convertedDate);
				voiceDetailsUIO.setTimeZone(voiceDetails.getGmtOffset());
				voiceDetailsUIO.setTechType(voiceDetails.getRecordType());
				voiceDetailsUIO.setCallType(voiceDetails.getCallType());
				voiceDetailsUIO.setMinutesOfUse(voiceDetails.getTotalMinutes());
				voiceDetailsUIO.setCallDirection(voiceDetails.getCallDirectionInd());
				voiceDetailsUIO.setOtherPartyNumber(voiceDetails.getOtherPartyNumber());
				voiceDetailsUIO.setFootprint(voiceDetails.getFootprintCode());
				voiceDetailsUIO.setToCountry(voiceDetails.getToCountryCode());
				voiceDetailsUIO.setFromCountry(voiceDetails.getFromCountryCode());
				return voiceDetailsUIO;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " getSmsDetails getVoiceDetails end .");
		return voiceDetailsUIOLST;
	}

}
