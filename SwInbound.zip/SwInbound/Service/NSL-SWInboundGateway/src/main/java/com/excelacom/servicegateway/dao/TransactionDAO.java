package com.excelacom.servicegateway.dao;

import com.excelacom.servicegateway.bean.RequestBean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.json.JSONObject;

public interface TransactionDAO {
	
	String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName);
		
	void insertMNORequestDetails(String request, String responseId);
	
	void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId, String transGroupId, String serviceName);
	
	String insertMNONBTransaction(String requestJson, String entityId,String transUId,String serviceName,String applicationName,String httpmethod,String source);
	
	String constructSubOrderJson(String request);
	
	String insertFallOut(String request, String response, String processPlanId, String processPlan,
			String serviceName, String taskName, String requestJson, String transId);
	
	void updateNorthBoundTransactionFailure(String transId,String entityId,String groupId,
			String processPlanId,String serviceName,String frameworkResponse);
	
	int mdnRetrieval(final String mdn);
	
	String insertTransaction(String requestJson, String entityId,String transUId,String serviceName);
	
	String validateBasicToken(String basicToken);

	String insertAsyncTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName,String reqType,String source, String refNo);
	
	String tokenCheck(String token);

	String constructSubOrderJson(String request, String responseId);
	
	String insertAsyncStatus(RequestBean requestBean, String response);
	
	boolean getStatusFromDB(String serviceName, String method);
	
	String insertMNOResponseDetails(RequestBean requestBean, String response, String responseId,
			String operationName);
	
	void insertBatchTransaction(JSONObject data,RequestBean requestBean);
	
	void insertBatchSchedulerTransaction(JSONObject data,RequestBean requestBean);
	     
	String getServiceURL(String ServiceName);
	
	String getRetailPlanCode(String mdn);
	
	int getRetailPlanCodeCount(String mdn);
	
	String getTransactionType(String refNo);
	
	String constructFinalResponse(String transactionId);
	
	int getHostMdnCount(String mdn);
	
	String getTransactionNameFromCSR(String mdn);
	
	String getAccountNumberFromCSR(String accountNumber);
	
	String getContextIdFromCSR(String contextId);
	
	String getAccountTypeFromCSR(String accountType);
	
	String getBillCycleDayFromCSR(String billCycleDay);
	
	String subOrderIdFromCSR(String subOrder);
	
	String lineIdFromCSR(String lineId);
	
	List<String>  getMdnValues(String mdn);
	
	String updateHostMDN(String hostMDN,String mdn);
	
	String getHOSTMDN(String refNo);
	
     List<Map<String, Object>> gethostmdnTransId(String mdn);
		
	String getmdnFromResponse(String transactionid);
    
	String getWholesalePlancode(String transactionid);
    
	List<Map<String, Object>> gethostmdnDetails(String hostmdn);
	
	int getTransidCountFromResponse(String transactionId);
	
	void updateRootID(String transactionId,String rootId );
	
	List<Map<String, Object>> getAdditionalValues(String referenceNumber);	
	
	String insertAccountDetails(String requests);
    
	int getAccountNumberCount(String accountNumber);
	
	int getLineIdCount(String lineid,String mdn,String accountNumber);
	

	int getLineMdn(String lineid,String mdn);
	
	
	int getLineIdDuplicateCount(String lineid);
	
	String getMDNStatus(String mdn);
	
	void insertMNODomainDetails(RequestBean requestBean);
	
	String verifyAccount(String accountNumber);
	
	String getMdnTransCount(String mdn);
	
	int mnoStatusCount(String refNo);
	
	void updateMNOStatus(String transId);

	List<Map<String, Object>> getActivateddatas(String refNo);
	
	void updatechangeMDNResponse(MapSqlParameterSource input);
	
	void updatechangeMDNRequest(MapSqlParameterSource input);

	List<Map<String, Object>> getLineInquiryDetailsFromMdn(String mdn);
	
	String getLineResponse(String transId);
	
	String getLineId(String mdn);
	
	String getLineAccountId(String mdn);
	
	public String getResponseMsg(String transId);
	
	Integer getMdnStatusCount(String mdn);

	String getHostMdnValue(String mdn);
	
	public String getFirstActivatedNetwork(String lineId);
	
	public String insertIntoTransLineAssoc(String request, String transId, String serviceName);
	
	String insertMNONBTransactionWithLoginId(String requestJson, String entityId,String transUId,String serviceName,String applicationName,String httpmethod,String source,String userLogin);
	
	String insertNorthBoundTransactionWithLoginId(String requestJson, String entityId, String transUId, String serviceName, String applicationName, String userLogin);
	
	List<Map<String, Object>> getAccountNumberUsingIccid(String iccid);
	
	void updateSearchEnvNorthBoundTransaction(String transId, String responseJson);
	
}
