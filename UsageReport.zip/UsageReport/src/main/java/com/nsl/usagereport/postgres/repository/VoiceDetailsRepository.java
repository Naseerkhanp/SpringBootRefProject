package com.nsl.usagereport.postgres.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.postgres.entity.VoiceDetails;

@Repository
@Transactional
public interface VoiceDetailsRepository extends JpaRepository<VoiceDetails, Integer> {
	@Query("select d from VOICE_DETAILS d where d.billingNumber = :billingNumber and date(d.localCallStartDatetime) between :startDate AND :endDate AND  d.imsi = :imsi")
	List<VoiceDetails> findDataByDate(@Param("billingNumber") long billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") long imsi);

	@Query("select d from VOICE_DETAILS d where d.billingNumber = :billingNumber and date(d.localCallStartDatetime) between :startDate  AND :endDate")
	List<VoiceDetails> findDataByDateWithOutOptional(@Param("billingNumber") long billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);
	
	@Query("select d from VOICE_DETAILS d where d.billingNumber = :billingNumber")
	List<VoiceDetails> findDataByWithOutStartEnddateAndImsi(@Param("billingNumber") long billingNumber);
	
	@Query("select d from VOICE_DETAILS d where d.billingNumber = :billingNumber AND  d.imsi = :imsi")
	List<VoiceDetails> findDataByMdnAndImsi(@Param("billingNumber") long billingNumber, @Param("imsi") long imsi);
	
	@Modifying
	@Query("delete from VOICE_DETAILS d where d.createdDate <= :startDate AND d.createdDate >=:endDate")
	void  deleteDataByDate(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
}
