package com.nsl.managelines.batch.bean.planmigration;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@Getter
@Setter
public class RefPlanMigration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer planMigrationId;

	private String deviceType;

	private String lineType;
	
	private String oldPlan;
	
	private String oldPlanCategory;

	private String oldPlanGroup;

	private String planSubCategory;
	
	private String newPlan;

	private String newPlanCategory;

	private String newPlanGroup;

	private String createdDate;

	private String createdBy;

	private String modifiedBy;

	private String modifiedDate;

}
