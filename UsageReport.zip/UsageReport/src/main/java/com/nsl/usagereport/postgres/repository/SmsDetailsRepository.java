package com.nsl.usagereport.postgres.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.postgres.entity.SmsDetails;

@Repository
@Transactional
public interface SmsDetailsRepository extends JpaRepository<SmsDetails, Integer> {
	@Query("select d from SMS_DETAILS d where d.billingNumber = :billingNumber and date(d.eventDateTime) >= :startDate AND date(d.eventDateTime) <= :endDate AND  d.imsi = :imsi")
	List<SmsDetails> findDataByDate(@Param("billingNumber") String billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") String imsi);

	@Query("select d from SMS_DETAILS d where d.billingNumber = :billingNumber and date(d.eventDateTime) >= :startDate AND date(d.eventDateTime) <= :endDate")
	List<SmsDetails> findDataByDateWithOutOptional(@Param("billingNumber") String billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

	@Modifying
	@Query("delete from SMS_DETAILS d where d.createdDate <= :startDate AND d.createdDate >=:endDate")
	void deleteDataByDate(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query("select d from SMS_DETAILS d where d.billingNumber = :billingNumber")
	List<SmsDetails> findDataByWithOutStartEnddateAndImsi(@Param("billingNumber") String billingNumber);

	@Query("select d from SMS_DETAILS d where d.billingNumber = :billingNumber AND  d.imsi = :imsi")
	List<SmsDetails> findDataByMdnAndImsi(@Param("billingNumber") String billingNumber, @Param("imsi") String imsi);
}
