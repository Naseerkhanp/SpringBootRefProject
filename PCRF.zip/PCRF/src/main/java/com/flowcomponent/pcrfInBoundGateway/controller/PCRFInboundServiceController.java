package com.flowcomponent.pcrfInBoundGateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.flowcomponent.pcrfInBoundGateway.constants.UtilityClass;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundProperties;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundQueueProperties;

@RestController
public class PCRFInboundServiceController {

	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Autowired
	InboundProperties inboundProperties;

	Logger LOGGER = LoggerFactory.getLogger(PCRFInboundServiceController.class);

	
	@RequestMapping(value = "#{inboundProperties.getGetPcrfUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String getPcrfServiceCall(@RequestBody String request)
	{
		LOGGER.info("GETPCRFSERVICE");
		String responseString = null;
		try {
		
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			LOGGER.info("Queue::::::::::::::"+inboundQueueProperties.getGetPcrfExchange()+" "+inboundQueueProperties.getGetPcrfQueue());;
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getGetPcrfExchange(),
					inboundQueueProperties.getGetPcrfQueue(), message);
			responseString = new String(result.getBody());
	}
		catch(Exception e) {
			LOGGER.error("Exception in GETPCRFSERVICE "+ e);
		}
		return responseString;
	}
	@RequestMapping(value = "#{inboundProperties.getDeletePcrfUrl()}", produces = MediaType.APPLICATION_JSON_VALUE,  consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String deletePcrfCall(@RequestBody String request)
	{
		LOGGER.info("DeletePCRFSERVICE");
		String responseString = null;
		try {
		
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getDeletePcrfExchange(),
					inboundQueueProperties.getDeletePcrfQueue(), message);
			responseString = new String(result.getBody());
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in DeletePCRFSERVICE "+ e);
		}
		return responseString;
	}
	@RequestMapping(value =  "#{inboundProperties.getCreatePcrfUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String createPcrfCall(@RequestBody String request)
	{
		LOGGER.info("CREATEPCRFSERVICE");
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getCreatePcrfExchange(),
					inboundQueueProperties.getCreatePcrfQueue(), message);
			responseString = new String(result.getBody());
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in mnoChangeMdnCall "+ e);
		}
		return responseString;
	}
	@RequestMapping(value =  "#{inboundProperties.getUpdatePcrfUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.POST)
	@ResponseBody
	public String updatePcrfServiceCall(@RequestBody String request)
	{
		LOGGER.info("UpdatePCRFSERVICE");
		String responseString = null;
		try {
		
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getUpdatePcrfExchange(),
					inboundQueueProperties.getUpdatePcrfQueue(), message);
			responseString = new String(result.getBody());
	}
		catch(Exception e) {
			LOGGER.error("Exception in UpdatePCRFSERVICE "+ e);
		}
		return responseString;
	}


}
