package com.excelacom.servicegateway.dao;

public interface TransactionDAO {

	String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName);

	void insertMNORequestDetails(String request, String responseId);

	void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId,
			String transGroupId, String serviceName);

	String insertMNONBTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName, String httpMethod, String source);
	
}
