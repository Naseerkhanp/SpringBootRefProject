package com.excelacom.servicegateway.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.StatusType;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.exception.NslCustomException;
import com.excelacom.servicegateway.exception.NslStatusCode;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;

@Component
public class ExternalServiceClient {

	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	private UtilityClass utilityClass;

	Logger LOGGER = LoggerFactory.getLogger(ExternalServiceClient.class);

	/**
	 * Gets the response from client.
	 *
	 * @param requestJson the request json
	 * @param transId     the trans id
	 * @param responseId  the response id
	 * @return the response from client
	 */
	public String getResponseFromClient(String requestJson, String transId, String responseId, String serviceName,
			String operationName) {
		String request = null;
		String entityId = "0";
		String url = inboundProperties.getRouterserviceurl();
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.insertMNORequestDetails(requestJson, responseId);
			}
		});
		LOGGER.info(" responseId :: " + responseId);
		LOGGER.info(" serviceName :: " + serviceName + "***operationName ***" + operationName);
		request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
				+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=emmSubscriberMetaData";
		LOGGER.info(" request :: " + request);
		String frameworkResponse = utilityClass.callRestAPI(request, url);
		LOGGER.info(" frameworkResponse :: " + frameworkResponse);
		String Id = frameworkResponse.substring(frameworkResponse.indexOf("~") + 1);
		String groupId = Id.substring(Id.indexOf("~") + 1);
		serviceName = groupId.substring(groupId.indexOf("~") + 1);
		groupId = groupId.substring(0, groupId.indexOf("~"));
		String processPlanId = Id.substring(0, Id.indexOf("~"));
		frameworkResponse = frameworkResponse.substring(0, frameworkResponse.indexOf("~"));
		asyncUpdateNorthBoundTransaction(transId, entityId, frameworkResponse, groupId, processPlanId, serviceName);
		return frameworkResponse;
	}

	/**
	 * Async update north bound transaction.
	 *
	 * @param responseId the response id
	 * @param entityId   the entity id
	 * @param respJson   the resp json
	 * @param grpId      the grp id
	 * @param processId  the process id
	 * @param servName   the serv name
	 */
	private void asyncUpdateNorthBoundTransaction(String responseId, String entityId, String respJson, String grpId,
			String processId, String servName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransaction(responseId + "", entityId, respJson, grpId, processId,
						servName);
			}
		});

	}

	@SuppressWarnings("unchecked")
	public void responseHeader(Exchange exchange) throws NslCustomException, NotAuthorizedException {

		try {

			String req = exchange.getIn().getBody(String.class);
			String codeStr = "";
			String status = "";
			if (req.startsWith("{")) {

				JSONObject reqJson = new JSONObject(req);
				Iterator<String> reqJsonItr = reqJson.keys();
				while (reqJsonItr.hasNext()) {
					String reqKey = reqJsonItr.next();
					if (Constants.DATA.equalsIgnoreCase(reqKey)) {
						JSONObject dataJson = (JSONObject) reqJson.get(reqKey);
						Iterator<String> dataJsonItr = dataJson.keys();
						while (dataJsonItr.hasNext()) {
							String dataKey = dataJsonItr.next();
							if (Constants.CODE.equalsIgnoreCase(dataKey)) {
								codeStr = dataJson.getString(dataKey);
							} else if (Constants.STATUS.equalsIgnoreCase(dataKey)) {
								status = dataJson.getString(dataKey);
							}
						}
					}
				}
				if (StringUtils.hasText(codeStr)) {
					int code = Integer.parseInt(codeStr);
					if (code >= 400 && code <= 600) {
						throw new NslCustomException(
								Response.status(new NslStatusCode(code, status)).entity(req).build());
					}
				} else {
					exchange.setOut(exchange.getIn());
				}

			} else {
				exchange.setOut(exchange.getIn());
			}

		} catch (Exception e) {
			if (e instanceof NslCustomException) {
				String authErrorResponse = ((NslCustomException) e).getResponse().getEntity().toString();
				StatusType info = ((NslCustomException) e).getResponse().getStatusInfo();
				throw new NslCustomException(Response.status(info).entity(authErrorResponse).build());
			}

		}

	}

}
