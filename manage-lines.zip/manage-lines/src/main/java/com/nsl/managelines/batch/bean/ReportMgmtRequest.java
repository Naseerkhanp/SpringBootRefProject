package com.nsl.managelines.batch.bean;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReportMgmtRequest {

	public MessageHeader messageHeader;

	public Data data;

	@JsonProperty("queryString")
	public Map<String, String> queryString = new HashMap<String, String>();

}
