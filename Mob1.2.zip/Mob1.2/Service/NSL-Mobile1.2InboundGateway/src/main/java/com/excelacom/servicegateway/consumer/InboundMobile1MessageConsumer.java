package com.excelacom.servicegateway.consumer;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.service.ExternalServiceClient;

/**
 * The Class In-bound Mobile2.0 Message Consumer.
 */
@Component
public class InboundMobile1MessageConsumer {

	/** The transaction service. */
	@Autowired
	private ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(InboundMobile1MessageConsumer.class);

	@RabbitListener(queues = "#{inboundQueueProperties.getNslUpdateCancelQueue()}", containerFactory = "getNslUpdateCancelRabbitListenerContainerFactory")
	public Message updateCancelResponse(Message msg) {
		LOGGER.info("Inside updateCancelResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String groupId = null;
		String serviceName = Constants.Updateacancel_SERVICENAME;
		String operationName = Constants.Updateacancel_OPERATIONNAME;
		String Id = null;
		String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "MNOUpdateCancel",
					"MNO");

			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getUpdateModifyQueue()}", containerFactory = "getUpdateModifyRabbitListenerContainerFactory")
	public Message updateModifyResponse(Message msg) {
		LOGGER.info("Inside UpdateModifyService method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		// String groupId = null;
		String serviceName = Constants.UpdateModify_SERVICENAME;
		String operationName = Constants.UpdateModify_OPERATIONNAME;
		// String Id = null;
		// String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "MNOUpdateModify",
					"MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}

		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnoLineHistoryInquiryServiceQueue()}", containerFactory = "getHmnoLineHistoryInquiryServiceRabbitListenerContainerFactory")
	public Message hmnoLineHistoryInquiryServiceCall(Message msg) {
		LOGGER.info("Inside hmnolinehistoryinquiryserviceCall::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.HMNOlinehistoryinquiryservice_SERVICENAME;
		String operationName = Constants.HMNOlinehistoryinquiryservice_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;

		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();

			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,
					"HMNOLineHistoryInquiry", "MNO");

			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {

			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getMnoportinInquiryQueue()}", containerFactory = "getMnoportinInquiryRabbitListenerContainerFactory")
	public Message mnoportinInquiry(Message msg) {
		LOGGER.info("Inside MnoportinInquiry method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.MnoPortin_SERVICENAME;
		String operationName = Constants.MnoPortin_OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();

			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "mnoportininquiry",
					"MNO");

			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnodeviceinquiryQueue()}", containerFactory = "getHmnoDeviceinquiryRabbitListenerContainerFactory")
	public Message HmnoDeviceInquiryResponse(Message msg) {
		LOGGER.info("Inside HmnoDeviceInquiryResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		// String groupId = null;
		String serviceName = Constants.HMNODEVICEINQUIRY_SERVICENAME;
		String operationName = Constants.HMNODEVICEINQUIRY_OPERATIONNAME;
		// String Id = null;
		// String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "DeviceInquiry", "MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnoChangeFeatureQueue()}", containerFactory = "getHmnoChangeFeatureRabbitListenerContainerFactory")
	public Message HmnoChangeFeatureResponse(Message msg) {
		LOGGER.info("Inside HmnoChangeFeatureResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		// String groupId = null;
		String serviceName = Constants.HMNOCHANGEFEATURE_SERVICENAME;
		String operationName = Constants.HMNOCHANGEFEATURE_OPERATIONNAME;
		// String Id = null;
		// String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "HMNOChangeFeature",
					"MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnoValidateSimQueue()}", containerFactory = "getHmnoValidateSimRabbitListenerContainerFactory")
	public Message HmnoValidateSimResponse(Message msg) {
		LOGGER.info("Inside HmnoValidateSimResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String groupId = null;
		String serviceName = Constants.HMNOVALIDATESIM_SERVICENAME;
		String operationName = Constants.HMNOVALIDATESIM_OPERATIONNAME;
		String Id = null;
		String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "HMNOValidateSim",
					"MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnodeviceinquiryAsyncQueue()}", containerFactory = "getHmnoDeviceinquiryAsyncRabbitListenerContainerFactory")
	public Message HmnoDeviceInquiryAsyncResponse(Message msg) {
		LOGGER.info("Inside HmnoDeviceInquiryAsyncResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		// String groupId = null;
		String serviceName = Constants.HMNODEVICEINQUIRYASYNC_SERVICENAME;
		String operationName = Constants.HMNODEVICEINQUIRYASYNC_OPERATIONNAME;
		// String Id = null;
		// String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "DeviceInquiryAsyn",
					"MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnochangepsimQueue()}", containerFactory = "getHmnoChangepsimRabbitListenerContainerFactory")
	public Message HmnoChangepSIMResponse(Message msg) {
		LOGGER.info("Inside HmnoChangepSIMResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		// String groupId = null;
		String serviceName = Constants.HMNOCHANGEPSIM_SERVICENAME;
		String operationName = Constants.HMNOCHANGEPSIM_OPERATIONNAME;
		// String Id = null;
		// String processPlanId = null;
		UUID uuid = null;
		String responseId = null;
		try {

			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "HMNOChangepsim",
					"MNO");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getMnoLineDetailsQueue()}", containerFactory = "getMnoLineDetailsRabbitListenerContainerFactory")
	public Message mnoLineDetailsCallResponse(Message msg) {
		LOGGER.info("Inside mnolineDetailsCall::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "lineinquiryservice";
		String operationName = "lineinquiryserviceworkflow";
		String transactionName = "line-details";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			String httpmethod = "GET";
			String source = "RestClient";
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, transactionName, "MNO",
					httpmethod, source);
			LOGGER.info("responseId::::" + responseId);
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(request, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in mnolineDetailsCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getActivateHotlineQueue()}", containerFactory = "getActivateHotlineRabbitListenerContainerFactory")
	public Message activateHotLineServiceCallResponse(Message msg) {
		LOGGER.info("Inside activateHotLineSubscriberServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "sp6MNOHotLineServiceWorkflow";
		String serviceName = "sp6MNOHotLineService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"ActivateHotlineSubscriberService", "MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in changeMDNRequestCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	// String sd=inboundQueueProperties.getSuspendSubscriberQueue()

	@RabbitListener(queues = "#{inboundQueueProperties.getSuspendSubscriberQueue()}", containerFactory = "suspendSubscriberRabbitListenerContainerFactory")
	public Message SuspendSubscriberQueueCallResponse(Message msg) {
		LOGGER.info("Inside SuspendSubscriberQueueCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "Sp4SuspendSubscriberWorkflow";
		String serviceName = "Sp4SuspendSubscriberService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "SuspendSubscriber",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in SuspendSubscriber" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getRestoreSubscriberQueue()}", containerFactory = "restoreSubscriberRabbitListenerContainerFactory")
	public Message restoreSubscriberCall(Message msg) {
		LOGGER.info("Inside restoreSubscriberCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "Sp4RestoreSubscribeWorkflow";
		String serviceName = "Sp4RestoreSubscriberflow";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "RestoreSubscriber",
					"null");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in restoreSubscriberCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getActivateSubscriberQueue()}", containerFactory = "activateSubscriberabbitListenerContainerFactory")
	public Message activateSubscriberServiceCallResponse(Message msg) {
		LOGGER.info("Inside activateSubscriberServiceCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "ActivateSubscriberSystemWorkflow";
		String serviceName = "ActivateSubscriberSystem";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"ActivateSubscriberService", "MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in activateSubscriberServiceCallResponse" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getActivatePortinSubscriberQueue()}", containerFactory = "activatePortinSubscriberabbitListenerContainerFactory")
	public Message activatePortServiceCallResponse(Message msg) {
		LOGGER.info("Inside activatePortServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "ActivatePortServiceWorkflow";
		String serviceName = "ActivatePortService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"MNOActivatePortInService","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in activatePortServiceCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getDeactivateSubscriberQueue()}", containerFactory = "activatePortinSubscriberabbitListenerContainerFactory")
	public Message deactivateSubscriberCallCallResponse(Message msg) {
		LOGGER.info("Inside deactivateSubscriberCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "DeactivateSubscriberService";
		String serviceName = "DeactivateSubscriberService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"DeactivateSubscriberService","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in deactivateSubscriberCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getResetfeatureQueue()}", containerFactory = "resetFeatureRabbitListenerContainerFactory")
	public Message resetfeatureResponse(Message msg) {
		LOGGER.info("Inside resetfeatureResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "resetfeatureserviceworkflow";
		String serviceName = "resetfeatureservice";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"HMNOResetFeature","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in deactivateSubscriberCall" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getOrderinquiryQueue()}", containerFactory = "orderInquiryRabbitListenerContainerFactory")
	public Message hmnoOrderInquiryServiceResponse(Message msg) {
		LOGGER.info("Inside hmnoOrderInquiryServiceResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "hmnoorderinquiryserviceworkflow";
		String serviceName = "hmnoorderinquiryservice";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"HMNOOrderInquiry","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in hmnoOrderInquiryServiceResponse" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getChangefeatureasyncQueue()}", containerFactory = "changeFeatureAsyncrabbitListenerContainerFactory")
	public Message hmnoChangeFeatureAsynResponse(Message msg) {
		LOGGER.info("Inside hmnoChangeFeatureAsynResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "ChangeFeatureAsyncRequestWorkflow";
		String serviceName = "ChangeFeatureAsyncRequest";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"HMNOChangeFeatureAsync","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in hmnoChangeFeatureAsynResponse" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getHmnochangepsimasyncQueue()}", containerFactory = "changePSimAsyncrabbitListenerContainerFactory")
	public Message hmnoChangePSimAsynResponse(Message msg) {
		LOGGER.info("Inside hmnoChangePSimAsynResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "ChangePSIMAsyncWorkflow";
		String serviceName = "ChangePSIMAsyncRequest";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"ChangePSIMAsyncRequest","MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in hmnoChangeFeatureAsynResponse" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	private void asyncInsertRequestDetails(String requestJson, String responseId) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.insertRequestDetails(requestJson, responseId);
			}
		});
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getChangeRatePlanQueue()}", containerFactory = "changeRatePlanrabbitListenerContainerFactory")
	public Message changeRatePlanCallResponse(Message msg) {
		LOGGER.info("Inside changeRatePlanCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "Sp5ChangeRatePlanWorkflow";
		String serviceName = "Sp5ChangeESNRatePlanRequest";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "ChangeRatePlanRequest",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in changeRatePlan" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getChangeMdnQueue()}", containerFactory = "changeMdnrabbitListenerContainerFactory")
	public Message changeMdnResponse(Message msg) {
		LOGGER.info("Inside changeMdnResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "changemdnrequestWorkflow";
		String serviceName = "Sp5changemdnrequest";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "ChangeMDNRequest",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in changeMdn" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getLineInquiryQueue()}", containerFactory = "lineInquiryrabbitListenerContainerFactory")
	public Message lineInquiryCallResponse(Message msg) {
		LOGGER.info("Inside lineInquiryCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "MnoLineInquiryWorkflow";
		String serviceName = "MnoLineInquiry";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "lineinquiryservice",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in LineInquiry" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getRemoveHotlineQueue()}", containerFactory = "removeHotlinerabbitListenerContainerFactory")
	public Message removeHotlineCallResponse(Message msg) {
		LOGGER.info("Inside removeHotlineCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "RemoveHotlineWorkflow";
		String serviceName = "Sp6MnoRemoveHotlineService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "RemoveHotlineService",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in RemoveHotlineService" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getUpdatePortoutQueue()}", containerFactory = "updatePortoutrabbitListenerContainerFactory")
	public Message updatePortoutCallResponse(Message msg) {
		LOGGER.info("Inside updatePortoutCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "mnoupdateportoutworkflow";
		String serviceName = "mnoupdateportout";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "MnoUpdatePortOutService",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in MnoUpdatePortOutService" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getUpdateDuedatePortinQueue()}", containerFactory = "updateDuedatePortinrabbitListenerContainerFactory")
	public Message updateDuedatePortinCallResponse(Message msg) {
		LOGGER.info("Inside updateDuedatePortinCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "MnoUpdateDueDateServiceWorkflow";
		String serviceName = "MnoUpdateDueDateService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "MNOUpdateDueDate",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in MNOUpdateDueDate" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getValidateMdnQueue()}", containerFactory = "validateMdnrabbitListenerContainerFactory")
	public Message validateMdnCallResponse(Message msg) {
		LOGGER.info("Inside validateMdnCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "mdnportabilityWorkflow";
		String serviceName = "MDNservice";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "mdnportability",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in SuspendSubscriber" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
	@RabbitListener(queues = "#{inboundQueueProperties.getValidateDeviceQueue()}", containerFactory = "validateDevicerabbitListenerContainerFactory")
	public Message validateDeviceCallResponse(Message msg) {
		LOGGER.info("Inside validateDeviceCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String operationName = "HmnoValidateDeviceWorkflow";
		String serviceName = "HmnoValidateDeviceService";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "HmnoValidateDevice",
					"MNO");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, serviceName,
					operationName);
			this.asyncInsertRequestDetails(exchange, responseId);
		} catch (Exception e) {
			LOGGER.error("Exception in SuspendSubscriber" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}



}
