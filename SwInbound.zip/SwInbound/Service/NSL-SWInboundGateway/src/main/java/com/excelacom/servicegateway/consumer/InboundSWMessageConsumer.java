package com.excelacom.servicegateway.consumer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.bean.RequestBean;
import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.queue.RabbitQueueService;
import com.excelacom.servicegateway.service.ExternalServiceClient;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The Class In-bound Mobile2.0 Message Consumer.
 */
@Component
public class InboundSWMessageConsumer {
	
	@Autowired
	private RabbitTemplate searchEnvironmentWaitCustomRabbitTemplate;

	/** The transaction service. */
	@Autowired
	private ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	RequestBean requestBean;

	@Autowired
	UtilityClass utilityClass;
	
	@Autowired
	RabbitQueueService rabbitQueueService;
	
	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(InboundSWMessageConsumer.class);

	/**
	 * Line inquiry method.
	 *
	 * @param msg the msg
	 * @return the message
	 */

	@RabbitListener(queues = "#{inboundQueueProperties.getWifiQueue()}", containerFactory = "wifirabbitListenerContainerFactory")
	public Message wifiCallResponse(Message msg) {
		LOGGER.info("Inside wifiResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "Get-Wifi-Address";
		String operationName = "swqueryaddressserviceworkflow";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			String requestURI = URLDecoder.decode(subrequest.split("_DELIM")[2], "UTF-8");
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "MBO";
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(requestURI, entityId, transId, "Get Wifi Address",
					"MNO", "GET", source);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	}

    @RabbitListener(queues = "#{inboundQueueProperties.getUpdateWifiQueue()}", containerFactory = "updateWifirabbitListenerContainerFactory")
	public Message updateWifiCallResponse(Message msg) {
		LOGGER.info("Inside wifiResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "Update-Wifi-Address";
		String operationName = "swupdateaddressserviceworkflow";
		JSONObject object1 = new JSONObject();
		JSONObject object4 = new JSONObject();
		JSONObject object5 = new JSONObject();
		JSONArray additionAttrArr = new JSONArray();
		JSONArray suborderArr = new JSONArray();
		String additionaAttrType = Constants.EMPTYSTRING;
		String additionaAttrValue = Constants.EMPTYSTRING;
		String requestTypeValue = Constants.EMPTYSTRING;
		String mdn = Constants.EMPTYSTRING;
		JSONArray mdnArr = new JSONArray();
		String mdnValue = Constants.EMPTYSTRING;
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			JSONObject object2 = new JSONObject(request);
			if (object2.has("messageHeader")) {
				object1 = object2.getJSONObject("messageHeader");
				if (object1.has("requestType")) {
					requestTypeValue = object1.getString("requestType");
				}
			}
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if (object1.has("subOrder")) {
					suborderArr = object1.getJSONArray("subOrder");
					if (suborderArr.length() >= 1) {
						object2 = suborderArr.getJSONObject(0);
					}
				}
				if (object1.has("additionalData")) {
					additionAttrArr = object1.getJSONArray("additionalData");
					object2 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object2);
					if (object2.has("name")) {
						additionaAttrType = object2.getString("name");
					}
					if (object2.has("value")) {
						additionaAttrValue = object2.getString("value");
					}
				}
				if (object2.has("mdn")) {
					mdnArr = object2.getJSONArray("mdn");
					if (mdnArr.length() >= 1) {
						object5 = mdnArr.getJSONObject(0);
						if (object5.has("value")) {
							mdn = object5.getString("value");
							System.out.println("mdn from request::" + mdn);
						}
					}
				}
			}
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Update Wifi Address",
					"MNO", "POST", source);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	}

	@RabbitListener(queues = "#{inboundQueueProperties.getValidateWifiQueue()}", containerFactory = "validateWifirabbitListenerContainerFactory")
	public Message validateWifiCallResponse(Message msg) {
		LOGGER.info("Inside wifiResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "Validate-Wifi-Address";
		String operationName = "swvalidateaddressserviceworkflow";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Validate Wifi Address",
					"MNO", "POST", source);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getChangeEsimQueue()}", containerFactory = "ChangeEsimrabbitListenerContainerFactory")
	public Message ChangeEsimResponse(Message msg) {
		LOGGER.info("Inside ChangeEsim");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = Constants.CHANGEESIM_SERVICENAME;;
		String operationName="";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			System.out.println("subrequest:::"+subrequest);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			String user = subrequest.split("_DELIM")[3];
			LOGGER.info("user:::"+user);
			if(request.contains("deviceId"))
			{
			
				operationName = Constants.CHANGEESIM_OPERATIONNAME;
			}
			else
			{
				
				operationName = Constants.SWCHANGEESIM_OPERATIONNAME;
				
			}
			System.out.println("service&&operation request::"+request);
			String requestURI = URLDecoder.decode(subrequest.split("_DELIM")[2], "UTF-8");
			LOGGER.info("Request for ChangeEsim Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransactionWithLoginId(request, entityId, transId, "ChangeESIM",
					"MNO",user);
		
			// For invoking flow-through
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSwWearableQueue()}", containerFactory = "swWearablerabbitListenerContainerFactory")
	public Message swWearableCallResponse(Message msg) {
		LOGGER.info("Inside wifiResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String requestTypeValue = "";
		JSONArray additionAttrArr = new JSONArray();
		String additionaAttrType = "";
		String additionaAttrValue = "";
		JSONObject object1 = new JSONObject();
		String serviceName = "Add-Wearable";
		String operationName = "AddWearableWF";
		
		JSONArray suborderArr = new JSONArray();
		JSONArray suborderArray = new JSONArray();
	
		JSONObject requestJsonObject =null;
		
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String user = subrequest.split("_DELIM")[2];
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			JSONObject object2 = new JSONObject(request);
			if(object2.has("messageHeader"))
			{
				object1 = object2.getJSONObject("messageHeader");
				if(object1.has("requestType"))
				{
					requestTypeValue = object1.getString("requestType");
				}
			}				
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if (object1.has("additionalData")) {
					additionAttrArr = object1.getJSONArray("additionalData");
					object2 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object2);
					if (object2.has("name")) {
						additionaAttrType = object2.getString("name");
					}
					if (object2.has("value")) {
						additionaAttrValue = object2.getString("value");
					}
				}
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			
			
			
			
			
		

			
			responseId = transactionDAO.insertMNONBTransactionWithLoginId(request, entityId, transId, "Add Wearable",
					"MNO", "POST", source,user);
			if (request.contains("&")) {
				
			
			
				request = request.replaceAll("&", "u+00000026");
				
			}
			
			
			

			if (request.contains("subOrder")) {
				requestJsonObject= new JSONObject(request);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					
					suborderArray=requestJsonObjectData.getJSONArray("subOrder");
					
					requestJsonObjectData=	suborderArray.getJSONObject(0).getJSONObject("address");
					
					if(requestJsonObjectData.has("city")) {
						requestJsonObjectData.put("addresscity",requestJsonObjectData.getString("city"));
						requestJsonObjectData.remove("city");

					}
					if(requestJsonObjectData.has("state")) {
						requestJsonObjectData.put("addressstate",requestJsonObjectData.getString("state"));
						requestJsonObjectData.remove("state");
						
						
						
					}
					
			      }
				
				request = requestJsonObject.toString();
				}
			
			
			/*
			 * if (request.contains("city")) { request = request.replace("city",
			 * addresscity); } if (request.contains("state")) { request =
			 * request.replace("state", addressstate); }
			 */
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSwRetrieveDeviceQueue()}", containerFactory = "swRetrieveDetailsRabbitListenerContainerFactory")
	public Message swRetrieveDeviceCallResponse(Message msg) {
		LOGGER.info("Inside swRetrieveDeviceCallResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String requestTypeValue = "";
		JSONArray additionAttrArr = new JSONArray();
		String additionaAttrType = "";
		String additionaAttrValue = "";
		JSONObject object1 = new JSONObject();
		String serviceName = "Retrieve-Device-Details";
		String operationName = "RetrieveDeviceDetailsWorkflow";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			JSONObject object2 = new JSONObject(request);
			if(object2.has("messageHeader"))
			{
				object1 = object2.getJSONObject("messageHeader");
				if(object1.has("requestType"))
				{
					requestTypeValue = object1.getString("requestType");
				}
			}				
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if (object1.has("additionalData")) {
					additionAttrArr = object1.getJSONArray("additionalData");
					object2 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object2);
					if (object2.has("name")) {
						additionaAttrType = object2.getString("name");
					}
					if (object2.has("value")) {
						additionaAttrValue = object2.getString("value");
					}
				}
			}
			LOGGER.info("Request for swRetrieveDeviceCallResponse Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Retrieve Device Details",
					"MNO", "POST", source);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			if (request.contains("transactionTimeStamp")) {
				request = request.replaceAll("transactionTimeStamp", "transactionTimeStampGd");
			}
			LOGGER.info("swRetrieveDeviceCallResponse transactionTimeStamp:::::" +request);
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	}

	@RabbitListener(queues = "#{inboundQueueProperties.getTransferWearableQueue()}", containerFactory = "transferWearablerabbitListenerContainerFactory")
	public Message transferWearableCallResponse(Message msg) {
		LOGGER.info("Inside wifiResponse");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String requestTypeValue = "";
		JSONArray additionAttrArr = new JSONArray();
		String additionaAttrType = "";
		String additionaAttrValue = "";
		JSONObject object1 = new JSONObject();
		String serviceName = Constants.TRANSFER_WEARABLE_SERVICE_NAME;
		String operationName = Constants.TRANSFER_WEARABLE_OPERATION_NAME;
		JSONArray suborderArr = new JSONArray();
		JSONArray suborderArray = new JSONArray();	
		JSONObject requestJsonObject =null;
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String user = subrequest.split("_DELIM")[2];
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			JSONObject object2 = new JSONObject(request);
			if(object2.has("messageHeader"))
			{
				object1 = object2.getJSONObject("messageHeader");
				if(object1.has("requestType"))
				{
					requestTypeValue = object1.getString("requestType");
				}
			}				
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if (object1.has("additionalData")) {
					additionAttrArr = object1.getJSONArray("additionalData");
					object2 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object2);
					if (object2.has("name")) {
						additionaAttrType = object2.getString("name");
					}
					if (object2.has("value")) {
						additionaAttrValue = object2.getString("value");
					}
				}
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransactionWithLoginId(request, entityId, transId, "Transfer Wearable",
					"MNO", "POST", source,user);			
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}			
			if (request.contains("subOrder")) {
				requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					suborderArray = requestJsonObjectData.getJSONArray("subOrder");
					if (suborderArray.length() != 0) {
						requestJsonObjectData = suborderArray.getJSONObject(0);//.getJSONObject("address");
						if (requestJsonObjectData != null && requestJsonObjectData.length() !=0) {
							if (requestJsonObjectData.has("address")) {
								JSONObject requestJsonObjectAddress=null;
								requestJsonObjectAddress=requestJsonObjectData.getJSONObject("address");
								if (requestJsonObjectAddress.has("city")) {
									requestJsonObjectAddress.put("addresscity", requestJsonObjectAddress.getString("city"));
									requestJsonObjectAddress.remove("city");
								}
								if (requestJsonObjectAddress.has("state")) {
									requestJsonObjectAddress.put("addressstate", requestJsonObjectAddress.getString("state"));
									requestJsonObjectAddress.remove("state");
								}
							}
						}
					}
				}
				request = requestJsonObject.toString();
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	} 

	private void getResponseFromClientAsync(String splitRequest, String transId, String responseId, String serName,
			String operationName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				String response = externalServiceClient.getResponseFromClient(splitRequest, transId, responseId, serName,operationName);
			}
		});		
	}

	public String jsonFormatter(String inputJson, StringBuilder res, StringBuilder subOrderCount, ArrayList aList) {
		String response = null;
		String type = "json";

		if ("json".equals(type)) {
			try {
				if (inputJson.startsWith("[")) {
					JSONArray jsonarr = new JSONArray(inputJson);
					for (int i = 0; i < jsonarr.length(); i++) {
						JSONObject obj = jsonarr.getJSONObject(i);
						response = "[{" + printJsonObject1(obj, res, subOrderCount, aList) + "}]";
						LOGGER.info("JsonArray Formatter Final Response:::" + response);
					}
				} else {
					JSONObject object = new JSONObject(inputJson);
					response = printJsonObject1(object, res, subOrderCount, aList);

					LOGGER.info("JsonObject Formatter Final Response:::" + response);
				}
			} catch (JSONException e) {
				LOGGER.error(e.getMessage());
			}
			return response;
		} else {
			response = inputJson;
			return response;
		}
	}
    
		public JSONArray jsonFormatterforBatch(String inputJson) {
		JSONArray response = new JSONArray();
		/*
		 * String type = inputType(inputJson); if ("json".equals(type)) {
		 */
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					// response ="[" + printJsonObject(obj, finalObj) +"]";
					response.put(printJsonforBatchObject(obj, finalObj));
					LOGGER.info("JsonArray Formatter Final Response:::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				// response ="[" + printJsonObject(object, finalObj) +"]";
				response.put(printJsonforBatchObject(object, finalObj));
				LOGGER.info("JsonObject Formatter Final Response:::" + response);
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage());
		}
		return response;
		/*
		 * } else { //response = inputJson; return response; }
		 */
	}
	
	public JSONObject printJsonforBatchObject(JSONObject jsonObj, JSONObject obj) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();

				Object keyvalue = jsonObj.get(keyStr);
				JSONObject object = null;

				if (!keyvalue.equals(null) && !(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)
						|| !keyvalue.equals(null) && "mdn".equalsIgnoreCase(keyStr)) {
					obj.put(keyStr, keyvalue);
				}
				if (keyvalue instanceof JSONObject && !"mdn".equalsIgnoreCase(keyStr)) {
					printJsonforBatchObject((JSONObject) keyvalue, obj);
				}
				if (keyvalue instanceof JSONArray && !"mdn".equalsIgnoreCase(keyStr)) {
					printJsonArrayforBatch((JSONArray) keyvalue, obj);
				}
				if("hotline".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONObject) {
						JSONObject hotLineObj= (JSONObject) keyvalue;
						for (int i = 0; i < hotLineObj.length(); i++) {
							String str = hotLineObj.toString();
							System.out.println("STRING BEFORE FOTMAT"+str);
							str = str.replace("type","hotlineType");
							System.out.println("STRING FOTMAT"+str);
							object = new JSONObject(str);
						}
					}
					if (object != null) {
						keyvalue = object;

						printJsonforBatchObject((JSONObject) keyvalue, obj);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return obj;
	}
	
	public String printJsonArrayforBatch(JSONArray array, JSONObject obj) {
		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				printJsonforBatchObject(jsonObject1, obj);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}
	
	public String printJsonObject1(JSONObject jsonObj, StringBuilder res, StringBuilder subOrderCount,
			ArrayList aList) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();

				Object keyvalue = jsonObj.get(keyStr);

				if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
					// obj.put(keyStr, keyvalue.toString());
					res.append("\"");
					res.append(keyStr).append("\":\"").append(keyvalue.toString()).append("\",");
				}
				if (keyvalue instanceof JSONObject) {
					res.append("\"");
					res.append(keyStr).append("\":{");
					printJsonObject1((JSONObject) keyvalue, res, subOrderCount, aList);
					//
					res.append("},");
				}
				if (keyvalue instanceof JSONArray) {
					if (keyStr.equalsIgnoreCase("subOrder")) {
						JSONArray subOrder = new JSONArray(jsonObj.get(keyStr).toString());
						subOrderCount.append(subOrder.length());
						for (int i = 0; i < subOrder.length(); i++) {
							if (!aList.contains(i)) {
								aList.add(i);
								res.append("\"").append(keyStr).append("\":[{");
								printJsonObject1((JSONObject) subOrder.getJSONObject(i), res, subOrderCount, aList);
								String subRes = res.substring(0, res.length() - 1);
								res.replace(0, res.length(), subRes);
								res.append("}],");
								break;
							}
						}
					} else {
						res.append("\"").append(keyStr).append("\":[");
						printJsonArray1((JSONArray) keyvalue, res, subOrderCount, aList);
						String subRes = res.substring(0, res.length() - 1);
						res.replace(0, res.length(), subRes);
						res.append("],");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return res.toString();
	}

	public String printJsonArray1(JSONArray array, StringBuilder res, StringBuilder subOrderCount, ArrayList aList) {
		try {
			LOGGER.info("res.length()::::" + res.length());
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				res.append("{");
				printJsonObject1(jsonObject1, res, subOrderCount, aList);
				String subRes = res.substring(0, res.length() - 1);
				res.replace(0, res.length(), subRes);
				res.append("},");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	public String jsonFormat(String inputJson) {
		LOGGER.info("inputJson:::::" + inputJson);
		String response = null;
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					response = "[" + printJsonObject(obj, finalObj) + "]";
					LOGGER.info("JsonArray Formatter Final Response:::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				response = "[" + printJsonObject(object, finalObj) + "]";
				LOGGER.info("JsonObject Formatter Final Response:::" + response);
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	public String printJsonObject(JSONObject jsonObj, JSONObject obj) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();

				Object keyvalue = jsonObj.get(keyStr);

				if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
					obj.put(keyStr, keyvalue.toString());
				}
				if (keyvalue instanceof JSONObject) {
					printJsonObject((JSONObject) keyvalue, obj);
				}
				if (keyvalue instanceof JSONArray) {
					printJsonArray((JSONArray) keyvalue, obj);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return obj.toString();
	}

	public String printJsonArray(JSONArray array, JSONObject obj) {
		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				printJsonObject(jsonObject1, obj);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	private void asyncUpdateNorthBoundTransaction(String responseId, String entityId, String respJson, String grpId,
			String processId, String servName,String frameworkResponse) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				try{
				transactionDAO.updateNorthBoundTransaction(responseId, entityId, respJson, grpId, processId, servName);
				}
				catch( Exception e){
					transactionDAO.updateNorthBoundTransactionFailure(responseId, entityId, grpId, processId, servName, frameworkResponse);
			LOGGER.error(e.getMessage(), e);
				}
			}
		});
	}

	public String invokeRuleSystem(String request, String serName) {
		String data = null;
		HttpURLConnection connection = null;
		BufferedReader in = null;
		String inputLine = null;
		// String request="";
		String finResponse = "";
		String outputString = Constants.EMPTYSTRING;
		String url = inboundProperties.getRuleurl();
		//url ="http://10.90.3.179:7020/century/nsl/rule/businessRuleServices/nsl-rule-server/";
		HttpURLConnection conn = null;
		URL serviceUrl = null;
		try {
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			if (serName =="RestoreServiceRequest" ||serName =="suspenddeactivatehotlinesubscriberservice" || serName=="Reconnect-Subscriber" || serName=="Manage-Subscriber") {
				LOGGER.info("splitterServiceMetaData");
				serviceUrl = new URL(url + "splitterServiceMetaData");
			} else {
				LOGGER.info("activateSubscriberServiceMetaData");
				serviceUrl = new URL(url + "activateSubscriberServiceMetaData");
			}
			conn = (HttpURLConnection) serviceUrl.openConnection();
			request = "[json=" + request + "&serviceName=" + serName + "]";
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in1 = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in1.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
			LOGGER.info("\nResponse XML from Rule System:\n" + outputString
					+ "\n-----------------------------------------\n");
		} catch (Exception e4) {
			LOGGER.error("Exception ===>" + e4.getMessage());
		}
		if (outputString != null) {
			return outputString;
		} else {
			return null;
		}
	}

	

	public String jsonFormatter(String inputJson) {
		LOGGER.info("inputJson:::::" + inputJson);
		String response = null;
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					response = "[" + printJsonObject(obj, finalObj) + "]";
					LOGGER.info("JsonArray Formatter Final Response:::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				response = "[" + printJsonObject(object, finalObj) + "]";
				LOGGER.info("JsonObject Formatter Final Response:::" + response);
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage());
		}
		return response;
	}

	public boolean isValidJson(String inputJson) {
		System.out.println("inputJson:::::" + inputJson);
		String response = "";
		try {
			String type = inputType(inputJson);
			if ("json".equals(type)) {
				LOGGER.info("Inside Json");
				if (inputJson.startsWith("[")) {
					JSONArray jsonarr = new JSONArray(inputJson);
					if (jsonarr != null && jsonarr.length() > 0) {
						return true;
					}

				} else {
					JSONObject object = new JSONObject(inputJson);

					if (object != null && object.length() > 0) {
						return true;
					}
				}
			} else if ("XML".equals(type)) {
				LOGGER.info("Inside XML");
				return true;
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage());
			System.out.println("jsonFormatterforRequest.............." + inputJson);
			// response =false;
			return false;
		}
		return false;
	}

	private String inputType(String ipData) {

		if (!utilityClass.isEmpty(ipData) && ipData.trim().startsWith("<")) {
			return "XML";
		} else if (!utilityClass.isEmpty(ipData) && (ipData.trim().startsWith("[") || ipData.trim().startsWith("{"))) {
			return "json";
		}

		return "INVALID_TYPE";
	}

	//@RabbitListener(queues = "#{inboundQueueProperties.getRestoreHostMdnQueue()}", containerFactory = "restoreHostMdnrabbitListenerContainerFactory")
	/*public Message restoreHostMdnResponse(Message msg) {
		String response = Constants.EMPTYSTRING ;
		String serName = Constants.RESTORESERVICE_SERVICENAME;
		String operationName = Constants.RESTORESERVICE_OPERATIONNAME;
        String serviceName = "RestoreServiceRequest~Smartwatch"; 
		String responseId = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request="";
			if(subrequest.contains("~"))
			{
				 request = subrequest.split("~")[0];	
				String responseIdNew=subrequest.split("~")[1];
				responseId=responseIdNew.split("_DELIM")[0];
				LOGGER.info("RESPONSE::",responseId);
				
			}
			else
			{
			request = subrequest.split("_DELIM")[0];
			}
			// String serviceName = "ReconnectSubscriber";
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "MBO";
			}
			//responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Reconnect Subscriber",
				//	"MNO", "POST", source);
			response = this.splitterServiceCall(request, serName, operationName, serviceName, responseId, transId);
			if (response != null && response.contains("InvalidJson")) {
				String err = response.split("=")[1];
				LOGGER.info("response error" + err);
				response = "{\"messageHeader\":{\"serviceId\":\"SPECTRUM_MOBILE\",\"requestType\":\"MNO\",\"referenceNumber\":\""
						+ err
						+ "\"},\"data\":{\"code\":\"400\",\"status\":\"Bad Request\",\"reason\":\"Invalid JSON request\",\"message\":[{\"responseCode\":\"ERR01\",\"description\":\"Invalid JSON format\"}]}}";
			} else if(response == null) {
				response = "";
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	} */
	
	
	
	
	
	//@RabbitListener(queues = "#{inboundQueueProperties.getSuspendDeactiveHostMdnQueue()}", containerFactory = "SuspendDeactiveHostMdnrabbitListenerContainerFactory")
	/*public Message SuspendDeactiveMDN(Message msg) {
		String serName = Constants.SUSPENDDEACTIVESUB_SERVICENAME;
		String operationName = Constants.SUSPENDDEACTIVESUB_OPERATIONNAME;
		String serviceName = "SuspendDeactivateHotlineSubscriber~Smartwatch";
		String response = Constants.EMPTYSTRING;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request="";
			if(subrequest.contains("~"))
			{
				 request = subrequest.split("~")[0];	
				String responseIdNew=subrequest.split("~")[1];
				responseId=responseIdNew.split("_DELIM")[0];
				LOGGER.info("RESPONSE::",responseId);
				
			}
			else
			{
			request = subrequest.split("_DELIM")[0];
			}
			LOGGER.info("Request for updatePortOut Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "MBO";
			}
			//responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Manage Subscriber", "MNO",
				//	"POST", source);
			response = this.splitterServiceCall(request, serName, operationName, serviceName, responseId, transId);
			if (response != null && response.contains("InvalidJson")) {
				String err = response.split("=")[1];
				LOGGER.info("response error" + err);
				response = "{\"messageHeader\":{\"serviceId\":\"SPECTRUM_MOBILE\",\"requestType\":\"MNO\",\"referenceNumber\":\""
						+ err
						+ "\"},\"data\":{\"code\":\"400\",\"status\":\"Bad Request\",\"reason\":\"Invalid JSON request\",\"message\":[{\"responseCode\":\"ERR01\",\"description\":\"Invalid JSON format\"}]}}";
			} else if(response == null) {
				response = "";
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}*/
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getTransferWearableAsyncQueue()}", containerFactory = "transferWearableAsyncRabbitListenerContainerFactory")
	public Message transferWearableAsync(Message msg) {
		LOGGER.info("Inside transferWearableAsync");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.AddwearableAsyncTW;
		String operationName =Constants.AddwearableAsyncTWWorkflow;
		UUID uuid = null;
		String responseId = null;
		String refNo = null;
		String source = null;
		String servName="";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "MBO";
			}
			/* if(request.contains("Wear01le")){
				request=request.replace("Wear01le","");
			} */
			LOGGER.info("Request for Tw wearable Service : " + request);
			JSONObject obj = new JSONObject(request);
			JSONObject messageHeaderObj = null;
			JSONObject mdnDetail = null;
			String mdn="";
			String iccid="";
			String imei="";			
			String deviceId="";
			if (obj.has("messageHeader")) {
				messageHeaderObj = obj.getJSONObject("messageHeader");
				if (messageHeaderObj.has("referenceNumber")) {
					refNo = messageHeaderObj.getString("referenceNumber");
					requestBean.setReferenceNumber(refNo);
					System.out.println("refNo" + refNo);
				}
			}
			if (obj.has("asyncResponse")) {
				messageHeaderObj = obj.getJSONObject("asyncResponse");
				if (messageHeaderObj.has("mdn")) {
					mdn = messageHeaderObj.getString("mdn");
					requestBean.setMdn(mdn);
					LOGGER.info("mdn  " + mdn);
				}
				if (messageHeaderObj.has("iccid")) {
					iccid = messageHeaderObj.getString("iccid");
					requestBean.setIccid(iccid);
					LOGGER.info("iccid  " + iccid);
				}
				if (messageHeaderObj.has("imei")) {
					imei = messageHeaderObj.getString("imei");
					requestBean.setImei(imei);
					LOGGER.info("imei  " + imei);
				}
				if (messageHeaderObj.has("deviceId")) {
					deviceId = messageHeaderObj.getString("deviceId");
					requestBean.setImei(deviceId);
					LOGGER.info("deviceId  " + deviceId);
				}
				//servName="AsyncService";
			} if (request.contains("asyncResponseProg")) {
				serviceName = Constants.MNOASYNCPROGRAMMINGSERVICE;
				operationName = Constants.MNOASYNCPROGRAMMINGWF;
			}
			servName="AsyncService";
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			// responseId = transactionDAO.insertMNONBTransaction(request, entityId,
			// transId, "Sim-inquiry", "MNO", "GET", source);
			LOGGER.info("Calling insertAsyncTransaction with :: request = " + request + " :: entityId = " + entityId + " :: transId = " + transId
				 + " :: source = " + source + " :: refNo = " + refNo);
			responseId = transactionDAO.insertAsyncTransaction(request, entityId, transId, servName, "MNO","GET",source, refNo);
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName, operationName);
			String responseValue = jsonFormatter(response);
			transactionDAO.insertAsyncStatus(requestBean, responseValue);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	
	
	
	
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getLoginauthwsQueue()}", containerFactory = "loginauthwsrabbitListenerContainerFactory")
	public Message loginauthwsCallResponse(Message msg) {
		LOGGER.info("Inside loginauthws");
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String requestTypeValue = "";
		JSONArray additionAttrArr = new JSONArray();
		String additionaAttrType = "";
		String additionaAttrValue = "";
		JSONObject object1 = new JSONObject();
		String serviceName = Constants.LOGINAUTH_SERVICE_NAME;
		String operationName = Constants.LOGINAUTH_OPERATION_NAME;
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String user = subrequest.split("_DELIM")[2];
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			JSONObject object2 = new JSONObject(request);
			if(object2.has("messageHeader"))
			{
				object1 = object2.getJSONObject("messageHeader");
				if(object1.has("requestType"))
				{
					requestTypeValue = object1.getString("requestType");
				}
			}				
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if (object1.has("additionalData")) {
					additionAttrArr = object1.getJSONArray("additionalData");
					object2 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object2);
					if (object2.has("name")) {
						additionaAttrType = object2.getString("name");
					}
					if (object2.has("value")) {
						additionaAttrValue = object2.getString("value");
					}
				}
			}
			LOGGER.info("Request for Mnopromotion Service : " + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransactionWithLoginId(request, entityId, transId, "loginAuthService",
					"MNO", "POST", source,user);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

	} 
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSearchEnvironmentQueue()}", containerFactory = "searchEnvironmentrabbitListenerContainerFactory")
	public Message searchEnvironmentCallResponse(Message msg) {
		LOGGER.info("Inside searchEnvironmentCallResponse");
		String response = null;
		String responseSE = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "Search-Environment";
		String operationName = "SearchEnvironmentWF";
		JSONObject object1 = new JSONObject();
		JSONObject object4 = new JSONObject();
		JSONObject object5 = new JSONObject();
		JSONObject object6 = new JSONObject();
		JSONArray additionAttrArr = new JSONArray();
		JSONArray suborderArr = new JSONArray();
		JSONArray simIdArr = new JSONArray();
		String additionaAttrType = Constants.EMPTYSTRING;
		String additionaAttrValue = Constants.EMPTYSTRING;
		String requestTypeValue = Constants.EMPTYSTRING;
		String mdn = Constants.EMPTYSTRING;
		String type = Constants.EMPTYSTRING;
		String value = Constants.EMPTYSTRING;
		JSONArray mdnArr = new JSONArray();
		String mdnValue = Constants.EMPTYSTRING;
		String extInquiry = "";
		try {
			byte[] body = msg.getBody();
			String subrequest = new String(body);
			String source = subrequest.split("_DELIM")[1];
			String request = subrequest.split("_DELIM")[0];
			if (source.contains("insomnia")) {
				source = "RestClient";
			} else if (source.contains("postman") || source.contains("Postman")) {
				source = "RestClient";
			} else {
				source = "BSS";
			}
			LOGGER.info("Request for searchEnvironment Service : " + request);
			JSONObject object2 = new JSONObject(request);
			JSONObject object7 = new JSONObject(request);
			if (object2.has("messageHeader")) {
				object1 = object2.getJSONObject("messageHeader");
				if (object1.has("requestType")) {
					requestTypeValue = object1.getString("requestType");
				}
			}
			if (object2.has("data")) {
				object1 = object2.getJSONObject("data");
				if(object1.has("extInquiry")) {
					extInquiry = object1.getString("extInquiry");
				}
				if (object1.has("subOrder")) {
					suborderArr = object1.getJSONArray("subOrder");
					if (suborderArr.length() >= 1) {
						object2 = suborderArr.getJSONObject(0);
					}
					if (object2.has("simId")) {
						simIdArr = object2.getJSONArray("simId");
						if (simIdArr.length() >= 1) {
							object5 = simIdArr.getJSONObject(0);
							if (object5.has("type")) {
								type = object5.getString("type");
								System.out.println("type from request::" + type);
							}
							if (object5.has("value")) {
								value = object5.getString("value");
								System.out.println("value from request::" + value);
							}
						}
					}

				}
			}
			if (object7.has("additionalData")) {
				additionAttrArr = object7.getJSONArray("additionalData");
				if (!additionAttrArr.isNull(0)) {
					object6 = additionAttrArr.getJSONObject(0);
					System.out.println("newObj additionAttrArr::" + object6);
					if (object6.has("name")) {
						additionaAttrType = object6.getString("name");
					}
					if (object6.has("value")) {
						additionaAttrValue = object6.getString("value");
					}
				}
			}
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertMNONBTransaction(request, entityId, transId, "Search Environment", "MNO",
					"POST", source);
			if (request.contains("&")) {
				request = request.replaceAll("&", "u+00000026");
			}
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, serviceName,
					operationName);
			LOGGER.info("before if framework response:::"+response);
			if (!(response.contains("\"code\":\"400\"") || response.contains("\"reason\":\"Bad Request\""))) {
				LOGGER.info("Inside if success search ENV framework response:::" + response);
				if (extInquiry != null && !"".equalsIgnoreCase(extInquiry) && response != null
						&& !"".equalsIgnoreCase(response)
						&& (extInquiry.equalsIgnoreCase("TRUE") || extInquiry.equalsIgnoreCase("YES")
								|| extInquiry.equalsIgnoreCase("Y")
								|| (response.contains("\"returnCode\":\"00\"") && response
										.contains("\"returnMessage\":\"SUCCESSFULLY PROCESSED THE REQUEST\"")))) {
					// Thread.sleep(5000);
					LOGGER.info("inside if framework response:::" + response);
					String queueName = "SEARCH_ENV_WAIT_QUEUE_" + responseId;
					String routingKey = "SEARCH_ENV_WAIT_TRANSACTIONID_" + responseId;
					Boolean queueCreated = rabbitQueueService.addNewQueue(queueName, routingKey);

					if (queueCreated) {
						LOGGER.info("SENDING Queue:::"+ queueCreated);
						Object queueResponse = searchEnvironmentWaitCustomRabbitTemplate.receiveAndConvert(queueName,
								30000L);
						LOGGER.info("Queue response from outbound:::" + queueResponse);
						String json = new Gson().toJson(queueResponse);
						LOGGER.info("Queue response to json:::" + json);
						responseSE = json;
						LOGGER.info("json to responseSE:::" + responseSE);
						if (responseSE.startsWith("[")) {
							LOGGER.info("Inside if json as array:::" + responseSE);
							JSONArray obj = new JSONArray(responseSE);
							LOGGER.info("after json as obj:::" + obj);
							JSONObject data = new JSONObject();
							data = obj.getJSONObject(0);
							LOGGER.info("after json as data:::" + data);
							if (data.has("searchEnvironment")) {
								data = data.getJSONObject("searchEnvironment");
								LOGGER.info("Inside searchEnvironment response data:::" + data);
							}
							responseSE = data.toString();
							LOGGER.info("data to responseSE json:::" + responseSE);
						}
						LOGGER.info("Queue response:::" + responseSE);
						if (responseSE != null) {
							try {
								LOGGER.info("Queue response inside not null:::" + responseSE);
								transactionDAO.updateSearchEnvNorthBoundTransaction(responseId, responseSE);
								LOGGER.info("Queue response to json:::" + json);
							} catch (Exception e) {
								LOGGER.error("response error:::", e);
							}
						}
						response = responseSE;
						LOGGER.info("Final Queue response:::" + response);
					}
				}

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		LOGGER.info("before return to controller:::"+response);
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	
	
	
	
	
	
	
	

}
