package com.excelacom.servicegateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;


@RestController
//@RequestMapping(value = "#{inboundProperties.getCbrspcrfendpoint()}")
public class CBRSInboundServiceController {	
	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;
	
	@Autowired
	private InboundQueueProperties inboundQueueProperties;
	
	@Autowired
	InboundProperties inboundProperties;
	
	Logger LOGGER = LoggerFactory.getLogger(CBRSInboundServiceController.class);


	@RequestMapping(value = "#{inboundProperties.getCbrsSuspendUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, 
			method = RequestMethod.POST)
	@ResponseBody
	public String CBRSSuspendServiceCall(@RequestBody String request) {
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getCbrssuspendExchange(), inboundQueueProperties.getCbrssuspendQueue(), message);
			responseString = new String(result.getBody());
	}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getCbrsRestoreUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, 
			method = RequestMethod.POST)
	@ResponseBody
	public String CBRSRestoreServiceCall(@RequestBody String request) {
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getCbrsrestoreExchange(), inboundQueueProperties.getCbrsrestoreQueue(), message);
			responseString = new String(result.getBody());
	}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}

	
	@RequestMapping(value = "#{inboundProperties.getCbrsDeleteUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, 
			method = RequestMethod.POST)
	@ResponseBody
	public String CBRSDeleteServiceCall(@RequestBody String request) {
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getCbrsdeleteExchange(), inboundQueueProperties.getCbrsdeleteQueue(), message);
			responseString = new String(result.getBody());
	}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}
	
	
	@RequestMapping(value = "#{inboundProperties.getPrepareProfileMustangUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, 
			method = RequestMethod.POST)
	@ResponseBody
	 public String PrepareProfileCall(@RequestBody String request) {
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getPrepareprofilemustangExchange(), inboundQueueProperties.getPrepareprofilemustangQueue(), message);
			responseString = new String(result.getBody());
	}
		catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;		
	}	
}
