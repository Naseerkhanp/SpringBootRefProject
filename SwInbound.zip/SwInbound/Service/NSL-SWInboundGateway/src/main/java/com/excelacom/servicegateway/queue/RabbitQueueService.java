package com.excelacom.servicegateway.queue;

public interface RabbitQueueService {

	Boolean addNewQueue(String queueName, String routingKey);

}
