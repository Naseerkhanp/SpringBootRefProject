package com.nsl.usagereport.datahandler;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.transaction.entity.RefFileUpload;

@Component
public interface Handler {

	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber, List<RefFileUpload> fileUploadLst, UsageReportDetails usageReportDetails) throws Exception;

}
