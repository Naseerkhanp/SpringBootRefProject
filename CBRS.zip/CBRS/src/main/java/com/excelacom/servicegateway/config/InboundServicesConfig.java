package com.excelacom.servicegateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.util.ErrorHandler;

import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import com.excelacom.servicegateway.properties.InboundQueueProperties;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;
	
	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;
	
	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}
	
	@Bean
	public ErrorHandler errorHandler() {
		return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}
	 
	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
		return new CustomFatalExceptionStrategy();
	}

	@Bean
	public Queue cbrsSuspendQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getCbrssuspendQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange cbrsSuspendExchange() {
		return new DirectExchange(inboundQueueProperties.getCbrssuspendExchange());
	}

	@Bean
	Binding cbrsSuspendBinding() {
		return BindingBuilder.bind(cbrsSuspendQueue()).to(cbrsSuspendExchange())
				.with(inboundQueueProperties.getCbrssuspendQueue());
	}

	@Bean
	public Queue cbrsRestoreQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getCbrsrestoreQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange cbrsRestoreExchange() {
		return new DirectExchange(inboundQueueProperties.getCbrsrestoreExchange());
	}

	@Bean
	Binding cbrsRestoreBinding() {
		return BindingBuilder.bind(cbrsRestoreQueue()).to(cbrsRestoreExchange())
				.with(inboundQueueProperties.getCbrsrestoreQueue());
	}

	@Bean
	public Queue cbrsDeleteQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getCbrsdeleteQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange cbrsDeleteExchange() {
		return new DirectExchange(inboundQueueProperties.getCbrsdeleteExchange());
	}

	@Bean
	Binding cbrsDeleteBinding() {
		return BindingBuilder.bind(cbrsDeleteQueue()).to(cbrsDeleteExchange())
				.with(inboundQueueProperties.getCbrsdeleteQueue());
	}

	@Bean
	public Queue prepareprofilemustangQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getPrepareprofilemustangQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange prepareprofilemustangExchange() {
		return new DirectExchange(inboundQueueProperties.getPrepareprofilemustangExchange());
	}

	@Bean
	Binding preparerofilemustangBinding() {
		return BindingBuilder.bind(prepareprofilemustangQueue()).to(prepareprofilemustangExchange())
				.with(inboundQueueProperties.getPrepareprofilemustangQueue());
	}

	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	
    
	@Bean
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}

	@Bean()
    RabbitAdmin CbrsSuspendRabbitAdmin(){
        return new RabbitAdmin(CbrsSuspendrabbitMQConnectionFactory());
    };
    
	@Bean(name = "CbrsSuspendConnectionFactory")
	public ConnectionFactory CbrsSuspendrabbitMQConnectionFactory() {
		CachingConnectionFactory CbrsSuspendconnectionFactory = new CachingConnectionFactory(host);
		CbrsSuspendconnectionFactory.setPort(Integer.parseInt(port));
		CbrsSuspendconnectionFactory.setUsername(username);
		CbrsSuspendconnectionFactory.setPassword(password);
		CbrsSuspendconnectionFactory.setConnectionTimeout(30000);
		return CbrsSuspendconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin CbrsRestoreRabbitAdmin(){
        return new RabbitAdmin(CbrsRestorerabbitMQConnectionFactory());
    };
    
	@Bean(name = "CbrsRestoreConnectionFactory")
	public ConnectionFactory CbrsRestorerabbitMQConnectionFactory() {
		CachingConnectionFactory CbrsRestoreconnectionFactory = new CachingConnectionFactory(host);
		CbrsRestoreconnectionFactory.setPort(Integer.parseInt(port));
		CbrsRestoreconnectionFactory.setUsername(username);
		CbrsRestoreconnectionFactory.setPassword(password);
		CbrsRestoreconnectionFactory.setConnectionTimeout(30000);
		return CbrsRestoreconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin CbrsDeleteRabbitAdmin(){
        return new RabbitAdmin(CbrsDeleterabbitMQConnectionFactory());
    };
    
	@Bean(name = "CbrsDeleteConnectionFactory")
	public ConnectionFactory CbrsDeleterabbitMQConnectionFactory() {
		CachingConnectionFactory CbrsDeleteconnectionFactory = new CachingConnectionFactory(host);
		CbrsDeleteconnectionFactory.setPort(Integer.parseInt(port));
		CbrsDeleteconnectionFactory.setUsername(username);
		CbrsDeleteconnectionFactory.setPassword(password);
		CbrsDeleteconnectionFactory.setConnectionTimeout(30000);
		return CbrsDeleteconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin PrepareProfileMustangRabbitAdmin(){
        return new RabbitAdmin(PrepareProfileMustangrabbitMQConnectionFactory());
    };
    
	@Bean(name = "PrepareProfileMustangConnectionFactory")
	public ConnectionFactory PrepareProfileMustangrabbitMQConnectionFactory() {
		CachingConnectionFactory PrepareProfileMustangconnectionFactory = new CachingConnectionFactory(host);
		PrepareProfileMustangconnectionFactory.setPort(Integer.parseInt(port));
		PrepareProfileMustangconnectionFactory.setUsername(username);
		PrepareProfileMustangconnectionFactory.setPassword(password);
		PrepareProfileMustangconnectionFactory.setConnectionTimeout(30000);
		return PrepareProfileMustangconnectionFactory;
	}
	
	@Bean("customSimpleRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(rabbitMQConnectionFactory());
		factory.setConcurrentConsumers(200);
		factory.setMaxConcurrentConsumers(250);
		factory.setReceiveTimeout((long) 30000);
		return factory;
	}
	
	@Bean("CbrsSuspendrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory CbrsSuspendrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory CbrsSuspendfactory = new SimpleRabbitListenerContainerFactory();
		CbrsSuspendfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		CbrsSuspendfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		CbrsSuspendfactory.setPrefetchCount(1);
		CbrsSuspendfactory.setReceiveTimeout((long) 50000);
		CbrsSuspendfactory.setConnectionFactory(CbrsSuspendrabbitMQConnectionFactory());
		CbrsSuspendfactory.setErrorHandler(errorHandler());
		return CbrsSuspendfactory;
	}
	
	@Bean("CbrsRestorerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory CbrsRestorerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory CbrsRestorefactory = new SimpleRabbitListenerContainerFactory();
		CbrsRestorefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		CbrsRestorefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		CbrsRestorefactory.setPrefetchCount(1);
		CbrsRestorefactory.setReceiveTimeout((long) 50000);
		CbrsRestorefactory.setConnectionFactory(CbrsRestorerabbitMQConnectionFactory());
		CbrsRestorefactory.setErrorHandler(errorHandler());
		return CbrsRestorefactory;
	}
	
	@Bean("CbrsDeleterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory CbrsDeleterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory CbrsDeletefactory = new SimpleRabbitListenerContainerFactory();
		CbrsDeletefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		CbrsDeletefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		CbrsDeletefactory.setPrefetchCount(1);
		CbrsDeletefactory.setReceiveTimeout((long) 50000);
		CbrsDeletefactory.setConnectionFactory(CbrsDeleterabbitMQConnectionFactory());
		CbrsDeletefactory.setErrorHandler(errorHandler());
		return CbrsDeletefactory;
	}
	
	@Bean("PrepareProfileMustangrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory PrepareProfileMustangrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory PrepareProfileMustangfactory = new SimpleRabbitListenerContainerFactory();
		PrepareProfileMustangfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		PrepareProfileMustangfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		PrepareProfileMustangfactory.setPrefetchCount(1);
		PrepareProfileMustangfactory.setReceiveTimeout((long) 50000);
		PrepareProfileMustangfactory.setConnectionFactory(PrepareProfileMustangrabbitMQConnectionFactory());
		PrepareProfileMustangfactory.setErrorHandler(errorHandler());
		return PrepareProfileMustangfactory;
	}
	
	@Bean("customRabbitTemplate")
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate CbrsSuspendcustomRabbitTemplate() {
		RabbitTemplate CbrsSuspendrabbitTemplate = new RabbitTemplate();
		CbrsSuspendrabbitTemplate.setReplyTimeout(30000L);
		CbrsSuspendrabbitTemplate.setMessageConverter(jsonMessageConverter());
		CbrsSuspendrabbitTemplate.setConnectionFactory(CbrsSuspendrabbitMQConnectionFactory());
		return CbrsSuspendrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate CbrsRestorecustomRabbitTemplate() {
		RabbitTemplate CbrsRestorerabbitTemplate = new RabbitTemplate();
		CbrsRestorerabbitTemplate.setReplyTimeout(30000L);
		CbrsRestorerabbitTemplate.setMessageConverter(jsonMessageConverter());
		CbrsRestorerabbitTemplate.setConnectionFactory(CbrsRestorerabbitMQConnectionFactory());
		return CbrsRestorerabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate CbrsDeletecustomRabbitTemplate() {
		RabbitTemplate CbrsDeleterabbitTemplate = new RabbitTemplate();
		CbrsDeleterabbitTemplate.setReplyTimeout(30000L);
		CbrsDeleterabbitTemplate.setMessageConverter(jsonMessageConverter());
		CbrsDeleterabbitTemplate.setConnectionFactory(CbrsDeleterabbitMQConnectionFactory());
		return CbrsDeleterabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate PrepareProfileMustangcustomRabbitTemplate() {
		RabbitTemplate PrepareProfileMustangrabbitTemplate = new RabbitTemplate();
		PrepareProfileMustangrabbitTemplate.setReplyTimeout(30000L);
		PrepareProfileMustangrabbitTemplate.setMessageConverter(jsonMessageConverter());
		PrepareProfileMustangrabbitTemplate.setConnectionFactory(PrepareProfileMustangrabbitMQConnectionFactory());
		return PrepareProfileMustangrabbitTemplate;
	}
}
