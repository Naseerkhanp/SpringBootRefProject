package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String rabbitListenerContainer;

	private String EmmCreateSubscriberQueue;

	private String EmmCreateSubscriberExchange;

	private String EmmUpdateSubscriberQueue;

	private String EmmUpdateSubscriberExchange;

	private String EmmDeleteSubscriberQueue;

	private String EmmDeleteSubscriberExchange;

	private String EmmGetSubscriberQueue;

	private String EmmGetSubscriberExchange;
	
	private String EmmUsageinquiryQueue;

	private String EmmUsageinquiryExchange;
	
	private String EmmChangemdnsubscriberQueue;

	private String EmmChangemdnsubscriberExchange;

}
