package com.nsl.usagereport.postgres.repository;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.postgres.entity.SmsDetails;
import com.nsl.usagereport.uio.SmsDetailsUIO;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("SmsDetailsDaoImpl")
public class SmsDetailsDaoImpl implements NslDao {
	@Autowired
	SmsDetailsRepository smsDetailsRepository;
	@Autowired
	private Environment env;

	@Transactional
	@Override
	public void save(List<Object> smsDetailsList) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<SmsDetails> dataDetails = smsDetailsList.stream().map(s -> (SmsDetails) s)
					.collect(Collectors.toList());
			smsDetailsRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

	@Transactional
	public void deleteData(GetUsageReportDetails smsUsageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		Date startDate = null;
		Date endDate = null;
		try {
			if (smsUsageReportDetails.getStartDate() != null && smsUsageReportDetails.getEndDate() != null) {
				startDate = NslFileUploadUtils.convertStringToDate1(smsUsageReportDetails.getStartDate());
				endDate = NslFileUploadUtils.convertStringToDate1(smsUsageReportDetails.getEndDate());
			}
			smsDetailsRepository.deleteDataByDate(startDate, endDate);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " deleteData method end .");
	}

	@Transactional
	public List<SmsDetailsUIO> getSmsDetails(GetUsageReportDetails smsUsageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		List<SmsDetails> smsDetailsLst = null;
		List<SmsDetailsUIO> smsDetailsUIOLST = null;
		Date startDate = null;
		Date enddate = null;
		try {
			if (smsUsageReportDetails.getStartDate() != null && smsUsageReportDetails.getEndDate() != null) {
				startDate = NslFileUploadUtils.convertStringToDate1(smsUsageReportDetails.getStartDate());
				enddate = NslFileUploadUtils.convertStringToDate1(smsUsageReportDetails.getEndDate());
			}
			if (smsUsageReportDetails.getStartDate() == null && smsUsageReportDetails.getEndDate() == null
					&& smsUsageReportDetails.getImsi() == null) {
				smsDetailsLst = smsDetailsRepository
						.findDataByWithOutStartEnddateAndImsi(smsUsageReportDetails.getMdn().toString());
			} else if (smsUsageReportDetails.getImsi() == null) {
				smsDetailsLst = smsDetailsRepository
						.findDataByDateWithOutOptional(smsUsageReportDetails.getMdn().toString(), startDate, enddate);
			} else if (smsUsageReportDetails.getStartDate() == null && smsUsageReportDetails.getEndDate() == null) {
				smsDetailsLst = smsDetailsRepository.findDataByMdnAndImsi(smsUsageReportDetails.getMdn().toString(),
						smsUsageReportDetails.getImsi().toString());
			} else {
				smsDetailsLst = smsDetailsRepository.findDataByDate(smsUsageReportDetails.getMdn().toString(),
						startDate, enddate, smsUsageReportDetails.getImsi().toString());
			}
			/*
			 * smsDetailsLst = ((smsUsageReportDetails.getImsi() == null) ?
			 * smsDetailsRepository.findDataByDateWithOutOptional(String.valueOf(
			 * smsUsageReportDetails.getMdn()), startDate, enddate) :
			 * smsDetailsRepository.findDataByDate(String.valueOf(smsUsageReportDetails.
			 * getMdn()), startDate, enddate, smsUsageReportDetails.getImsi().toString()));
			 */
			smsDetailsUIOLST = smsDetailsLst.stream().map(smsDetails -> {
				SmsDetailsUIO smsDetailsUIO = new SmsDetailsUIO();
				String convertedDate = NslFileUploadUtils.convertLongToDate(smsDetails.getEventDateTime().getTime());
				smsDetailsUIO.setEventStart(convertedDate);
				smsDetailsUIO.setTimeZone(smsDetails.getGmtOffset());
				if (smsDetails.getRecordType() != null) {
					smsDetailsUIO.setTechType(smsDetails.getRecordType().toString());
				} else {
					smsDetailsUIO.setTechType("");
				}
				smsDetailsUIO.setUnits(smsDetails.getTotalUnits());
				smsDetailsUIO.setDirection(smsDetails.getCallDirectionInd());
				smsDetailsUIO.setOtherPartyNumber(smsDetails.getOtherPartyAddress());
				if (smsDetails.getEventType() != null) {
					smsDetailsUIO.setFootPrint(smsDetails.getEventType().toString());
				} else {
					smsDetailsUIO.setFootPrint("");
				}
				smsDetailsUIO.setEventType(smsDetails.getEventType());
				smsDetailsUIO.setdSource(smsDetails.getDsource());
				return smsDetailsUIO;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " getSmsDetails method end .");
		return smsDetailsUIOLST;
	}

}
