package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "Voice_Details")
@Entity(name = "Voice_Details")
public class VoiceDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "VOICE_ID")
	private Integer id;
	@Column(name = "RECORD_ID")
	private Long recordId;
	@Column(name = "USAGE_SEQUENCE_ID")
	private Long usageSequenceId;
	@Column(name = "RERATE_IND")
	private String rerateInd;
	@Column(name = "RERATE_REASON_CODE")
	private Long rerateReasonCode;
	@Column(name = "BILLING_NUMBER")
	private Long billingNumber;
	@Column(name = "IMSI")
	private Long imsi;
	@Column(name = "MIN_NUM")
	private Long minNum;
	@Column(name = "DEVICE_ID")
	private String deviceId;
	@Column(name = "RECORD_TYPE")
	private String recordType;
	@Column(name = "SERVICE_PLAN")
	private String servicePlan;
	@Column(name = "TARIFF_PLAN")
	private String tariffPlan;
	@Column(name = "TIER_CD")
	private String tierCd;
	@Column(name = "LOCAL_CALL_START_DATETIME")
	private Date localCallStartDatetime;
	@Column(name = "GMT_OFFSET")
	private Long gmtOffset;
	@Column(name = "OTHER_PARTY_NUMBER")
	private String otherPartyNumber;
	@Column(name = "CALL_TYPE")
	private Long callType;
	@Column(name = "CALL_DIRECTION_IND")
	private String callDirectionInd;
	@Column(name = "SERVING_BID")
	private String servingBid;
	@Column(name = "TO_CITY")
	private String toCity;
	@Column(name = "TO_STATE")
	private String toState;
	@Column(name = "TO_COUNTRY_CODE")
	private String toCountryCode;
	@Column(name = "FROM_CITY")
	private String fromCity;
	@Column(name = "FROM_STATE")
	private String fromState;
	@Column(name = "FROM_COUNTRY_CODE")
	private String fromCountryCode;
	@Column(name = "INTERNATIONAL_TERMINAT_POINT")
	private String internationalTerminationPoint;
	@Column(name = "PEAK_AIRTIME_MOU")
	private Long peakAirtime;
	@Column(name = "OFF_PEAK_AIRTIME_MOU")
	private Long offPeakAirtime;
	@Column(name = "TOTAL_MINUTES_MOU")
	private Long totalMinutes;
	@Column(name = "TOTAL_SECONDS_OF_CALL")
	private Long totalSecondsOfCall;
	@Column(name = "INCLUDED_MINUTES")
	private Long includedMinutes;
	@Column(name = "CHARGED_MINUTES")
	private Long chargedMinutes;
	@Column(name = "RATE_SPAN_IND")
	private String rateSpanInd;
	@Column(name = "RATE_TYPE")
	private String rateType;
	@Column(name = "AIR_TIME_CHARGE")
	private Long airTimeCharge;
	@Column(name = "TOLL_CHARGE")
	private Long tollCharge;
	@Column(name = "SDD_CHARGE")
	private Long sddCharge;
	@Column(name = "ROAMING_TAX_CHARGE")
	private Long roamingTaxCharge;
	@Column(name = "ROAMER_SURCHARGE")
	private Long roamerSurcharge;
	@Column(name = "CALL_WAITING")
	private String callWaiting;
	@Column(name = "CALLER_ID_BLOCK")
	private String callerIdBlock;
	@Column(name = "N_WAY_CALLING")
	private String nWayCalling;
	@Column(name = "CANCEL_CALL_WAITING_IND")
	private String cancelCallWaitingInd;
	@Column(name = "FEATURE_SETUP_IND")
	private String featureSetupInd;
	@Column(name = "CALL_FORWARD")
	private String callForward;
	@Column(name = "CALL_DELIVERY")
	private String callDelivery;
	@Column(name = "BUSY_TRANSFER_IND")
	private String busyTransferInd;
	@Column(name = "NO_ANSWER_TRANSFER_IND")
	private String noAnswerTransferInd;
	@Column(name = "FOOTPRINT_CODE")
	private String footprintCode;
	@Column(name = "ZONE")
	private String zone;
	@Column(name = "EQUIVALENT_UNITS")
	private Long equivalentUnits;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getAirTimeCharge() {
		return airTimeCharge;
	}

	public void setAirTimeCharge(Long airTimeCharge) {
		this.airTimeCharge = airTimeCharge;
	}

	public Long getTollCharge() {
		return tollCharge;
	}

	public void setTollCharge(Long tollCharge) {
		this.tollCharge = tollCharge;
	}

	public Long getSddCharge() {
		return sddCharge;
	}

	public void setSddCharge(Long sddCharge) {
		this.sddCharge = sddCharge;
	}

	public Long getRoamingTaxCharge() {
		return roamingTaxCharge;
	}

	public void setRoamingTaxCharge(Long roamingTaxCharge) {
		this.roamingTaxCharge = roamingTaxCharge;
	}

	public Long getRoamerSurcharge() {
		return roamerSurcharge;
	}

	public void setRoamerSurcharge(Long roamerSurcharge) {
		this.roamerSurcharge = roamerSurcharge;
	}

	public Long getEquivalentUnits() {
		return equivalentUnits;
	}

	public void setEquivalentUnits(Long equivalentUnits) {
		this.equivalentUnits = equivalentUnits;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public Long getUsageSequenceId() {
		return usageSequenceId;
	}

	public void setUsageSequenceId(Long usageSequenceId) {
		this.usageSequenceId = usageSequenceId;
	}

	public String getRerateInd() {
		return rerateInd;
	}

	public void setRerateInd(String rerateInd) {
		this.rerateInd = rerateInd;
	}

	public Long getRerateReasonCode() {
		return rerateReasonCode;
	}

	public void setRerateReasonCode(Long rerateReasonCode) {
		this.rerateReasonCode = rerateReasonCode;
	}

	public Long getBillingNumber() {
		return billingNumber;
	}

	public void setBillingNumber(Long billingNumber) {
		this.billingNumber = billingNumber;
	}

	public Long getImsi() {
		return imsi;
	}

	public void setImsi(Long imsi) {
		this.imsi = imsi;
	}

	public Long getMinNum() {
		return minNum;
	}

	public void setMinNum(Long minNum) {
		this.minNum = minNum;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}

	public String getTariffPlan() {
		return tariffPlan;
	}

	public void setTariffPlan(String tariffPlan) {
		this.tariffPlan = tariffPlan;
	}

	public String getTierCd() {
		return tierCd;
	}

	public void setTierCd(String tierCd) {
		this.tierCd = tierCd;
	}

	public Date getLocalCallStartDatetime() {
		return localCallStartDatetime;
	}

	public void setLocalCallStartDatetime(Date localCallStartDatetime) {
		this.localCallStartDatetime = localCallStartDatetime;
	}

	public Long getGmtOffset() {
		return gmtOffset;
	}

	public void setGmtOffset(Long gmtOffset) {
		this.gmtOffset = gmtOffset;
	}

	public String getOtherPartyNumber() {
		return otherPartyNumber;
	}

	public void setOtherPartyNumber(String otherPartyNumber) {
		this.otherPartyNumber = otherPartyNumber;
	}

	public Long getCallType() {
		return callType;
	}

	public void setCallType(Long callType) {
		this.callType = callType;
	}

	public String getCallDirectionInd() {
		return callDirectionInd;
	}

	public void setCallDirectionInd(String callDirectionInd) {
		this.callDirectionInd = callDirectionInd;
	}

	public String getServingBid() {
		return servingBid;
	}

	public void setServingBid(String servingBid) {
		this.servingBid = servingBid;
	}

	public String getToCity() {
		return toCity;
	}

	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

	public String getToState() {
		return toState;
	}

	public void setToState(String toState) {
		this.toState = toState;
	}

	public String getToCountryCode() {
		return toCountryCode;
	}

	public void setToCountryCode(String toCountryCode) {
		this.toCountryCode = toCountryCode;
	}

	public String getFromCity() {
		return fromCity;
	}

	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	public String getFromState() {
		return fromState;
	}

	public void setFromState(String fromState) {
		this.fromState = fromState;
	}

	public String getFromCountryCode() {
		return fromCountryCode;
	}

	public void setFromCountryCode(String fromCountryCode) {
		this.fromCountryCode = fromCountryCode;
	}

	public String getInternationalTerminationPoint() {
		return internationalTerminationPoint;
	}

	public void setInternationalTerminationPoint(String internationalTerminationPoint) {
		this.internationalTerminationPoint = internationalTerminationPoint;
	}

	public Long getPeakAirtime() {
		return peakAirtime;
	}

	public void setPeakAirtime(Long peakAirtime) {
		this.peakAirtime = peakAirtime;
	}

	public Long getOffPeakAirtime() {
		return offPeakAirtime;
	}

	public void setOffPeakAirtime(Long offPeakAirtime) {
		this.offPeakAirtime = offPeakAirtime;
	}

	public Long getTotalMinutes() {
		return totalMinutes;
	}

	public void setTotalMinutes(Long totalMinutes) {
		this.totalMinutes = totalMinutes;
	}

	public Long getTotalSecondsOfCall() {
		return totalSecondsOfCall;
	}

	public void setTotalSecondsOfCall(Long totalSecondsOfCall) {
		this.totalSecondsOfCall = totalSecondsOfCall;
	}

	public Long getIncludedMinutes() {
		return includedMinutes;
	}

	public void setIncludedMinutes(Long includedMinutes) {
		this.includedMinutes = includedMinutes;
	}

	public Long getChargedMinutes() {
		return chargedMinutes;
	}

	public void setChargedMinutes(Long chargedMinutes) {
		this.chargedMinutes = chargedMinutes;
	}

	public String getRateSpanInd() {
		return rateSpanInd;
	}

	public void setRateSpanInd(String rateSpanInd) {
		this.rateSpanInd = rateSpanInd;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public String getCallWaiting() {
		return callWaiting;
	}

	public void setCallWaiting(String callWaiting) {
		this.callWaiting = callWaiting;
	}

	public String getCallerIdBlock() {
		return callerIdBlock;
	}

	public void setCallerIdBlock(String callerIdBlock) {
		this.callerIdBlock = callerIdBlock;
	}

	public String getnWayCalling() {
		return nWayCalling;
	}

	public void setnWayCalling(String nWayCalling) {
		this.nWayCalling = nWayCalling;
	}

	public String getCancelCallWaitingInd() {
		return cancelCallWaitingInd;
	}

	public void setCancelCallWaitingInd(String cancelCallWaitingInd) {
		this.cancelCallWaitingInd = cancelCallWaitingInd;
	}

	public String getFeatureSetupInd() {
		return featureSetupInd;
	}

	public void setFeatureSetupInd(String featureSetupInd) {
		this.featureSetupInd = featureSetupInd;
	}

	public String getCallForward() {
		return callForward;
	}

	public void setCallForward(String callForward) {
		this.callForward = callForward;
	}

	public String getCallDelivery() {
		return callDelivery;
	}

	public void setCallDelivery(String callDelivery) {
		this.callDelivery = callDelivery;
	}

	public String getBusyTransferInd() {
		return busyTransferInd;
	}

	public void setBusyTransferInd(String busyTransferInd) {
		this.busyTransferInd = busyTransferInd;
	}

	public String getNoAnswerTransferInd() {
		return noAnswerTransferInd;
	}

	public void setNoAnswerTransferInd(String noAnswerTransferInd) {
		this.noAnswerTransferInd = noAnswerTransferInd;
	}

	public String getFootprintCode() {
		return footprintCode;
	}

	public void setFootprintCode(String footprintCode) {
		this.footprintCode = footprintCode;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

}
