package com.excelacom.servicegateway.consumer;

import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.service.ExternalServiceClient;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * The Class In-bound Mobile2.0 Message Consumer.
 */
@Component
public class InboundKoreMessageConsumer {

	/** The transaction service. */
	@Autowired
	private ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(InboundKoreMessageConsumer.class);

	@RabbitListener(queues = "#{inboundQueueProperties.getDisconnectDeviceQueue()}", containerFactory = "disconnectDevicerabbitListenerContainerFactory")
	public Message disconnectDeviceCall(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.DISCONNECT_DEVICE_SERVICE_NAME;
		String transId = null;
		String request = null;
		String operationName = Constants.DISCONNECT_DEVICE_OPERATION_NAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"KoreDisconnectDeviceService", Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId, "postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod, entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreQuerygetEapCodeQueue()}", containerFactory = "getKoreQueryEapCoderabbitListenerContainerFactory")
	public Message koreQueryEapCodeSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreQueryEapCodesService";
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryEapCodesService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore Tests");
				operationName = Constants.NCM_GET_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreQuerygetEapDetailsQueue()}", containerFactory = "getKoreQueryEapDetailsrabbitListenerContainerFactory")
	public Message koreQueryEapDetailsSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreQueryEapDetailsService";
		String transId = null;
		String request =null;
	    String operationName = "KoreQueryEapDetailsWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryEapDetailsService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore Tests");
				operationName = Constants.KORE_GET_OPERATION_NAME;
			} 
			
			LOGGER.info("operationName" +operationName);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			LOGGER.info("request123 ::" +request);
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreQueryPlanCodeNextPeriodQueue()}", containerFactory = "getKoreQueryPlanCodeNextPeriodrabbitListenerContainerFactory")
	public Message KoreQueryPlanCodeNextPeriodSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreQueryPlanCodeNextPeriod";
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryPlanCodeNextPeriod",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore Query Next Period");
				operationName = Constants.KORE_QUERY_GET_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreSIMRadiusQueryQueue()}", containerFactory = "getKoreSIMRadiusQueryrabbitListenerContainerFactory")
	public Message koreSIMRadiusQuerySystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreSimRadiusServ";
		String transId = null;
		String request =null;
	    String operationName = "KoreSimRadiusWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreSimRadiusServ",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore SIM Radius");
				operationName = Constants.KORE_GET_SIM_RADIUS_OPERATION_NAME;
			} 
			
			LOGGER.info("operationName" +operationName);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			LOGGER.info("request123 ::" +request);
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getChangemsisdnQueue()}", containerFactory = "getChangemsisdnrabbitListenerContainerFactory")
	public Message koreChangeMsisdnSystemCall(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_CHANGE_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = Constants.KORE_CHANGE_OPERATION_NAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KorechangeMSISDNService",Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getDeactivatedeviceQueue()}", containerFactory = "getDeactivatedevicerabbitListenerContainerFactory")
	public Message koreDeactivatedeviceSystemCall(Message msg) {
		LOGGER.info("koreDeactivatedeviceSystemCall::::::");;
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_DEACTIVATE_SERVICE_NAME;
		String transId = null;
		String request =null;
		String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info("exchange::::::::::::"+exchange);
			boolean emailFlag = false;
			JSONObject obj = new JSONObject();
			JSONObject jsonObjRes = new JSONObject(exchange);
			LOGGER.info("jsonObjRes::::::::::"+jsonObjRes);
			if (jsonObjRes.has("data")) {
				obj = jsonObjRes.getJSONObject("data");
				emailFlag = obj.has("email");
			}
			if(emailFlag) {
				operationName = Constants.DEACTIVATEDEVICE_WEA_OPERATION_NAME;
			} else {
				operationName = Constants.KORE_DEACTIVATE_OPERATION_NAME;
			}
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreDeactivateDeviceService",Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}

    @RabbitListener(queues = "#{inboundQueueProperties.getModifyDeviceThresholdQueue()}", containerFactory = "getModifyDeviceThresholdrabbitListenerContainerFactory")
	public Message ModifyDeviceThresholdCreateController(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreModifyDeviceThresholdsUsageBarring";
		String operationName = "KoreModifyDeviceThresholdCreateWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreModifyDeviceThresholdsUsageBarring",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in ncmCreateSubAccountSystemCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryDeviceQueue()}", containerFactory = "getQueryDevicerabbitListenerContainerFactory")
	public Message koreQueryDeviceSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_QUERY_DEVICE_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryDeviceService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Query Device");
				operationName = Constants.KORE_QUERY_DEVICE_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryDeviceDetailsExtQueue()}", containerFactory = "getQueryDeviceDetailsExtrabbitListenerContainerFactory")
	public Message koreQueryDeviceDetailsExtSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_QUERY_DEVICE_DETAILS_EXT_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryDeviceDetailsExtService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Query Device Details Ext");
				operationName = Constants.KORE_QUERY_DEVICE_DETAILS_EXT_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryAllDevicesQueue()}", containerFactory = "getQueryAllDevicesrabbitListenerContainerFactory")
	public Message koreQueryAllDevices(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_QUERY_ALL_DEVICES_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryAllDevicesService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Query All Devices");
				operationName = Constants.KORE_QUERY_ALL_DEVICES_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getGetAlertsBySimIdQueue()}", containerFactory = "getAlertsBySimIdrabbitListenerContainerFactory")
	public Message koreGetAlertsBySimId(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_GET_ALERTS_BY_SIMID_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreGetAlertsBySimIdService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Alerts By SimId");
				operationName = Constants.KORE_GET_ALERTS_BY_SIMID_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getReactivateDeviceQueue()}", containerFactory = "getReactivateDevicerabbitListenerContainerFactory")
	public Message reactivateDevice(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName =  Constants.KORE_REACTIVATE_DEVICE_SERVICE_NAME;
		String operationName = Constants.KORE_REACTIVATE_DEVICE_OPERATION_NAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "koreReactivateDeviceService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in reactivateDevice" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKorePingQueue()}", containerFactory = "getKorePingrabbitListenerContainerFactory")
	public Message PingCreateController(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KorePing";
		String operationName = "KorePingCreateWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KorePing",applicationName);
			LOGGER.info("INSIDE SERVICE NAME ::" +serviceName);
			LOGGER.info("INSIDE OPERATION NAME ::" +operationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"getKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in KorePing" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getReportingPingQueue()}", containerFactory = "reportingPingrabbitListenerContainerFactory")
	public Message ReportingPingCreateController(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreReportingPing"; // PP Name
		String operationName = "KoreReportingPingCreateWF"; // WF Name
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreReportingPing",
					applicationName);
			LOGGER.info("INSIDE SERVICE NAME ::" + serviceName);
			LOGGER.info("INSIDE OPERATION NAME ::" + operationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId, "getKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod, entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in KoreReportingPing" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	private String constructRequestJson(String requestJson, String serviceName, String operationName, String transId,
			String responseId, String ruleParam) {
		StringBuilder requestBuilder = new StringBuilder();
		requestBuilder.append(Constants.REQUEST_JSON);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(requestJson);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_SERVICE_NAME);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(serviceName);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_OPERATION_NAME);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(operationName);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_TRANS_ID);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(transId);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_RESPONSE_ID);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(responseId);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.RULE_PARAM);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(ruleParam);

		return requestBuilder.toString();
	}

	@SuppressWarnings("unchecked")
	private String formatRequestForMerge(String response) {
		JSONArray jsonArr = new JSONArray();
		try {
			JSONObject obj = new JSONObject(response);
			JSONObject finalObj = new JSONObject();
			Iterator<String> objItr = obj.keys();
			while (objItr.hasNext()) {
				String key = objItr.next();
				JSONObject reqObj = obj.getJSONObject(key);
				Iterator<String> reqObjItr = reqObj.keys();
				while (reqObjItr.hasNext()) {
					String groupKey = reqObjItr.next();
					Object data = reqObj.get(groupKey);
					if (data instanceof JSONObject) {
						JSONObject lastObj = (JSONObject) data;
						Iterator<String> lastItr = lastObj.keys();
						while (lastItr.hasNext()) {
							String lastKey = lastItr.next();
							Object val = lastObj.get(lastKey);
							finalObj.put(lastKey, val);
						}
					} else if (data instanceof String) {
						finalObj.put(groupKey, data);
					}
				}
			}
			jsonArr.put(finalObj);
		} catch (Exception e) {
			LOGGER.error("Error in formatRequestForMerge" + e);
		}
		LOGGER.info("jsonArr.toString()::" + jsonArr.toString());
		return jsonArr.toString();
	}

	private void asyncinsertMNORequestDetails(String requestJson, String responseId) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.insertMNORequestDetails(requestJson, responseId);
			}
		});
	}
	@RabbitListener(queues = "#{inboundQueueProperties.getActivateDeviceQueue()}", containerFactory = "getActivateDevicerabbitListenerContainerFactory")
	public Message activateDeviceCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KOREActivate-Device";
		String operationName = "Activate-DeviceWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);	
			
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "koreActivateDeviceService",applicationName);
				String returnUrl="";
				JSONObject jsonObjRes = new JSONObject(request);
				JSONObject obj=new JSONObject();
				if(jsonObjRes.has("messageHeader")) {
					if(jsonObjRes.get("messageHeader") instanceof JsonObject) {
					JSONObject messageHeader=jsonObjRes.getJSONObject("messageHeader");
					if(messageHeader.has("returnUrl")) {
						returnUrl=messageHeader.getString("returnUrl");
					}
					}
				}
				if(!returnUrl.isEmpty()) {
					transactionDAO.updateKOREAsyncSouthboundUrl(returnUrl);
				}
				if (jsonObjRes.has("data")) {
					obj = jsonObjRes.getJSONObject("data");
				
				if(obj.has("deviceId")) {
					if(obj.getString("deviceId").isEmpty()) {
						obj.put("deviceId",Constants.EMPTYINWORDS+Constants.EMPTYINWORDS+Constants.EMPTYINWORDS);
					}
				}
				if(obj.has("serialNumber")) {
					if(obj.getString("serialNumber").isEmpty()) {
						obj.put("serialNumber",Constants.EMPTYINWORDS);
					}
				}
				if(obj.has("modelNumber")) {
					if(obj.getString("modelNumber").isEmpty()) {
						obj.put("modelNumber",Constants.EMPTYINWORDS);
					}
				}
					request=jsonObjRes.toString();
				}
	
			
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in activateDeviceCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSimAssociateToGroupQueue()}", containerFactory = "getSimAssociateToGrouprabbitListenerContainerFactory")
	public Message koreSimAssociateToGroupCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreSIMAssocaiteToGroupService";
		String operationName = "KoreSimAssociateToGroupWorkflow";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreSIMAssocaiteToGroupService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in koreSimAssociateToGroupCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getActivateToStateQueue()}", containerFactory = "getActivateToStaterabbitListenerContainerFactory")
	public Message activateToStateCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "koreActivateToStateService";
		String operationName = "koreActivToStatewf";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "koreActivateToStateService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in activateToStateCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getCostCentersQueue()}", containerFactory = "getCostCentersrabbitListenerContainerFactory")
	public Message koreGetCostCentersCallResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.GETCOSTCENTRE_SERVICE_NAME;
		String applicationName = Constants.KORE;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "koreGetCostCenters",applicationName);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside koreGetCostCentersCallResponse");
				operationName = Constants.GETCOSTCENTRE_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getMdCustomInfoQueue()}", containerFactory = "getMdCustomInforabbitListenerContainerFactory")
	public Message koreMdCustomInfoCallResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.GETMD_CUSTOMINFO_SERVICE_NAME;
		String applicationName = Constants.KORE;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		String DeviceIdval = "";
		String outboundResponseId = "";
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info("Request::"+exchange);
			JSONObject obj = new JSONObject();
			boolean isInitRequest=false;
			JsonObject requestObj=new JsonObject();
			if(exchange.startsWith("{")&&exchange.endsWith("}")){
			JSONObject jsonObjRes = new JSONObject(exchange);
			if (jsonObjRes.has("data")) {
				obj = jsonObjRes.getJSONObject("data");
			}
			if(obj.has("deviceId") || obj.has("serialNumber") || obj.has("modelNumber")) {
				operationName = Constants.GETMD_CUSTOM_FIELD_EITH_INFO_OPERATION_NAME;
			} else {
				operationName = Constants.GETMD_CUSTOMINFO_OPERATION_NAME;
			}
			if (jsonObjRes.has("initRequest")) {
				exchange = jsonObjRes.getString("initRequest");
				outboundResponseId=jsonObjRes.getString("responseId");
				JSONObject jsonObjRes1 = new JSONObject(exchange);
				if (jsonObjRes1.has("data")) {
					obj = jsonObjRes1.getJSONObject("data");
				}
				if(obj.has("deviceId"))
				{  DeviceIdval = obj.get("deviceId").toString(); }
				LOGGER.info("DeviceIdval value :" +DeviceIdval);
				if(!DeviceIdval.equalsIgnoreCase("") && !DeviceIdval.equalsIgnoreCase("EMPTYEMPTYEMPTY") ) {
					serviceName="KoreActivateModifyWithOtherInfo";
					operationName="KoreActivateModifyWithOtherWF";
					
				}
				else {
					serviceName="KoreActivateModifyWithOtherInfo";
					operationName="KoreActivateModifywithCustWF";
					LOGGER.info("Work Flow::"+operationName);
				}
				isInitRequest=true;
			}
		}
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			if(isInitRequest) {
				//responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "koreModifyDeviceCustomInformation",applicationName);
				LOGGER.info("Inside koreMdCustomInfoCallResponse"); 
				responseId=outboundResponseId;
				request = constructRequestJson(exchange, serviceName, operationName, transId, outboundResponseId,"getKoreRule");
				response = externalServiceClient.getResponseFromClient(request, transId, outboundResponseId, httpmethod,entityId);
			}else {
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "koreModifyDeviceCustomInformation",applicationName);
				LOGGER.info("Inside koreMdCustomInfoCallResponse"); 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
			}
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getQueryDeviceUsageBySimQueue()}", containerFactory = "getQueryDeviceUsageBySimrabbitListenerContainerFactory")
	public Message koreQueryDeviceUsageBySimSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.QUERY_DEVICEUSAGE_BYSIM_AND_DATE_PROCESS_PLAN;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			JSONObject obj = new JSONObject();
			JSONObject jsonObjRes = new JSONObject(exchange);
			if (jsonObjRes.has("koredeviceusage")) {
				obj = jsonObjRes.getJSONObject("koredeviceusage");
			}
			if(obj.has("startDate") || obj.has("endDate")) {
				operationName = Constants.QUERY_DEVICEUSAGE_BYSIM_WITH_DATE_WORK_FLOW;
			} else {
				operationName = Constants.QUERY_DEVICEUSAGE_BYSIM_WORK_FLOW;
			}
			LOGGER.info("Operation Name" +operationName);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KOREQueryDeviceUsageBySimService",Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryFeatureCodesQueue()}", containerFactory = "getQueryFeatureCodesrabbitListenerContainerFactory")
	public Message koreQueryFeatureCodesSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.QUERY_FEATURE_CODES_PROCESS_PLAN ;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KOREQueryFeatureCodesService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Query Feature Codes");
				operationName = Constants.QUERY_FEATURE_CODES_WORK_FLOW;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdQueue()}", containerFactory = "ncmmodifydeviceplanfornxtprdrabbitListenerContainerFactory")
	public Message ncmModifyDevicePlanForNxtPrdCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = "koremodifyDevicePlanForNextPeriod";
		String operationName = "KoremodifyDevicePlanForNextPeriodWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMModifyDevicePlanForNextPeriod", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmAllertIntegrationServiceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	

	@RabbitListener(queues = "#{inboundQueueProperties.getKoreQueryDeviceUsageQueue()}", containerFactory = "getKoreQueryDeviceUsagerabbitListenerContainerFactory")
	public Message koreQueryDeviceUsageSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.QUERY_DEVICE_USAGE_PROCESS_PLAN ;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KOREQueryDeviceUsageService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Query Device Usage");
				operationName = Constants.QUERY_DEVICE_USAGE_WORK_FLOW;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	@RabbitListener(queues = "#{inboundQueueProperties.getModifyDeviceFeaturesQueue()}", containerFactory = "koremodifydevicefeaturesrabbitListenerContainerFactory")
	public Message koreModifyDeviceFeaturesCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = Constants.MODIFY_DEVICE_FEATURES_PROCESS_PLAN;
		String operationName = Constants.MODIFY_DEVICE_FEATURES_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreModifyDeviceFeatures ", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in koreModifyDeviceFeaturesCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryRequestStatusQueue()}", containerFactory = "queryRequestStatusrabbitListenerContainerFactory")
	public Message koreQueryRequestStatusCallResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreQueryProvisioningActivateDeviceFlow";
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		String requestJson=null;
		KeyHolder keyHolder = new GeneratedKeyHolder();
		try {
			String responseIdFromOubound="";
			byte[] body = msg.getBody();
			String exchange1 = new String(body);
			JsonObject exchange= new JsonParser().parse(exchange1).getAsJsonObject();
			if((exchange.has("request"))) {
			 requestJson=exchange.get("request").getAsString();
			 JSONObject requestJson1=new JSONObject(requestJson);
			 responseIdFromOubound=requestJson1.get("responseId").toString();
			 requestJson1.remove("responseId");
			 requestJson=requestJson1.toString();
			exchange.remove("request");
			
			}
			
			LOGGER.info(exchange.toString());
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
		//	responseId = transactionDAO.insertNorthBoundTransaction(exchange.toString(), entityId, transId, "KoreQueryProvisioningRequestStatus",Constants.KORE);
		//			responseId = "";
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore Tests");
				operationName = "KoreQueryProvisionWF";
			}
			if(operationName!=null && operationName.equalsIgnoreCase( "KoreQueryProvisionWF"))
            {
                  responseId = keyHolder.getKey()+"";
            }else 
            {
                  responseId = transactionDAO.insertNorthBoundTransaction(exchange.toString(), entityId, transId, "KoreQueryProvisioningRequestStatus",Constants.KORE);
            }

			if(requestJson!=null) {
			String currTransId=responseId;
			responseId=responseIdFromOubound;
			request = constructRequestJson(requestJson, serviceName, operationName, transId, responseId,"getKoreRule");
			responseId=currTransId+"ROOT_TRANSACTION_ID"+responseIdFromOubound;
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
			
			}
			else{
				serviceName = "KoreQueryProvisioningRequestStatus";
				operationName = Constants.QUERY_REQUEST_STATUS_OPERATION_NAME;
				request = constructRequestJson(exchange1, serviceName, operationName, transId, responseId,"getKoreRule");
				response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
			}
			
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getQueryServiceTypeCodesQueue()}", containerFactory = "queryServiceTypeCodesrabbitListenerContainerFactory")
	public Message koreQueryServiceTypeCodesCallResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "KoreQueryServiceTypeCodePP";
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreQueryServiceTypeCodesService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Kore Tests");
				operationName = Constants.QUERY_SERVICETYPECODES__OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getSuspendDeviceQueue()}", containerFactory = "suspendDevicerabbitListenerContainerFactory")
	public Message suspendDeviceCall(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.SUSPEND_DEVICE_SERVICE_NAME;
		String transId = null;
		String request = null;
		String operationName = Constants.SUSPEND_DEVICE_OPERATION_NAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"KoreSuspendDeviceService", Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId, "postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod, entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getDownloadReportingQueue()}", containerFactory = "downloadReportingrabbitListenerContainerFactory")
	public Message downloadReportingCall(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.DOWNLOAD_REPORTING_SERVICE_NAME;
		String transId = null;
		String request = null;
		String operationName = Constants.DOWNLOAD_REPORTING_SUM_OPERATION_NAME;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);

			boolean decisionFlag = false;
			JSONObject obj = new JSONObject();
			JSONObject jsonObjRes = new JSONObject(exchange);
			LOGGER.info("jsonObjRes::::::::::"+jsonObjRes);
			if (jsonObjRes.has("data")) {
				JSONObject newObj = (JSONObject) jsonObjRes.get("data");
				LOGGER.info("newObj::::::::::"+newObj);
				if (newObj.has("summaryFileName")) {
					if (!newObj.getString("summaryFileName").isEmpty())
						decisionFlag = true;
				}
				if (newObj.has("dailyFileName")) {
					if (!newObj.getString("dailyFileName").isEmpty())
						decisionFlag = false;
				}
				//decisionFlag = newObj.has("summaryFileName");
			}
			if(decisionFlag) {
				operationName = Constants.DOWNLOAD_REPORTING_SUM_OPERATION_NAME;
			} else {
				operationName = Constants.DOWNLOAD_REPORTING_CSV_OPERATION_NAME;
			}	
			String httpmethod = "POST";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					serviceName, Constants.KORE);
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId, "postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod, entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreChangeSimStatusQueue()}", containerFactory = "getkoreChangeSimStatusrabbitListenerContainerFactory")
	public Message koreChangeSimStatus(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreSimChangeStatus";
		String operationName = "KoreSimChangeStatusWF";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);					
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "koreChangeSimStatusService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in koreChangeSimStatus" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getKoreQueryAvailableReportFilesQueue()}", containerFactory = "getkoreQueryAvailableReportFilesrabbitListenerContainerFactory")
	public Message koreQueryAvailableReportFilesSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = "koreQueryReportFiles" ;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "koreQueryReportFiles",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET QueryAvailable Report Files");
				operationName = "koreQueryReportFilesWF";
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
		@RabbitListener(queues = "#{inboundQueueProperties.getRestoreDevicesQueue()}", containerFactory = "korerestoredevicesrabbitListenerContainerFactory")
	public Message koreRestoreDevicesCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = Constants.RESTORE_DEVICES_PROCESS_PLAN;
		String operationName = Constants.RESTORE_DEVICES_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreRestoreDevicesService", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in koreRestoreDevicesCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSimChangeDeviceQueue()}", containerFactory = "koresimchangedevicerabbitListenerContainerFactory")
	public Message koreSimChangeDeviceCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = Constants.SIM_CHANGE_DEVICE_PROCESS_PLAN;
		String operationName = Constants.SIM_CHANGE_DEVICE_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreSimChangeDeviceService", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in koreSimChangeDeviceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getKoreUnbarToStateQueue()}", containerFactory = "koreUnbarToStaterabbitListenerContainerFactory")
	public Message koreUnbarToStateCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = "KoreUnbarToState";
		String operationName = "KoreUnbarToStateWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreUnbarToState", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"koreUnbarToStateRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in koreUnbarToStateCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getAcknowledgeAlertsbyGroupQueue()}", containerFactory = "acknowledgeAlertsbyGrouprabbitListenerContainerFactory")
	public Message koreAcknowledgeAlertsbyGroupCallResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = "KoreAcknowledgeGroupServ";
		String operationName = "KoreAcknowledgeGroupWorkflow";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "KoreAcknowledgeAlertsByGroup", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"postKoreRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in koreAcknowledgeAlertsbyGroupCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getRemoveSimAssociationQueue()}", containerFactory = "removeSimAssociationrabbitListenerContainerFactory")
	public Message RemoveSimAssociationController(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreRemoveSimAssoc"; // PP Name
		String operationName = "KoreRemoveSimAssociationWorkflow"; // WF Name
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,
					"RemoveSimAssociationController", applicationName);
			LOGGER.info("INSIDE SERVICE NAME ::" + serviceName);
			LOGGER.info("INSIDE OPERATION NAME ::" + operationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId, "postKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod, entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in RemoveSimAssociationConsumer" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getRetrieveGroupByCompanyIdQueue()}", containerFactory = "getKoreRetrieveGroupByCompanyIdrabbitListenerContainerFactory")
	public Message koreRetrieveGroupByCompanyIdSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.KORE_RETRIEVE_GROUP_BY_COMPANYID_SERVICE_NAME;
		String transId = null;
		String request = null;
		String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,
					"KoreRetrieveGroupByCompanyId", Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside Retrieve Group By ComapnyId");
				operationName = Constants.KORE_RETRIEVE_GROUP_BY_COMPANYID_OPERATION_NAME;
			}
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId, "getKoreRule");

			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod, entityId);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleQueue()}", containerFactory = "AcknowlegdeAlertBySimAndRuleContainerFactory")
	public Message AcknowlegdeAlertBySimAndRuleCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String responseId = null;
		UUID uuid = null;
		String serviceName = "AcknowlegdeNotifyBySimAndRule";
		String operationName = "AcknowlegdeNotifyBySimAndRuleWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "AcknowlegdeNotifyBySimAndRule", Constants.KORE);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"koreUnbarToStateRule");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in AcknowlegdeAlertBySimAndRuleCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getAlertByCompanyIdGroupIdQueue()}", containerFactory = "getAlertByCompanyIdGroupIdrabbitListenerContainerFactory")
	public Message koreAlertByCompanyIdGroupIdSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.ALERT_BYCOMPANYID_GROUPID_PROCESS_PLAN;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "KoreGetByCompanyIdGroupIdService",Constants.KORE);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Alert By CompanyId and GroupId");
				operationName = Constants.ALERT_BYCOMPANYID_GROUPID_WORK_FLOW;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"getKoreRule");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSendAcknowledgeQueue()}", containerFactory = "sendAcknowledgerabbitListenerContainerFactory")
	public Message sendAcknowledge(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		String applicationName = Constants.KORE;
		String serviceName = "KoreAsyncService"; // PP Name
		String operationName = "KoreAsyncServiceWF"; // WF Name
		UUID uuid = null;
		String responseId = null;
        KeyHolder keyHolder = new GeneratedKeyHolder();

		try {
			String returnUrl="";
			byte[] body = msg.getBody();
			String request = new String(body);
			String outRequestResponseId="";
			if(request.startsWith("{")&&request.endsWith("}")) {
				JsonObject reqObj=new JsonParser().parse(request).getAsJsonObject();
				if(reqObj.has("initRequest")) {
					String initRequestString=reqObj.get("initRequest").getAsString();
					JsonObject initRequest=new JsonParser().parse(initRequestString).getAsJsonObject();
					if(initRequest.has("messageHeader")) {
						JsonObject messageHeader=initRequest.get("messageHeader").getAsJsonObject();
						if(messageHeader.has("returnUrl")) {
							returnUrl=messageHeader.get("returnUrl").getAsString();
						}
					}
				}
				if(reqObj.has("response")) {
					request=reqObj.get("response").getAsString();
				}
				if(reqObj.has("responseId")) {
					outRequestResponseId=reqObj.get("responseId").getAsString();
				}
			}
			if(!returnUrl.isEmpty()) {
				transactionDAO.updateKOREAsyncSouthboundUrl(returnUrl);
			}
			uuid = UUID.randomUUID();
			transId = uuid.toString();
				/*responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,
			"KoreAsyncService", applicationName);*/
			responseId = keyHolder.getKey()+"";
			if(!outRequestResponseId.isEmpty()) {
				responseId=outRequestResponseId;
			}
			LOGGER.info("INSIDE SERVICE NAME ::" + serviceName);
			LOGGER.info("INSIDE OPERATION NAME ::" + operationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId, "getKoreRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod, entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in sendAcknowledge" + e.getMessage());
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	
}