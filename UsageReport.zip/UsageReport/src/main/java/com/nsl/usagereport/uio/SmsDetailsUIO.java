package com.nsl.usagereport.uio;

public class SmsDetailsUIO {
	private String eventStart;
	private Long timeZone;
	private String techType;
	private Long units;
	private String direction;
	private String otherPartyNumber;
	private String footPrint;
	private Long eventType;
	private String dSource;
	
	public String getTechType() {
		return techType;
	}
	public void setTechType(String techType) {
		this.techType = techType;
	}

	public String getFootPrint() {
		return footPrint;
	}

	public void setFootPrint(String footPrint) {
		this.footPrint = footPrint;
	}
	public String getdSource() {
		return dSource;
	}

	public void setdSource(String dSource) {
		this.dSource = dSource;
	}

	public String getEventStart() {
		return eventStart;
	}

	public void setEventStart(String eventStart) {
		this.eventStart = eventStart;
	}

	public Long getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(Long timeZone) {
		this.timeZone = timeZone;
	}

	public Long getUnits() {
		return units;
	}

	public void setUnits(Long units) {
		this.units = units;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getOtherPartyNumber() {
		return otherPartyNumber;
	}

	public void setOtherPartyNumber(String otherPartyNumber) {
		this.otherPartyNumber = otherPartyNumber;
	}

	public Long getEventType() {
		return eventType;
	}

	public void setEventType(Long eventType) {
		this.eventType = eventType;
	}

}
