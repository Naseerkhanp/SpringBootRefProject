spool 01_cif_dml_service_info.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;  

UPDATE SERVICE_INFO SET SERVICE_URL = 'http://mobile-2-0-stub-service:9999/validateDevice/imei/${imei}' where SERVICE_NAME='ValidateDeviceInquiry_URL' AND SERVER = 'NSL_UPG';


commit;
spool off;
