package com.excelacom.servicegateway.config;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.Connection;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.rabbit.support.RabbitExceptionTranslator;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.util.ErrorHandler;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.rabbitmq.client.GetResponse;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;
	
	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;
	
	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;
	
	Logger LOGGER = LoggerFactory.getLogger(InboundServicesConfig.class);

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}

	
	   @Bean
	  public Queue wifiQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getWifiQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	  }
	  
	  @Bean 
	  public DirectExchange wifiExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getWifiExchange()); 
	  }
	  
	  @Bean
	  Binding wifiBinding() {
		  return BindingBuilder.bind(wifiQueue()).to(wifiExchange()).with(inboundQueueProperties.getWifiQueue()); 
	  }

	  @Bean
	  public Queue updateWifiQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getUpdateWifiQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	  }
	  
	  @Bean 
	  public DirectExchange updateWifiExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getUpdateWifiExchange()); 
	  }
	  
	  @Bean
	  Binding updateWifiBinding() {
		  return BindingBuilder.bind(updateWifiQueue()).to(updateWifiExchange()).with(inboundQueueProperties.getUpdateWifiQueue()); 
	  }
	 
	  @Bean
	  public Queue validateWifiQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getValidateWifiQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	  }
	  
	  @Bean 
	  public DirectExchange validateWifiExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getValidateWifiExchange()); 
	  }
	  
	  @Bean
	  Binding validateWifiBinding() {
		  return BindingBuilder.bind(validateWifiQueue()).to(validateWifiExchange()).with(inboundQueueProperties.getValidateWifiQueue()); 
	  }  
	  
	  @Bean
	  public Queue swWearableQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getSwWearableQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	  }
	  
	  @Bean 
	  public DirectExchange swWearableExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getSwWearableExchange()); 
	  }
	  
	  @Bean
	  Binding swWearableBinding() {
		  return BindingBuilder.bind(swWearableQueue()).to(swWearableExchange()).with(inboundQueueProperties.getSwWearableQueue()); 
	  }
	
	@Bean
	public Queue swRetrieveDeviceQueue() {
	  return QueueBuilder.durable(inboundQueueProperties.getSwRetrieveDeviceQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
    }
	  
	@Bean 
	public DirectExchange swRetrieveDeviceExchange() { 
	  return new  DirectExchange(inboundQueueProperties.getSwRetrieveDeviceExchange()); 
	}
	  
	@Bean
	Binding swRetrieveDeviceBinding() {
	    return BindingBuilder.bind(swRetrieveDeviceQueue()).to(swRetrieveDeviceExchange()).with(inboundQueueProperties.getSwRetrieveDeviceQueue()); 
    }
	

	@Bean
	public Queue transferWearableQueue() {
	return QueueBuilder.durable(inboundQueueProperties.getTransferWearableQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	}
	  
	@Bean 
	public DirectExchange transferWearableExchange() { 
	return new  DirectExchange(inboundQueueProperties.getTransferWearableExchange()); 
	}
	  
	@Bean
	Binding transferWearableBinding() {
	return BindingBuilder.bind(transferWearableQueue()).to(transferWearableExchange()).with(inboundQueueProperties.getTransferWearableQueue()); 
	}
	
	
	
	
	
	
	@Bean
	public Queue loginauthwsQueue() {
	return QueueBuilder.durable(inboundQueueProperties.getLoginauthwsQueue()).withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue) .build(); 
	}
	  
	@Bean 
	public DirectExchange loginauthwsExchange() { 
	return new  DirectExchange(inboundQueueProperties.getLoginauthwsExchange()); 
	}
	  
	@Bean
	Binding loginauthwsBinding() {
	return BindingBuilder.bind(loginauthwsQueue()).to(loginauthwsExchange()).with(inboundQueueProperties.getLoginauthwsQueue()); 
	}
	
	@Bean
	public Queue searchEnvironmentQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSearchEnvironmentQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange searchEnvironmentExchange() {
		return new DirectExchange(inboundQueueProperties.getSearchEnvironmentExchange());
	}

	@Bean
	Binding searchEnvironmentBinding() {
		return BindingBuilder.bind(searchEnvironmentQueue()).to(searchEnvironmentExchange())
				.with(inboundQueueProperties.getSearchEnvironmentQueue());
	}
	
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	
	@Bean(name = "ConnectionFactory")
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}
	@Bean(name = "transactionConnectionFactory")
	public ConnectionFactory transactionrabbitMQConnectionFactory() {
		CachingConnectionFactory transactionconnectionFactory = new CachingConnectionFactory(host);
		transactionconnectionFactory.setPort(Integer.parseInt(port));
		transactionconnectionFactory.setUsername(username);
		transactionconnectionFactory.setPassword(password);
		transactionconnectionFactory.setConnectionTimeout(30000);
		return transactionconnectionFactory;
	}

	@Bean()
    RabbitAdmin  transactionRabbitAdmin(){
        return new RabbitAdmin(transactionrabbitMQConnectionFactory());
    }
    
    @Bean("transactionRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory transactionContainerFactory() {
		SimpleRabbitListenerContainerFactory transactionfactory = new SimpleRabbitListenerContainerFactory();
		transactionfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		transactionfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		transactionfactory.setPrefetchCount(1);
		transactionfactory.setReceiveTimeout((long) 50000);
		transactionfactory.setConnectionFactory(transactionrabbitMQConnectionFactory());
		transactionfactory.setErrorHandler(errorHandler());
		return transactionfactory;
	}
    
	@Bean(name = "activateServiceConnectionFactory")
	public ConnectionFactory activateServicerabbitMQConnectionFactory() {
		CachingConnectionFactory activateServiceconnectionFactory = new CachingConnectionFactory(host);
		activateServiceconnectionFactory.setPort(Integer.parseInt(port));
		activateServiceconnectionFactory.setUsername(username);
		activateServiceconnectionFactory.setPassword(password);
		activateServiceconnectionFactory.setConnectionTimeout(30000);
		return activateServiceconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin  activateServiceRabbitAdmin(){
        return new RabbitAdmin(activateServicerabbitMQConnectionFactory());
    }

    @Bean("activateServiceRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory activateServiceContainerFactory() {
		SimpleRabbitListenerContainerFactory activateServicefactory = new SimpleRabbitListenerContainerFactory();
		activateServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		activateServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		activateServicefactory.setPrefetchCount(1);
		activateServicefactory.setReceiveTimeout((long) 50000);
		activateServicefactory.setConnectionFactory(activateServicerabbitMQConnectionFactory());
		activateServicefactory.setErrorHandler(errorHandler());
		return activateServicefactory;
	}     
    
    @Bean
	public ErrorHandler errorHandler() {
	    return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}
	 
	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
	    return new CustomFatalExceptionStrategy();
	}    


	/*

	@Bean("customSimpleRabbitListenerContainer")

	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
			@Qualifier("ConnectionFactory") ConnectionFactory ConnectionFactory) {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConcurrentConsumers(20);
		factory.setMaxConcurrentConsumers(25);
		factory.setPrefetchCount(1);
		factory.setReceiveTimeout((long) 50000);
		factory.setConnectionFactory(rabbitMQConnectionFactory());
		return factory;
	}
*/
	
	@Bean()
	@Primary
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		return rabbitTemplate;
	}
	
	@Bean(name = "wifiConnectionFactory")
	public ConnectionFactory wifiRabbitMQConnectionFactory() {
			CachingConnectionFactory wifiConnectionFactory = new CachingConnectionFactory(host);
			wifiConnectionFactory.setPort(Integer.parseInt(port));
			wifiConnectionFactory.setUsername(username);
			wifiConnectionFactory.setPassword(password);
			wifiConnectionFactory.setConnectionTimeout(30000);
			return wifiConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin wifiRabbitAdmin(){
        return new RabbitAdmin(wifiRabbitMQConnectionFactory());
    }
	
	@Bean("wifirabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory wifiRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory wifiFactory = new SimpleRabbitListenerContainerFactory();
			wifiFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			wifiFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			wifiFactory.setPrefetchCount(1);
			wifiFactory.setReceiveTimeout((long) 50000);
			wifiFactory.setConnectionFactory(wifiRabbitMQConnectionFactory());
			wifiFactory.setErrorHandler(errorHandler());
			return wifiFactory;
	}

	@Bean()
	public RabbitTemplate wifiCustomRabbitTemplate() {
		RabbitTemplate wifiRabbitTemplate = new RabbitTemplate();
		wifiRabbitTemplate.setReplyTimeout(30000L);
		wifiRabbitTemplate.setMessageConverter(jsonMessageConverter());
		wifiRabbitTemplate.setConnectionFactory(wifiRabbitMQConnectionFactory());
		return wifiRabbitTemplate;
	}
	
	@Bean(name = "updateWifiConnectionFactory")
	public ConnectionFactory updateWifiRabbitMQConnectionFactory() {
			CachingConnectionFactory updateWifiConnectionFactory = new CachingConnectionFactory(host);
			updateWifiConnectionFactory.setPort(Integer.parseInt(port));
			updateWifiConnectionFactory.setUsername(username);
			updateWifiConnectionFactory.setPassword(password);
			updateWifiConnectionFactory.setConnectionTimeout(30000);
			return updateWifiConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin updateWifiRabbitAdmin(){
        return new RabbitAdmin(updateWifiRabbitMQConnectionFactory());
    }
	
	@Bean("updateWifirabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory updateWifiRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory updateWifiFactory = new SimpleRabbitListenerContainerFactory();
			updateWifiFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			updateWifiFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			updateWifiFactory.setPrefetchCount(1);
			updateWifiFactory.setReceiveTimeout((long) 50000);
			updateWifiFactory.setConnectionFactory(updateWifiRabbitMQConnectionFactory());
			updateWifiFactory.setErrorHandler(errorHandler());
			return updateWifiFactory;
	}

	@Bean()
	public RabbitTemplate updateWifiCustomRabbitTemplate() {
		RabbitTemplate updateWifiRabbitTemplate = new RabbitTemplate();
		updateWifiRabbitTemplate.setReplyTimeout(30000L);
		updateWifiRabbitTemplate.setMessageConverter(jsonMessageConverter());
		updateWifiRabbitTemplate.setConnectionFactory(updateWifiRabbitMQConnectionFactory());
		return updateWifiRabbitTemplate;
	}
	
	
	@Bean(name = "validateWifiConnectionFactory")
	public ConnectionFactory validateWifiRabbitMQConnectionFactory() {
			CachingConnectionFactory validateWifiConnectionFactory = new CachingConnectionFactory(host);
			validateWifiConnectionFactory.setPort(Integer.parseInt(port));
			validateWifiConnectionFactory.setUsername(username);
			validateWifiConnectionFactory.setPassword(password);
			validateWifiConnectionFactory.setConnectionTimeout(30000);
			return validateWifiConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin validateWifiRabbitAdmin(){
        return new RabbitAdmin(validateWifiRabbitMQConnectionFactory());
    }
	
	@Bean("validateWifirabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory validateWifiRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory validateWifiFactory = new SimpleRabbitListenerContainerFactory();
			validateWifiFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			validateWifiFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			validateWifiFactory.setPrefetchCount(1);
			validateWifiFactory.setReceiveTimeout((long) 50000);
			validateWifiFactory.setConnectionFactory(validateWifiRabbitMQConnectionFactory());
			validateWifiFactory.setErrorHandler(errorHandler());
			return validateWifiFactory;
	}

	@Bean()
	public RabbitTemplate validateWifiCustomRabbitTemplate() {
		RabbitTemplate validateWifiRabbitTemplate = new RabbitTemplate();
		validateWifiRabbitTemplate.setReplyTimeout(30000L);
		validateWifiRabbitTemplate.setMessageConverter(jsonMessageConverter());
		validateWifiRabbitTemplate.setConnectionFactory(validateWifiRabbitMQConnectionFactory());
		return validateWifiRabbitTemplate;
	}
	@Bean(name = "swWearableConnectionFactory")
	public ConnectionFactory swWearableRabbitMQConnectionFactory() {
			CachingConnectionFactory swWearableConnectionFactory = new CachingConnectionFactory(host);
			swWearableConnectionFactory.setPort(Integer.parseInt(port));
			swWearableConnectionFactory.setUsername(username);
			swWearableConnectionFactory.setPassword(password);
			swWearableConnectionFactory.setConnectionTimeout(30000);
			return swWearableConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin swWearableRabbitAdmin(){
        return new RabbitAdmin(swWearableRabbitMQConnectionFactory());
    }
	
	@Bean("swWearablerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory swWearableRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory swWearableFactory = new SimpleRabbitListenerContainerFactory();
			swWearableFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			swWearableFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			swWearableFactory.setPrefetchCount(1);
			swWearableFactory.setReceiveTimeout((long) 50000);
			swWearableFactory.setConnectionFactory(swWearableRabbitMQConnectionFactory());
			swWearableFactory.setErrorHandler(errorHandler());
			return swWearableFactory;
	}

	@Bean()
	public RabbitTemplate swWearableCustomRabbitTemplate() {
		RabbitTemplate swWearableRabbitTemplate = new RabbitTemplate();
		swWearableRabbitTemplate.setReplyTimeout(30000L);
		swWearableRabbitTemplate.setMessageConverter(jsonMessageConverter());
		swWearableRabbitTemplate.setConnectionFactory(swWearableRabbitMQConnectionFactory());
		return swWearableRabbitTemplate;
	}
	
	@Bean
	public Queue ChangeEsimQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getChangeEsimQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ChangeEsimExchange() {
		return new DirectExchange(inboundQueueProperties.getChangeEsimExchange());
	}

	@Bean
	Binding ChangeEsimBinding() {
		return BindingBuilder.bind(ChangeEsimQueue()).to(ChangeEsimExchange())
				.with(inboundQueueProperties.getChangeEsimQueue());
	}
	
	@Bean(name = "ChangeEsimConnectionFactory")
	public ConnectionFactory ChangeEsimRabbitMQConnectionFactory() {
			CachingConnectionFactory ChangeEsimConnectionFactory = new CachingConnectionFactory(host);
			ChangeEsimConnectionFactory.setPort(Integer.parseInt(port));
			ChangeEsimConnectionFactory.setUsername(username);
			ChangeEsimConnectionFactory.setPassword(password);
			ChangeEsimConnectionFactory.setConnectionTimeout(30000);
			return ChangeEsimConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ChangeEsimRabbitAdmin(){
        return new RabbitAdmin(ChangeEsimRabbitMQConnectionFactory());
    }
	
	@Bean("ChangeEsimrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ChangeEsimRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory ChangeEsimFactory = new SimpleRabbitListenerContainerFactory();
			ChangeEsimFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			ChangeEsimFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			ChangeEsimFactory.setPrefetchCount(1);
			ChangeEsimFactory.setReceiveTimeout((long) 50000);
			ChangeEsimFactory.setConnectionFactory(ChangeEsimRabbitMQConnectionFactory());
			ChangeEsimFactory.setErrorHandler(errorHandler());
			return ChangeEsimFactory;
	}

	@Bean()
	public RabbitTemplate ChangeEsimCustomRabbitTemplate() {
		RabbitTemplate ChangeEsimRabbitTemplate = new RabbitTemplate();
		ChangeEsimRabbitTemplate.setReplyTimeout(30000L);
		ChangeEsimRabbitTemplate.setMessageConverter(jsonMessageConverter());
		ChangeEsimRabbitTemplate.setConnectionFactory(ChangeEsimRabbitMQConnectionFactory());
		return ChangeEsimRabbitTemplate;
	}
	
	@Bean(name = "swRetrieveDetailsConnectionFactory")
	public ConnectionFactory swRetrieveDetailsRabbitMQConnectionFactory() {
		CachingConnectionFactory swRetrieveDetailsConnectionFactory = new CachingConnectionFactory(host);
		swRetrieveDetailsConnectionFactory.setPort(Integer.parseInt(port));
		swRetrieveDetailsConnectionFactory.setUsername(username);
		swRetrieveDetailsConnectionFactory.setPassword(password);
		swRetrieveDetailsConnectionFactory.setConnectionTimeout(30000);
		return swRetrieveDetailsConnectionFactory;
	}

	@Bean()
	RabbitAdmin swRetrieveDetailsRabbitAdmin() {
		return new RabbitAdmin(swRetrieveDetailsRabbitMQConnectionFactory());
	}

	@Bean("swRetrieveDetailsRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory swRetrieveDetailsRabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory bulkManageSubscriberFactory = new SimpleRabbitListenerContainerFactory();
		bulkManageSubscriberFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		bulkManageSubscriberFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		bulkManageSubscriberFactory.setPrefetchCount(1);
		bulkManageSubscriberFactory.setReceiveTimeout((long) 50000);
		bulkManageSubscriberFactory.setConnectionFactory(swRetrieveDetailsRabbitMQConnectionFactory());
		bulkManageSubscriberFactory.setErrorHandler(errorHandler());
		return bulkManageSubscriberFactory;
	}

	@Bean()
	public RabbitTemplate swRetrieveDetailsRabbitTemplate() {
		RabbitTemplate bulkManageSubscriberTemplate = new RabbitTemplate();
		bulkManageSubscriberTemplate.setReplyTimeout(30000L);
		bulkManageSubscriberTemplate.setMessageConverter(jsonMessageConverter());
		bulkManageSubscriberTemplate.setConnectionFactory(swRetrieveDetailsRabbitMQConnectionFactory());
		return bulkManageSubscriberTemplate;
	}
	
	@Bean(name = "transferWearableConnectionFactory")
	public ConnectionFactory transferWearableRabbitMQConnectionFactory() {
			CachingConnectionFactory transferWearableConnectionFactory = new CachingConnectionFactory(host);
			transferWearableConnectionFactory.setPort(Integer.parseInt(port));
			transferWearableConnectionFactory.setUsername(username);
			transferWearableConnectionFactory.setPassword(password);
			transferWearableConnectionFactory.setConnectionTimeout(30000);
			return transferWearableConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin transferWearableRabbitAdmin(){
        return new RabbitAdmin(transferWearableRabbitMQConnectionFactory());
    }
	
	@Bean("transferWearablerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory transferWearablerabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory transferWearableFactory = new SimpleRabbitListenerContainerFactory();
			transferWearableFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			transferWearableFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			transferWearableFactory.setPrefetchCount(1);
			transferWearableFactory.setReceiveTimeout((long) 50000);
			transferWearableFactory.setConnectionFactory(transferWearableRabbitMQConnectionFactory());
			transferWearableFactory.setErrorHandler(errorHandler());
			return transferWearableFactory;
	}

	@Bean()
	public RabbitTemplate transferWearableFactoryCustomRabbitTemplate() {
		RabbitTemplate transferWearableFactoryRabbitTemplate = new RabbitTemplate();
		transferWearableFactoryRabbitTemplate.setReplyTimeout(30000L);
		transferWearableFactoryRabbitTemplate.setMessageConverter(jsonMessageConverter());
		transferWearableFactoryRabbitTemplate.setConnectionFactory(transferWearableRabbitMQConnectionFactory());
		return transferWearableFactoryRabbitTemplate;
	}
	
	//new
	@Bean
	public Queue transferWearableAsyncQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getTransferWearableAsyncQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange transferWearableAsyncExchange() {
		return new DirectExchange(inboundQueueProperties.getTransferWearableAsyncExchange());
	}

	@Bean
	Binding transferWearableAsyncBinding() {
		return BindingBuilder.bind(transferWearableAsyncQueue()).to(transferWearableAsyncExchange())
				.with(inboundQueueProperties.getTransferWearableAsyncQueue());
	}
	
	@Bean(name = "transferWearableAsyncConnectionFactory")
	public ConnectionFactory transferWearableAsyncRabbitMQConnectionFactory() {
			CachingConnectionFactory transferWearableAsyncConnectionFactory = new CachingConnectionFactory(host);
			transferWearableAsyncConnectionFactory.setPort(Integer.parseInt(port));
			transferWearableAsyncConnectionFactory.setUsername(username);
			transferWearableAsyncConnectionFactory.setPassword(password);
			transferWearableAsyncConnectionFactory.setConnectionTimeout(30000);
			return transferWearableAsyncConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin transferWearableAsyncRabbitAdmin(){
        return new RabbitAdmin(transferWearableAsyncRabbitMQConnectionFactory());
    }
	
	@Bean("transferWearableAsyncRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory transferWearableAsyncRabbitListenerContainerFactory(){
			SimpleRabbitListenerContainerFactory transferWearableAsync = new SimpleRabbitListenerContainerFactory();
			transferWearableAsync.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			transferWearableAsync.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			transferWearableAsync.setPrefetchCount(1);
			transferWearableAsync.setReceiveTimeout((long) 50000);
			transferWearableAsync.setConnectionFactory(transferWearableAsyncRabbitMQConnectionFactory());
			transferWearableAsync.setErrorHandler(errorHandler());
			return transferWearableAsync;
	}

	@Bean()
	public RabbitTemplate transferWearableAsyncCustomRabbitTemplate() {
		RabbitTemplate transferWearableAsyncRabbitTemplate = new RabbitTemplate();
		transferWearableAsyncRabbitTemplate.setReplyTimeout(30000L);
		transferWearableAsyncRabbitTemplate.setMessageConverter(jsonMessageConverter());
		transferWearableAsyncRabbitTemplate.setConnectionFactory(transferWearableAsyncRabbitMQConnectionFactory());
		return transferWearableAsyncRabbitTemplate;
	}
	
	
	
	 @Bean(name = "loginauthwsConnectionFactory")
		public ConnectionFactory loginauthwsRabbitMQConnectionFactory() {
				CachingConnectionFactory loginauthwsConnectionFactory = new CachingConnectionFactory(host);
				loginauthwsConnectionFactory.setPort(Integer.parseInt(port));
				loginauthwsConnectionFactory.setUsername(username);
				loginauthwsConnectionFactory.setPassword(password);
				loginauthwsConnectionFactory.setConnectionTimeout(30000);
				return loginauthwsConnectionFactory;
		}
		
		@Bean()
	    RabbitAdmin loginauthwsRabbitAdmin(){
	        return new RabbitAdmin(loginauthwsRabbitMQConnectionFactory());
	    }
		
		@Bean("loginauthwsrabbitListenerContainerFactory")
		public SimpleRabbitListenerContainerFactory loginauthwsrabbitListenerContainerFactory (){
				SimpleRabbitListenerContainerFactory loginauthwsFactory = new SimpleRabbitListenerContainerFactory();
				loginauthwsFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
				loginauthwsFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
				loginauthwsFactory.setPrefetchCount(1);
				loginauthwsFactory.setReceiveTimeout((long) 50000);
				loginauthwsFactory.setConnectionFactory(loginauthwsRabbitMQConnectionFactory());
				loginauthwsFactory.setErrorHandler(errorHandler());
				return loginauthwsFactory;
		}

		@Bean()
		public RabbitTemplate loginauthwsCustomRabbitTemplate() {
			RabbitTemplate loginauthwsRabbitTemplate = new RabbitTemplate();
			loginauthwsRabbitTemplate.setReplyTimeout(30000L);
			loginauthwsRabbitTemplate.setMessageConverter(jsonMessageConverter());
			loginauthwsRabbitTemplate.setConnectionFactory(loginauthwsRabbitMQConnectionFactory());
			return loginauthwsRabbitTemplate;
		}

	
		@Bean(name = "searchEnvironmentConnectionFactory")
		public ConnectionFactory searchEnvironmentRabbitMQConnectionFactory() {
				CachingConnectionFactory searchEnvironmentConnectionFactory = new CachingConnectionFactory(host);
				searchEnvironmentConnectionFactory.setPort(Integer.parseInt(port));
				searchEnvironmentConnectionFactory.setUsername(username);
				searchEnvironmentConnectionFactory.setPassword(password);
				searchEnvironmentConnectionFactory.setConnectionTimeout(30000);
				return searchEnvironmentConnectionFactory;
		}
		
		@Bean()
	    RabbitAdmin searchEnvironmentRabbitAdmin(){
	        return new RabbitAdmin(searchEnvironmentRabbitMQConnectionFactory());
	    }
		
		@Bean("searchEnvironmentrabbitListenerContainerFactory")
		public SimpleRabbitListenerContainerFactory searchEnvironmentRabbitListenerContainerFactory (){
				SimpleRabbitListenerContainerFactory searchEnvironmentFactory = new SimpleRabbitListenerContainerFactory();
				searchEnvironmentFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
				searchEnvironmentFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
				searchEnvironmentFactory.setPrefetchCount(1);
				searchEnvironmentFactory.setReceiveTimeout((long) 30000);
				searchEnvironmentFactory.setConnectionFactory(searchEnvironmentRabbitMQConnectionFactory());
				searchEnvironmentFactory.setErrorHandler(errorHandler());
				return searchEnvironmentFactory;
		}

		@Bean()
		public RabbitTemplate searchEnvironmentCustomRabbitTemplate() {
			RabbitTemplate searchEnvironmentRabbitTemplate = new RabbitTemplate();
			searchEnvironmentRabbitTemplate.setReplyTimeout(30000L);
			searchEnvironmentRabbitTemplate.setMessageConverter(jsonMessageConverter());
			searchEnvironmentRabbitTemplate.setConnectionFactory(searchEnvironmentRabbitMQConnectionFactory());
			return searchEnvironmentRabbitTemplate;
		}
	
}
