package com.nsl.usagereport.transaction.dao.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.VoiceDetails;

@Repository("voicedao")
public interface VoiceDetailsRepository extends JpaRepository<VoiceDetails, Integer> {
	@Query("select d from Voice_Details d where d.minNum = :minNum and d.localCallStartDatetime BETWEEN :startDate AND :endDate AND  d.imsi = :imsi")
	List<VoiceDetails> findDataByDate(@Param("minNum") long minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") long imsi);

	@Query("select d from Voice_Details d where d.minNum = :minNum and d.localCallStartDatetime BETWEEN :startDate AND :endDate")
	List<VoiceDetails> findDataByDateWithOutOptional(@Param("minNum") long minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);
	
	@Query("select d from Voice_Details d where d.minNum = :minNum")
	List<VoiceDetails> findDataByWithOutStartEnddateAndImsi(@Param("minNum") long minNum);
	
	@Query("select d from Voice_Details d where d.minNum = :minNum AND  d.imsi = :imsi")
	List<VoiceDetails> findDataByMdnAndImsi(@Param("minNum") long minNum, @Param("imsi") long imsi);
}
