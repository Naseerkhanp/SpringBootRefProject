package com.nsl.usagereport.datahandler;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.transaction.dao.repository.RefFileUploadDaoImpl;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslBeanManagerUtil;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class NslDataHandler {

	@Autowired
	private Environment env;
	@Autowired
	private NslBeanManagerUtil nslBeanManagerUtil;
	
	@Autowired
	private RefFileUploadDaoImpl refFileUploadDaoImpl;

	public Map<Long, List<Object>> buildData(UsageReportDetails usageReportDetails,
			Map<Long, List<Object>> detailsBuiler, String content, Long longValue,
			Map<Long, RefFileUpload> refFileUploadMap, List<RefFileUpload> refFileUploadColumnsLST, long lineNumber,
			RefFileUpload refFileUpload, Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds,
			List<RefFileUpload> fileUploadLst) throws Exception {
		String beanName = NslFileUploadConstants.EMPTY;
		String fileData[] = divideColumns(usageReportDetails, content);
		
		int beanId = longValue.intValue();
		if (usageReportDetails.getFileType().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
			beanName = refFileUpload.getDescription();
		}else if (NslFileUploadConstants.CBRS.equalsIgnoreCase(usageReportDetails.getFileType())
				|| NslFileUploadConstants.PRR_FILE.equalsIgnoreCase(usageReportDetails.getFileType())) {
			long filterValue=Long.parseLong(fileData[0]);
			refFileUpload = refFileUploadDaoImpl.getRefFileUploadDetailByFilterValue(usageReportDetails.getFileType(),filterValue);
			beanName = refFileUpload.getDescription();
		}
		else {
			beanName = refFileUpload.getDescription();
		}

		return nslBeanManagerUtil.getHandler(beanName).buildData(fileData, detailsBuiler, recordsStatus,
				existingRouterIds, lineNumber, fileUploadLst,usageReportDetails);
	}

	public String[] divideColumns(UsageReportDetails usageReportDetails, String content) {
		if((NslFileUploadConstants.FILETYPE_AAA).equalsIgnoreCase(usageReportDetails.getFileType())) {
			usageReportDetails.setCsvDelimiter(",");
		}
		String row = NslFileUploadUtils.divideColumns(content, usageReportDetails.getCsvDelimiter())
				.replace(usageReportDetails.getCsvDelimiter(), NslFileUploadConstants.SPECIAL);
		return row.split(NslFileUploadConstants.SPECIAL);
	}

	public void smbChecks(String[] fileData, List<RefFileUpload> refFileUploadColumnsLST) throws Exception {
		log.info(this.getClass() + "checking SMB columns");
		if (refFileUploadColumnsLST.size() > fileData.length || refFileUploadColumnsLST.size() < fileData.length) {
			throw new Exception("ERR05 – File format is invalid");
		} else {
			for (int index = 0; index < fileData.length; index++) {
				if (!(refFileUploadColumnsLST.get(index).getColumnName()).equals(fileData[index])) {
					throw new Exception("ERR05 – File format is invalid");
				}
			}
		}
		log.info(this.getClass() + " SMB columns were matching with DB .");
	}

}
