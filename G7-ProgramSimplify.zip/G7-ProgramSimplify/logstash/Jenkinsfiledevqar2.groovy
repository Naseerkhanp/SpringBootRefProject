pipeline {
    agent any
	
    stages {
        
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-devqar2-CICD@excelacom.in',
			to: 'nsl_devops@excelacom.in',
			subject: "NSL devqar2 logstash Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }
		stage('NSL devqar2 - Configmap Inject') {
			steps {
			echo 'Applying QAR1 Properties and Datasource Configurations...'
			sh 'kubectl create configmap devqar2-logstash-properties --from-file=propertiesdevqar2 -n default -o yaml --dry-run | kubectl apply -f -'
			sh 'kubectl get configmaps devqar2-logstash-properties -o yaml -n default'
                  }
        }
		stage('NSL devqar2 - EKS POD Deploy') {
			steps {
			echo 'logstash POD Deployment has been started...'
			sh 'cat devqar2-logstash-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f devqar2-logstash-service.yaml'
			sh 'kubectl rollout restart deployment logstash-deployment'
			//sh 'kubectl apply -f devqar2-logstash-config.yaml'
			//sh 'kubectl apply -f devqar2-logstash-apm.yaml'
			sh 'kubectl rollout restart deployment logstash-deployment'
                  }
        }
		stage('NSL devqar2 - EKS POD Status') {
		    steps {
			echo 'logstash POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep logstash-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 logstash Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 logstash Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }