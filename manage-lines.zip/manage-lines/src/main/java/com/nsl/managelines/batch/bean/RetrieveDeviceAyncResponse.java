package com.nsl.managelines.batch.bean;

import java.io.Serializable;
import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class RetrieveDeviceAyncResponse  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public Data data;

	@Setter
	@Getter
	@ToString
	public class Feature {

		public String featureCode;

		public String subscribe;
	}

	@Setter
	@Getter
	@ToString
	public class Equipment {

		public String make;

		public String model;

		public String mode;
	}

	@Setter
	@Getter
	@ToString
	public class Data {

		public String returnCode;

		public String returnMessage;

		public String deviceId;

		public String min;

		public String mdn;

		public String iccid;

		public String imsi;

		public String iec;

		public String statusCode;

		public ArrayList<Feature> feature;

		public String planCode;

		public Equipment equipment;

		public String initialServiceDate;
	}

}
