package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String authserver;

	private String routerserviceurl;

	private String authchecktoken;
	
	private String credentials;
	
	private String hmnoendpoint;
	
	private String smbendpoint;
	
	private String cbrspcrfendpoint;
	
	private String mobile1endpoint;
	
	private String mobile2endpoint;
	
	private String getspeedtesturl;
	
	private String deletespeedtesturl;
	
	private String configmanagerurl;
	
	private String deviceappsintegrationurl;
	
	private String netdevicehealthurl;
	
	private String productsintegrationurl;
	
	private String netDeviceIntegrationurl;
	
	private String ncmPushNotificationurl;
	
	private String netdevicemetricsurl;
	
	private String netDeviceUsageSamplesurl;
	
	private String ncmGroupDeleteurl;
	
	private String ncmAccountGeturl;
	
	private String ncmAccountDeleteurl;
	
	private String ncmDeviceAppsStateServiceurl;
	
	private String ncmGetRouterStateServiceurl;
	
	private String DeleteLocationServicurl;
	
	private String ncmRouterLogsurl;
	
	private String LocationServiceurl;
	
	private String NcmFirmwareurl;
	
	private String ncmDeviceusagesampleurl;
	
	private String NcmLocationServiceCreateurl;
	
	private String RouterStreamUsageSamplesIntegrationurl;
	
	private String ncmRoutersallertsIntegrationurl;
	
	private String ncmGetGroupServiceQueueurl;
	
	private String NCMGroupUpdateServiceurl;
	
	private String ncmGetDeviceAppVersionurl;
	
	private String NcmgetRouterurl;
	
	private String Ncmgetactivitylogurl;
	
	private String ncmAccountCreateurl;
	
	private String ncmRouterUpdateurl;
	
	private String DeleteDeviceAppBindingsurl;
	
	private String UpdateLocationServiceurl;
	
	private String ncmCreateGroupServiceurl;
	
	private String ncmUpdateAccountSystemurl;
	
	private String Ncmgetdeviceappbindinglogurl;
	
	private String NcmCreateSpeedlogurl;
	
	private String ncmRouterDeleteurl;
	
	private String nslDeviceAppsIntegrationServiceurl;
	
	private String deleteDeviceAppVersionurl;
	
	private String NcmFailoversIntegrationServiceurl;
	
	private String Ncmrebooturl;
	
	private String NcmcreatedeviceappbindinglogUrl;
	
	private String Ncmhistoricalloclogurl;
	
	private String NCMAllertIntegrationServiceurl;
	
	private String NCMUpdateConfigMangerServiceurl;
	
	private String applicationName;
	
	private String accounturl;
	
	private String groupurl;
	
	private String targetFirmwareurl;
	
	private String producturl;
	
	private String routerurl;
	
	private String appVersionurl;
	
	private String locationurl;
	
	private String secCode;

	
}
