package com.nsl.usagereport.transaction.dao.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.ResourceInfo;

@Repository
public interface ResourceInfoRepository extends JpaRepository<ResourceInfo, Integer> {

}
