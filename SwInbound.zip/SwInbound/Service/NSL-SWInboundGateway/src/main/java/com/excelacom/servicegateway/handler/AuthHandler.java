package com.excelacom.servicegateway.handler;


import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.properties.InboundProperties;

import io.restassured.path.json.JsonPath;

@Component
@Import (InboundProperties.class)
public class AuthHandler {
	
	@Autowired
	private InboundProperties inboundProperties;

	@Autowired
	private UtilityClass utilityClass;
	
	static Logger LOGGER = LoggerFactory.getLogger(AuthHandler.class);

	public boolean checkToken(String token) {
		LOGGER.info("checkToken");
		boolean isValid = false;
		if (!(StringUtils.hasText(token) && token.split("\\.").length == 3)) {
			return isValid;
		}
		token = token.startsWith("Bearer ") ? token.substring(7) : token;
		String[] parts = token.split("\\.");
		String base64EncodedBody = parts[1];
		Base64 base64Url = new Base64(true);
		String body = new String(base64Url.decode(base64EncodedBody));
		LOGGER.info("body : " + body);
		if (StringUtils.hasText(body) && body.startsWith("{")) {
			JsonPath jsonBody = JsonPath.from(body);
			Long exp = Long.parseLong(jsonBody.getString("exp")) * 1000;
			isValid = System.currentTimeMillis() < exp;
			LOGGER.info("Inside IF statement");
		}
		LOGGER.info("Check token outside");
		return isValid;
	}
	
	public boolean checkOAuthToken(String token,String applciationName){
		boolean authSuccess = false;
		try{
			LOGGER.info(token);
			LOGGER.info("applicationName" + applciationName);
			LOGGER.info("appname:: "+ inboundProperties.getApplicationName());
			LOGGER.info("authcheck:: "+inboundProperties.getAuthchecktoken());
			
			String url = new URIBuilder(inboundProperties.getAuthchecktoken()).addParameter(Constants.TOKEN, token) .toString(); 
			
			LOGGER.info(url);
			 
			CredentialsProvider credentailsProvider = new BasicCredentialsProvider();
			UsernamePasswordCredentials credentials = null;
			LOGGER.info(applciationName);
			if(Constants.APPLICATION_SMB.equalsIgnoreCase(applciationName)){
				LOGGER.info("SMB");
				credentials = new UsernamePasswordCredentials("account-service-user","user123#");	
				
			}
			else if(Constants.APPLICATION_HMNO.equalsIgnoreCase(applciationName)){
				LOGGER.info("HMNO");
				credentials = new UsernamePasswordCredentials("account-service-user","user123#");
				
			}
			else
			{
				credentials = new UsernamePasswordCredentials(Constants.EMPTYSTRING,Constants.EMPTYSTRING);
			}
			LOGGER.info(credentials.toString());
			credentailsProvider.setCredentials(AuthScope.ANY, credentials);
			LOGGER.info(credentailsProvider.toString());
			HttpClient client = HttpClientBuilder
								.create()
								.setDefaultCredentialsProvider(credentailsProvider)
								.build();
			LOGGER.info(client.toString());
			HttpPost postMethod = new HttpPost(url);
			LOGGER.info(postMethod.toString());
			HttpResponse response = client.execute(postMethod);
			LOGGER.info(response.toString());
			int statusCode = response.getStatusLine().getStatusCode();
			LOGGER.info("statusCode");
			if(statusCode == HttpStatus.SC_OK){
				LOGGER.info("SC_OK");
				String responseStr = EntityUtils.toString(response.getEntity());
				JSONObject responseObj = new JSONObject(responseStr);
				if(responseObj.has(Constants.RESPONSE_PARAM_ACTIVE)){
					boolean activeFlag = (boolean) responseObj.get(Constants.RESPONSE_PARAM_ACTIVE);
					authSuccess = activeFlag ? true : false;
				}
			}
		}
		catch(Exception e){
			LOGGER.error("Exception in validating oauth token : " + e.getMessage(), e);
		}
		return authSuccess;
	}
	
	public String checkOAuthTokenServiceCall(String oauthToken, String serviceName, String httpMethod, String server,String applicationName) {
		try {
			LOGGER.info("applicationName"+ applicationName);
			boolean checkToken= this.checkOAuthToken(oauthToken, applicationName);
			if(checkToken) {
			LOGGER.info("checkOAuthTokenServiceCall:::::::::");
			LOGGER.info("checkOAuthTokenServiceCall:::::::::");
			LOGGER.info("resource:::::::::");
			HashMap<String, String> formMap = new HashMap<String, String>();
			formMap.put("token", oauthToken);
			formMap.put("serviceName", serviceName);
			formMap.put("httpMethod",httpMethod);
			formMap.put("server",server);
			String req = formMap.keySet().stream().map(key -> key + "=" + formMap.get(key)).collect(Collectors.joining("&"));
			LOGGER.info("response:::::::::");
//			Response response=	resource.request().post(Entity.form(form));
			String response = utilityClass.callRestAPI(req, inboundProperties.getValidateOauthServiceUrl());
			return response;
			}
			else {
				HashMap<String, String> formMap = new HashMap<String, String>();
				formMap.put("token", oauthToken);
				formMap.put("serviceName", serviceName);
				formMap.put("httpMethod", httpMethod);
				formMap.put("server", server);
				String req = formMap.keySet().stream().map(key -> key + "=" + formMap.get(key))
						.collect(Collectors.joining("&"));
				LOGGER.info("response:::::::::");
//				Response response=	resource.request().post(Entity.form(form));
				String response = utilityClass.callRestAPI(req, inboundProperties.getValidateOauthServiceUrl());

				if (response.contains("SUCCESS")) {
					return response.replace("SUCCESS", "FAILED");
				} else {
					return response;
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return "FAILED";
		}
	}

}