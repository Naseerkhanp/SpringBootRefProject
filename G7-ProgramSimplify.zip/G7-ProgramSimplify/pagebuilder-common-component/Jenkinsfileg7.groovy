pipeline {
    agent any

    stages {
      stage('Image Fetch') {
            steps {
            script {
            properties([
            parameters([
            string(
            name: 'Image_Name', 
            trim: true
            )
            ])
            ])
            }
            }
            }
        stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-PERF-CICD@excelacom.in',
			to: 'devops@excelacom.in',
			subject: "NSL PERF Framework Weblogic Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }        
		/*stage('NSL PERF - Configmap Inject') {
			steps {
			echo 'Applying PERF Properties and Datasource Configurations...'
			sh 'kubectl create configmap perf-frameworkwl-properties --from-file=propertiesdatasourceperf -n default -o yaml --dry-run | kubectl apply -f -'
			sh 'kubectl get configmaps perf-frameworkwl-properties -o yaml -n default'
                  }
        }
		stage('NSL devqar2 - EKS Existing POD Deletion') {
		    steps {
			echo 'pagebuilder-service Existing pod deletion...'
			sh 'rm -rf devr1-pagebuilder-service-deployment.yaml'
			sh 'kubectl delete -f devr1-pagebuilder-service-deployment.yaml'
			sleep(time: 120, unit: "SECONDS")
			
			
			      }
		}*/
		stage('NSL PERF EKS POD Deploy') {
			steps {
			echo 'Framework Weblogic POD Deployment has been started...'
			sh 'sed -i "s/imagename/${Image_Name}/g" devr1-pagebuilder-service-deployment.yaml'
			//sh 'cat devr1-pagebuilder-service-deployment.yaml | sed "s/{{imagename}}/$Image_Name/g" | kubectl apply -f -'
			sh 'kubectl apply -f devr1-pagebuilder-service-deployment.yaml'
			sh 'kubectl apply -f devr1-pagebuilder-service.yaml'
			sh 'kubectl apply -f devr1-pagebuilder-service-config.yaml'
			
			
			
                  }
        }
		stage('NSL devqar2 - EKS POD Status') {
		    steps {
			echo 'pagebuilder-service POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep pagebuilder-service-deployment'
			
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 pagebuilder-service Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL devqar2 pagebuilder-service Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
	always {
        cleanWs()
        }
  }
  }
  