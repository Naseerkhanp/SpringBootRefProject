package com.nsl.usagereport.batch;

import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.ReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.repository.NslDao;
import com.nsl.usagereport.transaction.dao.repository.RefFileUploadDaoImpl;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslBeanManagerUtil;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class NslBatchWriter implements ItemWriter<UsageReportDetails>, StepExecutionListener {
	@Autowired
	private NslBeanManagerUtil nslBeanManagerUtil;

	@Autowired
	NslDataHandler nslDataHandler;
	@Autowired
	private RefFileUploadDaoImpl refFileUploadDaoImpl;
	@Autowired
	private Environment env;
	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;
	@Autowired
	private JobOperator jobOperator;
	private StepExecution stepExecution;

	@Override
	public void write(List<? extends UsageReportDetails> usageReportDetails) throws Exception {
		saveFileDataToDB(usageReportDetails.get(0));
	}

	public void saveFileDataToDB(UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " saveFileDataToDB method called .");
		try {
			if (usageReportDetails.getFileType().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				RefFileUpload refFileUpload = refFileUploadDaoImpl
						.getRefFileUploadDetail(usageReportDetails.getFileType());
				for (ReportDetails reportDetails : usageReportDetails.getReportDetails()) {
					for (Entry<Long, List<Object>> data : reportDetails.getDetailsBuiler().entrySet()) {
						uploadData(nslBeanManagerUtil.getDaoImpl(refFileUpload.getDescription()), data,
								reportDetails.getFileName());
					}
					transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
							(reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
									+ reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSFAILED)
											.size()),
							reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
							reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSFAILED).size(),
							reportDetails.getFileName(), reportDetails.getRecordsStatus(),
							NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);

					return;
				}
			}
			for (ReportDetails reportDetails : usageReportDetails.getReportDetails()) {
				for (Entry<Long, List<Object>> dataDetails : reportDetails.getDetailsBuiler().entrySet()) {
					String id = dataDetails.getKey() + "";
					uploadData(
							nslBeanManagerUtil.getDaoImpl(
									reportDetails.getRefFileUploadMap().get(dataDetails.getKey()).getDescription()),
							dataDetails, reportDetails.getFileName());
					if(usageReportDetails.getSftpTargetPath()!=null) {
						downloadFromSFTP(usageReportDetails, reportDetails.getFileName());
					}					
					System.out.println("completed inserting for id:-" + id);
				}

				transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
						(reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
								+ reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSFAILED)
										.size()),
						reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
						reportDetails.getRecordsStatus().get(NslFileUploadConstants.TOTALRECORDSFAILED).size(),
						reportDetails.getFileName(), reportDetails.getRecordsStatus(),
						NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);
				
			}
		} catch (Exception e) {
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception("  Internal Error: Unable to extract data from file ::", e.getCause());
		}
	}

	public void uploadData(NslDao nslDao, Entry<Long, List<Object>> data, String fileName) throws Exception {
		try {
			nslDao.save(data.getValue());
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to save data into DB ", e);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception(" Internal Error: Unable to save data into DB ", e);
		}
	}

	@Retryable(value = { FileSystemException.class }, maxAttempts = 3)
	public void downloadFromSFTP(UsageReportDetails usageReportDetails, String downloadedFile)
			throws Exception, FileSystemException {
		log.info(this.getClass() + " Connecting to SFTP.... ");
		String getfilesurl = null;
		StandardFileSystemManager manager = new StandardFileSystemManager();
		FileObject remoteFile = null;
		FileObject folderPath = null;
		FileObject[] fileObjectArray = null;
		String fileName = NslFileUploadConstants.EMPTY;
		String destinationUrl = "";
		FileObject destinationPath = null;

		try {

			try {
				manager.init();
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze VFS ::", e);
				throw new FileSystemException(" Internal Error: Unable to iniatilze VFS ::", e.getCause());
			}
			FileSystemOptions opts = new FileSystemOptions();

			try {
				SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze StrictHostKeyChecking ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException(" Internal Error: Unable to iniatilze StrictHostKeyChecking ::",
						e.getCause());
			}
			SftpFileSystemConfigBuilder.getInstance().setConnectTimeoutMillis(opts, 100000);
			String host = usageReportDetails.getHost();
			String user = usageReportDetails.getUserName();
			String password = usageReportDetails.getPassword();
			String port = usageReportDetails.getPort();
			String url = usageReportDetails.getSftpFolderPath();
			String targeturl = usageReportDetails.getSftpTargetPath();
			StaticUserAuthenticator auth = new StaticUserAuthenticator(host, user, password);
			try {
				DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(opts, auth);
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException("  Internal Error: Invalid SFTP Details ::", e.getCause());
			}
			// TODO need to Remove
			String sftpurl = "sftp://" + user + ":" + password + "@" + host + "/" + url + "/"
					+ usageReportDetails.getReportsFileName();

			try {
				getfilesurl = "sftp://" + host + ":" + port + "/" + url + "/";				
				destinationUrl = "sftp://" + host + ":" + port + "/" + targeturl + "/" +downloadedFile;
				folderPath = manager.resolveFile(getfilesurl, opts);
				destinationPath = manager.resolveFile(destinationUrl, opts);
				fileObjectArray = folderPath.getChildren();
				for (FileObject fileObj : fileObjectArray) {
					fileName = fileObj.getName().getBaseName();
					log.info("File Name ::" + fileName);
					if (fileName.equalsIgnoreCase(downloadedFile)) {
						fileObj.moveTo(destinationPath);
						log.info("File moved to destination::" + fileName);
						break;
					}
				}

			} catch (Exception e) {
				log.error(this.getClass() + " Error RemotefileDeatils ::", e);
				jobOperator.stop(this.stepExecution.getJobExecutionId());
				throw new FileSystemException("  Internal Error: Error RemotefileDeatils ::", e.getCause());
			}

		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::", e);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}

	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.stepExecution = stepExecution;

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}
}
