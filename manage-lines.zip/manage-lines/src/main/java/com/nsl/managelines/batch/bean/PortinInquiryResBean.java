package com.nsl.managelines.batch.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class PortinInquiryResBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public Data data;

	@Setter
	@Getter
	@ToString
	public class Name {
		public String first;
		public String middleInitial;
		public String last;
		public String suffix;
		public String prefix;
	}

	@Setter
	@Getter
	@ToString
	public class LnpName {
		public String business;
		public Name name;
	}

	@Setter
	@Getter
	@ToString
	public class Address {
		public String addressLine1;
		public String addressLine2;
		public String city;
		public String state;
		public String zip;
	}

	@Setter
	@Getter
	@ToString
	public class Lnp {
		public LnpName lnpName;
		public Address address;
		public String directionalIndicator;
		public String ssnOrTaxId;
		public String ospAccountNo;
		public String pin;
		public String remark;
	}

	@Setter
	@Getter
	@ToString
	public class Data {
		public String returnCode;
		public String returnMessage;
		public String mdn;
		public String lnpStatusCode;
		public String lnpResponseType;
		public String onsp;
		public String reasonCode;
		public String reasonDetail;
		public String portDueDateTime;
		public Lnp lnp;
	}

}
