pipeline {
    agent any

    stages {
        stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-DEVQAR1-CICD@excelacom.in',
			to: 'devops@excelacom.in',
			subject: "NSL DEVQAR1 Swagger UI Deployment  STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }
	 stage('Container Build') {
            steps {
			script{
                echo 'Contianer Build has been started...'
				docker.build('nsl-devqar1' + ':swagger-ui_v$BUILD_NUMBER')
            }
			}
        }
        stage('Container Upload') {
            steps {
			script{
                echo 'Image Push has been started...'
				 
				docker.withRegistry('https://852563228231.dkr.ecr.us-east-1.amazonaws.com', 'ecr:us-east-1:AWS-ECR-Upload')
				{
               docker.image('nsl-devqar1' + ':swagger-ui_v$BUILD_NUMBER').push('swagger-ui_v$BUILD_NUMBER')
            }
        }
		}
		}
        stage('Container Cleanup') {
            steps {
            	echo 'Image cleanup has been started...'
				sh "docker rmi nsl-devqar1:swagger-ui_v${env.BUILD_NUMBER}"
				sh "docker rmi 852563228231.dkr.ecr.us-east-1.amazonaws.com/nsl-devqar1:swagger-ui_v${env.BUILD_NUMBER}"
                  }
		}
    	stage('NSL DEVQAR1 - EKS POD Deploy') {
			steps {
			echo 'swagger-ui POD Deployment has been started...'
			sh 'cat devqar1-swagger-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f devqar1-swagger-service.yaml'
			
			
                  }
        }
		stage('NSL DEVQAR1 - EKS POD Status') {
		    steps {
			echo 'swagger-ui POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep swagger-ui'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-DEVQAR1-CICD@excelacom.in',
		  to: 'devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL DEVQAR1 Swagger UI Deployment  SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-DEVQAR1-CICD@excelacom.in',
		  to: 'devops@excelacom.in',
		  attachLog: true,
		  subject: "NSL DEVQAR1 Swagger UI Deployment  FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }