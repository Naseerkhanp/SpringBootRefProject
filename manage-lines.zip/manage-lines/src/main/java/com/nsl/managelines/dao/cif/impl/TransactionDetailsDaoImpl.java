/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nsl.managelines.dao.cif.entity.TransactionDetails;
import com.nsl.managelines.dao.cif.repository.TransactionDetailsRepository;

import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */
@Component
@Log4j2
public class TransactionDetailsDaoImpl implements TransactionDetailsDao {

	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;

	public Set<TransactionDetails> findTransactionDetailsByErrorCode(String errorCode) {
		transactionDetailsRepository.findAllTransactionDetailsByErrorCode(null);
		return null;
	}

	public Set<TransactionDetails> findTransactionDetailsByTransactionNameAndStatus(String status,
			List<String> transactionName) {
		return transactionDetailsRepository.findAllByNotifiEntityStatusAndTransactionNameIn(status, transactionName);
	}

	public TransactionDetails findByTransactionId(Long transactionId) {
		return transactionDetailsRepository.findByTransactionId(transactionId);
	}

	public int findCountByExtTransactionIdAndTransactionTypeAndTransactionName(String extTransactionId,
			String transactionType, java.util.List<String> transactionName) {
		List<TransactionDetails> transList = transactionDetailsRepository
				.findByExtTransactionIdAndTransactionTypeAndTransactionNameIn(extTransactionId, transactionType,
						transactionName);
		int count = 0;
		if (transList != null) {
			count = transList.size();
		}
		return count;
	}

	public void clearNotifiEntityStatus(Long transactionId, String notifiEntityStatus) {
		try {
			transactionDetailsRepository.clearNotifiEntityStatus(transactionId, notifiEntityStatus);
		} catch (Exception e) {
			log.error("Error clearNotifiEntityStatus:", e);
		}
	}

}
