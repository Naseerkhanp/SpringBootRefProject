package com.nsl.usagereport.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author HarshaVardhan.M
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "nbosEntityManagerFactory", transactionManagerRef = "resnbosTransactionManager", basePackages = {
		"com.nsl.usagereport.nbos" })
public class UsageReportNbosmbDBConfig {
	@Bean(name = "nbosDataSource")
	@ConfigurationProperties(prefix = "spring.nbosmb.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "nbosEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean nbosEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("nbosDataSource") DataSource dataSource) {
		Map<String, String> propertyMap = new HashMap<String, String>();
		propertyMap.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");		
		return builder.dataSource(dataSource).packages("com.nsl.usagereport.nbos.entity").persistenceUnit("nbos").properties(propertyMap)
				.build();
	}

	@Bean(name = "resnbosTransactionManager")
	public PlatformTransactionManager nbosTransactionManager(
			@Qualifier("nbosEntityManagerFactory") EntityManagerFactory nbosEntityManagerFactory) {
		return new JpaTransactionManager(nbosEntityManagerFactory);
	}

}
