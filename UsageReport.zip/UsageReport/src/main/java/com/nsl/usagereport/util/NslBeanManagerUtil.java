package com.nsl.usagereport.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.Handler;
import com.nsl.usagereport.postgres.repository.NslDao;

@Component
public class NslBeanManagerUtil {

	@Autowired
	private ApplicationContext context;

	public Handler getHandler(String handler) {
		return (Handler) context.getBean(handler + NslFileUploadConstants.HANDLER);
	}

	public NslDao getDaoImpl(String nslDao) {
		return (NslDao) context.getBean(nslDao + NslFileUploadConstants.DAO_IMPL);
	}
}
