package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String nslUpdateCancelQueue;

	private String nslUpdateCancelExchange;

	private String UpdateModifyQueue;

	private String UpdateModifyExchange;

	private String HmnochangepsimQueue;

	private String HmnochangepsimExchange;

	private String HmnodeviceinquiryQueue;

	private String HmnodeviceinquiryExchange;

	private String HmnoChangeFeatureQueue;

	private String HmnoChangeFeatureExchange;

	private String HmnoValidateSimQueue;

	private String HmnoValidateSimExchange;

	private String HmnodeviceinquiryAsyncQueue;

	private String HmnodeviceinquiryAsyncExchange;

	private String hmnoLineHistoryInquiryServiceQueue;

	private String hmnoLineHistoryInquiryServiceExchange;

	private String MnoportinInquiryQueue;

	private String MnoportinInquiryExchange;
	
	private String mnoLineDetailsExchange;
	
	private String mnoLineDetailsQueue;
	
	private String activateHotlineExchange;
	
	private String activateHotlineQueue;
	
	private String suspendSubscriberQueue;
	
	private String suspendSubscriberExchange;
	
	private String restoreSubscriberQueue;
	
	private String restoreSubscriberExchange;
	
	private String activateSubscriberQueue;
	
	private String activateSubscriberExchange;
	
	private String activatePortinSubscriberQueue;
	
	private String activatePortinSubscriberExchange;
	
	private String deactivateSubscriberQueue;
	
	private String deactivateSubscriberExchhange;

	private String resetfeatureQueue;

	private String resetfeatureExchange;

	private String hmnochangepsimasyncQueue;

	private String hmnochangepsimasyncExchange;

	private String orderinquiryQueue;

	private String orderinquiryExchange;

	private String changefeatureasyncQueue;	

	private String changefeatureasyncExchange;

	private String changeRatePlanQueue;
	
	private String changeRatePlanExchange;

	private String changeMdnQueue;
	
	private String changeMdnExchange;

	private String lineInquiryQueue;
	
	private String lineInquiryExchange;

	private String removeHotlineQueue;
	
	private String removeHotlineExchange;

	private String updatePortoutQueue;
	
	private String updatePortoutExchange;

	private String updateDuedatePortinQueue;
	
	private String updateDuedatePortinExchange;

	private String validateMdnQueue;
	
	private String validateMdnExchange;

	private String validateDeviceQueue;
	
	private String validateDeviceExchange;
}
