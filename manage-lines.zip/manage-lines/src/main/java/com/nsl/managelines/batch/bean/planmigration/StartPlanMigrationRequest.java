package com.nsl.managelines.batch.bean.planmigration;

import java.io.Serializable;
import java.util.ArrayList;

import com.nsl.managelines.batch.bean.MessageHeader;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class StartPlanMigrationRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public Data data;

	public class Data {
		public String transactionType;
		public String transactionTimeStamp;
		public Account account;
		public ArrayList<SubOrder> subOrder;
	}

	@Setter
	@Getter
	@ToString
	public class Account {
		public String accountNumber;
		public String contextId;
		public String type;
	}

	public class Mdn {
		public String type;
		public String value;
	}

	public class DeviceId {
		public String type;
		public String value;
	}

	public class SubOrder {
		public String id;
		public String lineId;
		public String isPilotPlanMigration;
		public ArrayList<Mdn> mdn;
		public ArrayList<DeviceId> deviceId;
	}

}
