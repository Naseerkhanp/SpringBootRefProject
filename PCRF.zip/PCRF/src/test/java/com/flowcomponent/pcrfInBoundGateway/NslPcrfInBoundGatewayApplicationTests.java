package com.flowcomponent.pcrfInBoundGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NslPcrfInBoundGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
