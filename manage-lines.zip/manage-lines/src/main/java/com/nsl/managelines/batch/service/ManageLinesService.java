/**
 * 
 */
package com.nsl.managelines.batch.service;

import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.nsl.managelines.batch.bean.AsyncType;
import com.nsl.managelines.batch.bean.Data;
import com.nsl.managelines.batch.bean.FileDetails;
import com.nsl.managelines.batch.bean.FileOperationRequest;
import com.nsl.managelines.batch.bean.Line;
import com.nsl.managelines.batch.bean.LinePlan;
import com.nsl.managelines.batch.bean.LineInquiryResponse;
import com.nsl.managelines.batch.bean.MessageHeader;
import com.nsl.managelines.batch.bean.OutboundRequest;
import com.nsl.managelines.batch.bean.PortinInquiryResBean;
import com.nsl.managelines.batch.bean.ReportMgmtRequest;
import com.nsl.managelines.batch.bean.RetrieveDeviceAyncResponse;
import com.nsl.managelines.batch.bean.async.AsyncCallbackResponse;
import com.nsl.managelines.batch.bean.async.GatewayResponse;
import com.nsl.managelines.batch.bean.async.MdnDetail;
import com.nsl.managelines.batch.bean.planmigration.JobType;
import com.nsl.managelines.batch.bean.planmigration.NSLResponse;
import com.nsl.managelines.batch.bean.planmigration.PlanMigrationEligibilityOutput;
import com.nsl.managelines.batch.bean.planmigration.PlanMigrationRequest;
import com.nsl.managelines.batch.bean.planmigration.StgPlanMigration;
import com.nsl.managelines.batch.bean.planmigration.StgPlanMigrationDto;
import com.nsl.managelines.batch.constants.Constants;
import com.nsl.managelines.batch.constants.UtilityClass;
import com.nsl.managelines.batch.properties.InboundProperties;
import com.nsl.managelines.dao.cif.entity.BatchTransaction;
import com.nsl.managelines.dao.cif.entity.TransactionDetails;
import com.nsl.managelines.dao.cif.impl.BatchTransactionDao;
import com.nsl.managelines.dao.cif.impl.TransactionLogDao;
import com.nsl.managelines.batch.bean.planmigration.RefPlanMigration;

import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */

@Component
@Log4j2
public class ManageLinesService {

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundProperties inboundProperties;

	@Autowired
	private ResourceClientService resourceClientService;

	@Autowired
	private BatchTransactionDao batchTransactionDao;
	
	@Autowired
	private TransactionLogDao transactionLogDao;
	
	public void triggerAsyncCallback(TransactionDetails transactionDetail,
			RetrieveDeviceAyncResponse retrieveDeviceReponse, PortinInquiryResBean portinInquiryResBean,
			OutboundRequest outRequestBean, AsyncType asyncType) {
		log.info("Inside ManageLinesService: triggerAsyncCallback");
		String callbackUrl = null;
		AsyncCallbackResponse asyncCallbackResponse = null;
		if (asyncType == AsyncType.SUCCESS) {
			if (retrieveDeviceReponse != null) {
				log.info("triggerAsyncCallback : SUCCESS : " + retrieveDeviceReponse);
				asyncCallbackResponse = constructAsyncBasedonRetrieveDevice(transactionDetail, retrieveDeviceReponse,
						portinInquiryResBean, outRequestBean, asyncType);
			} else if (portinInquiryResBean != null) {
				log.info("triggerAsyncCallback : SUCCESS : " + portinInquiryResBean);
				asyncCallbackResponse = constructAsyncBasedonPortInInquiry(transactionDetail, portinInquiryResBean,
						outRequestBean, asyncType);
			}
			callbackUrl = outRequestBean.getMessageHeader().getReturnURL();
		} else if (asyncType == AsyncType.ERROR) {
			if (retrieveDeviceReponse != null) {
				log.info("triggerAsyncCallback : ERROR : " + retrieveDeviceReponse);
				asyncCallbackResponse = constructAsyncBasedonRetrieveDevice(transactionDetail, retrieveDeviceReponse,
						portinInquiryResBean, outRequestBean, asyncType);
			} else if (portinInquiryResBean != null) {
				log.info("triggerAsyncCallback : ERROR : " + portinInquiryResBean);
				asyncCallbackResponse = constructAsyncBasedonPortInInquiry(transactionDetail, portinInquiryResBean,
						outRequestBean, asyncType);
			}
			callbackUrl = outRequestBean.getMessageHeader().getAsyncErrorURL();
		} else if (asyncType == AsyncType.GATEWAY_RESPONSE) {
			if (portinInquiryResBean != null) {
				log.info("triggerAsyncCallback : GATEWAY_RESPONSE : " + portinInquiryResBean);
				asyncCallbackResponse = constructAsyncBasedonPortInInquiry(transactionDetail, portinInquiryResBean,
						outRequestBean, asyncType);
			}
			callbackUrl = outRequestBean.getMessageHeader().getReturnURL();
		}

		if (callbackUrl != null && asyncCallbackResponse != null) {
			Gson gson = new Gson();
			String asynRequest = gson.toJson(asyncCallbackResponse);
			utilityClass.callRestAPI(asynRequest, callbackUrl, Constants.TOKEN_CODE);
		} else {
			log.info("triggerAsyncCallback : NO CALLBACK WAS TRIGGRED");
		}

	}

	public AsyncCallbackResponse constructAsyncBasedonRetrieveDevice(TransactionDetails transactionDetail,
			RetrieveDeviceAyncResponse retrieveDeviceReponse, PortinInquiryResBean portinInquiryResBean,
			OutboundRequest outRequestBean, AsyncType asyncType) {
		AsyncCallbackResponse asyncCallbackResponse = new AsyncCallbackResponse();
		if (asyncType == AsyncType.SUCCESS) {
			log.info("Triggering Async Callback....");
			// Message Header
			MessageHeader msgHeader = new MessageHeader();
			msgHeader.setRequestType(retrieveDeviceReponse.getMessageHeader().getRequestType());
			msgHeader.setServiceId(retrieveDeviceReponse.getMessageHeader().getServiceId());
			msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
			asyncCallbackResponse.setMessageHeader(msgHeader);

			// Async callback
			asyncCallbackResponse.setAsyncResponse(new com.nsl.managelines.batch.bean.AsyncResponse());
			asyncCallbackResponse.getAsyncResponse().setStatusCode("S0000");
			asyncCallbackResponse.getAsyncResponse().setIccid(retrieveDeviceReponse.getData().getIccid());
			asyncCallbackResponse.getAsyncResponse().setImsi(retrieveDeviceReponse.getData().getImsi());
			asyncCallbackResponse.getAsyncResponse().setMdn(retrieveDeviceReponse.getData().getMdn());
			asyncCallbackResponse.getAsyncResponse().setMin(retrieveDeviceReponse.getData().getMin());
			asyncCallbackResponse.getAsyncResponse().setErrorCode("");
			asyncCallbackResponse.getAsyncResponse().setErrorDescription("Success");

			log.info("Async Callback asyncCallbackResponse :" + asyncCallbackResponse);
		} else if (asyncType == AsyncType.ERROR) {
			log.info("Triggering Error Callback....");
			// Message Header
			MessageHeader msgHeader = new MessageHeader();
			msgHeader.setRequestType(retrieveDeviceReponse.getMessageHeader().getRequestType());
			msgHeader.setServiceId(retrieveDeviceReponse.getMessageHeader().getServiceId());
			msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
			asyncCallbackResponse.setMessageHeader(msgHeader);

			asyncCallbackResponse.setAsyncResponse(new com.nsl.managelines.batch.bean.AsyncResponse());
			asyncCallbackResponse.getAsyncResponse().setStatusCode("E1004");
			asyncCallbackResponse.getAsyncResponse().setErrorCode("E1004");
			asyncCallbackResponse.getAsyncResponse().setErrorDescription("SYSTEM ERROR");

			log.info("Error Callback asyncCallbackResponse :" + asyncCallbackResponse);

		}

		return asyncCallbackResponse;
	}

	public AsyncCallbackResponse constructAsyncBasedonPortInInquiry(TransactionDetails transactionDetail,
			PortinInquiryResBean portinInquiryResBean, OutboundRequest outRequestBean, AsyncType asyncType) {
		AsyncCallbackResponse asyncCallbackResponse = new AsyncCallbackResponse();

		if (asyncType == AsyncType.SUCCESS) {
			log.info("Triggering Async Callback....");
			MessageHeader msgHeader = new MessageHeader();
			msgHeader = new MessageHeader();
			msgHeader.setRequestType(portinInquiryResBean.getMessageHeader().getRequestType());
			msgHeader.setServiceId(portinInquiryResBean.getMessageHeader().getServiceId());
			msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
			asyncCallbackResponse.setMessageHeader(msgHeader);

			asyncCallbackResponse.setAsyncResponse(new com.nsl.managelines.batch.bean.AsyncResponse());
			asyncCallbackResponse.getAsyncResponse().setStatusCode("S0000");

			try {
				LineInquiryResponse lineInquiryResponse = callLineInqury(transactionDetail,
						portinInquiryResBean.getData().getMdn());
				if (lineInquiryResponse != null && lineInquiryResponse.getData() != null
						&& lineInquiryResponse.getData().getMessage() != null
						&& lineInquiryResponse.getData().getMessage().size() > 0
						&& lineInquiryResponse.getData().getMessage().get(0).getResponseCode() != null
						&& lineInquiryResponse.getData().getMessage().get(0).getResponseCode().equals("00")) {

					if (lineInquiryResponse.getData().getSimId() != null
							&& lineInquiryResponse.getData().getSimId().size() > 0) {
						asyncCallbackResponse.getAsyncResponse()
								.setIccid(lineInquiryResponse.getData().getSimId().get(0).getValue());
					}
					asyncCallbackResponse.getAsyncResponse().setImsi(lineInquiryResponse.getData().getImsi());
					if (lineInquiryResponse.getData().getMdn() != null
							&& lineInquiryResponse.getData().getMdn().size() > 0) {
						asyncCallbackResponse.getAsyncResponse()
								.setMdn(lineInquiryResponse.getData().getMdn().get(0).getValue());
					}
					asyncCallbackResponse.getAsyncResponse().setMin(lineInquiryResponse.getData().getMin());
					asyncCallbackResponse.getAsyncResponse().setErrorCode("");
					asyncCallbackResponse.getAsyncResponse().setErrorDescription("Success");
				} else {
					return null;
				}
			} catch (Exception e) {
				log.error("Error calling line inquiry API:", e);
			}
			log.info("Async Callback asyncCallbackResponse :" + asyncCallbackResponse);
		} else if (asyncType == AsyncType.GATEWAY_RESPONSE) {
			MessageHeader msgHeader = new MessageHeader();
			msgHeader.setRequestType(portinInquiryResBean.getMessageHeader().getRequestType());
			msgHeader.setServiceId(portinInquiryResBean.getMessageHeader().getServiceId());
			msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
			asyncCallbackResponse.setMessageHeader(msgHeader);

			asyncCallbackResponse.setGatewayResponse(new GatewayResponse());
			// asyncCallbackResponse.getGatewayResponse().setRequestNo(portinInquiryResBean);
			asyncCallbackResponse.getGatewayResponse()
					.setLnpStatusCode(portinInquiryResBean.getData().getLnpStatusCode());
			asyncCallbackResponse.getGatewayResponse()
					.setResponseType(portinInquiryResBean.getData().getLnpResponseType());
			asyncCallbackResponse.getGatewayResponse().setOnsp(portinInquiryResBean.getData().getOnsp());

			asyncCallbackResponse.getGatewayResponse().setMdnDetail(new MdnDetail());
			asyncCallbackResponse.getGatewayResponse().getMdnDetail().setMdn(portinInquiryResBean.getData().getMdn());
			asyncCallbackResponse.getGatewayResponse().getMdnDetail()
					.setReasonCode(portinInquiryResBean.getData().getReasonCode());
			asyncCallbackResponse.getGatewayResponse().getMdnDetail()
					.setReasonDetail(portinInquiryResBean.getData().getReasonDetail());
			log.info("GATE WAY RESPONSE Callback asyncCallbackResponse :" + asyncCallbackResponse);
		} else if (asyncType == AsyncType.ERROR) {
			log.info("Triggering Error Callback....");
			// Message Header
			MessageHeader msgHeader = new MessageHeader();
			msgHeader.setRequestType(portinInquiryResBean.getMessageHeader().getRequestType());
			msgHeader.setServiceId(portinInquiryResBean.getMessageHeader().getServiceId());
			msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
			asyncCallbackResponse.setMessageHeader(msgHeader);

			asyncCallbackResponse.setAsyncResponse(new com.nsl.managelines.batch.bean.AsyncResponse());
			asyncCallbackResponse.getAsyncResponse().setStatusCode("E1004");
			asyncCallbackResponse.getAsyncResponse().setErrorCode("E1004");
			asyncCallbackResponse.getAsyncResponse().setErrorDescription("SYSTEM ERROR");

			log.info("Error Callback asyncCallbackResponse :" + asyncCallbackResponse);

		}

		return asyncCallbackResponse;
	}

	public LineInquiryResponse callLineInqury(TransactionDetails transactionDetail, String mdn) {
		LineInquiryResponse lineInquiryResponse = null;
		String serviceName = "Line-Inquiry";
		String operationName = "lineinquiryserviceworkflow";
		String outboundRequest = "{\"mdn\":\"" + mdn + "\"}";
		String url = inboundProperties.getRouterserviceurl();

		String request = utilityClass.getRequestJson(outboundRequest, serviceName, operationName,
				transactionDetail.getTransactionUid(), String.valueOf(transactionDetail.getRootTransactionId()));
		String frameworkResponse = utilityClass.callRestAPIForFramework(request, url, null);
		Gson gson = new Gson();
		try {
			if (frameworkResponse != null) {
				frameworkResponse = frameworkResponse.substring(0, frameworkResponse.lastIndexOf("}~") + 1);
				log.info("Line Inquiry Response: " + frameworkResponse);
				lineInquiryResponse = gson.fromJson(frameworkResponse, LineInquiryResponse.class);
			}
		} catch (Exception e) {
			log.error("Exception:", e);
		}
		log.info("lineInquiryResponse : " + lineInquiryResponse);
		return lineInquiryResponse;
	}

	public PlanMigrationRequest planMigration(PlanMigrationRequest request) {
		log.info("planMigration :: " + request);
		if (request.getJobType() == JobType.PREPARE_PM_DATA) {
			request = preparePlanMigration(request);
		} else if (request.getJobType() == JobType.START_PLAN_MIRGATION) {
			request = startPlanMigration(request);
		}
		return request;
	}

	public PlanMigrationRequest preparePlanMigration(PlanMigrationRequest request) {
		ArrayList<StgPlanMigration> stgPlanMigrationList = new ArrayList<StgPlanMigration>();
		try {
			String billCycleResetDay = getCurrentDate();
			ArrayList<Line> lineDetailsList = resourceClientService
					.getlinedetailsbyPlanMigrationEligibile(billCycleResetDay);
			BatchTransaction batchTransaction = new BatchTransaction();
			batchTransaction.setBatchType("PPM");
			batchTransaction = insertIntoBatchTransaction(batchTransaction);
			if (lineDetailsList != null && lineDetailsList.size() > 0) {
				for (Line line : lineDetailsList) {
					StgPlanMigration stgPlanMigration = new StgPlanMigration();
					stgPlanMigration.setELineId(line.getELineId());
					stgPlanMigration.setCreatedDate(getTimeStamp());
					stgPlanMigration.setCreatedBy("NSL");
					stgPlanMigration.setStatus("PENDING");
					stgPlanMigration.setBatchId(batchTransaction.getBatchId());
					stgPlanMigration.setBcd(billCycleResetDay);
					stgPlanMigrationList.add(stgPlanMigration);

				}
			}
			stgPlanMigrationList = resourceClientService.updateStgPlanMigration(stgPlanMigrationList);
		} catch (Exception e) {
			log.error("Exception:", e);
		}
		return request;
	}

	public String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd");
		Calendar cal = Calendar.getInstance();
		String date = sdf.format(cal.getTime());
		log.info("Current Date: " + date);
		if (date.matches("29|30|31")) {
			date = "01";
			log.info("Current Date: " + date);
		}
		return date;
	}

	public String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		Calendar cal = Calendar.getInstance();
		log.debug("Current Date: " + sdf.format(cal.getTime()));
		String date = sdf.format(cal.getTime());
		return date;
	}

	public FileOperationRequest planMigrationEligibilityCheck(String request) {
		FileOperationRequest fileOperationReq = null;
		try {

			log.info("planMigrationEligibilityCheck :: " + request);
			if (request != null) {
				fileOperationReq = (new Gson()).fromJson(request, FileOperationRequest.class);
				for (FileDetails fileDetails : fileOperationReq.getData().getFileDetails()) {
					log.info("filename:" + fileDetails.getReportsFileName());
					if (fileDetails.getReportsFileName() != null) {
						int count = batchTransactionDao.findCountByExternalValue1(fileDetails.getReportsFileName());
						log.info("count : " + count);
						if (count > 0) {
							log.info("File already processed " + fileDetails.getReportsFileName());
						} else if (fileDetails.getReportsFile() != null) {
							log.info("Processing file :" + fileDetails.getReportsFileName());
							BatchTransaction batchTransaction = new BatchTransaction();
							batchTransaction.setRequestMsg(request);
							batchTransaction.setBatchType("PME");
							batchTransaction.setExternalValue1(fileDetails.getReportsFileName());
							batchTransaction = insertIntoBatchTransaction(batchTransaction);
							String reportContent = new String(fileDetails.getReportsFile());
							String[] requetsContent = reportContent.split("\n");
							LinkedHashMap<String, PlanMigrationEligibilityOutput> planMigOutput = getFileContent(
									requetsContent);
							if (batchTransaction.getBatchId() != null) {
								generateOutputFile(planMigOutput, batchTransaction);
							} else {
								log.error("BATCH ID not generated.");
							}
						} else {
							log.info("File is EMPTY " + fileDetails.getReportsFileName());
						}
					}

				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return fileOperationReq;
	}

	private void generateOutputFile(LinkedHashMap<String, PlanMigrationEligibilityOutput> planMigOutput,
			BatchTransaction batchTransaction) {
		if (planMigOutput != null) {
			Set<String> keys = planMigOutput.keySet();
			String fileContent = "MDN,LINEID,EligibleForOCSMigration,Result\n";
			for (String key : keys) {
				PlanMigrationEligibilityOutput pmlOut = planMigOutput.get(key);
				fileContent += (((pmlOut.getInputrow()) + "," + pmlOut.getResult()) + "\n");
			}
			batchTransaction.setResponseMsg(fileContent);
			batchTransaction.setBatchStatus(Constants.COMPLETED);
			batchTransaction.setBatchUpdateStatus(Constants.COMPLETED);
			if (batchTransaction.getModifiedDate() == null) {
				batchTransaction.setModifiedDate(ZonedDateTime.now());
			}
			String reportname = batchTransaction.getExternalValue1();
			if (reportname != null) {
				String outputFilename = reportname.replace("Input", "Output");
				batchTransaction.setExternalValue2(outputFilename);
			}
			batchTransaction = batchTransactionDao.saveBatchTransaction(batchTransaction);

			ReportMgmtRequest reportMgmtRequest = new ReportMgmtRequest();
			reportMgmtRequest.setData(new Data());
			reportMgmtRequest.getData().setJobName(Constants.PLAN_MIG_ELIG_OUT_REP);
			reportMgmtRequest.getData().setReportType(Constants.PLAN_MIG_ELIG_OUT_REP);
			reportMgmtRequest.getData().setFileName(batchTransaction.getExternalValue2());
			reportMgmtRequest.setQueryString(new HashMap<String, String>());
			reportMgmtRequest.getQueryString().put("batchId", String.valueOf(batchTransaction.getBatchId()));
			try {
				Gson gson = new Gson();
				String request = gson.toJson(reportMgmtRequest, ReportMgmtRequest.class);
				utilityClass.callRestAPI(request, inboundProperties.getGenerateReportManagement(), null);
			} catch (Exception e) {
				log.error("Error in sending output file", e);
			}
		}
	}

	private LinkedHashMap<String, PlanMigrationEligibilityOutput> getFileContent(String[] requetsContent) {
		LinkedHashMap<String, PlanMigrationEligibilityOutput> planMigOutput = new LinkedHashMap<String, PlanMigrationEligibilityOutput>();
		ArrayList<Line> lineDetailsList = new ArrayList<Line>();
		for (int i = 0; i < requetsContent.length; i++) {
			if (i == 0)
				continue;
			String row = requetsContent[i];
			PlanMigrationEligibilityOutput plmOutput = new PlanMigrationEligibilityOutput();
			String elineId = null;
			String mdnValue = null;
			String eligibleFormigration = null;
			if (row.contains("\r")) {
				row = row.replace("\r", "");
			}
			if (row.contains("\n")) {
				row = row.replace("\n", "");
			}
			plmOutput.setInputrow(row);
			if (row.contains(",")) {
				if (row.split(",").length >= 3) {
					eligibleFormigration = row.split(",")[2];
				}
				if (row.split(",").length >= 2) {
					elineId = row.split(",")[1];
				}
				if (row.split(",").length >= 1) {
					mdnValue = row.split(",")[0];
				}
				plmOutput.setMdn(mdnValue);
				plmOutput.setELineId(elineId);
				plmOutput.setEligibleFormigration(eligibleFormigration);
				log.info("Inside mdnValue::::" + mdnValue + " elineId:::::::" + elineId);
				log.info("Inside eligibleFormigration::::" + eligibleFormigration);
				if (mdnValue == null || elineId == null) {
					plmOutput.setResult("Line ID-MDN does not exist");
				} else if (eligibleFormigration == null
						|| (eligibleFormigration != null && !eligibleFormigration.matches("Y|N"))) {
					plmOutput.setResult("Invalid EligibleforOCSMigration value");
				} else {
					Line lineDetails = new Line();
					lineDetails.setMdn(mdnValue);
					lineDetails.setELineId(elineId);
					lineDetails.setPlanMigrationEligibile(eligibleFormigration);
					lineDetails.setIndex(String.valueOf(i));
					lineDetailsList.add(lineDetails);

					plmOutput.setResult("PENDING");
				}
			} else {
				plmOutput.setResult("Invalid row.");
			}

			String key = String.valueOf(i) + (elineId != null ? elineId : "") + (mdnValue != null ? mdnValue : "");
			planMigOutput.put(key, plmOutput);
		}

		if (lineDetailsList.size() > 0) {
			lineDetailsList = resourceClientService.updateMigrationEligibility(lineDetailsList);
			if (lineDetailsList != null && lineDetailsList.size() > 0) {
				for (Line line : lineDetailsList) {
					String keyvalue = line.getIndex() + (line.getELineId() != null ? line.getELineId() : "")
							+ (line.getMdn() != null ? line.getMdn() : "");
					PlanMigrationEligibilityOutput plm = planMigOutput.get(keyvalue);
					if (line.getIsLineIdExist() != null && line.getIsLineIdExist().equals("Y")) {
						plm.setResult("SUCCESS");
					} else {
						plm.setResult("Line ID-MDN does not exist");
					}
				}
			}
		}
		return planMigOutput;
	}

	public BatchTransaction insertIntoBatchTransaction(BatchTransaction batchTransaction) {
		if (batchTransaction == null) {
			batchTransaction = new BatchTransaction();
		}
		batchTransaction.setBatchStatus(Constants.IN_PROGRESS);
		batchTransaction.setBatchUpdateStatus(Constants.IN_PROGRESS);
		batchTransaction.setCreatedBy("NSL");
		if (batchTransaction.getCreatedDate() == null) {
			batchTransaction.setCreatedDate(ZonedDateTime.now());
		}
		batchTransaction = batchTransactionDao.saveBatchTransaction(batchTransaction);
		return batchTransaction;
	}

	public PlanMigrationRequest startPlanMigration(PlanMigrationRequest request) {
		ArrayList<StgPlanMigrationDto> stgPlanMigrationDtolist = null;
		String ServiceURL = "";
		ArrayList<Line> lineDetailsList = new ArrayList<Line>();
		ArrayList<LinePlan> linePlanList = new ArrayList<LinePlan>();

		try {
			stgPlanMigrationDtolist = resourceClientService.getStgPlanMigrationList(getCurrentDate());
			if (request.getData() == null) {
				request.setData(new Data());
			}
			request.getData().setBcd(getCurrentDate());
			if (stgPlanMigrationDtolist != null && stgPlanMigrationDtolist.size() > 0) {
				ArrayList<StgPlanMigration> stgPlanMigrationList = new ArrayList<StgPlanMigration>();
				ArrayList<RefPlanMigration> refPlanMigrationlist = resourceClientService.getRefPlanMigrationList();
				for (StgPlanMigrationDto stgPlanMigrationDto : stgPlanMigrationDtolist) {
					BatchTransaction batchTransaction = new BatchTransaction();
					batchTransaction.setBatchType("SPM");
					batchTransaction.setExtBatchId(Long.toString(stgPlanMigrationDto.getBatchId()));
					batchTransaction.setMdn(stgPlanMigrationDto.getMdn());
					
					batchTransaction = insertIntoBatchTransaction(batchTransaction);
					boolean smartwatch = false;
					if (stgPlanMigrationDto.getLineType() != null
							&& ("SMARTWATCH").equalsIgnoreCase(stgPlanMigrationDto.getLineType())) {
						smartwatch = true;
					}
					String startPlanMigrationRequest = pilotPlanMigrationRequestContruction(stgPlanMigrationDto,
							batchTransaction, smartwatch);
					if (smartwatch) {
						ServiceURL = inboundProperties.getChangefeatureurl();
					} else {
						ServiceURL = inboundProperties.getChangerateplanurl();
					}
					String OauthUrl = inboundProperties.getAuthserver();
					String ServerURL = inboundProperties.getIntrernalServerURL();
					StgPlanMigration stgPlanMigration = new StgPlanMigration();
					BeanUtils.copyProperties(stgPlanMigrationDto, stgPlanMigration);
					stgPlanMigration.setELineId(stgPlanMigrationDto.getELineId());
					stgPlanMigration.setBatchId(stgPlanMigrationDto.getBatchId());
					stgPlanMigration.setProcessedStartDate(getTimeStamp());
					stgPlanMigration.setCreatedBy("NSL");
					boolean isEligibileForMigration =false;
					boolean hasPlanMapping =false;
					log.info("planCode::"+ stgPlanMigrationDto.getWhsPlan()+" PlanGroup::"+stgPlanMigrationDto.getPlanGroup());
					if(stgPlanMigrationDto.getPlanGroup()!=null && ("OCS").equalsIgnoreCase(stgPlanMigrationDto.getPlanGroup())){
						if(refPlanMigrationlist!=null){
							for (RefPlanMigration refPlanMigration : refPlanMigrationlist) {
								if(stgPlanMigrationDto.getWhsPlan()!=null && refPlanMigration.getNewPlan()!=null){
									if(stgPlanMigrationDto.getWhsPlan().equalsIgnoreCase(refPlanMigration.getNewPlan())){
										Line lineDetails = new Line();
										lineDetails.setMdn(stgPlanMigrationDto.getMdn());
										lineDetails.setELineId(stgPlanMigrationDto.getELineId());
										lineDetails.setPlanMigrationEligibile("P");
										lineDetailsList.add(lineDetails);
										LinePlan linePlan = new LinePlan();
										linePlan.setELineId(stgPlanMigrationDto.getELineId());	
										linePlan.setPlanCategory(refPlanMigration.getNewPlanCategory());
										linePlanList.add(linePlan);
										stgPlanMigration.setStatus("SUCCESS");
										break;
									}
								}
							}
						}
					}else if(refPlanMigrationlist!=null){
						for (RefPlanMigration refPlanMigration : refPlanMigrationlist) {
							if(stgPlanMigrationDto.getWhsPlan()!=null && refPlanMigration.getOldPlan()!=null){
								if(stgPlanMigrationDto.getWhsPlan().equalsIgnoreCase(refPlanMigration.getOldPlan())){
									isEligibileForMigration = true;
									if(refPlanMigration.getNewPlan()!=null){
										hasPlanMapping=true;
									}
									break;
								}
							}
						}
					}
					if(!hasPlanMapping && isEligibileForMigration){
						stgPlanMigration.setErrorCode("ERR22");
						stgPlanMigration.setErrorMessage("Line with " + stgPlanMigrationDto.getWhsPlan() + " does NOT HAVE OCS Plan mapping");
						stgPlanMigration.setStatus("FAILED");
					}/*else if (stgPlanMigrationDto.getLineStatus() != null
							&& (("HOTLINE").equalsIgnoreCase(stgPlanMigrationDto.getLineStatus())
									|| ("SUSPEND").equalsIgnoreCase(stgPlanMigrationDto.getLineStatus()))) {
						stgPlanMigration.setErrorCode("ERR21");
						stgPlanMigration.setErrorMessage("Line in " + stgPlanMigrationDto.getLineStatus() + " Status");
						stgPlanMigration.setStatus("FAILED");
					}*/else if(isEligibileForMigration){
						String nslResponse = utilityClass.batchProcessingResponseFromClient(startPlanMigrationRequest,
								ServerURL, OauthUrl, ServiceURL);
						NSLResponse nslresp = null;
						Boolean failed = Boolean.FALSE;
						if (StringUtils.hasText(nslResponse)) {
							nslresp = (new Gson()).fromJson(nslResponse, NSLResponse.class);
							if (nslresp != null) {
								if (nslresp.getData() != null && nslresp.getData().getCode() != null
										&& nslresp.getData().getCode().contains("200")) {
									String transactionId = nslresp.getData().getTransactionId();
									stgPlanMigration.setTransactionId(transactionId);
									stgPlanMigration.setStatus("IN PROGRESS");
								} else {
									stgPlanMigration.setStatus("FAILED");
									failed = Boolean.TRUE;
								}
							} else {
								stgPlanMigration.setStatus("FAILED");
								failed = Boolean.TRUE;
							}
						} else {
							stgPlanMigration.setStatus("FAILED");
							failed = Boolean.TRUE;
						}
						if (failed && nslresp != null) {
							stgPlanMigration = getErrorDetails(stgPlanMigration, nslresp);
						}
					}
					stgPlanMigrationList.add(stgPlanMigration);
				}
				if (stgPlanMigrationList.size() > 0) {
					stgPlanMigrationList = resourceClientService.updateStgPlanMigration(stgPlanMigrationList);
				}
				if (lineDetailsList.size() > 0) {
					lineDetailsList = resourceClientService.updateMigrationEligibility(lineDetailsList);
				}
				if (linePlanList.size() > 0) {
					linePlanList = resourceClientService.updatePlanCategoryByLineId(linePlanList);
				}
			}
			generateOutputReportForPlanMigration(request, null);
		} catch (Exception e) {
			log.error("Exception::", e);
		}
		return request;
	}

	private Integer verifyPlanMigrationCompleted(PlanMigrationRequest request) {
		StgPlanMigration stgPlanMigration = new StgPlanMigration();
		stgPlanMigration.setBcd(getCurrentDate());
		stgPlanMigration.setStatus("IN PROGRESS");
		Integer count = resourceClientService.getStgPlanMigrationCount(stgPlanMigration);
		if (count == null) {
			count = 0;
		}
		return count;
	}

	public void generateOutputReportForPlanMigration(PlanMigrationRequest request, BatchTransaction batchTransaction) {
		try {
			Integer count = verifyPlanMigrationCompleted(request);
			log.info("PlanMigration Count::"+ count);
			if (count != null && count == 0) {
				String fileName = "YYYYMMDD_BCD_OCSMigration_Report.csv";
				if (fileName.contains("YYYYMMDDHHMMSS")) {
					SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
					fileName = fileName.replaceAll("YYYYMMDDHHMMSS", f.format(new Date()));
				} else if (fileName.contains("YYYYMMDD")) {
					SimpleDateFormat f = new SimpleDateFormat("yyyMMdd");
					fileName = fileName.replaceAll("YYYYMMDD", f.format(new Date()));
					log.debug("Inside fileNameReports" + fileName);
				} else if (fileName != null) {
					Date date = new Date(System.currentTimeMillis());
					SimpleDateFormat sdf1;
					sdf1 = new SimpleDateFormat("MMddyyy");
					String dateString = sdf1.format(date);
					fileName = fileName.replaceAll("MMDDYYYY", dateString);
				}
				
				if (fileName.contains("BCD") ) {
					fileName = fileName.replaceAll("BCD", request.getData().getBcd());
				}
				log.info("fileName:"+ fileName);
				int fileCount = transactionLogDao.findCountByFileName(fileName,"SUCCESS");
				log.info("fileCount:"+ fileCount);
				if(fileCount==0){
					ReportMgmtRequest reportMgmtRequest = new ReportMgmtRequest();
					reportMgmtRequest.setData(new Data());
					reportMgmtRequest.getData().setJobName(Constants.PLAN_MIG_OUTPUT_REP);
					reportMgmtRequest.getData().setReportType(Constants.PLAN_MIG_OUTPUT_REP);
					reportMgmtRequest.getData().setFileName(fileName);
					reportMgmtRequest.getData().setBcd(request.getData().getBcd());
					reportMgmtRequest.setQueryString(new HashMap<String, String>());
					//reportMgmtRequest.getQueryString().put("batchId", String.valueOf(batchTransaction.getBatchId()));
					reportMgmtRequest.getQueryString().put("bcd", String.valueOf(request.getData().getBcd()));
					try {
						Gson gson = new Gson();
						String rptReq = gson.toJson(reportMgmtRequest, ReportMgmtRequest.class);
						utilityClass.callRestAPI(rptReq, inboundProperties.getGenerateReportManagement(), null);
					} catch (Exception e) {
						log.error("Error in sending output file", e);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception::", e);
		}
	}

	private StgPlanMigration getErrorDetails(StgPlanMigration stgPlanMigration, NSLResponse nslresp) {
		if (nslresp.getData().getMessage() != null) {
			for (com.nsl.managelines.batch.bean.planmigration.NSLResponse.Message msg : nslresp.getData()
					.getMessage()) {
				stgPlanMigration.setErrorCode(msg.getResponseCode());
				stgPlanMigration.setErrorMessage(msg.getDescription());
			}
		}
		return stgPlanMigration;
	}

	public String pilotPlanMigrationRequestContruction(StgPlanMigrationDto stgPlanMigrationDto,
			BatchTransaction batchTransaction, boolean smartwatch) {
		String referenceNumber = batchTransaction.getReferenceNumber();
		StringBuilder parameterJson = new StringBuilder();
		String request = "";
		try {
			parameterJson.append("{\r\n");
			parameterJson.append(" \"messageHeader\": {\r\n");
			parameterJson.append(" \"serviceId\": \"SPECTRUM_MOBILE\",\r\n");
			parameterJson.append(" \"requestType\": \"MNO-AP\",\r\n");
			parameterJson.append(" \"referenceNumber\": \"" + referenceNumber + "\",\r\n");
			parameterJson.append(" \"returnURL\": \"BatchProcessing\",\r\n");
			parameterJson.append(" \"asyncErrorURL\": \"BatchProcessing\"\r\n");
			parameterJson.append(" },\r\n");
			parameterJson.append(" \"data\": {\r\n");
			if (smartwatch) {
				parameterJson.append(" \"transactionType\": \"WC\",\r\n");
			} else {
				parameterJson.append(" \"transactionType\": \"WR\",\r\n");
			}
			parameterJson.append(" \"transactionTimeStamp\": \"" + getTimeStamp() + "\",\r\n");
			parameterJson.append(" \"channel\": \"SFTP\",\r\n");
			parameterJson.append(" \"syncTransaction\": \"T\",\r\n");
			parameterJson.append(" \"account\": {\r\n");
			parameterJson.append(" \"accountNumber\": \"" + stgPlanMigrationDto.getAccountNumber() + "\",\r\n");
			parameterJson.append(" \"contextId\": \"" + stgPlanMigrationDto.getContextId() + "\",\r\n");
			parameterJson.append(" \"type\": \"" + stgPlanMigrationDto.getAccountType() + "\"},\r\n");
			parameterJson.append(" \"subOrder\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"id\": \"" + stgPlanMigrationDto.getELineId() + "\",\r\n");
			parameterJson.append(" \"isFlatRatePlan\": \"N\",\r\n");
			parameterJson.append(" \"isPlanMigration\": \"Y\",\r\n");
			parameterJson.append(" \"lineStatus\": \"" + stgPlanMigrationDto.getLineStatus() +"\",\r\n");			
			parameterJson.append(" \"lineId\": \"" + stgPlanMigrationDto.getELineId() + "\",\r\n");
			parameterJson.append(" \"mdn\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"type\": \"mdn\",\r\n");
			parameterJson.append(" \"value\": \"" + stgPlanMigrationDto.getMdn() + "\"\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append(" ],\r\n");

			parameterJson.append("\"deviceId\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"type\": \"IMEI\",\r\n");
			parameterJson.append(" \"value\": \"" + stgPlanMigrationDto.getImei() + "\"\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append(" ]\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append(" ]\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append("}");
			request = parameterJson.toString();
			log.info("Request for MDN : " + stgPlanMigrationDto.getMdn() + " : construct json::" + request);
		} catch (Exception e) {
			log.error("Exception::", e);
		}
		return request;
	}

}
