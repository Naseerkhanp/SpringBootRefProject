package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.entity.DataDetails;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("DataDetailsHandler")
public class DataDetailsHandler implements Handler {

	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst,UsageReportDetails usageReportDetails) throws Exception {
		long id = NslFileUploadUtils.nullCheck(column[0]);
		try {
			DataDetails dataDetails = new DataDetails();
			dataDetails.setDsource(fileUploadLst.stream().findFirst().get().getDefaultValue());
			dataDetails.setRecordId(id);
			dataDetails.setUsageSequenceId(NslFileUploadUtils.nullCheck(column[1]));
			dataDetails.setRerateInd(NslFileUploadUtils.nullChecker(column[2]));
			dataDetails.setRerateReasonCode(NslFileUploadUtils.nullCheck(column[3]));
			dataDetails.setBillingNumber(column[4]);
			dataDetails.setImsi(NslFileUploadUtils.nullChecker(column[5]));
			dataDetails.setMinNum(NslFileUploadUtils.nullChecker(column[6]));
			dataDetails.setDeviceId(NslFileUploadUtils.nullChecker(column[7]));
			dataDetails.setServicePlan(NslFileUploadUtils.nullChecker(column[8]));
			dataDetails.setTariffPlan(NslFileUploadUtils.nullChecker(column[9]));
			dataDetails.setTierCd(NslFileUploadUtils.nullChecker(column[10]));
			dataDetails.setStartDateTime(NslFileUploadUtils.convertIntToDate(column[11]));
			dataDetails.setEndDateTime(NslFileUploadUtils.convertIntToDate(column[12]));
			dataDetails.setGmtOffset(NslFileUploadUtils.nullCheck(column[13]));
			dataDetails.setRecordType(NslFileUploadUtils.nullCheck(column[14]));
			dataDetails.setEventType(NslFileUploadUtils.nullCheck(column[15]));
			dataDetails.setCategory(NslFileUploadUtils.nullChecker(column[16]));
			dataDetails.setFootprintCode(NslFileUploadUtils.nullChecker(column[17]));
			dataDetails.setSeqNo(NslFileUploadUtils.nullCheck(column[18]));
			dataDetails.setRatePeriod(NslFileUploadUtils.nullChecker(column[19]));
			dataDetails.setRateType(NslFileUploadUtils.nullChecker(column[20]));
			dataDetails.setBsid(NslFileUploadUtils.nullChecker(column[21]));
			dataDetails.setOrigBsid(NslFileUploadUtils.nullChecker(column[22]));
			dataDetails.setCountryCd(NslFileUploadUtils.nullChecker(column[23]));
			dataDetails.setServingPlmnId(NslFileUploadUtils.nullCheck(column[24]));
			dataDetails.setCauseForRecordClosure(NslFileUploadUtils.nullChecker(column[25]));
			long totalkbUnits = (long) Float.parseFloat(column[26]);
			dataDetails.setTotalKbUnits(totalkbUnits);
			dataDetails.setIncludedKbUnits(NslFileUploadUtils.nullCheck(column[27]));
			dataDetails.setChargedKbUnits((long) Float.parseFloat(column[28]));
			dataDetails.setChargeAmount((long) Float.parseFloat(column[29]));
			dataDetails.setZone(NslFileUploadUtils.nullChecker(column[30]));
			dataDetails.setEquivalentUnits(NslFileUploadUtils.nullCheck(column[31]));
			dataDetails.setData_1(NslFileUploadUtils.nullCheck(column[32]));
			if (column.length > 33)
			dataDetails.setFeatureCd(NslFileUploadUtils.nullChecker(column[33]));
			if (detailsBuiler.containsKey(id)) {
				List<Object> li = detailsBuiler.get(id);
				li.add(dataDetails);
				detailsBuiler.put(id, li);
			} else {
				List<Object> li = new ArrayList<>();
				li.add(dataDetails);
				detailsBuiler.put(id, li);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

}
