package com.excelacom.servicegateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.util.ErrorHandler;

import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import org.springframework.util.ErrorHandler;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;
	
	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;


	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}

	@Bean
	public Queue speedTestQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSpeedTestQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange speedTestExchange() {
		return new DirectExchange(inboundQueueProperties.getSpeedTestExchange());
	}

	@Bean
	Binding speedTestBinding() {
		return BindingBuilder.bind(speedTestQueue()).to(speedTestExchange())
				.with(inboundQueueProperties.getSpeedTestQueue());
	}

	
	@Bean
	public Queue deleteSpeedTestQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDeleteSpeedTestQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange deleteSpeedTestExchange() {
		return new DirectExchange(inboundQueueProperties.getDeleteSpeedTestExchange());
	}

	@Bean
	Binding deleteSpeedTestBinding() {
		return BindingBuilder.bind(deleteSpeedTestQueue()).to(deleteSpeedTestExchange())
				.with(inboundQueueProperties.getDeleteSpeedTestQueue());
	}
	

	@Bean
	public Queue getConfigManagerQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getGetConfigManagerQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange getConfigManagerExchange() {
		return new DirectExchange(inboundQueueProperties.getGetConfigManagerExchange());
	}

	@Bean
	Binding getConfigManagerBinding() {
		return BindingBuilder.bind(getConfigManagerQueue()).to(getConfigManagerExchange())
				.with(inboundQueueProperties.getGetConfigManagerQueue());
	}
	
	@Bean
	public Queue ncmDeviceAppIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmDeviceAppIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmDeviceAppIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmDeviceAppIntegrationExchange());
	}

	@Bean
	Binding ncmDeviceAppIntegrationBinding() {
		return BindingBuilder.bind(ncmDeviceAppIntegrationQueue()).to(ncmDeviceAppIntegrationExchange())
				.with(inboundQueueProperties.getNcmDeviceAppIntegrationQueue());
	}
	
	
	@Bean
	public Queue ncmNetDeviceHealthIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmNetDeviceHealthIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmNetDeviceHealthIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmNetDeviceHealthIntegrationExchange());
	}

	@Bean
	Binding ncmNetDeviceHealthIntegrationBinding() {
		return BindingBuilder.bind(ncmNetDeviceHealthIntegrationQueue()).to(ncmNetDeviceHealthIntegrationExchange())
				.with(inboundQueueProperties.getNcmNetDeviceHealthIntegrationQueue());
	}
	

	@Bean
	public Queue ncmproductIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmproductIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmProductIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmProductIntegrationExchange());
	}

	@Bean
	Binding ncmProductIntegrationBinding() {
		return BindingBuilder.bind(ncmproductIntegrationQueue()).to(ncmProductIntegrationExchange())
				.with(inboundQueueProperties.getNcmproductIntegrationQueue());
	}
	
	@Bean
	public Queue netDeviceIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNetDeviceIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange netDeviceIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getNetDeviceIntegrationExchange());
	}

	@Bean
	Binding netDeviceIntegrationBinding() {
		return BindingBuilder.bind(netDeviceIntegrationQueue()).to(netDeviceIntegrationExchange())
				.with(inboundQueueProperties.getNetDeviceIntegrationQueue());
	}
	
	@Bean
	public Queue netDeviceMetricsQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNetDeviceMetricsQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange netDeviceMetricsExchange() {
		return new DirectExchange(inboundQueueProperties.getNetDeviceMetricsExchange());
	}

	@Bean
	Binding netDeviceMetricsBinding() {
		return BindingBuilder.bind(netDeviceMetricsQueue()).to(netDeviceMetricsExchange())
				.with(inboundQueueProperties.getNetDeviceMetricsQueue());
	}
	
	@Bean
	public Queue NcmNetDeviceSampleQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmNetDeviceSampleQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmNetDeviceSampleExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmNetDeviceSampleExchange());
	}

	@Bean
	Binding NcmNetDeviceSampleBinding() {
		return BindingBuilder.bind(NcmNetDeviceSampleQueue()).to(NcmNetDeviceSampleExchange())
				.with(inboundQueueProperties.getNcmNetDeviceSampleQueue());
	}
	
	@Bean
	public Queue ncmGroupDeleteQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmGroupDeleteQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmGroupDeleteExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmGroupDeleteExchange());
	}

	@Bean
	Binding ncmGroupDeleteBinding() {
		return BindingBuilder.bind(ncmGroupDeleteQueue()).to(ncmGroupDeleteExchange())
				.with(inboundQueueProperties.getNcmGroupDeleteQueue());
	}
	
	
	@Bean
	public Queue ncmAccountGetQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmAccountGetQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmAccountGetExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmAccountGetExchange());
	}

	@Bean
	Binding ncmAccountGetBinding() {
		return BindingBuilder.bind(ncmAccountGetQueue()).to(ncmAccountGetExchange())
				.with(inboundQueueProperties.getNcmAccountGetQueue());
	}
	
	@Bean
	public Queue ncmPushNotificationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmPushNotificationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmPushNotificationExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmPushNotificationExchange());
	}

	@Bean
	Binding ncmPushNotificationBinding() {
		return BindingBuilder.bind(ncmPushNotificationQueue()).to(ncmPushNotificationExchange())
				.with(inboundQueueProperties.getNcmPushNotificationQueue());
	}

	
	@Bean
	public Queue ncmAccountDeleteQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmAccountDeleteQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmAccountDeleteExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmAccountDeleteExchange());
	}

	@Bean
	Binding ncmAccountDeleteBinding() {
		return BindingBuilder.bind(ncmAccountDeleteQueue()).to(ncmAccountDeleteExchange())
				.with(inboundQueueProperties.getNcmAccountDeleteQueue());
	}
	
	
	@Bean
	public Queue ncmDeviceAppsStateServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmDeviceAppsStateServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmDeviceAppsStateServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmDeviceAppsStateServiceExchange());
	}

	@Bean
	Binding ncmDeviceAppsStateServiceBinding() {
		return BindingBuilder.bind(ncmDeviceAppsStateServiceQueue()).to(ncmDeviceAppsStateServiceExchange())
				.with(inboundQueueProperties.getNcmDeviceAppsStateServiceQueue());
	}
	
	@Bean
	public Queue ncmGetRouterStateServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmGetRouterStateServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmGetRouterStateServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmGetRouterStateServiceExchange());
	}

	@Bean
	Binding ncmGetRouterStateServiceBinding() {
		return BindingBuilder.bind(ncmGetRouterStateServiceQueue()).to(ncmGetRouterStateServiceExchange())
				.with(inboundQueueProperties.getNcmGetRouterStateServiceQueue());
	}
	
	@Bean
	public Queue DeleteLocationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDeleteLocationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange DeleteLocationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getDeleteLocationServiceExchange());
	}

	@Bean
	Binding DeleteLocationServiceBinding() {
		return BindingBuilder.bind(DeleteLocationServiceQueue()).to(DeleteLocationServiceExchange())
				.with(inboundQueueProperties.getDeleteLocationServiceQueue());
	}
	

	@Bean
	public Queue RouterLogsQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getRouterLogsQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange RouterLogsExchange() {
		return new DirectExchange(inboundQueueProperties.getRouterLogsExchange());
	}

	@Bean
	Binding RouterLogsBinding() {
		return BindingBuilder.bind(RouterLogsQueue()).to(RouterLogsExchange())
				.with(inboundQueueProperties.getRouterLogsQueue());
	}
	
	
	@Bean
	public Queue LocationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getLocationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange LocationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getLocationServiceExchange());
	}

	@Bean
	Binding LocationServiceBinding() {
		return BindingBuilder.bind(LocationServiceQueue()).to(LocationServiceExchange())
				.with(inboundQueueProperties.getLocationServiceQueue());
	}
	
	@Bean
	public Queue NcmFirmwareQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmFirmwareQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmFirmwareExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmFirmwareExchange());
	}

	@Bean
	Binding NcmFirmwareBinding() {
		return BindingBuilder.bind(NcmFirmwareQueue()).to(NcmFirmwareExchange())
				.with(inboundQueueProperties.getNcmFirmwareQueue());
	}
	

	@Bean
	public Queue ncmnetdeviceusagesampleserviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmnetdeviceusagesampleserviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmnetdeviceusagesampleserviceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmnetdeviceusagesampleserviceExchange());
	}

	@Bean
	Binding ncmnetdeviceusagesampleserviceBinding() {
		return BindingBuilder.bind(ncmnetdeviceusagesampleserviceQueue()).to(ncmnetdeviceusagesampleserviceExchange())
				.with(inboundQueueProperties.getNcmnetdeviceusagesampleserviceQueue());
	}
	
	


	@Bean
	public Queue NcmLocationServiceCreateQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmLocationServiceCreateQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmLocationServiceCreateExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmLocationServiceCreateExchange());
	}

	@Bean
	Binding NcmLocationServiceCreateeBinding() {
		return BindingBuilder.bind(NcmLocationServiceCreateQueue()).to(NcmLocationServiceCreateExchange())
				.with(inboundQueueProperties.getNcmLocationServiceCreateQueue());
	}
	
	@Bean
	public Queue RouterStreamUsageSamplesIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getRouterStreamUsageSamplesIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange RouterStreamUsageSamplesIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getRouterStreamUsageSamplesIntegrationExchange());
	}

	@Bean
	Binding RouterStreamUsageSamplesIntegrationBinding() {
		return BindingBuilder.bind(RouterStreamUsageSamplesIntegrationQueue()).to(RouterStreamUsageSamplesIntegrationExchange())
				.with(inboundQueueProperties.getRouterStreamUsageSamplesIntegrationQueue());
	}
	
	@Bean
	public Queue ncmRoutersallertsIntegrationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmRoutersallertsIntegrationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmRoutersallertsIntegrationExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmRoutersallertsIntegrationExchange());
	}

	@Bean
	Binding ncmRoutersallertsIntegrationBinding() {
		return BindingBuilder.bind(ncmRoutersallertsIntegrationQueue()).to(ncmRoutersallertsIntegrationExchange())
				.with(inboundQueueProperties.getNcmRoutersallertsIntegrationQueue());
	}
	
	@Bean
	public Queue ncmGetGroupServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmGetGroupServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmGetGroupServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmGetGroupServiceExchange());
	}

	@Bean
	Binding ncmGetGroupServiceBinding() {
		return BindingBuilder.bind(ncmGetGroupServiceQueue()).to(ncmGetGroupServiceExchange())
				.with(inboundQueueProperties.getNcmGetGroupServiceQueue());
	}
	
	@Bean
	public Queue NCMGroupUpdateServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNCMGroupUpdateServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NCMGroupUpdateServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNCMGroupUpdateServiceExchange());
	}

	@Bean
	Binding NCMGroupUpdateServiceBinding() {
		return BindingBuilder.bind(NCMGroupUpdateServiceQueue()).to(NCMGroupUpdateServiceExchange())
				.with(inboundQueueProperties.getNCMGroupUpdateServiceQueue());
	}
	
	@Bean
	public Queue ncmGetDeviceAppVersionQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmGetDeviceAppVersionQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmGetDeviceAppVersionExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmGetDeviceAppVersionExchange());
	}

	@Bean
	Binding ncmGetDeviceAppVersionBinding() {
		return BindingBuilder.bind(ncmGetDeviceAppVersionQueue()).to(ncmGetDeviceAppVersionExchange())
				.with(inboundQueueProperties.getNcmGetDeviceAppVersionQueue());
	}
	
	@Bean
	public Queue NcmgetRouterQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmgetRouterQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmgetrouterExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmgetrouterExchange());
	}

	@Bean
	Binding NcmgetrouterBinding() {
		return BindingBuilder.bind(NcmgetRouterQueue()).to(NcmgetrouterExchange())
				.with(inboundQueueProperties.getNcmgetRouterQueue());
	}
	
	
	@Bean
	public Queue NcmgetactivitylogQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmgetactivitylogQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmgetactivitylogExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmgetactivitylogExchange());
	}

	@Bean
	Binding NcmgetactivitylogrBinding() {
		return BindingBuilder.bind(NcmgetactivitylogQueue()).to(NcmgetactivitylogExchange())
				.with(inboundQueueProperties.getNcmgetactivitylogQueue());
	}
	
	
	@Bean
	public Queue ncmAccountCreateQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmAccountCreateQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmAccountCreateExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmAccountCreateExchange());
	}

	@Bean
	Binding ncmAccountCreateBinding() {
		return BindingBuilder.bind(ncmAccountCreateQueue()).to(ncmAccountCreateExchange())
				.with(inboundQueueProperties.getNcmAccountCreateQueue());
	}
	
	@Bean
	public Queue ncmRouterUpdateQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmRouterUpdateQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmRouterUpdateExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmRouterUpdateExchange());
	}

	@Bean
	Binding ncmRouterUpdateBinding() {
		return BindingBuilder.bind(ncmRouterUpdateQueue()).to(ncmRouterUpdateExchange())
				.with(inboundQueueProperties.getNcmRouterUpdateQueue());
	}
	
	@Bean
	public Queue DeleteDeviceAppBindingsQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDeleteDeviceAppBindingsQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange DeleteDeviceAppBindingsExchange() {
		return new DirectExchange(inboundQueueProperties.getDeleteDeviceAppBindingsExchange());
	}

	@Bean
	Binding DeleteDeviceAppBindingsBinding() {
		return BindingBuilder.bind(DeleteDeviceAppBindingsQueue()).to(DeleteDeviceAppBindingsExchange())
				.with(inboundQueueProperties.getDeleteDeviceAppBindingsQueue());
	}
	
	
	@Bean
	public Queue UpdateLocationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getUpdateLocationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange UpdateLocationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getUpdateLocationServiceExchange());
	}

	@Bean
	Binding UpdateLocationServiceBinding() {
		return BindingBuilder.bind(UpdateLocationServiceQueue()).to(UpdateLocationServiceExchange())
				.with(inboundQueueProperties.getUpdateLocationServiceQueue());
	}
	
	@Bean
	public Queue ncmCreateGroupServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmCreateGroupServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmCreateGroupServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmCreateGroupServiceExchange());
	}

	@Bean
	Binding ncmCreateGroupServiceBinding() {
		return BindingBuilder.bind(ncmCreateGroupServiceQueue()).to(ncmCreateGroupServiceExchange())
				.with(inboundQueueProperties.getNcmCreateGroupServiceQueue());
	}
	
	@Bean
	public Queue ncmUpdateAccountSystemQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmUpdateAccountSystemQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmUpdateAccountSystemExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmUpdateAccountSystemExchange());
	}

	@Bean
	Binding ncmUpdateAccountSystemBinding() {
		return BindingBuilder.bind(ncmUpdateAccountSystemQueue()).to(ncmUpdateAccountSystemExchange())
				.with(inboundQueueProperties.getNcmUpdateAccountSystemQueue());
	}
	
	@Bean
	public Queue NcmgetdeviceappbindinglogQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmgetdeviceappbindinglogQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmgetdeviceappbindinglogExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmgetdeviceappbindinglogExchange());
	}

	@Bean
	Binding NcmgetdeviceappBinding() {
		return BindingBuilder.bind(NcmgetdeviceappbindinglogQueue()).to(NcmgetdeviceappbindinglogExchange())
				.with(inboundQueueProperties.getNcmgetdeviceappbindinglogQueue());
	}
	
	@Bean
	public Queue NcmCreateSpeedlogQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmCreateSpeedlogQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmCreateSpeedlogExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmCreateSpeedlogExchange());
	}

	@Bean
	Binding NcmCreateSpeedlogBinding() {
		return BindingBuilder.bind(NcmCreateSpeedlogQueue()).to(NcmCreateSpeedlogExchange())
				.with(inboundQueueProperties.getNcmCreateSpeedlogQueue());
	}
	
	@Bean
	public Queue ncmRouterDeleteQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmRouterDeleteQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmRouterDeleteExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmRouterDeleteExchange());
	}

	@Bean
	Binding ncmRouterDeleteBinding() {
		return BindingBuilder.bind(ncmRouterDeleteQueue()).to(ncmRouterDeleteExchange())
				.with(inboundQueueProperties.getNcmRouterDeleteQueue());
	}
	
	
	@Bean
	public Queue nslDeviceAppsIntegrationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNslDeviceAppsIntegrationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange nslDeviceAppsIntegrationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNslDeviceAppsIntegrationServiceExchange());
	}

	@Bean
	Binding nslDeviceAppsIntegrationServiceBinding() {
		return BindingBuilder.bind(nslDeviceAppsIntegrationServiceQueue()).to(nslDeviceAppsIntegrationServiceExchange())
				.with(inboundQueueProperties.getNslDeviceAppsIntegrationServiceQueue());
	}
	
	@Bean
	public Queue deleteDeviceAppVersionQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDeleteDeviceAppVersionQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange deleteDeviceAppVersionExchange() {
		return new DirectExchange(inboundQueueProperties.getDeleteDeviceAppVersionExchange());
	}

	@Bean
	Binding getDeleteDeviceAppVersionBinding() {
		return BindingBuilder.bind(deleteDeviceAppVersionQueue()).to(deleteDeviceAppVersionExchange())
				.with(inboundQueueProperties.getDeleteDeviceAppVersionQueue());
	}
	
	
	@Bean
	public Queue NcmFailoversIntegrationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmFailoversIntegrationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmFailoversIntegrationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmFailoversIntegrationServiceExchange());
	}

	@Bean
	Binding NcmFailoversIntegrationServiceBinding() {
		return BindingBuilder.bind(NcmFailoversIntegrationServiceQueue()).to(NcmFailoversIntegrationServiceExchange())
				.with(inboundQueueProperties.getNcmFailoversIntegrationServiceQueue());
	}
	
	
	
	@Bean
	public Queue NcmrebootQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmrebootQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmrebootExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmrebootExchange());
	}

	@Bean
	Binding NcmrebootBinding() {
		return BindingBuilder.bind(NcmrebootQueue()).to(NcmrebootExchange())
				.with(inboundQueueProperties.getNcmrebootQueue());
	}
	
	@Bean
	public Queue NcmcreatedeviceappbindinglogQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmcreatedeviceappbindinglogQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmcreatedeviceappbindinglogExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmcreatedeviceappbindinglogExchange());
	}

	@Bean
	Binding NcmcreatedeviceappbindinglogBinding() {
		return BindingBuilder.bind(NcmcreatedeviceappbindinglogQueue()).to(NcmcreatedeviceappbindinglogExchange())
				.with(inboundQueueProperties.getNcmcreatedeviceappbindinglogQueue());
	}
	
	
	@Bean
	public Queue NcmhistoricalloclogQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNcmhistoricalloclogQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NcmhistoricalloclogExchange() {
		return new DirectExchange(inboundQueueProperties.getNcmhistoricalloclogExchange());
	}

	@Bean
	Binding getNcmhistoricalloclogBinding() {
		return BindingBuilder.bind(NcmhistoricalloclogQueue()).to(NcmhistoricalloclogExchange())
				.with(inboundQueueProperties.getNcmhistoricalloclogQueue());
	}
	
	
	@Bean
	public Queue NCMAllertIntegrationServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNCMAllertIntegrationServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NCMAllertIntegrationServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNCMAllertIntegrationServiceExchange());
	}

	@Bean
	Binding NCMAllertIntegrationServiceBinding() {
		return BindingBuilder.bind(NCMAllertIntegrationServiceQueue()).to(NCMAllertIntegrationServiceExchange())
				.with(inboundQueueProperties.getNCMAllertIntegrationServiceQueue());
	}
	
	
	@Bean
	public Queue NCMUpdateConfigMangerServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNCMUpdateConfigMangerServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange NCMUpdateConfigMangerServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getNCMUpdateConfigMangerServiceExchange());
	}

	@Bean
	Binding NCMUpdateConfigMangerServiceBinding() {
		return BindingBuilder.bind(NCMUpdateConfigMangerServiceQueue()).to(NCMUpdateConfigMangerServiceExchange())
				.with(inboundQueueProperties.getNCMUpdateConfigMangerServiceQueue());
	}
	
	
	
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}
	
	
	
	
	@Bean(name = "ConnectionFactory")
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}
	
	@Bean(name = "getSpeedTestConnectionFactory")
	public ConnectionFactory getSpeedTestrabbitMQConnectionFactory() {
		CachingConnectionFactory getSpeedTestconnectionFactory = new CachingConnectionFactory(host);
		getSpeedTestconnectionFactory.setPort(Integer.parseInt(port));
		getSpeedTestconnectionFactory.setUsername(username);
		getSpeedTestconnectionFactory.setPassword(password);
		getSpeedTestconnectionFactory.setConnectionTimeout(30000);
		return getSpeedTestconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getSpeedTestRabbitAdmin(){
        return new RabbitAdmin(getSpeedTestrabbitMQConnectionFactory());
    }
	
	@Bean(name = "deleteSpeedTestConnectionFactory")
	public ConnectionFactory deleteSpeedTestrabbitMQConnectionFactory() {
		CachingConnectionFactory deleteSpeedTestconnectionFactory = new CachingConnectionFactory(host);
		deleteSpeedTestconnectionFactory.setPort(Integer.parseInt(port));
		deleteSpeedTestconnectionFactory.setUsername(username);
		deleteSpeedTestconnectionFactory.setPassword(password);
		deleteSpeedTestconnectionFactory.setConnectionTimeout(30000);
		return deleteSpeedTestconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin deleteSpeedTestRabbitAdmin(){
        return new RabbitAdmin(deleteSpeedTestrabbitMQConnectionFactory());
    }
	
	@Bean(name = "deviceAppsIntegrationConnectionFactory")
	public ConnectionFactory deviceAppsIntegrationrabbitMQConnectionFactory() {
		CachingConnectionFactory deviceAppsIntegrationconnectionFactory = new CachingConnectionFactory(host);
		deviceAppsIntegrationconnectionFactory.setPort(Integer.parseInt(port));
		deviceAppsIntegrationconnectionFactory.setUsername(username);
		deviceAppsIntegrationconnectionFactory.setPassword(password);
		deviceAppsIntegrationconnectionFactory.setConnectionTimeout(30000);
		return deviceAppsIntegrationconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin deviceAppsIntegrationRabbitAdmin(){
        return new RabbitAdmin(deviceAppsIntegrationrabbitMQConnectionFactory());
    }
	
	@Bean(name = "configManagerConnectionFactory")
	public ConnectionFactory configManagerrabbitMQConnectionFactory() {
		CachingConnectionFactory configManagerconnectionFactory = new CachingConnectionFactory(host);
		configManagerconnectionFactory.setPort(Integer.parseInt(port));
		configManagerconnectionFactory.setUsername(username);
		configManagerconnectionFactory.setPassword(password);
		configManagerconnectionFactory.setConnectionTimeout(30000);
		return configManagerconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin configManagerRabbitAdmin(){
        return new RabbitAdmin(configManagerrabbitMQConnectionFactory());
    }
	
	@Bean(name = "netDeviceHealthConnectionFactory")
	public ConnectionFactory netDeviceHealthrabbitMQConnectionFactory() {
		CachingConnectionFactory netDeviceHealthconnectionFactory = new CachingConnectionFactory(host);
		netDeviceHealthconnectionFactory.setPort(Integer.parseInt(port));
		netDeviceHealthconnectionFactory.setUsername(username);
		netDeviceHealthconnectionFactory.setPassword(password);
		netDeviceHealthconnectionFactory.setConnectionTimeout(30000);
		return netDeviceHealthconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin netDeviceHealthRabbitAdmin(){
        return new RabbitAdmin(netDeviceHealthrabbitMQConnectionFactory());
    }
	
	@Bean(name = "productsIntegrationConnectionFactory")
	public ConnectionFactory productsIntegrationrabbitMQConnectionFactory() {
		CachingConnectionFactory productsIntegrationconnectionFactory = new CachingConnectionFactory(host);
		productsIntegrationconnectionFactory.setPort(Integer.parseInt(port));
		productsIntegrationconnectionFactory.setUsername(username);
		productsIntegrationconnectionFactory.setPassword(password);
		productsIntegrationconnectionFactory.setConnectionTimeout(30000);
		return productsIntegrationconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin productsIntegrationRabbitAdmin(){
        return new RabbitAdmin(productsIntegrationrabbitMQConnectionFactory());
    }
	
	@Bean(name = "netDeviceIntegrationConnectionFactory")
	public ConnectionFactory netDeviceIntegrationrabbitMQConnectionFactory() {
		CachingConnectionFactory netDeviceIntegrationconnectionFactory = new CachingConnectionFactory(host);
		netDeviceIntegrationconnectionFactory.setPort(Integer.parseInt(port));
		netDeviceIntegrationconnectionFactory.setUsername(username);
		netDeviceIntegrationconnectionFactory.setPassword(password);
		netDeviceIntegrationconnectionFactory.setConnectionTimeout(30000);
		return netDeviceIntegrationconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin netDeviceIntegrationRabbitAdmin(){
        return new RabbitAdmin(netDeviceIntegrationrabbitMQConnectionFactory());
    }
	
	@Bean(name = "netdevicemetricsConnectionFactory")
	public ConnectionFactory netdevicemetricsrabbitMQConnectionFactory() {
		CachingConnectionFactory netdevicemetricsconnectionFactory = new CachingConnectionFactory(host);
		netdevicemetricsconnectionFactory.setPort(Integer.parseInt(port));
		netdevicemetricsconnectionFactory.setUsername(username);
		netdevicemetricsconnectionFactory.setPassword(password);
		netdevicemetricsconnectionFactory.setConnectionTimeout(30000);
		return netdevicemetricsconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin netdevicemetricsRabbitAdmin(){
        return new RabbitAdmin(netdevicemetricsrabbitMQConnectionFactory());
    }
	
	@Bean(name = "netDeviceUsageSamplesConnectionFactory")
	public ConnectionFactory netDeviceUsageSamplesrabbitMQConnectionFactory() {
		CachingConnectionFactory netDeviceUsageSamplesconnectionFactory = new CachingConnectionFactory(host);
		netDeviceUsageSamplesconnectionFactory.setPort(Integer.parseInt(port));
		netDeviceUsageSamplesconnectionFactory.setUsername(username);
		netDeviceUsageSamplesconnectionFactory.setPassword(password);
		netDeviceUsageSamplesconnectionFactory.setConnectionTimeout(30000);
		return netDeviceUsageSamplesconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin netDeviceUsageSamplesRabbitAdmin(){
        return new RabbitAdmin(netDeviceUsageSamplesrabbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmGroupDeleteConnectionFactory")
	public ConnectionFactory ncmGroupDeleterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmGroupDeleteconnectionFactory = new CachingConnectionFactory(host);
		ncmGroupDeleteconnectionFactory.setPort(Integer.parseInt(port));
		ncmGroupDeleteconnectionFactory.setUsername(username);
		ncmGroupDeleteconnectionFactory.setPassword(password);
		ncmGroupDeleteconnectionFactory.setConnectionTimeout(30000);
		return ncmGroupDeleteconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmGroupDeleteRabbitAdmin(){
        return new RabbitAdmin(ncmGroupDeleterabbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmAccountGetConnectionFactory")
	public ConnectionFactory ncmAccountGetrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmAccountGetconnectionFactory = new CachingConnectionFactory(host);
		ncmAccountGetconnectionFactory.setPort(Integer.parseInt(port));
		ncmAccountGetconnectionFactory.setUsername(username);
		ncmAccountGetconnectionFactory.setPassword(password);
		ncmAccountGetconnectionFactory.setConnectionTimeout(30000);
		return ncmAccountGetconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmAccountGetRabbitAdmin(){
        return new RabbitAdmin(ncmAccountGetrabbitMQConnectionFactory());
    }
	
		@Bean(name = "ncmPushNotificationConnectionFactory")
	public ConnectionFactory ncmPushNotificationrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmPushNotificationconnectionFactory = new CachingConnectionFactory(host);
		ncmPushNotificationconnectionFactory.setPort(Integer.parseInt(port));
		ncmPushNotificationconnectionFactory.setUsername(username);
		ncmPushNotificationconnectionFactory.setPassword(password);
		ncmPushNotificationconnectionFactory.setConnectionTimeout(30000);
		return ncmPushNotificationconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmPushNotificationRabbitAdmin(){
        return new RabbitAdmin(ncmPushNotificationrabbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmUpdateAccountSystemConnectionFactory")
	public ConnectionFactory ncmUpdateAccountSystemrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmUpdateAccountSystemconnectionFactory = new CachingConnectionFactory(host);
		ncmUpdateAccountSystemconnectionFactory.setPort(Integer.parseInt(port));
		ncmUpdateAccountSystemconnectionFactory.setUsername(username);
		ncmUpdateAccountSystemconnectionFactory.setPassword(password);
		ncmUpdateAccountSystemconnectionFactory.setConnectionTimeout(30000);
		return ncmUpdateAccountSystemconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmUpdateAccountSystemRabbitAdmin(){
        return new RabbitAdmin(ncmUpdateAccountSystemrabbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmgetdeviceappbindinglogConnectionFactory")
	public ConnectionFactory ncmgetdeviceappbindinglograbbitMQConnectionFactory() {
		CachingConnectionFactory ncmgetdeviceappbindinglogconnectionFactory = new CachingConnectionFactory(host);
		ncmgetdeviceappbindinglogconnectionFactory.setPort(Integer.parseInt(port));
		ncmgetdeviceappbindinglogconnectionFactory.setUsername(username);
		ncmgetdeviceappbindinglogconnectionFactory.setPassword(password);
		ncmgetdeviceappbindinglogconnectionFactory.setConnectionTimeout(30000);
		return ncmgetdeviceappbindinglogconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmgetdeviceappbindinglogRabbitAdmin(){
        return new RabbitAdmin(ncmgetdeviceappbindinglograbbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmCreateSpeedlogConnectionFactory")
	public ConnectionFactory ncmCreateSpeedlograbbitMQConnectionFactory() {
		CachingConnectionFactory ncmCreateSpeedlogconnectionFactory = new CachingConnectionFactory(host);
		ncmCreateSpeedlogconnectionFactory.setPort(Integer.parseInt(port));
		ncmCreateSpeedlogconnectionFactory.setUsername(username);
		ncmCreateSpeedlogconnectionFactory.setPassword(password);
		ncmCreateSpeedlogconnectionFactory.setConnectionTimeout(30000);
		return ncmCreateSpeedlogconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmCreateSpeedlogRabbitAdmin(){
        return new RabbitAdmin(ncmCreateSpeedlograbbitMQConnectionFactory());
    }
	
	@Bean(name = "ncmRouterDeleteConnectionFactory")
	public ConnectionFactory ncmRouterDeleterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmRouterDeleteconnectionFactory = new CachingConnectionFactory(host);
		ncmRouterDeleteconnectionFactory.setPort(Integer.parseInt(port));
		ncmRouterDeleteconnectionFactory.setUsername(username);
		ncmRouterDeleteconnectionFactory.setPassword(password);
		ncmRouterDeleteconnectionFactory.setConnectionTimeout(30000);
		return ncmRouterDeleteconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmRouterDeleteRabbitAdmin(){
        return new RabbitAdmin(ncmRouterDeleterabbitMQConnectionFactory());
    }
	
	@Bean("customSimpleRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(rabbitMQConnectionFactory());
		//factory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers0));
		//factory.setMaxConcurrentConsumers(Integer.parseInt(250));
		factory.setReceiveTimeout((long) 30000);
		factory.setErrorHandler(errorHandler());
		return factory;
	}
	
	@Bean("getSpeedTestrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getSpeedTestrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getSpeedTestfactory = new SimpleRabbitListenerContainerFactory();
		getSpeedTestfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getSpeedTestfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getSpeedTestfactory.setPrefetchCount(1);
		getSpeedTestfactory.setReceiveTimeout((long) 50000);
		getSpeedTestfactory.setConnectionFactory(getSpeedTestrabbitMQConnectionFactory());
		getSpeedTestfactory.setErrorHandler(errorHandler());
		return getSpeedTestfactory;
	}
	
	@Bean
	public ErrorHandler errorHandler() {
	    return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}
	
	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
	    return new CustomFatalExceptionStrategy();
	}

	

	@Bean("deleteSpeedTestrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory deleteSpeedTestrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory deleteSpeedfactory = new SimpleRabbitListenerContainerFactory();
		deleteSpeedfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		deleteSpeedfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		deleteSpeedfactory.setPrefetchCount(1);
		deleteSpeedfactory.setReceiveTimeout((long) 50000);
		deleteSpeedfactory.setConnectionFactory(deleteSpeedTestrabbitMQConnectionFactory());
		deleteSpeedfactory.setErrorHandler(errorHandler());
		return deleteSpeedfactory;
	}
	
	@Bean("deviceAppsIntegrationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory deviceAppsIntegrationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory deviceAppsIntegrationfactory = new SimpleRabbitListenerContainerFactory();
		deviceAppsIntegrationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		deviceAppsIntegrationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		deviceAppsIntegrationfactory.setPrefetchCount(1);
		deviceAppsIntegrationfactory.setReceiveTimeout((long) 50000);
		deviceAppsIntegrationfactory.setConnectionFactory(deviceAppsIntegrationrabbitMQConnectionFactory());
		return deviceAppsIntegrationfactory;
	}
	
	@Bean("configManagerrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory configManagerrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory configManagerfactory = new SimpleRabbitListenerContainerFactory();
		configManagerfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		configManagerfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		configManagerfactory.setPrefetchCount(1);
		configManagerfactory.setReceiveTimeout((long) 50000);
		configManagerfactory.setConnectionFactory(configManagerrabbitMQConnectionFactory());
		configManagerfactory.setErrorHandler(errorHandler());
		return configManagerfactory;
	}
	
	@Bean("netDeviceHealthrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory netDeviceHealthrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory netDeviceHealthfactory = new SimpleRabbitListenerContainerFactory();
		netDeviceHealthfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		netDeviceHealthfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		netDeviceHealthfactory.setPrefetchCount(1);
		netDeviceHealthfactory.setReceiveTimeout((long) 50000);
		netDeviceHealthfactory.setConnectionFactory(netDeviceHealthrabbitMQConnectionFactory());
		netDeviceHealthfactory.setErrorHandler(errorHandler());
		return netDeviceHealthfactory;
	}
	
	@Bean("productsIntegrationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory productsIntegrationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory productsIntegrationfactory = new SimpleRabbitListenerContainerFactory();
		productsIntegrationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		productsIntegrationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		productsIntegrationfactory.setPrefetchCount(1);
		productsIntegrationfactory.setReceiveTimeout((long) 50000);
		productsIntegrationfactory.setConnectionFactory(productsIntegrationrabbitMQConnectionFactory());
		productsIntegrationfactory.setErrorHandler(errorHandler());
		return productsIntegrationfactory;
	}
	
	@Bean("pushnotificationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory pushNotificationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory pushNotificationfactory = new SimpleRabbitListenerContainerFactory();
		pushNotificationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		pushNotificationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		pushNotificationfactory.setPrefetchCount(1);
		pushNotificationfactory.setReceiveTimeout((long) 50000);
		pushNotificationfactory.setConnectionFactory(ncmPushNotificationrabbitMQConnectionFactory());
		pushNotificationfactory.setErrorHandler(errorHandler());
		return pushNotificationfactory;
	}
	
	@Bean("netDeviceIntegrationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory netDeviceIntegrationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory netDeviceIntegrationfactory = new SimpleRabbitListenerContainerFactory();
		netDeviceIntegrationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		netDeviceIntegrationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		netDeviceIntegrationfactory.setPrefetchCount(1);
		netDeviceIntegrationfactory.setReceiveTimeout((long) 50000);
		netDeviceIntegrationfactory.setConnectionFactory(netDeviceIntegrationrabbitMQConnectionFactory());
		netDeviceIntegrationfactory.setErrorHandler(errorHandler());
		return netDeviceIntegrationfactory;
	}
	
	@Bean("netdevicemetricsrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory netdevicemetricsrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory netdevicemetricsfactory = new SimpleRabbitListenerContainerFactory();
		netdevicemetricsfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		netdevicemetricsfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		netdevicemetricsfactory.setPrefetchCount(1);
		netdevicemetricsfactory.setReceiveTimeout((long) 50000);
		netdevicemetricsfactory.setConnectionFactory(netdevicemetricsrabbitMQConnectionFactory());
		netdevicemetricsfactory.setErrorHandler(errorHandler());
		return netdevicemetricsfactory;
	}
	
	@Bean("netDeviceUsageSamplesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory netDeviceUsageSamplesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory netDeviceUsageSamplesfactory = new SimpleRabbitListenerContainerFactory();
		netDeviceUsageSamplesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		netDeviceUsageSamplesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		netDeviceUsageSamplesfactory.setPrefetchCount(1);
		netDeviceUsageSamplesfactory.setReceiveTimeout((long) 50000);
		netDeviceUsageSamplesfactory.setConnectionFactory(netDeviceUsageSamplesrabbitMQConnectionFactory());
		netDeviceUsageSamplesfactory.setErrorHandler(errorHandler());
		return netDeviceUsageSamplesfactory;
	}
	
	@Bean("ncmGroupDeleterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmGroupDeleterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmGroupDeletefactory = new SimpleRabbitListenerContainerFactory();
		ncmGroupDeletefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmGroupDeletefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmGroupDeletefactory.setPrefetchCount(1);
		ncmGroupDeletefactory.setReceiveTimeout((long) 50000);
		ncmGroupDeletefactory.setConnectionFactory(ncmGroupDeleterabbitMQConnectionFactory());
		ncmGroupDeletefactory.setErrorHandler(errorHandler());
		return ncmGroupDeletefactory;
	}
	
	@Bean("ncmAccountGetrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmAccountGetrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmAccountGetfactory = new SimpleRabbitListenerContainerFactory();
		ncmAccountGetfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmAccountGetfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmAccountGetfactory.setPrefetchCount(1);
		ncmAccountGetfactory.setReceiveTimeout((long) 50000);
		ncmAccountGetfactory.setConnectionFactory(ncmAccountGetrabbitMQConnectionFactory());
		ncmAccountGetfactory.setErrorHandler(errorHandler());
		return ncmAccountGetfactory;
	}
	
	@Bean("ncmUpdateAccountSystemrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmUpdateAccountSystemrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmUpdateAccountSystemfactory = new SimpleRabbitListenerContainerFactory();
		ncmUpdateAccountSystemfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmUpdateAccountSystemfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmUpdateAccountSystemfactory.setPrefetchCount(1);
		ncmUpdateAccountSystemfactory.setReceiveTimeout((long) 50000);
		ncmUpdateAccountSystemfactory.setConnectionFactory(ncmUpdateAccountSystemrabbitMQConnectionFactory());
		return ncmUpdateAccountSystemfactory;
	}
	
	@Bean("ncmgetdeviceappbindinglograbbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmgetdeviceappbindinglograbbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmgetdeviceappbindinglogfactory = new SimpleRabbitListenerContainerFactory();
		ncmgetdeviceappbindinglogfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmgetdeviceappbindinglogfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmgetdeviceappbindinglogfactory.setPrefetchCount(1);
		ncmgetdeviceappbindinglogfactory.setReceiveTimeout((long) 50000);
		ncmgetdeviceappbindinglogfactory.setConnectionFactory(ncmgetdeviceappbindinglograbbitMQConnectionFactory());
		return ncmgetdeviceappbindinglogfactory;
	}
	
	
@Bean("ncmCreateSpeedlograbbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmCreateSpeedlograbbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmCreateSpeedlogfactory = new SimpleRabbitListenerContainerFactory();
		ncmCreateSpeedlogfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmCreateSpeedlogfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmCreateSpeedlogfactory.setPrefetchCount(1);
		ncmCreateSpeedlogfactory.setReceiveTimeout((long) 50000);
		ncmCreateSpeedlogfactory.setConnectionFactory(ncmCreateSpeedlograbbitMQConnectionFactory());
		return ncmCreateSpeedlogfactory;
	}

@Bean("ncmRouterDeleterabbitListenerContainerFactory")
public SimpleRabbitListenerContainerFactory ncmRouterDeleterabbitListenerContainerFactory() {
	SimpleRabbitListenerContainerFactory ncmRouterDeletefactory = new SimpleRabbitListenerContainerFactory();
	ncmRouterDeletefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
	ncmRouterDeletefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
	ncmRouterDeletefactory.setPrefetchCount(1);
	ncmRouterDeletefactory.setReceiveTimeout((long) 50000);
	ncmRouterDeletefactory.setConnectionFactory(ncmRouterDeleterabbitMQConnectionFactory());
	return ncmRouterDeletefactory;
}

	
	@Bean("customRabbitTemplate")
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate getSpeedTestcustomRabbitTemplate() {
		RabbitTemplate getSpeedrabbitTemplate = new RabbitTemplate();
		getSpeedrabbitTemplate.setReplyTimeout(30000L);
		getSpeedrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getSpeedrabbitTemplate.setConnectionFactory(getSpeedTestrabbitMQConnectionFactory());
		return getSpeedrabbitTemplate;
	}

	@Bean()
	public RabbitTemplate deleteSpeedTestcustomRabbitTemplate() {
		RabbitTemplate deleteSpeedrabbitTemplate = new RabbitTemplate();
		deleteSpeedrabbitTemplate.setReplyTimeout(30000L);
		deleteSpeedrabbitTemplate.setMessageConverter(jsonMessageConverter());
		deleteSpeedrabbitTemplate.setConnectionFactory(deleteSpeedTestrabbitMQConnectionFactory());
		return deleteSpeedrabbitTemplate;
	}

	@Bean()
	public RabbitTemplate deviceAppsIntegrationcustomRabbitTemplate() {
		RabbitTemplate deviceAppsIntegrationrabbitTemplate = new RabbitTemplate();
		deviceAppsIntegrationrabbitTemplate.setReplyTimeout(30000L);
		deviceAppsIntegrationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		deviceAppsIntegrationrabbitTemplate.setConnectionFactory(deviceAppsIntegrationrabbitMQConnectionFactory());
		return deviceAppsIntegrationrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate configMangercustomRabbitTemplate() {
		RabbitTemplate configMangerrabbitTemplate = new RabbitTemplate();
		configMangerrabbitTemplate.setReplyTimeout(30000L);
		configMangerrabbitTemplate.setMessageConverter(jsonMessageConverter());
		configMangerrabbitTemplate.setConnectionFactory(configManagerrabbitMQConnectionFactory());
		return configMangerrabbitTemplate;
	}

	@Bean()
	public RabbitTemplate netDeviceHealthcustomRabbitTemplate() {
		RabbitTemplate netDeviceHealthrabbitTemplate = new RabbitTemplate();
		netDeviceHealthrabbitTemplate.setReplyTimeout(30000L);
		netDeviceHealthrabbitTemplate.setMessageConverter(jsonMessageConverter());
		netDeviceHealthrabbitTemplate.setConnectionFactory(netDeviceHealthrabbitMQConnectionFactory());
		return netDeviceHealthrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate productsIntegrationcustomRabbitTemplate() {
		RabbitTemplate productsIntegrationrabbitTemplate = new RabbitTemplate();
		productsIntegrationrabbitTemplate.setReplyTimeout(30000L);
		productsIntegrationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		productsIntegrationrabbitTemplate.setConnectionFactory(productsIntegrationrabbitMQConnectionFactory());
		return productsIntegrationrabbitTemplate;
	}

	@Bean()
	public RabbitTemplate netDeviceIntegrationcustomRabbitTemplate() {
		RabbitTemplate netDeviceIntegrationrabbitTemplate = new RabbitTemplate();
		netDeviceIntegrationrabbitTemplate.setReplyTimeout(30000L);
		netDeviceIntegrationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		netDeviceIntegrationrabbitTemplate.setConnectionFactory(netDeviceIntegrationrabbitMQConnectionFactory());
		return netDeviceIntegrationrabbitTemplate;
	}

	

	@Bean()
	public RabbitTemplate netdevicemetricscustomRabbitTemplate() {
		RabbitTemplate netdevicemetricsrabbitTemplate = new RabbitTemplate();
		netdevicemetricsrabbitTemplate.setReplyTimeout(30000L);
		netdevicemetricsrabbitTemplate.setMessageConverter(jsonMessageConverter());
		netdevicemetricsrabbitTemplate.setConnectionFactory(netdevicemetricsrabbitMQConnectionFactory());
		return netdevicemetricsrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate netDeviceUsageSamplescustomRabbitTemplate() {
		RabbitTemplate netDeviceUsageSamplesrabbitTemplate = new RabbitTemplate();
		netDeviceUsageSamplesrabbitTemplate.setReplyTimeout(30000L);
		netDeviceUsageSamplesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		netDeviceUsageSamplesrabbitTemplate.setConnectionFactory(netDeviceUsageSamplesrabbitMQConnectionFactory());
		return netDeviceUsageSamplesrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmGroupDeletecustomRabbitTemplate() {
		RabbitTemplate ncmGroupDeleterabbitTemplate = new RabbitTemplate();
		ncmGroupDeleterabbitTemplate.setReplyTimeout(30000L);
		ncmGroupDeleterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmGroupDeleterabbitTemplate.setConnectionFactory(ncmGroupDeleterabbitMQConnectionFactory());
		return ncmGroupDeleterabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmAccountGetcustomRabbitTemplate() {
		RabbitTemplate ncmAccountGetrabbitTemplate = new RabbitTemplate();
		ncmAccountGetrabbitTemplate.setReplyTimeout(30000L);
		ncmAccountGetrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmAccountGetrabbitTemplate.setConnectionFactory(ncmAccountGetrabbitMQConnectionFactory());
		return ncmAccountGetrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmPushNotificationcustomRabbitTemplate() {
		RabbitTemplate ncmPushNotificationrabbitTemplate = new RabbitTemplate();
		ncmPushNotificationrabbitTemplate.setReplyTimeout(30000L);
		ncmPushNotificationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmPushNotificationrabbitTemplate.setConnectionFactory(ncmPushNotificationrabbitMQConnectionFactory());
		return ncmPushNotificationrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmUpdateAccountSystemcustomRabbitTemplate() {
		RabbitTemplate ncmUpdateAccountSystemrabbitTemplate = new RabbitTemplate();
		ncmUpdateAccountSystemrabbitTemplate.setReplyTimeout(30000L);
		ncmUpdateAccountSystemrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmUpdateAccountSystemrabbitTemplate.setConnectionFactory(ncmUpdateAccountSystemrabbitMQConnectionFactory());
		return ncmUpdateAccountSystemrabbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmgetdeviceappbindinglogcustomRabbitTemplate() {
		RabbitTemplate ncmgetdeviceappbindinglograbbitTemplate = new RabbitTemplate();
		ncmgetdeviceappbindinglograbbitTemplate.setReplyTimeout(30000L);
		ncmgetdeviceappbindinglograbbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmgetdeviceappbindinglograbbitTemplate.setConnectionFactory(ncmgetdeviceappbindinglograbbitMQConnectionFactory());
		return ncmgetdeviceappbindinglograbbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmCreateSpeedlogcustomRabbitTemplate() {
		RabbitTemplate ncmCreateSpeedlograbbitTemplate = new RabbitTemplate();
		ncmCreateSpeedlograbbitTemplate.setReplyTimeout(30000L);
		ncmCreateSpeedlograbbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmCreateSpeedlograbbitTemplate.setConnectionFactory(ncmCreateSpeedlograbbitMQConnectionFactory());
		return ncmCreateSpeedlograbbitTemplate;
	}
	
	@Bean()
	public RabbitTemplate ncmRouterDeletecustomRabbitTemplate() {
		RabbitTemplate ncmRouterDeleterabbitTemplate = new RabbitTemplate();
		ncmRouterDeleterabbitTemplate.setReplyTimeout(30000L);
		ncmRouterDeleterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmRouterDeleterabbitTemplate.setConnectionFactory(ncmRouterDeleterabbitMQConnectionFactory());
		return ncmRouterDeleterabbitTemplate;
	}
	

	
	@Bean(name = "routersAllertsConnectionFactory")
	public ConnectionFactory routersAllertsrabbitMQConnectionFactory() {
		CachingConnectionFactory routersAllertsConnectionFactory = new CachingConnectionFactory(host);
		routersAllertsConnectionFactory.setPort(Integer.parseInt(port));
		routersAllertsConnectionFactory.setUsername(username);
		routersAllertsConnectionFactory.setPassword(password);
		routersAllertsConnectionFactory.setConnectionTimeout(30000);
		return routersAllertsConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin routersAllertsRabbitAdmin(){
        return new RabbitAdmin(routersAllertsrabbitMQConnectionFactory());
    }

@Bean("routersAllertsrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory routersAllertsrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory routersAllertsfactory = new SimpleRabbitListenerContainerFactory();
		routersAllertsfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		routersAllertsfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		routersAllertsfactory.setPrefetchCount(1);
		routersAllertsfactory.setReceiveTimeout((long) 50000);
		routersAllertsfactory.setConnectionFactory(routersAllertsrabbitMQConnectionFactory());
		routersAllertsfactory.setErrorHandler(errorHandler());
		return routersAllertsfactory;
	}
	
	@Bean()
	public RabbitTemplate routersAllertscustomRabbitTemplate() {
		RabbitTemplate routersAllertsrabbitTemplate = new RabbitTemplate();
		routersAllertsrabbitTemplate.setReplyTimeout(30000L);
		routersAllertsrabbitTemplate.setMessageConverter(jsonMessageConverter());
		routersAllertsrabbitTemplate.setConnectionFactory(routersAllertsrabbitMQConnectionFactory());
		return routersAllertsrabbitTemplate;
	}
	
	//GetGroupService
	@Bean(name = "GetGroupServiceConnectionFactory")
	public ConnectionFactory GetGroupServicerabbitMQConnectionFactory() {
		CachingConnectionFactory GetGroupServiceConnectionFactory = new CachingConnectionFactory(host);
		GetGroupServiceConnectionFactory.setPort(Integer.parseInt(port));
		GetGroupServiceConnectionFactory.setUsername(username);
		GetGroupServiceConnectionFactory.setPassword(password);
		GetGroupServiceConnectionFactory.setConnectionTimeout(30000);
		return GetGroupServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin GetGroupServiceRabbitAdmin(){
        return new RabbitAdmin(GetGroupServicerabbitMQConnectionFactory());
    }

@Bean("GetGroupServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory GetGroupServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory GetGroupServicefactory = new SimpleRabbitListenerContainerFactory();
		GetGroupServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		GetGroupServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		GetGroupServicefactory.setPrefetchCount(1);
		GetGroupServicefactory.setReceiveTimeout((long) 50000);
		GetGroupServicefactory.setConnectionFactory(GetGroupServicerabbitMQConnectionFactory());
		GetGroupServicefactory.setErrorHandler(errorHandler());
		return GetGroupServicefactory;
	}
	
	@Bean()
	public RabbitTemplate GetGroupServicecustomRabbitTemplate() {
		RabbitTemplate GetGroupServicerabbitTemplate = new RabbitTemplate();
		GetGroupServicerabbitTemplate.setReplyTimeout(30000L);
		GetGroupServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		GetGroupServicerabbitTemplate.setConnectionFactory(GetGroupServicerabbitMQConnectionFactory());
		return GetGroupServicerabbitTemplate;
	}
//NCMGroupUpdateService	
	@Bean(name = "NCMGroupUpdateServiceConnectionFactory")
	public ConnectionFactory NCMGroupUpdateServicerabbitMQConnectionFactory() {
		CachingConnectionFactory NCMGroupUpdateServiceConnectionFactory = new CachingConnectionFactory(host);
		NCMGroupUpdateServiceConnectionFactory.setPort(Integer.parseInt(port));
		NCMGroupUpdateServiceConnectionFactory.setUsername(username);
		NCMGroupUpdateServiceConnectionFactory.setPassword(password);
		NCMGroupUpdateServiceConnectionFactory.setConnectionTimeout(30000);
		return NCMGroupUpdateServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin NCMGroupUpdateServiceRabbitAdmin(){
        return new RabbitAdmin(NCMGroupUpdateServicerabbitMQConnectionFactory());
    }

@Bean("NCMGroupUpdateServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory NCMGroupUpdateServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory NCMGroupUpdateServicefactory = new SimpleRabbitListenerContainerFactory();
		NCMGroupUpdateServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		NCMGroupUpdateServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		NCMGroupUpdateServicefactory.setPrefetchCount(1);
		NCMGroupUpdateServicefactory.setReceiveTimeout((long) 50000);
		NCMGroupUpdateServicefactory.setConnectionFactory(NCMGroupUpdateServicerabbitMQConnectionFactory());
		NCMGroupUpdateServicefactory.setErrorHandler(errorHandler());
		return NCMGroupUpdateServicefactory;
	}
	
	@Bean()
	public RabbitTemplate NCMGroupUpdateServicecustomRabbitTemplate() {
		RabbitTemplate NCMGroupUpdateServicerabbitTemplate = new RabbitTemplate();
		NCMGroupUpdateServicerabbitTemplate.setReplyTimeout(30000L);
		NCMGroupUpdateServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		NCMGroupUpdateServicerabbitTemplate.setConnectionFactory(NCMGroupUpdateServicerabbitMQConnectionFactory());
		return NCMGroupUpdateServicerabbitTemplate;
	}
	//ncmGetDeviceAppVersion
	@Bean(name = "ncmGetDeviceAppVersionConnectionFactory")
	public ConnectionFactory ncmGetDeviceAppVersionrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmGetDeviceAppVersionConnectionFactory = new CachingConnectionFactory(host);
		ncmGetDeviceAppVersionConnectionFactory.setPort(Integer.parseInt(port));
		ncmGetDeviceAppVersionConnectionFactory.setUsername(username);
		ncmGetDeviceAppVersionConnectionFactory.setPassword(password);
		ncmGetDeviceAppVersionConnectionFactory.setConnectionTimeout(30000);
		return ncmGetDeviceAppVersionConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmGetDeviceAppVersionRabbitAdmin(){
        return new RabbitAdmin(ncmGetDeviceAppVersionrabbitMQConnectionFactory());
    }

@Bean("ncmGetDeviceAppVersionrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmGetDeviceAppVersionrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmGetDeviceAppVersionfactory = new SimpleRabbitListenerContainerFactory();
		ncmGetDeviceAppVersionfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmGetDeviceAppVersionfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmGetDeviceAppVersionfactory.setPrefetchCount(1);
		ncmGetDeviceAppVersionfactory.setReceiveTimeout((long) 50000);
		ncmGetDeviceAppVersionfactory.setConnectionFactory(ncmGetDeviceAppVersionrabbitMQConnectionFactory());
		ncmGetDeviceAppVersionfactory.setErrorHandler(errorHandler());
		return ncmGetDeviceAppVersionfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmGetDeviceAppVersioncustomRabbitTemplate() {
		RabbitTemplate ncmGetDeviceAppVersionrabbitTemplate = new RabbitTemplate();
		ncmGetDeviceAppVersionrabbitTemplate.setReplyTimeout(30000L);
		ncmGetDeviceAppVersionrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmGetDeviceAppVersionrabbitTemplate.setConnectionFactory(ncmGetDeviceAppVersionrabbitMQConnectionFactory());
		return ncmGetDeviceAppVersionrabbitTemplate;
	}
	//NcmgetRouter
	@Bean(name = "ncmgetRouterConnectionFactory")
	public ConnectionFactory ncmgetRouterrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmgetRouterConnectionFactory = new CachingConnectionFactory(host);
		ncmgetRouterConnectionFactory.setPort(Integer.parseInt(port));
		ncmgetRouterConnectionFactory.setUsername(username);
		ncmgetRouterConnectionFactory.setPassword(password);
		ncmgetRouterConnectionFactory.setConnectionTimeout(30000);
		return ncmgetRouterConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmgetRouterRabbitAdmin(){
        return new RabbitAdmin(ncmgetRouterrabbitMQConnectionFactory());
    }


@Bean("ncmgetRouterrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmgetRouterrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmgetRouterfactory = new SimpleRabbitListenerContainerFactory();
		ncmgetRouterfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmgetRouterfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmgetRouterfactory.setPrefetchCount(1);
		ncmgetRouterfactory.setReceiveTimeout((long) 50000);
		ncmgetRouterfactory.setConnectionFactory(ncmgetRouterrabbitMQConnectionFactory());
		ncmgetRouterfactory.setErrorHandler(errorHandler());
		return ncmgetRouterfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmgetRoutercustomRabbitTemplate() {
		RabbitTemplate ncmgetRouterrabbitTemplate = new RabbitTemplate();
		ncmgetRouterrabbitTemplate.setReplyTimeout(30000L);
		ncmgetRouterrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmgetRouterrabbitTemplate.setConnectionFactory(ncmgetRouterrabbitMQConnectionFactory());
		return ncmgetRouterrabbitTemplate;
	}
	//Ncmgetactivitylog
	@Bean(name = "ncmgetactivitylogConnectionFactory")
	public ConnectionFactory ncmgetactivitylograbbitMQConnectionFactory() {
		CachingConnectionFactory ncmgetactivitylogConnectionFactory = new CachingConnectionFactory(host);
		ncmgetactivitylogConnectionFactory.setPort(Integer.parseInt(port));
		ncmgetactivitylogConnectionFactory.setUsername(username);
		ncmgetactivitylogConnectionFactory.setPassword(password);
		ncmgetactivitylogConnectionFactory.setConnectionTimeout(30000);
		return ncmgetactivitylogConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmgetactivitylogRabbitAdmin(){
        return new RabbitAdmin(ncmgetactivitylograbbitMQConnectionFactory());
    }

@Bean("ncmgetactivitylograbbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmgetactivitylograbbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmgetactivitylogfactory = new SimpleRabbitListenerContainerFactory();
		ncmgetactivitylogfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmgetactivitylogfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmgetactivitylogfactory.setPrefetchCount(1);
		ncmgetactivitylogfactory.setReceiveTimeout((long) 50000);
		ncmgetactivitylogfactory.setConnectionFactory(ncmgetactivitylograbbitMQConnectionFactory());
		ncmgetactivitylogfactory.setErrorHandler(errorHandler());
		return ncmgetactivitylogfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmgetactivitylogcustomRabbitTemplate() {
		RabbitTemplate ncmgetactivitylograbbitTemplate = new RabbitTemplate();
		ncmgetactivitylograbbitTemplate.setReplyTimeout(30000L);
		ncmgetactivitylograbbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmgetactivitylograbbitTemplate.setConnectionFactory(ncmgetactivitylograbbitMQConnectionFactory());
		return ncmgetactivitylograbbitTemplate;
	}
	//ncmAccountCreateurl
	@Bean(name = "ncmAccountCreateConnectionFactory")
	public ConnectionFactory ncmAccountCreaterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmAccountCreateConnectionFactory = new CachingConnectionFactory(host);
		ncmAccountCreateConnectionFactory.setPort(Integer.parseInt(port));
		ncmAccountCreateConnectionFactory.setUsername(username);
		ncmAccountCreateConnectionFactory.setPassword(password);
		ncmAccountCreateConnectionFactory.setConnectionTimeout(30000);
		return ncmAccountCreateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmAccountCreateRabbitAdmin(){
        return new RabbitAdmin(ncmAccountCreaterabbitMQConnectionFactory());
    }

@Bean("ncmAccountCreaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmAccountCreaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmAccountCreaterfactory = new SimpleRabbitListenerContainerFactory();
		ncmAccountCreaterfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmAccountCreaterfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmAccountCreaterfactory.setPrefetchCount(1);
		ncmAccountCreaterfactory.setReceiveTimeout((long) 50000);
		ncmAccountCreaterfactory.setConnectionFactory(ncmAccountCreaterabbitMQConnectionFactory());
		ncmAccountCreaterfactory.setErrorHandler(errorHandler());
		return ncmAccountCreaterfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmAccountCreatercustomRabbitTemplate() {
		RabbitTemplate ncmAccountCreaterrabbitTemplate = new RabbitTemplate();
		ncmAccountCreaterrabbitTemplate.setReplyTimeout(30000L);
		ncmAccountCreaterrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmAccountCreaterrabbitTemplate.setConnectionFactory(ncmAccountCreaterabbitMQConnectionFactory());
		return ncmAccountCreaterrabbitTemplate;
	}
	//ncmRouterUpdate
	
	@Bean(name = "ncmRouterUpdateConnectionFactory")
	public ConnectionFactory ncmRouterUpdaterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmRouterUpdateConnectionFactory = new CachingConnectionFactory(host);
		ncmRouterUpdateConnectionFactory.setPort(Integer.parseInt(port));
		ncmRouterUpdateConnectionFactory.setUsername(username);
		ncmRouterUpdateConnectionFactory.setPassword(password);
		ncmRouterUpdateConnectionFactory.setConnectionTimeout(30000);
		return ncmRouterUpdateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmRouterUpdateRabbitAdmin(){
        return new RabbitAdmin(ncmRouterUpdaterabbitMQConnectionFactory());
    }

@Bean("ncmRouterUpdaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmRouterUpdaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmRouterUpdatefactory = new SimpleRabbitListenerContainerFactory();
		ncmRouterUpdatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmRouterUpdatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmRouterUpdatefactory.setPrefetchCount(1);
		ncmRouterUpdatefactory.setReceiveTimeout((long) 50000);
		ncmRouterUpdatefactory.setConnectionFactory(ncmRouterUpdaterabbitMQConnectionFactory());
		ncmRouterUpdatefactory.setErrorHandler(errorHandler());
		return ncmRouterUpdatefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmRouterUpdatecustomRabbitTemplate() {
		RabbitTemplate ncmRouterUpdaterabbitTemplate = new RabbitTemplate();
		ncmRouterUpdaterabbitTemplate.setReplyTimeout(30000L);
		ncmRouterUpdaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmRouterUpdaterabbitTemplate.setConnectionFactory(ncmRouterUpdaterabbitMQConnectionFactory());
		return ncmRouterUpdaterabbitTemplate;
	}
	//DeleteDeviceAppBindingsurl
	
	@Bean(name = "DeleteDeviceAppBindingsConnectionFactory")
	public ConnectionFactory DeleteDeviceAppBindingsrabbitMQConnectionFactory() {
		CachingConnectionFactory DeleteDeviceAppBindingsConnectionFactory = new CachingConnectionFactory(host);
		DeleteDeviceAppBindingsConnectionFactory.setPort(Integer.parseInt(port));
		DeleteDeviceAppBindingsConnectionFactory.setUsername(username);
		DeleteDeviceAppBindingsConnectionFactory.setPassword(password);
		DeleteDeviceAppBindingsConnectionFactory.setConnectionTimeout(30000);
		return DeleteDeviceAppBindingsConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin DeleteDeviceAppBindingsRabbitAdmin(){
        return new RabbitAdmin(DeleteDeviceAppBindingsrabbitMQConnectionFactory());
    }

@Bean("DeleteDeviceAppBindingsrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory DeleteDeviceAppBindingsrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory DeleteDeviceAppBindingsfactory = new SimpleRabbitListenerContainerFactory();
		DeleteDeviceAppBindingsfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		DeleteDeviceAppBindingsfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		DeleteDeviceAppBindingsfactory.setPrefetchCount(1);
		DeleteDeviceAppBindingsfactory.setReceiveTimeout((long) 50000);
		DeleteDeviceAppBindingsfactory.setConnectionFactory(DeleteDeviceAppBindingsrabbitMQConnectionFactory());
		DeleteDeviceAppBindingsfactory.setErrorHandler(errorHandler());
		return DeleteDeviceAppBindingsfactory;
	}
	
	@Bean()
	public RabbitTemplate  DeleteDeviceAppBindingscustomRabbitTemplate() {
		RabbitTemplate DeleteDeviceAppBindingsrabbitTemplate = new RabbitTemplate();
		DeleteDeviceAppBindingsrabbitTemplate.setReplyTimeout(30000L);
		DeleteDeviceAppBindingsrabbitTemplate.setMessageConverter(jsonMessageConverter());
		DeleteDeviceAppBindingsrabbitTemplate.setConnectionFactory(DeleteDeviceAppBindingsrabbitMQConnectionFactory());
		return DeleteDeviceAppBindingsrabbitTemplate;
	}
	//UpdateLocationServiceurl
	@Bean(name = "UpdateLocationServiceConnectionFactory")
	public ConnectionFactory UpdateLocationServicerabbitMQConnectionFactory() {
		CachingConnectionFactory UpdateLocationServiceConnectionFactory = new CachingConnectionFactory(host);
		UpdateLocationServiceConnectionFactory.setPort(Integer.parseInt(port));
		UpdateLocationServiceConnectionFactory.setUsername(username);
		UpdateLocationServiceConnectionFactory.setPassword(password);
		UpdateLocationServiceConnectionFactory.setConnectionTimeout(30000);
		return UpdateLocationServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin UpdateLocationServiceRabbitAdmin(){
        return new RabbitAdmin(UpdateLocationServicerabbitMQConnectionFactory());
    }

@Bean("UpdateLocationServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory UpdateLocationServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory UpdateLocationServicefactory = new SimpleRabbitListenerContainerFactory();
		UpdateLocationServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		UpdateLocationServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		UpdateLocationServicefactory.setPrefetchCount(1);
		UpdateLocationServicefactory.setReceiveTimeout((long) 50000);
		UpdateLocationServicefactory.setConnectionFactory(UpdateLocationServicerabbitMQConnectionFactory());
		UpdateLocationServicefactory.setErrorHandler(errorHandler());
		return UpdateLocationServicefactory;
	}
	
	@Bean()
	public RabbitTemplate  UpdateLocationServicescustomRabbitTemplate() {
		RabbitTemplate UpdateLocationServicerabbitTemplate = new RabbitTemplate();
		UpdateLocationServicerabbitTemplate.setReplyTimeout(30000L);
		UpdateLocationServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		UpdateLocationServicerabbitTemplate.setConnectionFactory(UpdateLocationServicerabbitMQConnectionFactory());
		return UpdateLocationServicerabbitTemplate;
	}
	//ncmCreateGroupService
	@Bean(name = "ncmCreateGroupServiceConnectionFactory")
	public ConnectionFactory ncmCreateGroupServicerabbitMQConnectionFactory() {
		CachingConnectionFactory ncmCreateGroupServiceConnectionFactory = new CachingConnectionFactory(host);
		ncmCreateGroupServiceConnectionFactory.setPort(Integer.parseInt(port));
		ncmCreateGroupServiceConnectionFactory.setUsername(username);
		ncmCreateGroupServiceConnectionFactory.setPassword(password);
		ncmCreateGroupServiceConnectionFactory.setConnectionTimeout(30000);
		return ncmCreateGroupServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmCreateGroupServiceRabbitAdmin(){
        return new RabbitAdmin(ncmCreateGroupServicerabbitMQConnectionFactory());
    }

@Bean("ncmCreateGroupServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmCreateGroupServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmCreateGroupServicefactory = new SimpleRabbitListenerContainerFactory();
		ncmCreateGroupServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmCreateGroupServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmCreateGroupServicefactory.setPrefetchCount(1);
		ncmCreateGroupServicefactory.setReceiveTimeout((long) 50000);
		ncmCreateGroupServicefactory.setConnectionFactory(ncmCreateGroupServicerabbitMQConnectionFactory());
		ncmCreateGroupServicefactory.setErrorHandler(errorHandler());
		return ncmCreateGroupServicefactory;
	}
	
	@Bean()
	public RabbitTemplate  ncmCreateGroupServicecustomRabbitTemplate() {
		RabbitTemplate ncmCreateGroupServicerabbitTemplate = new RabbitTemplate();
		ncmCreateGroupServicerabbitTemplate.setReplyTimeout(30000L);
		ncmCreateGroupServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmCreateGroupServicerabbitTemplate.setConnectionFactory(ncmCreateGroupServicerabbitMQConnectionFactory());
		return ncmCreateGroupServicerabbitTemplate;
	}
	
	//NcmcreatedeviceappbindinglogUrl
	@Bean(name = "ncmcreatedeviceappbindinglogConnectionFactory")
	public ConnectionFactory ncmcreatedeviceappbindinglograbbitMQConnectionFactory() {
		CachingConnectionFactory ncmcreatedeviceappbindinglogConnectionFactory = new CachingConnectionFactory(host);
		ncmcreatedeviceappbindinglogConnectionFactory.setPort(Integer.parseInt(port));
		ncmcreatedeviceappbindinglogConnectionFactory.setUsername(username);
		ncmcreatedeviceappbindinglogConnectionFactory.setPassword(password);
		ncmcreatedeviceappbindinglogConnectionFactory.setConnectionTimeout(30000);
		return ncmcreatedeviceappbindinglogConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmcreatedeviceappbindinglogRabbitAdmin(){
        return new RabbitAdmin(ncmcreatedeviceappbindinglograbbitMQConnectionFactory());
    }

@Bean("ncmcreatedeviceappbindinglograbbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmcreatedeviceappbindinglograbbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmcreatedeviceappbindinglogfactory = new SimpleRabbitListenerContainerFactory();
		ncmcreatedeviceappbindinglogfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmcreatedeviceappbindinglogfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmcreatedeviceappbindinglogfactory.setPrefetchCount(1);
		ncmcreatedeviceappbindinglogfactory.setReceiveTimeout((long) 50000);
		ncmcreatedeviceappbindinglogfactory.setConnectionFactory(ncmcreatedeviceappbindinglograbbitMQConnectionFactory());
		return ncmcreatedeviceappbindinglogfactory;
	}
	
	@Bean()
	public RabbitTemplate  ncmcreatedeviceappbindinglogcustomRabbitTemplate() {
		RabbitTemplate ncmcreatedeviceappbindinglograbbitTemplate = new RabbitTemplate();
		ncmcreatedeviceappbindinglograbbitTemplate.setReplyTimeout(30000L);
		ncmcreatedeviceappbindinglograbbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmcreatedeviceappbindinglograbbitTemplate.setConnectionFactory(ncmcreatedeviceappbindinglograbbitMQConnectionFactory());
		return ncmcreatedeviceappbindinglograbbitTemplate;
	}
	//Ncmhistoricalloclogurl
	@Bean(name = "NcmhistoricalloclogConnectionFactory")
	public ConnectionFactory NcmhistoricalloclograbbitMQConnectionFactory() {
		CachingConnectionFactory NcmhistoricalloclogConnectionFactory = new CachingConnectionFactory(host);
		NcmhistoricalloclogConnectionFactory.setPort(Integer.parseInt(port));
		NcmhistoricalloclogConnectionFactory.setUsername(username);
		NcmhistoricalloclogConnectionFactory.setPassword(password);
		NcmhistoricalloclogConnectionFactory.setConnectionTimeout(30000);
		return NcmhistoricalloclogConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin NcmhistoricalloclogRabbitAdmin(){
        return new RabbitAdmin(NcmhistoricalloclograbbitMQConnectionFactory());
    }

@Bean("NcmhistoricalloclograbbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory NcmhistoricalloclograbbitListenerContainerFactory(
			@Qualifier("NcmhistoricalloclogConnectionFactory") ConnectionFactory NcmhistoricalloclogConnectionFactory) {
		SimpleRabbitListenerContainerFactory Ncmhistoricallocloglogfactory = new SimpleRabbitListenerContainerFactory();
		Ncmhistoricallocloglogfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		Ncmhistoricallocloglogfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		Ncmhistoricallocloglogfactory.setPrefetchCount(1);
		Ncmhistoricallocloglogfactory.setReceiveTimeout((long) 50000);
		Ncmhistoricallocloglogfactory.setConnectionFactory(NcmhistoricalloclograbbitMQConnectionFactory());
		Ncmhistoricallocloglogfactory.setErrorHandler(errorHandler());
		return Ncmhistoricallocloglogfactory;
	}
	
	@Bean()
	public RabbitTemplate  NcmhistoricalloclogcustomRabbitTemplate() {
		RabbitTemplate NcmhistoricalloclograbbitTemplate = new RabbitTemplate();
		NcmhistoricalloclograbbitTemplate.setReplyTimeout(30000L);
		NcmhistoricalloclograbbitTemplate.setMessageConverter(jsonMessageConverter());
		NcmhistoricalloclograbbitTemplate.setConnectionFactory(NcmhistoricalloclograbbitMQConnectionFactory());
		return NcmhistoricalloclograbbitTemplate;
	}
	//NCMAllertIntegrationServiceurl
	@Bean(name = "NCMAllertIntegrationServiceConnectionFactory")
	public ConnectionFactory NCMAllertIntegrationServicerabbitMQConnectionFactory() {
		CachingConnectionFactory NCMAllertIntegrationServiceConnectionFactory = new CachingConnectionFactory(host);
		NCMAllertIntegrationServiceConnectionFactory.setPort(Integer.parseInt(port));
		NCMAllertIntegrationServiceConnectionFactory.setUsername(username);
		NCMAllertIntegrationServiceConnectionFactory.setPassword(password);
		NCMAllertIntegrationServiceConnectionFactory.setConnectionTimeout(30000);
		return NCMAllertIntegrationServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin NCMAllertIntegrationServiceRabbitAdmin(){
        return new RabbitAdmin(NCMAllertIntegrationServicerabbitMQConnectionFactory());
    }

@Bean("NCMAllertIntegrationServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory NCMAllertIntegrationServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory NCMAllertIntegrationServicefactory = new SimpleRabbitListenerContainerFactory();
		NCMAllertIntegrationServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		NCMAllertIntegrationServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		NCMAllertIntegrationServicefactory.setPrefetchCount(1);
		NCMAllertIntegrationServicefactory.setReceiveTimeout((long) 50000);
		NCMAllertIntegrationServicefactory.setConnectionFactory(NCMAllertIntegrationServicerabbitMQConnectionFactory());
		NCMAllertIntegrationServicefactory.setErrorHandler(errorHandler());
		return NCMAllertIntegrationServicefactory;
	}
	
	@Bean()
	public RabbitTemplate  NCMAllertIntegrationServicecustomRabbitTemplate() {
		RabbitTemplate NCMAllertIntegrationServicerabbitTemplate = new RabbitTemplate();
		NCMAllertIntegrationServicerabbitTemplate.setReplyTimeout(30000L);
		NCMAllertIntegrationServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		NCMAllertIntegrationServicerabbitTemplate.setConnectionFactory(NCMAllertIntegrationServicerabbitMQConnectionFactory());
		return NCMAllertIntegrationServicerabbitTemplate;
	}
	//NCMUpdateConfigMangerServiceurl
	@Bean(name = "NCMUpdateConfigMangerServiceConnectionFactory")
	public ConnectionFactory NCMUpdateConfigMangerServicerabbitMQConnectionFactory() {
		CachingConnectionFactory NCMUpdateConfigMangerServiceConnectionFactory = new CachingConnectionFactory(host);
		NCMUpdateConfigMangerServiceConnectionFactory.setPort(Integer.parseInt(port));
		NCMUpdateConfigMangerServiceConnectionFactory.setUsername(username);
		NCMUpdateConfigMangerServiceConnectionFactory.setPassword(password);
		NCMUpdateConfigMangerServiceConnectionFactory.setConnectionTimeout(30000);
		return NCMUpdateConfigMangerServiceConnectionFactory;
	}

	@Bean()
    RabbitAdmin NCMUpdateConfigMangerServiceRabbitAdmin(){
        return new RabbitAdmin(NCMUpdateConfigMangerServicerabbitMQConnectionFactory());
    }
	
@Bean("NCMUpdateConfigMangerServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory NCMUpdateConfigMangerServicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory NCMUpdateConfigMangerServicefactory = new SimpleRabbitListenerContainerFactory();
		NCMUpdateConfigMangerServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		NCMUpdateConfigMangerServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		NCMUpdateConfigMangerServicefactory.setPrefetchCount(1);
		NCMUpdateConfigMangerServicefactory.setReceiveTimeout((long) 50000);
		NCMUpdateConfigMangerServicefactory.setConnectionFactory(NCMUpdateConfigMangerServicerabbitMQConnectionFactory());
		NCMUpdateConfigMangerServicefactory.setErrorHandler(errorHandler());
		return NCMUpdateConfigMangerServicefactory;
	}
	
	@Bean()
	public RabbitTemplate  NCMUpdateConfigMangerServicecustomRabbitTemplate() {
		RabbitTemplate NCMUpdateConfigMangerServicerabbitTemplate = new RabbitTemplate();
		NCMUpdateConfigMangerServicerabbitTemplate.setReplyTimeout(30000L);
		NCMUpdateConfigMangerServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		NCMUpdateConfigMangerServicerabbitTemplate.setConnectionFactory(NCMUpdateConfigMangerServicerabbitMQConnectionFactory());
		return NCMUpdateConfigMangerServicerabbitTemplate;
	}


	@Bean(name = "ncmAccountDeleteConnectionFactory")
	public ConnectionFactory ncmAccountDeleterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmAccountDeleteConnectionFactory = new CachingConnectionFactory(host);
		ncmAccountDeleteConnectionFactory.setPort(Integer.parseInt(port));
		ncmAccountDeleteConnectionFactory.setUsername(username);
		ncmAccountDeleteConnectionFactory.setPassword(password);
		ncmAccountDeleteConnectionFactory.setConnectionTimeout(30000);
		return ncmAccountDeleteConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmAccountDeleteRabbitAdmin(){
        return new RabbitAdmin(ncmAccountDeleterabbitMQConnectionFactory());
    }
	
	@Bean("ncmAccountDeleterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmAccountDeleterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmAccountDeletefactory = new SimpleRabbitListenerContainerFactory();
		ncmAccountDeletefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmAccountDeletefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmAccountDeletefactory.setPrefetchCount(1);
		ncmAccountDeletefactory.setReceiveTimeout((long) 50000);
		ncmAccountDeletefactory.setConnectionFactory(ncmAccountDeleterabbitMQConnectionFactory());
		ncmAccountDeletefactory.setErrorHandler(errorHandler());
		return ncmAccountDeletefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmAccountDeletecustomRabbitTemplate() {
		RabbitTemplate ncmAccountDeleterabbitTemplate = new RabbitTemplate();
		ncmAccountDeleterabbitTemplate.setReplyTimeout(30000L);
		ncmAccountDeleterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmAccountDeleterabbitTemplate.setConnectionFactory(ncmAccountDeleterabbitMQConnectionFactory());
		return ncmAccountDeleterabbitTemplate;
	}

	@Bean(name = "ncmDeviceAppsStateConnectionFactory")
	public ConnectionFactory ncmDeviceAppsStaterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmDeviceAppsStateConnectionFactory = new CachingConnectionFactory(host);
		ncmDeviceAppsStateConnectionFactory.setPort(Integer.parseInt(port));
		ncmDeviceAppsStateConnectionFactory.setUsername(username);
		ncmDeviceAppsStateConnectionFactory.setPassword(password);
		ncmDeviceAppsStateConnectionFactory.setConnectionTimeout(30000);
		return ncmDeviceAppsStateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmDeviceAppsStateRabbitAdmin(){
        return new RabbitAdmin(ncmDeviceAppsStaterabbitMQConnectionFactory());
    }
	
	@Bean("ncmDeviceAppsStaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmDeviceAppsStaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmDeviceAppsStatefactory = new SimpleRabbitListenerContainerFactory();
		ncmDeviceAppsStatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmDeviceAppsStatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmDeviceAppsStatefactory.setPrefetchCount(1);
		ncmDeviceAppsStatefactory.setReceiveTimeout((long) 50000);
		ncmDeviceAppsStatefactory.setConnectionFactory(ncmDeviceAppsStaterabbitMQConnectionFactory());
		ncmDeviceAppsStatefactory.setErrorHandler(errorHandler());
		return ncmDeviceAppsStatefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmDeviceAppsStatecustomRabbitTemplate() {
		RabbitTemplate ncmDeviceAppsStaterabbitTemplate = new RabbitTemplate();
		ncmDeviceAppsStaterabbitTemplate.setReplyTimeout(30000L);
		ncmDeviceAppsStaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmDeviceAppsStaterabbitTemplate.setConnectionFactory(ncmDeviceAppsStaterabbitMQConnectionFactory());
		return ncmDeviceAppsStaterabbitTemplate;
	}
	
	@Bean(name = "ncmGetRouterStateConnectionFactory")
	public ConnectionFactory ncmGetRouterStaterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmGetRouterStateConnectionFactory = new CachingConnectionFactory(host);
		ncmGetRouterStateConnectionFactory.setPort(Integer.parseInt(port));
		ncmGetRouterStateConnectionFactory.setUsername(username);
		ncmGetRouterStateConnectionFactory.setPassword(password);
		ncmGetRouterStateConnectionFactory.setConnectionTimeout(30000);
		return ncmGetRouterStateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmGetRouterStateRabbitAdmin(){
        return new RabbitAdmin(ncmGetRouterStaterabbitMQConnectionFactory());
    }
	
	@Bean("ncmGetRouterStaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmGetRouterStaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmGetRouterStatefactory = new SimpleRabbitListenerContainerFactory();
		ncmGetRouterStatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmGetRouterStatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmGetRouterStatefactory.setPrefetchCount(1);
		ncmGetRouterStatefactory.setReceiveTimeout((long) 50000);
		ncmGetRouterStatefactory.setConnectionFactory(ncmGetRouterStaterabbitMQConnectionFactory());
		ncmGetRouterStatefactory.setErrorHandler(errorHandler());
		return ncmGetRouterStatefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmGetRouterStatecustomRabbitTemplate() {
		RabbitTemplate ncmGetRouterStaterabbitTemplate = new RabbitTemplate();
		ncmGetRouterStaterabbitTemplate.setReplyTimeout(30000L);
		ncmGetRouterStaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmGetRouterStaterabbitTemplate.setConnectionFactory(ncmGetRouterStaterabbitMQConnectionFactory());
		return ncmGetRouterStaterabbitTemplate;
	}
	
	@Bean(name = "ncmDeleteLocationConnectionFactory")
	public ConnectionFactory ncmDeleteLocationrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmDeleteLocationConnectionFactory = new CachingConnectionFactory(host);
		ncmDeleteLocationConnectionFactory.setPort(Integer.parseInt(port));
		ncmDeleteLocationConnectionFactory.setUsername(username);
		ncmDeleteLocationConnectionFactory.setPassword(password);
		ncmDeleteLocationConnectionFactory.setConnectionTimeout(30000);
		return ncmDeleteLocationConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmDeleteLocationRabbitAdmin(){
        return new RabbitAdmin(ncmDeleteLocationrabbitMQConnectionFactory());
    }
	
	@Bean("ncmDeleteLocationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmDeleteLocationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmDeleteLocationfactory = new SimpleRabbitListenerContainerFactory();
		ncmDeleteLocationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmDeleteLocationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmDeleteLocationfactory.setPrefetchCount(1);
		ncmDeleteLocationfactory.setReceiveTimeout((long) 50000);
		ncmDeleteLocationfactory.setConnectionFactory(ncmDeleteLocationrabbitMQConnectionFactory());
		ncmDeleteLocationfactory.setErrorHandler(errorHandler());
		return ncmDeleteLocationfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmDeleteLocationcustomRabbitTemplate() {
		RabbitTemplate ncmDeleteLocationrabbitTemplate = new RabbitTemplate();
		ncmDeleteLocationrabbitTemplate.setReplyTimeout(30000L);
		ncmDeleteLocationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmDeleteLocationrabbitTemplate.setConnectionFactory(ncmDeleteLocationrabbitMQConnectionFactory());
		return ncmDeleteLocationrabbitTemplate;
	}
	

	@Bean(name = "ncmRouterLogsConnectionFactory")
	public ConnectionFactory ncmRouterLogsrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmRouterLogsConnectionFactory = new CachingConnectionFactory(host);
		ncmRouterLogsConnectionFactory.setPort(Integer.parseInt(port));
		ncmRouterLogsConnectionFactory.setUsername(username);
		ncmRouterLogsConnectionFactory.setPassword(password);
		ncmRouterLogsConnectionFactory.setConnectionTimeout(30000);
		return ncmRouterLogsConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmRouterLogsRabbitAdmin(){
        return new RabbitAdmin(ncmRouterLogsrabbitMQConnectionFactory());
    }
	
	@Bean("ncmRouterLogsrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmRouterLogsrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmRouterLogsfactory = new SimpleRabbitListenerContainerFactory();
		ncmRouterLogsfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmRouterLogsfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmRouterLogsfactory.setPrefetchCount(1);
		ncmRouterLogsfactory.setReceiveTimeout((long) 50000);
		ncmRouterLogsfactory.setConnectionFactory(ncmRouterLogsrabbitMQConnectionFactory());
		ncmRouterLogsfactory.setErrorHandler(errorHandler());
		return ncmRouterLogsfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmRouterLogscustomRabbitTemplate() {
		RabbitTemplate ncmRouterLogsrabbitTemplate = new RabbitTemplate();
		ncmRouterLogsrabbitTemplate.setReplyTimeout(30000L);
		ncmRouterLogsrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmRouterLogsrabbitTemplate.setConnectionFactory(ncmRouterLogsrabbitMQConnectionFactory());
		return ncmRouterLogsrabbitTemplate;
	}
	
	@Bean(name = "ncmLocationServiceConnectionFactory")
	public ConnectionFactory ncmLocationServicerabbitMQConnectionFactory() {
		CachingConnectionFactory ncmLocationServiceConnectionFactory = new CachingConnectionFactory(host);
		ncmLocationServiceConnectionFactory.setPort(Integer.parseInt(port));
		ncmLocationServiceConnectionFactory.setUsername(username);
		ncmLocationServiceConnectionFactory.setPassword(password);
		ncmLocationServiceConnectionFactory.setConnectionTimeout(30000);
		return ncmLocationServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmLocationServiceRabbitAdmin(){
        return new RabbitAdmin(ncmLocationServicerabbitMQConnectionFactory());
    }
	
	@Bean("ncmLocationServicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmLocationServicerabbitListenerContainerFactory(
			@Qualifier("ncmLocationServiceConnectionFactory") ConnectionFactory ncmLocationServiceConnectionFactory) {
		SimpleRabbitListenerContainerFactory ncmLocationServicefactory = new SimpleRabbitListenerContainerFactory();
		ncmLocationServicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmLocationServicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmLocationServicefactory.setPrefetchCount(1);
		ncmLocationServicefactory.setReceiveTimeout((long) 50000);
		ncmLocationServicefactory.setConnectionFactory(ncmLocationServicerabbitMQConnectionFactory());
		ncmLocationServicefactory.setErrorHandler(errorHandler());
		return ncmLocationServicefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmLocationServicecustomRabbitTemplate() {
		RabbitTemplate ncmLocationServicerabbitTemplate = new RabbitTemplate();
		ncmLocationServicerabbitTemplate.setReplyTimeout(30000L);
		ncmLocationServicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmLocationServicerabbitTemplate.setConnectionFactory(ncmLocationServicerabbitMQConnectionFactory());
		return ncmLocationServicerabbitTemplate;
	}
	
	@Bean(name = "ncmFirmwareConnectionFactory")
	public ConnectionFactory ncmFirmwarerabbitMQConnectionFactory() {
		CachingConnectionFactory ncmFirmwareConnectionFactory = new CachingConnectionFactory(host);
		ncmFirmwareConnectionFactory.setPort(Integer.parseInt(port));
		ncmFirmwareConnectionFactory.setUsername(username);
		ncmFirmwareConnectionFactory.setPassword(password);
		ncmFirmwareConnectionFactory.setConnectionTimeout(30000);
		return ncmFirmwareConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmFirmwareRabbitAdmin(){
        return new RabbitAdmin(ncmFirmwarerabbitMQConnectionFactory());
    }
	
	@Bean("ncmFirmwarerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmFirmwarerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmFirmwarefactory = new SimpleRabbitListenerContainerFactory();
		ncmFirmwarefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmFirmwarefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmFirmwarefactory.setPrefetchCount(1);
		ncmFirmwarefactory.setReceiveTimeout((long) 50000);
		ncmFirmwarefactory.setConnectionFactory(ncmFirmwarerabbitMQConnectionFactory());
		ncmFirmwarefactory.setErrorHandler(errorHandler());
		return ncmFirmwarefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmFirmwarecustomRabbitTemplate() {
		RabbitTemplate ncmFirmwarerabbitTemplate = new RabbitTemplate();
		ncmFirmwarerabbitTemplate.setReplyTimeout(30000L);
		ncmFirmwarerabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmFirmwarerabbitTemplate.setConnectionFactory(ncmFirmwarerabbitMQConnectionFactory());
		return ncmFirmwarerabbitTemplate;
	}
	
	@Bean(name = "ncmDeviceusagesampleConnectionFactory")
	public ConnectionFactory ncmDeviceusagesamplerabbitMQConnectionFactory() {
		CachingConnectionFactory ncmDeviceusagesampleConnectionFactory = new CachingConnectionFactory(host);
		ncmDeviceusagesampleConnectionFactory.setPort(Integer.parseInt(port));
		ncmDeviceusagesampleConnectionFactory.setUsername(username);
		ncmDeviceusagesampleConnectionFactory.setPassword(password);
		ncmDeviceusagesampleConnectionFactory.setConnectionTimeout(30000);
		return ncmDeviceusagesampleConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmDeviceusagesampleRabbitAdmin(){
        return new RabbitAdmin(ncmDeviceusagesamplerabbitMQConnectionFactory());
    }
	
	@Bean("ncmDeviceusagesamplerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmDeviceusagesamplerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmDeviceusagesamplefactory = new SimpleRabbitListenerContainerFactory();
		ncmDeviceusagesamplefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmDeviceusagesamplefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmDeviceusagesamplefactory.setPrefetchCount(1);
		ncmDeviceusagesamplefactory.setReceiveTimeout((long) 50000);
		ncmDeviceusagesamplefactory.setConnectionFactory(ncmDeviceusagesamplerabbitMQConnectionFactory());
		ncmDeviceusagesamplefactory.setErrorHandler(errorHandler());
		return ncmDeviceusagesamplefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmDeviceusagesamplecustomRabbitTemplate() {
		RabbitTemplate ncmDeviceusagesamplerabbitTemplate = new RabbitTemplate();
		ncmDeviceusagesamplerabbitTemplate.setReplyTimeout(30000L);
		ncmDeviceusagesamplerabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmDeviceusagesamplerabbitTemplate.setConnectionFactory(ncmDeviceusagesamplerabbitMQConnectionFactory());
		return ncmDeviceusagesamplerabbitTemplate;
	}
	
	@Bean(name = "ncmLocationServiceCreateConnectionFactory")
	public ConnectionFactory ncmLocationServiceCreaterabbitMQConnectionFactory() {
		CachingConnectionFactory ncmLocationServiceCreateConnectionFactory = new CachingConnectionFactory(host);
		ncmLocationServiceCreateConnectionFactory.setPort(Integer.parseInt(port));
		ncmLocationServiceCreateConnectionFactory.setUsername(username);
		ncmLocationServiceCreateConnectionFactory.setPassword(password);
		ncmLocationServiceCreateConnectionFactory.setConnectionTimeout(30000);
		return ncmLocationServiceCreateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmLocationServiceCreateRabbitAdmin(){
        return new RabbitAdmin(ncmLocationServiceCreaterabbitMQConnectionFactory());
    }
	
	@Bean("ncmLocationServiceCreaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmLocationServiceCreaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmLocationServiceCreatefactory = new SimpleRabbitListenerContainerFactory();
		ncmLocationServiceCreatefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmLocationServiceCreatefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmLocationServiceCreatefactory.setPrefetchCount(1);
		ncmLocationServiceCreatefactory.setReceiveTimeout((long) 50000);
		ncmLocationServiceCreatefactory.setConnectionFactory(ncmLocationServiceCreaterabbitMQConnectionFactory());
		ncmLocationServiceCreatefactory.setErrorHandler(errorHandler());
		return ncmLocationServiceCreatefactory;
	}
	
	@Bean()
	public RabbitTemplate ncmLocationServiceCreatecustomRabbitTemplate() {
		RabbitTemplate ncmLocationServiceCreaterabbitTemplate = new RabbitTemplate();
		ncmLocationServiceCreaterabbitTemplate.setReplyTimeout(30000L);
		ncmLocationServiceCreaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmLocationServiceCreaterabbitTemplate.setConnectionFactory(ncmLocationServiceCreaterabbitMQConnectionFactory());
		return ncmLocationServiceCreaterabbitTemplate;
	}
	
	@Bean(name = "ncmRouterStreamUsageSamplesConnectionFactory")
	public ConnectionFactory ncmRouterStreamUsageSamplesrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmRouterStreamUsageSamplesConnectionFactory = new CachingConnectionFactory(host);
		ncmRouterStreamUsageSamplesConnectionFactory.setPort(Integer.parseInt(port));
		ncmRouterStreamUsageSamplesConnectionFactory.setUsername(username);
		ncmRouterStreamUsageSamplesConnectionFactory.setPassword(password);
		ncmRouterStreamUsageSamplesConnectionFactory.setConnectionTimeout(30000);
		return ncmRouterStreamUsageSamplesConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmRouterStreamUsageSamplesRabbitAdmin(){
        return new RabbitAdmin(ncmRouterStreamUsageSamplesrabbitMQConnectionFactory());
    }
	
	@Bean("ncmRouterStreamUsageSamplesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmRouterStreamUsageSamplesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmRouterStreamUsageSamplesfactory = new SimpleRabbitListenerContainerFactory();
		ncmRouterStreamUsageSamplesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmRouterStreamUsageSamplesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmRouterStreamUsageSamplesfactory.setPrefetchCount(1);
		ncmRouterStreamUsageSamplesfactory.setReceiveTimeout((long) 50000);
		ncmRouterStreamUsageSamplesfactory.setConnectionFactory(ncmRouterStreamUsageSamplesrabbitMQConnectionFactory());
		ncmRouterStreamUsageSamplesfactory.setErrorHandler(errorHandler());
		return ncmRouterStreamUsageSamplesfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmRouterStreamUsageSamplescustomRabbitTemplate() {
		RabbitTemplate ncmRouterStreamUsageSamplesrabbitTemplate = new RabbitTemplate();
		ncmRouterStreamUsageSamplesrabbitTemplate.setReplyTimeout(30000L);
		ncmRouterStreamUsageSamplesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmRouterStreamUsageSamplesrabbitTemplate.setConnectionFactory(ncmRouterStreamUsageSamplesrabbitMQConnectionFactory());
		return ncmRouterStreamUsageSamplesrabbitTemplate;
	}
	
	@Bean(name = "nslDeviceAppsIntegrationConnectionFactory")
	public ConnectionFactory nslDeviceAppsIntegrationrabbitMQConnectionFactory() {
		CachingConnectionFactory nslDeviceAppsIntegrationConnectionFactory = new CachingConnectionFactory(host);
		nslDeviceAppsIntegrationConnectionFactory.setPort(Integer.parseInt(port));
		nslDeviceAppsIntegrationConnectionFactory.setUsername(username);
		nslDeviceAppsIntegrationConnectionFactory.setPassword(password);
		nslDeviceAppsIntegrationConnectionFactory.setConnectionTimeout(30000);
		return nslDeviceAppsIntegrationConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin nslDeviceAppsIntegrationRabbitAdmin(){
        return new RabbitAdmin(nslDeviceAppsIntegrationrabbitMQConnectionFactory());
    }
	
	@Bean("nslDeviceAppsIntegrationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory nslDeviceAppsIntegrationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory nslDeviceAppsIntegrationfactory = new SimpleRabbitListenerContainerFactory();
		nslDeviceAppsIntegrationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		nslDeviceAppsIntegrationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		nslDeviceAppsIntegrationfactory.setPrefetchCount(1);
		nslDeviceAppsIntegrationfactory.setReceiveTimeout((long) 50000);
		nslDeviceAppsIntegrationfactory.setConnectionFactory(nslDeviceAppsIntegrationrabbitMQConnectionFactory());
		nslDeviceAppsIntegrationfactory.setErrorHandler(errorHandler());
		return nslDeviceAppsIntegrationfactory;
	}
	
	@Bean()
	public RabbitTemplate nslDeviceAppsIntegrationcustomRabbitTemplate() {
		RabbitTemplate nslDeviceAppsIntegrationrabbitTemplate = new RabbitTemplate();
		nslDeviceAppsIntegrationrabbitTemplate.setReplyTimeout(30000L);
		nslDeviceAppsIntegrationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		nslDeviceAppsIntegrationrabbitTemplate.setConnectionFactory(nslDeviceAppsIntegrationrabbitMQConnectionFactory());
		return nslDeviceAppsIntegrationrabbitTemplate;
	}
	
	@Bean(name = "deleteDeviceAppVersionConnectionFactory")
	public ConnectionFactory deleteDeviceAppVersionrabbitMQConnectionFactory() {
		CachingConnectionFactory deleteDeviceAppVersionConnectionFactory = new CachingConnectionFactory(host);
		deleteDeviceAppVersionConnectionFactory.setPort(Integer.parseInt(port));
		deleteDeviceAppVersionConnectionFactory.setUsername(username);
		deleteDeviceAppVersionConnectionFactory.setPassword(password);
		deleteDeviceAppVersionConnectionFactory.setConnectionTimeout(30000);
		return deleteDeviceAppVersionConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin deleteDeviceAppVersionRabbitAdmin(){
        return new RabbitAdmin(deleteDeviceAppVersionrabbitMQConnectionFactory());
    }
	
	@Bean("deleteDeviceAppVersionrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory deleteDeviceAppVersionrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory deleteDeviceAppVersionfactory = new SimpleRabbitListenerContainerFactory();
		deleteDeviceAppVersionfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		deleteDeviceAppVersionfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		deleteDeviceAppVersionfactory.setPrefetchCount(1);
		deleteDeviceAppVersionfactory.setReceiveTimeout((long) 50000);
		deleteDeviceAppVersionfactory.setConnectionFactory(deleteDeviceAppVersionrabbitMQConnectionFactory());
		deleteDeviceAppVersionfactory.setErrorHandler(errorHandler());
		return deleteDeviceAppVersionfactory;
	}
	
	@Bean()
	public RabbitTemplate deleteDeviceAppVersioncustomRabbitTemplate() {
		RabbitTemplate deleteDeviceAppVersionrabbitTemplate = new RabbitTemplate();
		deleteDeviceAppVersionrabbitTemplate.setReplyTimeout(30000L);
		deleteDeviceAppVersionrabbitTemplate.setMessageConverter(jsonMessageConverter());
		deleteDeviceAppVersionrabbitTemplate.setConnectionFactory(deleteDeviceAppVersionrabbitMQConnectionFactory());
		return deleteDeviceAppVersionrabbitTemplate;
	}
	
	@Bean(name = "ncmFailoversIntegrationConnectionFactory")
	public ConnectionFactory ncmFailoversIntegrationrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmFailoversIntegrationConnectionFactory = new CachingConnectionFactory(host);
		ncmFailoversIntegrationConnectionFactory.setPort(Integer.parseInt(port));
		ncmFailoversIntegrationConnectionFactory.setUsername(username);
		ncmFailoversIntegrationConnectionFactory.setPassword(password);
		ncmFailoversIntegrationConnectionFactory.setConnectionTimeout(30000);
		return ncmFailoversIntegrationConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmFailoversIntegrationRabbitAdmin(){
        return new RabbitAdmin(ncmFailoversIntegrationrabbitMQConnectionFactory());
    }
	
	@Bean("ncmFailoversIntegrationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmFailoversIntegrationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmFailoversIntegrationfactory = new SimpleRabbitListenerContainerFactory();
		ncmFailoversIntegrationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmFailoversIntegrationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmFailoversIntegrationfactory.setPrefetchCount(1);
		ncmFailoversIntegrationfactory.setReceiveTimeout((long) 50000);
		ncmFailoversIntegrationfactory.setConnectionFactory(ncmFailoversIntegrationrabbitMQConnectionFactory());
		ncmFailoversIntegrationfactory.setErrorHandler(errorHandler());
		return ncmFailoversIntegrationfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmFailoversIntegrationcustomRabbitTemplate() {
		RabbitTemplate ncmFailoversIntegrationrabbitTemplate = new RabbitTemplate();
		ncmFailoversIntegrationrabbitTemplate.setReplyTimeout(30000L);
		ncmFailoversIntegrationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmFailoversIntegrationrabbitTemplate.setConnectionFactory(ncmFailoversIntegrationrabbitMQConnectionFactory());
		return ncmFailoversIntegrationrabbitTemplate;
	}
	
	@Bean(name = "ncmrebootConnectionFactory")
	public ConnectionFactory ncmrebootrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmrebootConnectionFactory = new CachingConnectionFactory(host);
		ncmrebootConnectionFactory.setPort(Integer.parseInt(port));
		ncmrebootConnectionFactory.setUsername(username);
		ncmrebootConnectionFactory.setPassword(password);
		ncmrebootConnectionFactory.setConnectionTimeout(30000);
		return ncmrebootConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmrebootRabbitAdmin(){
        return new RabbitAdmin(ncmrebootrabbitMQConnectionFactory());
    }
	
	@Bean("ncmrebootrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmrebootrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmrebootfactory = new SimpleRabbitListenerContainerFactory();
		ncmrebootfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmrebootfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmrebootfactory.setPrefetchCount(1);
		ncmrebootfactory.setReceiveTimeout((long) 50000);
		ncmrebootfactory.setConnectionFactory(ncmrebootrabbitMQConnectionFactory());
		ncmrebootfactory.setErrorHandler(errorHandler());
		return ncmrebootfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmrebootcustomRabbitTemplate() {
		RabbitTemplate ncmrebootrabbitTemplate = new RabbitTemplate();
		ncmrebootrabbitTemplate.setReplyTimeout(30000L);
		ncmrebootrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmrebootrabbitTemplate.setConnectionFactory(ncmrebootrabbitMQConnectionFactory());
		return ncmrebootrabbitTemplate;
	}
	
	@Bean(name = "ncmcreatedeviceappbindingConnectionFactory")
	public ConnectionFactory ncmcreatedeviceappbindingrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmcreatedeviceappbindingConnectionFactory = new CachingConnectionFactory(host);
		ncmcreatedeviceappbindingConnectionFactory.setPort(Integer.parseInt(port));
		ncmcreatedeviceappbindingConnectionFactory.setUsername(username);
		ncmcreatedeviceappbindingConnectionFactory.setPassword(password);
		ncmcreatedeviceappbindingConnectionFactory.setConnectionTimeout(30000);
		return ncmcreatedeviceappbindingConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmcreatedeviceappbindingRabbitAdmin(){
        return new RabbitAdmin(ncmcreatedeviceappbindingrabbitMQConnectionFactory());
    }
	
	@Bean("ncmcreatedeviceappbindingrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmcreatedeviceappbindingrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmcreatedeviceappbindingfactory = new SimpleRabbitListenerContainerFactory();
		ncmcreatedeviceappbindingfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmcreatedeviceappbindingfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmcreatedeviceappbindingfactory.setPrefetchCount(1);
		ncmcreatedeviceappbindingfactory.setReceiveTimeout((long) 50000);
		ncmcreatedeviceappbindingfactory.setConnectionFactory(ncmcreatedeviceappbindingrabbitMQConnectionFactory());
		ncmcreatedeviceappbindingfactory.setErrorHandler(errorHandler());
		return ncmcreatedeviceappbindingfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmcreatedeviceappbindingcustomRabbitTemplate() {
		RabbitTemplate ncmcreatedeviceappbindingrabbitTemplate = new RabbitTemplate();
		ncmcreatedeviceappbindingrabbitTemplate.setReplyTimeout(30000L);
		ncmcreatedeviceappbindingrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmcreatedeviceappbindingrabbitTemplate.setConnectionFactory(ncmcreatedeviceappbindingrabbitMQConnectionFactory());
		return ncmcreatedeviceappbindingrabbitTemplate;
	}
}
