package com.excelacom.servicegateway.bean;

public class InboundRequest {

	/** The Constant request. */
	private String request;

	/** The Constant source. */
	private String source;

	/** The Constant destination. */
	private String destination;

	/**
	 * @return
	 */
	public String getRequest() {
		return request;
	}

	/**
	 * @param request
	 */
	public void setRequest(String request) {
		this.request = request;
	}

	/**
	 * @return
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * @param destination
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}

	private String CustomerID;

	private String CustomerRequestID;

	private String mdn;

	private String oldMDN;

	private String newMDN;

	private String hostMDN;

	private String imei;

	private String imsi;

	private String iccid;

	private String eid;

	private String transId;

	private String eiccid;

	private String matchingId;

	private String referenceNumber;

	private String returnURL;

	private String asyncErrorURL;

	public String getNewRatePlan() {
		return newRatePlan;
	}

	public void setNewRatePlan(String newRatePlan) {
		this.newRatePlan = newRatePlan;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getContextId() {
		return contextId;
	}

	public void setContextId(String contextId) {
		this.contextId = contextId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBillCycleResetDay() {
		return billCycleResetDay;
	}

	public void setBillCycleResetDay(String billCycleResetDay) {
		this.billCycleResetDay = billCycleResetDay;
	}

	private String accountNumber;

	private String subscriberGroupCd;

	private String id;

	private String iccId;

	private String deviceId;
	
	private String newRatePlan;
	
	private String planCode;
	
    private String lineId;
	
	private String contextId;
	
	private String type;
	
	private String billCycleResetDay;
	
	private String userId;
	
	private String origData;
	
	private String newData;
	
	private String orderType;
	
	private String deviceid;
	
	
	
	public String getDeviceid() {
		return deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrigData() {
		return origData;
	}

	public void setOrigData(String origData) {
		this.origData = origData;
	}

	public String getNewData() {
		return newData;
	}

	public void setNewData(String newData) {
		this.newData = newData;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	
	public String getnewRatePlan() {
		return newRatePlan;
	}

	public void setnewRatePlan(String newRatePlan) {
		this.newRatePlan = newRatePlan;
	}

	public String getOldMDN() {
		return oldMDN;
	}

	public void setOldMDN(String oldMDN) {
		this.oldMDN = oldMDN;
	}

	public String getNewMDN() {
		return newMDN;
	}

	public void setNewMDN(String newMDN) {
		this.newMDN = newMDN;
	}

	public String getHostMDN() {
		return hostMDN;
	}

	public void setHostMDN(String hostMDN) {
		this.hostMDN = hostMDN;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getMatchingId() {
		return matchingId;
	}

	public void setMatchingId(String matchingId) {
		this.matchingId = matchingId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getMdn() {
		return mdn;
	}

	public void setMdn(String mdn) {
		this.mdn = mdn;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getCustomerRequestID() {
		return CustomerRequestID;
	}

	public void setCustomerRequestID(String customerRequestID) {
		this.CustomerRequestID = customerRequestID;
	}

	public String getEiccid() {
		return eiccid;
	}

	public void setEiccid(String eiccid) {
		this.eiccid = eiccid;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getReturnURL() {
		return returnURL;
	}

	public void setReturnURL(String returnURL) {
		this.returnURL = returnURL;
	}

	public String getAsyncErrorURL() {
		return asyncErrorURL;
	}

	public void setAsyncErrorURL(String asyncErrorURL) {
		this.asyncErrorURL = asyncErrorURL;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getSubscriberGroupCd() {
		return subscriberGroupCd;
	}

	public void setSubscriberGroupCd(String subscriberGroupCd) {
		this.subscriberGroupCd = subscriberGroupCd;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIccId() {
		return iccId;
	}

	public void setIccId(String iccId) {
		this.iccId = iccId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
	@Override
	public String toString() {
		return "RequestBean [CustomerID=" + CustomerID + ", CustomerRequestID=" + CustomerRequestID + ", mdn=" + mdn
				+ ", oldMDN=" + oldMDN + ", newMDN=" + newMDN + ", hostMDN=" + hostMDN + ", imei=" + imei + ", imsi="
				+ imsi + ", iccid=" + iccid + ", eid=" + eid + ", transId=" + transId + ", eiccid=" + eiccid
				+ ", matchingId=" + matchingId + ", referenceNumber=" + referenceNumber + ", returnURL=" + returnURL
				+ ", asyncErrorURL=" + asyncErrorURL + ", accountNumber=" + accountNumber + ", subscriberGroupCd="
				+ subscriberGroupCd + ", id=" + id + ", iccId=" + iccId + ", deviceId=" + deviceId + ", deviceid="
				+ deviceid + ", planCode=" + planCode + ", lineId=" + lineId + ", newRatePlan=" + newRatePlan
				+ ", contextId=" + contextId + ", type=" + type + ", billCycleResetDay=" + billCycleResetDay
				+ ", userId=" + userId + ", origData=" + origData + ", newData=" + newData + ", orderType=" + orderType
				+ "]";
	}
	
	

	/*
	 * @Override public String toString() { return "RequestBean [CustomerID=" +
	 * CustomerID + ", CustomerRequestID=" + CustomerRequestID + ", mdn=" + mdn +
	 * ", imei=" + imei + ", iccid=" + iccid + ", eid=" + eid + ", transId=" +
	 * transId + ", eiccid=" + eiccid + ", matchingId=" + matchingId +
	 * ", referenceNumber=" + referenceNumber + ", returnURL=" + returnURL +
	 * ", asyncErrorURL=" + asyncErrorURL + ", accountNumber=" + accountNumber +
	 * ", subscriberGroupCd=" + subscriberGroupCd + "]"; }
	 */

}
