pipeline {
    agent any
	
	tools { 
        maven 'Maven-3.3.9' 
        jdk 'jdk1.8.0_151' 
    }	
	
    stages {
        
		stage ('Build') {
            steps {
                echo 'Maven build is in progress.'
				sh '''
                    echo "PATH = ${PATH}"
                    echo "M2_HOME = ${M2_HOME}"
                '''
				sh 'mvn clean install -Dmaven.test.skip=true'
            }
}
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-QAR1-CICD@excelacom.in',
			to: 'devops@excelacom.in',
			subject: "NSL QAR1 PCRF Inbound Service Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }
        stage('Container Build') {
            steps {
			script{
                echo 'Contianer Build has been started...'
				docker.build('nsl-qar1' + ':pcrf_inbound_v$BUILD_NUMBER')
            }
			}
        }
        stage('Container Upload') {
            steps {
			script{
                echo 'Image Push has been started...'
				 
				docker.withRegistry('https://155077822508.dkr.ecr.us-east-1.amazonaws.com', 'ecr:us-east-1:AWS-ECR-Upload')
				{
               docker.image('nsl-qar1' + ':pcrf_inbound_v$BUILD_NUMBER').push('pcrf_inbound_v$BUILD_NUMBER')
            }
        }
		}
		}
        stage('Container Cleanup') {
            steps {
            	echo 'Image cleanup has been started...'
				sh "docker rmi nsl-qar1:pcrf_inbound_v${env.BUILD_NUMBER}"
				sh "docker rmi 155077822508.dkr.ecr.us-east-1.amazonaws.com/nsl-qar1:pcrf_inbound_v${env.BUILD_NUMBER}"
                  }
		}
		stage('NSL QAR1 - Configmap Inject') {
			steps {
			echo 'Applying QAR1 Properties and Datasource Configurations...'
			sh 'kubectl create configmap qar1-pcrf-inbound-properties --from-file=propertiesqar1 -n default -o yaml --dry-run | kubectl apply -f -'
			sh 'kubectl get configmaps qar1-pcrf-inbound-properties -o yaml -n default'
                  }
        }
		stage('NSL QAR1 - EKS POD Deploy') {
			steps {
			echo 'PCRF Inbound Service POD Deployment has been started...'
			sh 'cat qar1-pcrf-inbound-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f qar1-pcrf-inbound-service.yaml'
			sh 'kubectl apply -f qar1-pcrf-inbound-service-apm.yaml'
                  }
        }
		stage('NSL QAR1 - EKS POD Status') {
		    steps {
			echo 'PCRF Inbound Service POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep pcrf-inbound-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-QAR1-CICD@excelacom.in',
		  attachLog: true,
		  to: 'devops@excelacom.in',
		  subject: "NSL QAR1 PCRF Inbound Service Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-QAR1-CICD@excelacom.in',
		  attachLog: true,
		  to: 'devops@excelacom.in',
		  subject: "NSL QAR1 PCRF Inbound Service Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }