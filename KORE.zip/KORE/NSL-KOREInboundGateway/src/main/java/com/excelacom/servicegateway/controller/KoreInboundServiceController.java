package com.excelacom.servicegateway.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.http.HttpStatus;*/
import org.apache.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.consumer.InboundKoreMessageConsumer;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.handler.JWTHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;

//import com.flowcomponent.koreintegrationservice.constants.KoreConstants;
import com.excelacom.servicegateway.exception.NslCustomException;
//import com.excelacom.servicegateway.exception.InboundKoreMessageConsumer;
//import com.excelacom.servicegateway.consumer.InboundKoreMessageConsumer;


import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javax.ws.rs.NotAuthorizedException;

import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;

@RestController
public class KoreInboundServiceController {

	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Autowired
	private InboundProperties inboundProperties;

	@Autowired
	private JWTHandler jwtHandler;

	@Autowired
	private AuthHandler authHandler;
	
	
	
	/* @Autowired
	private InboundKoreMessageConsumer  inboundKoreMessageConsumer; */

	Logger LOGGER = LoggerFactory.getLogger(KoreInboundServiceController.class);

	@RequestMapping(value = "#{inboundProperties.getDisconnectDevice()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String disconnectDeviceController(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("disconnectDeviceController -- initiatePostServiceCall");
		String responseString = null;
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					Message result = null;
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDisconnectDeviceExchange(),
							inboundQueueProperties.getDisconnectDeviceQueue(), message);
					
						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());
					
					

				} else {
					String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
					String user = "";
					if (user.isEmpty()) {
						user = "User not available";
					}
					errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
					responseString = errorMsg;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getKoreQuerygetEapCodeServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryEapCodeSystemCall(HttpServletRequest request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("KoreQuerygetEapCode");
		String responseString = null;
		try {

			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("getKoreRequest", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					LOGGER.info("requestJson :::" + requestJson);
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					//Message result = inboundKoreMessageConsumer.koreQueryEapCodeSystemCall(message);
					LOGGER.info("message :::" + message);
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getKoreQuerygetEapCodeExchange(),
							inboundQueueProperties.getKoreQuerygetEapCodeQueue(), message);
					
						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getKoreQuerygetEapDetailsServiceurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryEapDetailsSystemCall(@PathVariable String eapCode, HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreQueryEapDetailsSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				JSONObject dataJson = new JSONObject();
				JSONObject getQueryRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getQueryRequestJson.put(paramName, request.getParameter(paramName).toString());
					
				}
				getQueryRequestJson.put("eapCode", eapCode);
				dataJson.put("getKoreRequest", getQueryRequestJson);
				 requestJson = dataJson.toString();
				 LOGGER.info("requestJson :::" + requestJson);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				
				LOGGER.info("message :::" + message);
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getKoreQuerygetEapDetailsExchange(), inboundQueueProperties.getKoreQuerygetEapDetailsQueue(), message);
				
				res.setStatus(responseHeader(result));
				responseString = new String(result.getBody());
    	} else {
    		responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
    	}
    } else {
    	responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
    	LOGGER.info("Invalid Token " + responseString);
    }

    } catch (Exception e) {
    LOGGER.error(e.getMessage(), e);
    }
    return responseString;
  }
  
  @RequestMapping(value = "#{inboundProperties.getKoreQueryPlanCodeNextPeriodurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String KoreQueryPlanCodeNextPeriodSystemCall(HttpServletRequest request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("KoreQueryPlanCodeNextPeriod");
		String responseString = null;
		try {

			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("getKoreRequest", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					LOGGER.info("requestJson :::" + requestJson);
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					//Message result = inboundKoreMessageConsumer.KoreQueryPlanCodeNextPeriodSystemCall(message);
					LOGGER.info("message :::" + message);
					 Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getKoreQueryPlanCodeNextPeriodExchange(),
							inboundQueueProperties.getKoreQueryPlanCodeNextPeriodQueue(), message);
					
						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getKoreSIMRadiusQueryurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreSIMRadiusQuerySystemCall(HttpServletRequest request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreSIMRadiusQuerySystemCall");
		String responseString = null;
		try {

			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("getKoreSimRadiusRequest", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					LOGGER.info("requestJson :::" + requestJson);
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					//Message result = inboundKoreMessageConsumer.koreSIMRadiusQuerySystemCall(message);
					LOGGER.info("message :::" + message);
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getKoreSIMRadiusQueryExchange(),
							inboundQueueProperties.getKoreSIMRadiusQueryQueue(), message);
					
						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getChangemsisdnurl()}",produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public String koreChangemsisdnCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("koreChangemsisdnCall");
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
       			JSONObject requestObject = this.convertJsonArrayToString(new JSONObject(request));
				Message message = MessageBuilder.withBody(requestObject.toString().getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getChangemsisdnExchange(), inboundQueueProperties.getChangemsisdnQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				
					System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in koreChangemsisdnCall "+ e);
	}
	return responseString;
}
	private JSONObject convertJsonArrayToString(JSONObject requestObject) throws JSONException {
		Iterator<String> objItr = requestObject.keys();
		while (objItr.hasNext()) {
			String key = objItr.next();
			if (Constants.DATA.equalsIgnoreCase(key)) {
				JSONObject dataObj = (JSONObject) requestObject.get("data");
				Iterator<String> dataItr = dataObj.keys();
				while (dataItr.hasNext()) {
					String dkey = dataItr.next();
									 if ("msisdn".equalsIgnoreCase(dkey)) {
										if (dataObj.get(dkey) != JSONObject.NULL)
											dataObj.put(dkey, String.valueOf(dataObj.get(dkey)));
									}
									 if ("featuresCodes".equalsIgnoreCase(dkey)) {
											if (dataObj.get(dkey) != JSONObject.NULL)
												dataObj.put(dkey, String.valueOf(dataObj.get(dkey)));
											LOGGER.info("Inside FeaturesCodes:" +dataObj.toString());
										}
									 if ("simId".equalsIgnoreCase(dkey)) {
											if (dataObj.get(dkey) != JSONObject.NULL)
												dataObj.put(dkey, String.valueOf(dataObj.get(dkey)));
											LOGGER.info("Inside simId:" +dataObj.toString());
										}
								
							}
						}
					}
				
		
		return requestObject;	
		}
	
	
	private JSONObject convertEmptyJsonElementToEmptyValues(JSONObject requestObject) throws JSONException {
		Iterator<String> objItr = requestObject.keys();
		while (objItr.hasNext()) {
			String key = objItr.next();
			if (Constants.DATA.equalsIgnoreCase(key)) {
				JSONObject dataObj = (JSONObject) requestObject.get(Constants.DATA);
				Iterator<String> dataItr = dataObj.keys();
				while (dataItr.hasNext()) {
					String dkey = dataItr.next();
					switch(dkey) {
					
					case Constants.CUSTOM_FIELD_1:{
						String val=dataObj.getString(dkey);
						if(val.isEmpty()) {
							requestObject.put(dkey, Constants.EMPTYINWORDS);
						}
					break;
					}
					
					}
			
								
							}
						}
					}
				
		
		return requestObject;	
		}

	@RequestMapping(value = "#{inboundProperties.getDeactivatedeviceurl()}",produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String koreDeactivatedeviceCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreDeactivatedeviceCall");
		String responseString = null;
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDeactivatedeviceExchange(), inboundQueueProperties.getDeactivatedeviceQueue(), message);
					
						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());
					
				} else {
					String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
					String user = "";
					if (user.isEmpty()) {
						user = "User not available";
					}
					errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
					responseString = errorMsg;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}


@RequestMapping(value = "#{inboundProperties.getGetModifyDeviceThresholdurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public Object ModifyDeviceThresholdCreateController(@RequestBody String request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ModifyDeviceThresholdCreateController -- initiatePostServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				//LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
				Message result=null;
				JSONObject requestObject = this.modifyDeviceThreshold(new JSONObject(request));
				
					Message message = MessageBuilder.withBody(requestObject.toString().getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getModifyDeviceThresholdExchange(), inboundQueueProperties.getModifyDeviceThresholdQueue(), message);
					 
						 	res.setStatus(responseHeader(result));
							responseString = new String(result.getBody());
						
				
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error("Exception in ModifyDeviceThresholdCreateController " +e);
	}
	return responseString;
}

	private JSONObject modifyDeviceThreshold(JSONObject requestObject) throws JSONException {
		
		Iterator<String> objItr = requestObject.keys();
		while (objItr.hasNext()) {
			String key = objItr.next();
			if (Constants.DATA.equalsIgnoreCase(key)) {
				JSONObject dataObj = (JSONObject) requestObject.get(Constants.DATA);
				Iterator<String> dataItr = dataObj.keys();
				while (dataItr.hasNext()) {
					String dkey = dataItr.next();
					// String cValue = (String) dataObj.get(dkey);
					switch (dkey) {
					case Constants.DAILY_DATA_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.DAILY_DATA_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.DAILY_SMS_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.DAILY_SMS_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.DAILY_VOICE_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.DAILY_VOICE_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_DATA_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_DATA_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_SMS_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_SMS_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_VOICE_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_VOICE_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_BARRING_DATA_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_BARRING_DATA_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_BARRING_SMS_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_BARRING_SMS_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					case Constants.MONTHLY_BARRING_VOICE_THRESHOLD: {
						if (dataObj.get(dkey) == JSONObject.NULL)
							dataObj.put(Constants.MONTHLY_BARRING_VOICE_THRESHOLD, Constants.STRING_NULL);

					}
						break;
					}
				}
			}
		}
		return requestObject;
	}

	@RequestMapping(value = "#{inboundProperties.getGetPingurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String PingCreateController(HttpServletRequest request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("PingCreateController");
		String responseString = null;
		try {

			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("KorePing", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					// Message result =
					// inboundKoreMessageConsumer.koreQueryEapCodeSystemCall(message);
					Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getKorePingExchange(),
							inboundQueueProperties.getKorePingQueue(), message);

					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getReportingPing()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String ReportingPingCreateController(HttpServletRequest request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("ReportingPingCreateController");
		String responseString = null;
		try {

			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("KoreReportingPingRequest", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					// Message result =
					// inboundKoreMessageConsumer.koreQueryEapCodeSystemCall(message);
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getReportingPingExchange(),
							inboundQueueProperties.getReportingPingQueue(), message);

					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@SuppressWarnings("unchecked")
	public int responseHeader(Message msg) throws NslCustomException, NotAuthorizedException {
		int code=200;
		try {
			byte[] body = msg.getBody();
			String req = new String(body);
			LOGGER.info(" inside request " + req);
			
			System.out.println("inside request::" + req);
			if (!req.isEmpty()) {
				String codeStr = "";
				String status = "";
				if (req.startsWith("{")) {

					JSONObject reqJson = new JSONObject(req);
					Iterator<String> reqJsonItr = reqJson.keys();
					while (reqJsonItr.hasNext()) {
						String reqKey = reqJsonItr.next();
						if (Constants.DATA.equalsIgnoreCase(reqKey)) {
							JSONObject dataJson = (JSONObject) reqJson.get(reqKey);
							Iterator<String> dataJsonItr = dataJson.keys();
							while (dataJsonItr.hasNext()) {
								String dataKey = dataJsonItr.next();
								if (Constants.CODE.equalsIgnoreCase(dataKey)) {
									codeStr = dataJson.getString(dataKey);
									break;
								} else if (Constants.STATUS.equalsIgnoreCase(dataKey)) {
									status = dataJson.getString(dataKey);
								}
							}
						}
						LOGGER.info("inside codeStr " + codeStr);
						System.out.println("inside codeStr::" + codeStr);
					}
					if (StringUtils.hasText(codeStr)) {
						code = Integer.parseInt(codeStr);
						return code;
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return code;
		}
		return code;
	}
	@RequestMapping(value = "#{inboundProperties.getActivatedeviceurl()}",produces = "application/json", method = RequestMethod.POST)
	@ResponseBody
	public Object activateDeviceCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("activateDeviceCall");
		//String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					//LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
					Message result=null;
				
						Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getActivateDeviceExchange(), inboundQueueProperties.getActivateDeviceQueue(), message);
						 
							 res.setStatus(responseHeader(result));
								responseString = new String(result.getBody());
							
					
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		}
		catch(Exception e) {
			LOGGER.error("Exception in activateDeviceCall "+ e);
		}
		return responseString;
	}
	
	
	@RequestMapping(value = "#{inboundProperties.getSimAssociateToGroupUrl()}",produces = "application/json", method = RequestMethod.POST)
	@ResponseBody
	public Object koreSimAssociateToGroupCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreSimAssociateToGroupCall");
		//String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					JSONObject requestObject = this.convertJsonArrayToString(new JSONObject(request));
					request = requestObject.toString();
					//String slashquotes= new Character((char) 92).toString()+ new Character((char) 34).toString();
					//LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
					Message result=null;
				
						Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getSimAssociateToGroupExchange(), inboundQueueProperties.getSimAssociateToGroupQueue(), message);
						 
							 res.setStatus(responseHeader(result));
								responseString = new String(result.getBody());
							
					
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		}
		catch(Exception e) {
			LOGGER.error("Exception in koreSimAssociateToGroupCall "+ e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getActivatetostateurl()}",produces = "application/json", method = RequestMethod.POST)
	@ResponseBody
	public Object activateToStateCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("activateToStateCall");
		//String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					//LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
					Message result=null;
				
						Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getActivateToStateExchange(), inboundQueueProperties.getActivateToStateQueue(), message);
						 
							 	res.setStatus(responseHeader(result));
								responseString = new String(result.getBody());
							
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		}
		catch(Exception e) {
			LOGGER.error("Exception in activateToStateCall "+ e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getGetquerydeviceurl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String koreQueryDeviceSystemCall(HttpServletRequest request,@PathVariable String simId, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("koreQueryDeviceSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				HashMap<String, Object> data = new HashMap<String, Object>();
				data.put("simId", simId);
					  Enumeration<String> queryMap = request.getParameterNames();
					  while(queryMap.hasMoreElements()) { 
						  String paramName = queryMap.nextElement(); 
						  data.put(paramName,request.getParameter(paramName).toString()); 
						  }
	     		LOGGER.info("data :: " + data + " request  :: " + request);
				HashMap<String,Object> req = new HashMap<String, Object>();
				req.put("getQueryDeviceRequest", data);
				HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
				datareq.put("data", req);
				requestJson = new Gson().toJson(datareq);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryDeviceExchange(), inboundQueueProperties.getQueryDeviceQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				
				System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in koreQueryDeviceSystemCall "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getGetquerydevicedetailsexturl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String koreQueryDeviceDetailsExtSystemCall(HttpServletRequest request,@PathVariable String simId, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("koreQueryDeviceDetailsExtSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				HashMap<String, Object> data = new HashMap<String, Object>();
				data.put("simId", simId);
				  Enumeration<String> queryMap = request.getParameterNames();
				  while(queryMap.hasMoreElements()) { 
					  String paramName = queryMap.nextElement(); 
					  data.put(paramName,request.getParameter(paramName).toString()); 
					  }
				HashMap<String,Object> req = new HashMap<String, Object>();
				req.put("getQueryDeviceDetailsExtRequest", data);
				HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
				datareq.put("data", req);
				requestJson = new Gson().toJson(datareq);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryDeviceDetailsExtExchange(), inboundQueueProperties.getQueryDeviceDetailsExtQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in koreQueryDeviceDetailsExtSystemCall "+ e);
	}
	return responseString;
}

@RequestMapping(value = "#{inboundProperties.getReactivatedeviceurl()}",produces = "application/json", method = RequestMethod.POST)
@ResponseBody
public Object reactivateDeviceCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("reactivateDeviceCall");
	//String requestJson = "";
	String responseString = "";
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				//LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
				Message result=null;
			
					Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getReactivateDeviceExchange(), inboundQueueProperties.getReactivateDeviceQueue(), message);
					 
						 res.setStatus(responseHeader(result));
							responseString = new String(result.getBody());
						
				
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	}
	catch(Exception e) {
		LOGGER.error("Exception in activateDeviceCall "+ e);
	}
	return responseString;
}



@RequestMapping(value = "#{inboundProperties.getGetqueryalldevicesurl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String koreQueryAllDevices(HttpServletRequest request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("koreQueryAllDevices");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				HashMap<String, Object> data = new HashMap<String, Object>();
				
					  Enumeration<String> queryMap = request.getParameterNames();
					  while(queryMap.hasMoreElements()) { 
						  String paramName = queryMap.nextElement(); 
						  data.put(paramName,request.getParameter(paramName).toString()); 
						  }
	     		LOGGER.info("data :: " + data + " request  :: " + request);
				HashMap<String,Object> req = new HashMap<String, Object>();
				req.put("getQueryAllDevicesRequest", data);
				HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
				datareq.put("data", req);
				requestJson = new Gson().toJson(datareq);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryAllDevicesExchange(), inboundQueueProperties.getQueryAllDevicesQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				
				System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in koreQueryAllDevices "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getGetalertsbysimidurl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String koreGetAlertsBySimId(HttpServletRequest request,@PathVariable String companyId,@PathVariable String simId, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("koreGetAlertsBySimId");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				HashMap<String, Object> data = new HashMap<String, Object>();
				data.put("companyId", companyId);
				data.put("simId", simId);
					  Enumeration<String> queryMap = request.getParameterNames();
					  while(queryMap.hasMoreElements()) { 
						  String paramName = queryMap.nextElement(); 
						  data.put(paramName,request.getParameter(paramName).toString()); 
						  }
	     		LOGGER.info("data :: " + data + " request  :: " + request);
				HashMap<String,Object> req = new HashMap<String, Object>();
				req.put("GetAllertsBySIM", data);
				//HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
				//datareq.put("data", req);
				requestJson = new Gson().toJson(req);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getGetAlertsBySimIdExchange(), inboundQueueProperties.getGetAlertsBySimIdQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				
				System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in koreGetAlertsBySimId "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getGetcostcentersurl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String koreGetCostCentersCall(HttpServletRequest request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("Inside koreGetCostCentersCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("Oauth TOken" +token);  
        	 JSONObject requestObject = new JSONObject();
     		JSONObject dataJson = new JSONObject();
     		JSONObject getGetCostCentersJson = new JSONObject();
     		
     		Enumeration<String> queryMap = request.getParameterNames();
     		while(queryMap.hasMoreElements()) {
     			String paramName = queryMap.nextElement();
     			getGetCostCentersJson.put(paramName, request.getParameter(paramName).toString());
     		}
     		dataJson.put("getKoreRequest", getGetCostCentersJson);
     		requestObject.put("data", dataJson);
     	      requestJson = requestObject.toString();
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getCostCentersExchange(), inboundQueueProperties.getCostCentersQueue(), message);
				
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
				
				System.out.println("Response : " + responseString);
              }else {
  				String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
  				String user = "";
  				if (user.isEmpty()) {
  					user = "User not available";
  				}
  				errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
  				responseString = errorMsg;
  				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
  			}
       			LOGGER.info("Response :: " + responseString);
       			} else {
       				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
       				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
       			}

	}
	catch(Exception e) {
		LOGGER.error("Exception in koreGetCostCentersCall "+ e);
	}
	return responseString;
}

@RequestMapping(value = "#{inboundProperties.getMdcustominfourl()}",produces = "application/json",consumes = "application/json",method = RequestMethod.POST)
@ResponseBody
public String koreMdCustomInfoCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res,@RequestHeader(value="outboundNSLRequestActivate", required = false) String request1) {
	LOGGER.info("Inside koreMdCustomInfoCall::");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message result = null;
				if(request1!=null) {
					
					request=request1;
				}
				Message message = MessageBuilder.withBody(request.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getMdCustomInfoExchange(), inboundQueueProperties.getMdCustomInfoQueue(), message);
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
			} else {
				String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
				String user = "";
				if (user.isEmpty()) {
					user = "User not available";
				}
				errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
				responseString = errorMsg;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage());
	}
	return responseString;
}

@RequestMapping(value = "#{inboundProperties.getGetquerydeviceusagebysimurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String koreQueryDeviceUsageBySimSystemCall(@PathVariable String simId, HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) { 
	LOGGER.info("koreQueryDeviceUsageBySimSystemCall");
String requestJson = "";
String responseString = "";
try {       
   if (token != null) {
   	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
    	 LOGGER.info("JWT TOken" +token);  
    	 	JSONObject requestObject = new JSONObject();
			JSONObject dataJson = new JSONObject();
			JSONObject getQueryDeviceUsageBySimRequestJson = new JSONObject();
			Enumeration<String> queryMap = request.getParameterNames();
			while(queryMap.hasMoreElements()) {
				String paramName = queryMap.nextElement();
				getQueryDeviceUsageBySimRequestJson.put(paramName, request.getParameter(paramName).toString());
				
			}
			getQueryDeviceUsageBySimRequestJson.put("simId", simId);
			dataJson.put("koredeviceusage", getQueryDeviceUsageBySimRequestJson);
			requestObject.put("data", dataJson);
			 requestJson = dataJson.toString();
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryDeviceUsageBySimExchange(), inboundQueueProperties.getQueryDeviceUsageBySimQueue(), message);
			res.setStatus(responseHeader(result));
			responseString = new String(result.getBody());
	} else {
		responseString = utilityClass.invalidToken(token);
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
} else {
	responseString = utilityClass.unavailableToken();
	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	LOGGER.info("Invalid Token " + responseString);
}

} catch (Exception e) {
LOGGER.error(e.getMessage(), e);
}
return responseString;
}

@RequestMapping(value = "#{inboundProperties.getNCMModifyDevicePlanForNxtPrdurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
public Object ncmModifyDevicePlanForNxtPrdCall(@RequestBody String request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	
	String responseString = null;
	try {

		if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message message = MessageBuilder.withBody(request.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(

						inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdExchange(),
						inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdQueue(), message);
				
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(responseHeader(result));		
					responseString = new String(result.getBody());
				
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			System.out.println("Invalid Token " + responseString);
		}

		System.out.println("inside ncmModifyDevicePlanForNxtPrdCall" + responseString);
	} catch (Exception e) {
		LOGGER.error("Exception in ncmRebootCall " + e);
	}
	return responseString;

}

	@RequestMapping(value = "#{inboundProperties.getGetqueryfeaturecodesurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryFeaureCodesSystemCall(@PathVariable String serviceTypeCode, HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token,HttpServletResponse res) { 
		LOGGER.info("koreQueryFeaureCodesSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				JSONObject dataJson = new JSONObject();
				JSONObject getQueryFeatureCodesRequestJson = new JSONObject();
				JSONObject requestObject = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getQueryFeatureCodesRequestJson.put(paramName, request.getParameter(paramName).toString());
					
				}
				getQueryFeatureCodesRequestJson.put("serviceTypeCode", serviceTypeCode);
				dataJson.put("QueryfeatureCodes", getQueryFeatureCodesRequestJson);
				requestObject.put("data", dataJson);
				 requestJson = requestObject.toString();
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryFeatureCodesExchange(), inboundQueueProperties.getQueryFeatureCodesQueue(), message);
				responseString = new String(result.getBody());
				responseString = new String(result.getBody());
				res.setStatus(responseHeader(result));
				responseString = new String(result.getBody());
			
		} else {
			responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} else {
		responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		LOGGER.info("Invalid Token " + responseString);
	}

    } catch (Exception e) {
    LOGGER.error(e.getMessage(), e);
    }
    return responseString;
  }

		@RequestMapping(value = "#{inboundProperties.getGetquerydeviceusageurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryDeviceUSageSystemCall( HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token,HttpServletResponse res) { 
		LOGGER.info("koreQueryDeviceUSageSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				JSONObject dataJson = new JSONObject();
				JSONObject getQueryDeviceUsageJson = new JSONObject();
				JSONObject requestObject = new JSONObject();
			
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getQueryDeviceUsageJson.put(paramName, request.getParameter(paramName).toString());
					
				}

				dataJson.put("KoreQueryDeviceUsage", getQueryDeviceUsageJson);
				requestObject.put("data", dataJson);
				 requestJson = requestObject.toString();
				 requestJson = requestJson.replace("\\", "");
				 requestJson = requestJson.replace("\"{", "{");
				 requestJson = requestJson.replace("}\"", "}");
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getKoreQueryDeviceUsageExchange(), inboundQueueProperties.getKoreQueryDeviceUsageQueue(), message);
				responseString = new String(result.getBody());
				res.setStatus(responseHeader(result));
				responseString = new String(result.getBody());
			
		} else {
			responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} else {
		responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		LOGGER.info("Invalid Token " + responseString);
	}

    } catch (Exception e) {
    LOGGER.error(e.getMessage(), e);
    }
    return responseString;
  }
  
  @RequestMapping(value = "#{inboundProperties.getModifyDeviceFeaturesurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
public Object koreModifyDeviceFeaturesCall(@RequestBody String request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	
	String responseString = null;
	try {

		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = this.convertJsonArrayToString(new JSONObject(request));
				request = requestObject.toString();
				String slashquotes= new Character((char) 92).toString()+ new Character((char) 34).toString();
				//request = request.replaceAll(slashquotes, "");
				
				Message message = MessageBuilder.withBody(request.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(

						inboundQueueProperties.getModifyDeviceFeaturesExchange(),
						inboundQueueProperties.getModifyDeviceFeaturesQueue(), message);
				
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(responseHeader(result));		
					responseString = new String(result.getBody());
				
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			System.out.println("Invalid Token " + responseString);
		}

		System.out.println("inside koreModifyDeviceFeaturesCall" + responseString);
	} catch (Exception e) {
		LOGGER.error("Exception in koreModifyDeviceFeaturesCall " + e);
	}
	return responseString;

}
  
	@RequestMapping(value = "#{inboundProperties.getQueryrequeststatusurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryRequestStatusCall(@PathVariable String referenceno, HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res,@RequestHeader(value="outboundNSLRequestActivate", required = false) String request1) {
		LOGGER.info("koreQueryRequestStatusCall");
	String requestJson = "";
	String responseString = "";
	try {       
     if (token != null) {
     	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
      	 LOGGER.info("JWT TOken" +token);  
				JSONObject dataJson = new JSONObject();
				JSONObject getQueryRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getQueryRequestJson.put(paramName, request.getParameter(paramName).toString());
					
				}
				getQueryRequestJson.put("referenceno", referenceno);
				dataJson.put("getKoreRequest", getQueryRequestJson);
				if(request1!=null) {
				dataJson.put("request", request1);
				}
				 requestJson = dataJson.toString();
				 LOGGER.info("requestJson :::" + requestJson);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				
				LOGGER.info("message :::" + message);
			    Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryRequestStatusExchange(), inboundQueueProperties.getQueryRequestStatusQueue(), message);
				
				res.setStatus(responseHeader(result));
				responseString = new String(result.getBody());
  	} else {
  		responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
  	}
  } else {
  	responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
  	LOGGER.info("Invalid Token " + responseString);
  }

  } catch (Exception e) {
  LOGGER.error(e.getMessage(), e);
  }
  return responseString;
}
	
	@RequestMapping(value = "#{inboundProperties.getQueryservicetypecodesurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String koreQueryServiceTypeCodesCall(HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("Inside koreQueryServiceTypeCodesCall");
	String requestJson = "";
	String responseString = "";
	try {       
     if (token != null) {
     	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
      	 LOGGER.info("JWT TOken" +token);  
				JSONObject dataJson = new JSONObject();
				JSONObject getQueryRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getQueryRequestJson.put(paramName, request.getParameter(paramName).toString());
					
				}
				dataJson.put("getKoreRequest", getQueryRequestJson);
				 requestJson = dataJson.toString();
				 LOGGER.info("requestJson :::" + requestJson);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				
				LOGGER.info("message :::" + message);
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getQueryServiceTypeCodesExchange(), inboundQueueProperties.getQueryServiceTypeCodesQueue(), message); 
				
				res.setStatus(responseHeader(result));
				responseString = new String(result.getBody());
  	} else {
  		responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
  	}
  } else {
  	responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
  	LOGGER.info("Invalid Token " + responseString);
  }

  } catch (Exception e) {
  LOGGER.error(e.getMessage(), e);
  }
  return responseString;
}
	
	@RequestMapping(value = "#{inboundProperties.getSuspendDevice()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String suspendDeviceController(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("suspendDeviceController -- initiatePostServiceCall");
		String responseString = null;
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					Message result = null;
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getSuspendDeviceExchange(),
							inboundQueueProperties.getSuspendDeviceQueue(), message);

					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());

				} else {
					String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
					String user = "";
					if (user.isEmpty()) {
						user = "User not available";
					}
					errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
					responseString = errorMsg;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getDownloadReporting()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String downloadReportingController(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("downloadReportingController -- initiatePostServiceCall");
		String responseString = null;
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					Message result = null;
					Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDownloadReportingExchange(),inboundQueueProperties.getDownloadReportingQueue(), message);
					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());

				} else {
					String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
					String user = "";
					if (user.isEmpty()) {
						user = "User not available";
					}
					errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
					responseString = errorMsg;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return responseString;
	}
	
@RequestMapping(value = "#{inboundProperties.getKorechangesimstatusurl()}",produces = "application/json", method = RequestMethod.POST)
	@ResponseBody
	public Object koreChangeSimStatus(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreChangeSimStatus");
		//String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					Message result=null;
				
						Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getKoreChangeSimStatusExchange(), inboundQueueProperties.getKoreChangeSimStatusQueue(), message);
						 
							 	res.setStatus(responseHeader(result));
								responseString = new String(result.getBody());
							
					
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		}
		catch(Exception e) {
			LOGGER.error("Exception in koreChangeSimStatus "+ e);
		}
		return responseString;
	}

@RequestMapping(value = "#{inboundProperties.getKorequeryavailablereportfilesurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String koreQueryAvailableReportFilesSystemCall( HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token,HttpServletResponse res) { 
	LOGGER.info("koreQueryAvailableReportFilesSystemCall");
String requestJson = "";
String responseString = "";
try {       
   if (token != null) {
   	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
    	 LOGGER.info("JWT TOken" +token);  
			JSONObject dataJson = new JSONObject();
			JSONObject getQueryAvailableReportFilesJson = new JSONObject();
			JSONObject requestObject = new JSONObject();
		
			Enumeration<String> queryMap = request.getParameterNames();
			while(queryMap.hasMoreElements()) {
				String paramName = queryMap.nextElement();
				getQueryAvailableReportFilesJson.put(paramName, request.getParameter(paramName).toString());
				
			}

			dataJson.put("queryAvailableReports", getQueryAvailableReportFilesJson);
			requestObject.put("data", dataJson);
			 requestJson = requestObject.toString();
			 requestJson = requestJson.replace("\\", "");
			 requestJson = requestJson.replace("\"{", "{");
			 requestJson = requestJson.replace("}\"", "}");
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getKoreQueryAvailableReportFilesExchange(), inboundQueueProperties.getKoreQueryAvailableReportFilesQueue(), message);
			responseString = new String(result.getBody());
			res.setStatus(responseHeader(result));
			responseString = new String(result.getBody());
		
	} else {
		responseString = utilityClass.invalidToken(token);
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
} else {
	responseString = utilityClass.unavailableToken();
	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	LOGGER.info("Invalid Token " + responseString);
}

} catch (Exception e) {
LOGGER.error(e.getMessage(), e);
}
return responseString;
}

 @RequestMapping(value = "#{inboundProperties.getRestoreDevicesurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public Object koreRestoreDevicesCall(@RequestBody String request,
	 		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	 	
	 	String responseString = null;
	 	try {

	 		if (token != null) {
	 			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

	 				Message message = MessageBuilder.withBody(request.getBytes())
	 						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	 				Message result = customRabbitTemplate.sendAndReceive(

	 						inboundQueueProperties.getRestoreDevicesExchange(),
	 						inboundQueueProperties.getRestoreDevicesQueue(), message);
	 				
	 					LOGGER.info("responseHeader ::"+result);
	 					res.setStatus(responseHeader(result));		
	 					responseString = new String(result.getBody());
	 				
	 				
	 			} else {
	 				responseString = utilityClass.invalidToken(token);
	 				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 			}
	 			LOGGER.info("Response :: " + responseString);
	 		} else {
	 			responseString = utilityClass.unavailableToken();
	 			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 			System.out.println("Invalid Token " + responseString);
	 		}

	 		System.out.println("inside koreRestoreDevicesCall" + responseString);
	 	} catch (Exception e) {
	 		LOGGER.error("Exception in koreRestoreDevicesCall " + e);
	 	}
	 	return responseString;
	 }
	 
	 @RequestMapping(value = "#{inboundProperties.getSimChangeDeviceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public Object koreSimChangeDeviceCall(@RequestBody String request,
	 		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	 	
	 	String responseString = null;
	 	try {

	 		if (token != null) {
	 			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

	 				Message message = MessageBuilder.withBody(request.getBytes())
	 						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	 				Message result = customRabbitTemplate.sendAndReceive(

	 						inboundQueueProperties.getSimChangeDeviceExchange(),
	 						inboundQueueProperties.getSimChangeDeviceQueue(), message);
	 				
	 					LOGGER.info("responseHeader ::"+result);
	 					res.setStatus(responseHeader(result));		
	 					responseString = new String(result.getBody());
	 				
	 				
	 			} else {
	 				responseString = utilityClass.invalidToken(token);
	 				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 			}
	 			LOGGER.info("Response :: " + responseString);
	 		} else {
	 			responseString = utilityClass.unavailableToken();
	 			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 			System.out.println("Invalid Token " + responseString);
	 		}

	 		System.out.println("inside koreSimChangeDeviceCall" + responseString);
	 	} catch (Exception e) {
	 		LOGGER.error("Exception in koreSimChangeDeviceCall " + e);
	 	}
	 	return responseString;
	 }
	 
	 @RequestMapping(value = "#{inboundProperties.getKoreUnbarToStateCallurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	  public Object koreUnbarToStateCall(@RequestBody String request,
	  		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	  	
	  	String responseString = null;
	  	try {

	  		if (token != null) {
	  		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
	  				Message message = MessageBuilder.withBody(request.getBytes())
	  						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	  				Message result = customRabbitTemplate.sendAndReceive(

	  						inboundQueueProperties.getKoreUnbarToStateExchange(),
	  						inboundQueueProperties.getKoreUnbarToStateQueue(), message);
	  				
	  					LOGGER.info("responseHeader ::"+result);
	  					res.setStatus(responseHeader(result));		
	  					responseString = new String(result.getBody());
	  				
	  				
	  			} else {
	  				responseString = utilityClass.invalidToken(token);
	  				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			}
	  			LOGGER.info("Response :: " + responseString);
	  		} else {
	  			responseString = utilityClass.unavailableToken();
	  			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			System.out.println("Invalid Token " + responseString);
	  		}

	  		System.out.println("inside koreUnbarToStateCall" + responseString);
	  	} catch (Exception e) {
	  		LOGGER.error("Exception in koreUnbarToStateCall " + e);
	  	}
	  	return responseString;

	  }
	 
	 @RequestMapping(value = "#{inboundProperties.getAcknowledgealertsbygroupurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	  public Object koreAcknowledgeAlertsbyGroupCall(@RequestBody String request,
	  		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	  	
	  	String responseString = null;
	  	try {

	  		if (token != null) {
	  		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
	  				Message message = MessageBuilder.withBody(request.getBytes())
	  						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	  				Message result = customRabbitTemplate.sendAndReceive(

	  						inboundQueueProperties.getAcknowledgeAlertsbyGroupExchange(),
	  						inboundQueueProperties.getAcknowledgeAlertsbyGroupQueue(), message);
	  				
	  					LOGGER.info("responseHeader ::"+result);
	  					res.setStatus(responseHeader(result));		
	  					responseString = new String(result.getBody());
	  				
	  				
	  			} else {
	  				responseString = utilityClass.invalidToken(token);
	  				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			}
	  			LOGGER.info("Response :: " + responseString);
	  		} else {
	  			responseString = utilityClass.unavailableToken();
	  			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			System.out.println("Invalid Token " + responseString);
	  		}

	  		System.out.println("inside koreAcknowledgeAlertsbyGroupCall" + responseString);
	  	} catch (Exception e) {
	  		LOGGER.error("Exception in koreAcknowledgeAlertsbyGroupCall " + e);
	  	}
	  	return responseString;

	  }
	  
	 @RequestMapping(value = "#{inboundProperties.getRemoveSimAssociation()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
		@ResponseBody
		public String RemoveSimAssociationController(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res)  {
			LOGGER.info("RemoveSimAssociationController");
			String responseString = null;
			try {

				if (token != null) {
					if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
						
						JSONObject requestObject = this.convertJsonArrayToString(new JSONObject(request));
						request = requestObject.toString();
						//Message result=null;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						// Message result =
						// inboundKoreMessageConsumer.koreQueryEapCodeSystemCall(message);
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getRemoveSimAssociationExchange(),
								inboundQueueProperties.getRemoveSimAssociationQueue(), message);

						res.setStatus(responseHeader(result));
						responseString = new String(result.getBody());

					} else {
						responseString = utilityClass.invalidToken(token);
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
				} else {
					responseString = utilityClass.unavailableToken();
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					LOGGER.info("Invalid Token " + responseString);
				}

			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}
			return responseString;
		}

//RetrieveGroupByCompanyId	 
	@RequestMapping(value = "#{inboundProperties.getGetRetrieveGroupByCompanyIdurl()}", produces = "application/json", method = RequestMethod.GET)
	@ResponseBody
	public String koreRetrieveGroupByCompanyIdSystemCall(HttpServletRequest request, @PathVariable String companyId,
			@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
		LOGGER.info("koreRetrieveGroupByCompanyIdSystemCall");
		String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					LOGGER.info("JWT TOken" + token);
					HashMap<String, Object> data = new HashMap<String, Object>();
					data.put("companyId", companyId);
					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						data.put(paramName, request.getParameter(paramName).toString());
					}
					HashMap<String, Object> req = new HashMap<String, Object>();
					req.put("KoreRetrieveGroupByCompanyId", data);
					HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
					datareq.put("data", req);
					requestJson = new Gson().toJson(datareq);
					Message message = MessageBuilder.withBody(requestJson.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getRetrieveGroupByCompanyIdExchange(),
							inboundQueueProperties.getRetrieveGroupByCompanyIdQueue(), message);

					res.setStatus(responseHeader(result));
					responseString = new String(result.getBody());
					System.out.println("Response : " + responseString);
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in koreRetrieveGroupByCompanyIdSystemCall " + e);
		}
		return responseString;
	}
	
	 @RequestMapping(value = "#{inboundProperties.getAcknowlegdeAlertBySimAndRule()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	  public Object acknowlegdeAlertBySimAndRuleCall(@RequestBody String request,
	  		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	  	
	  	String responseString = null;
	  	try {

	  		if (token != null) {
	  		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
	  				Message message = MessageBuilder.withBody(request.getBytes())
	  						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	  				Message result = customRabbitTemplate.sendAndReceive(

	  						inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleExchange(),
	  						inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleQueue(), message);
	  				
	  					LOGGER.info("responseHeader ::"+result);
	  					res.setStatus(responseHeader(result));		
	  					responseString = new String(result.getBody());
	  				
	  				
	  			} else {
	  				responseString = utilityClass.invalidToken(token);
	  				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			}
	  			LOGGER.info("Response :: " + responseString);
	  		} else {
	  			responseString = utilityClass.unavailableToken();
	  			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			System.out.println("Invalid Token " + responseString);
	  		}

	  		System.out.println("inside koreUnbarToStateCall" + responseString);
	  	} catch (Exception e) {
	  		LOGGER.error("Exception in koreUnbarToStateCall " + e);
	  	}
	  	return responseString;

	  }
	  
	 @RequestMapping(value = "#{inboundProperties.getGetalertbycompanyidgroupidurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 @ResponseBody
	 public String koreAlertByCompanyIdGroupIdSystemCall(@PathVariable String companyId, @PathVariable String groupId, HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) { 
	 	LOGGER.info("koreAlertByCompanyIdGroupIdSystemCall");
	 String requestJson = "";
	 String responseString = "";
	 try {       
	    if (token != null) {
	    	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
	     	 LOGGER.info("JWT TOken" +token);  
	     	 	JSONObject requestObject = new JSONObject();
	 			JSONObject dataJson = new JSONObject();
	 			JSONObject getAlertByCompanyIdGroupIdRequestJson = new JSONObject();
	 			
	 			Enumeration<String> queryMap = request.getParameterNames();
	 			while(queryMap.hasMoreElements()) {
	 				String paramName = queryMap.nextElement();
	 				getAlertByCompanyIdGroupIdRequestJson.put(paramName, request.getParameter(paramName).toString());
	 				
	 			}
	 			getAlertByCompanyIdGroupIdRequestJson.put("companyId", companyId);
	 			getAlertByCompanyIdGroupIdRequestJson.put("groupId", groupId);
	 			dataJson.put("getbygroupid", getAlertByCompanyIdGroupIdRequestJson);
	 			requestObject.put("data", dataJson);
	 			 requestJson = dataJson.toString();
	 			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	 			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getAlertByCompanyIdGroupIdExchange(), inboundQueueProperties.getAlertByCompanyIdGroupIdQueue(), message);
	 			res.setStatus(responseHeader(result));
	 			responseString = new String(result.getBody());
	 	} else {
	 		responseString = utilityClass.invalidToken(token);
	 		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 	}
	 } else {
	 	responseString = utilityClass.unavailableToken();
	 	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	 	LOGGER.info("Invalid Token " + responseString);
	 }

	 } catch (Exception e) {
	 LOGGER.error(e.getMessage(), e);
	 }
	 return responseString;
	 }
	 
	 @RequestMapping(value = "#{inboundProperties.getSendAsyncAcknowledgeurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	  public Object sendAcknowledge(@RequestBody String request,
	  		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res
	  		) {
	  	
	  	String responseString = null;
	  	try {

	  		if (token != null) {
	  		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
	  				Message message = MessageBuilder.withBody(request.getBytes())
	  						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	  				Message result = customRabbitTemplate.sendAndReceive(

	  						inboundQueueProperties.getSendAcknowledgeExchange(),
	  						inboundQueueProperties.getSendAcknowledgeQueue(), message);
	  				
	  					LOGGER.info("responseHeader ::"+result);
	  					res.setStatus(responseHeader(result));		
	  					responseString = new String(result.getBody());
	  				
	  				
	  			} else {
	  				responseString = utilityClass.invalidToken(token);
	  				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			}
	  			LOGGER.info("Response :: " + responseString);
	  		} else {
	  			responseString = utilityClass.unavailableToken();
	  			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	  			System.out.println("Invalid Token " + responseString);
	  		}

	  		System.out.println("inside sendAcknowledge" + responseString);
	  	} catch (Exception e) {
	  		LOGGER.error("Exception in sendAcknowledge " + e);
	  	}
	  	return responseString;

	  }

}
