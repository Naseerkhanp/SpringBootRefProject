package com.nsl.managelines.batch.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Line {

	private String lineId;

	private String acctId;

	private String accountNumber;

	private String eLineId;

	private String mdn;

	private String lineStatus;

	private String lteStatus;

	private String lineName;

	private String activationDate;

	private String hostMdn;

	private String deactivationDate;

	private String min;

	private String bcd;

	private String hotlineType;

	private String isPorted;

	private String lineType;

	private String serviceType;

	private String referenceNumber;

	private String inflightTransStatus;

	private String speedReducedFlag;

	private String isGfPlan;

	private String createdDate;

	private String createdBy;

	private String modifiedBy;

	private String modifiedDate;

	private String isMigrated;

	private String index;
	
	private String isLineIdExist;
	
	private String planMigrationEligibile;
}
