/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class KeyValueObj implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String type;

	public String value;

}
