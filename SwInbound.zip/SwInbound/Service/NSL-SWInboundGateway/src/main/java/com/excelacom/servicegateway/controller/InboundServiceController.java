package com.excelacom.servicegateway.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.NotAuthorizedException;

import org.apache.http.HttpStatus;
//import org.hibernate.mapping.Array;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.consumer.InboundSWMessageConsumer;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.exception.NslCustomException;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.security.JWTHandler;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

//import antlr.collections.List;

import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;
import javax.ws.rs.core.Response;
import javax.ws.rs.NotAuthorizedException;
import lombok.Getter;
import lombok.Setter;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.math.BigDecimal;

@RestController
//@RequestMapping(value = "/nsl/provisioning/mno/v1")
public class InboundServiceController {

	private static final char[] MDN = null;

	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private InboundSWMessageConsumer inboundConsumer;
	
	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	TransactionDAO transactionDAO;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;
	
	@Autowired
	private JWTHandler jwtHandler;

	@Autowired
	InboundProperties inboundProperties;	
	
	@Autowired
	private AuthHandler authHandler ;
	
	@Autowired
	private InboundSWMessageConsumer inbound ;
	

	Logger LOGGER = LoggerFactory.getLogger(InboundServiceController.class);
	
	@RequestMapping(value = "#{inboundProperties.getUpdateWifiurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String updateWifiCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("updateWifiCall");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("update wifi address", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				if (token != null) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "update wifi address", "POST",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {

						request += "_DELIM" + source;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getUpdateWifiExchange(),
								inboundQueueProperties.getUpdateWifiQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getValidateWifiurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String validateWifiCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("validateWifiCall");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("validate wifi address", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				if (token != null) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "validate wifi address",
							"POST", inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {

						request += "_DELIM" + source;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getValidateWifiExchange(),
								inboundQueueProperties.getValidateWifiQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getWifiurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String wifiCall(HttpServletRequest request, @PathVariable String mdn,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("wifiCall");

		String requestJson = null;
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("mdn", mdn);
		HashMap<String, HashMap<String, String>> req = new HashMap<String, HashMap<String, String>>();
		req.put("data", data);
		requestJson = new Gson().toJson(req);
		String responseString = null;
		String reqUrl = getFullUrl(request);
		LOGGER.info("GET call :: reqURL:: " + reqUrl);
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("wifi address inquiry", "GET");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				if (token != null) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "wifi address inquiry", "GET",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {

						requestJson += "_DELIM" + source;
						requestJson += "_DELIM" + reqUrl;
						Message message = MessageBuilder.withBody(requestJson.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getWifiExchange(),
								inboundQueueProperties.getWifiQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getSwWearableurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String swWearableCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("swWearableCall");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("Add Wearable", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				if (token != null) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "Add Wearable", "POST",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {

						request += "_DELIM" + source + "_DELIM" + user;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getSwWearableExchange(),
								inboundQueueProperties.getSwWearableQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getChangeesimurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String ChangeEsimCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res,
			HttpServletRequest req) {
		LOGGER.info("ChangeEsimCall");
		String responseString = null;
		String reqUrl = getFullUrl(req);
		try {
			if (token != null) {
				String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "ChangeEsim", "POST",
						inboundProperties.getServer(), inboundProperties.getApplicationName());

				String user = "";
				if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
					user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
				}
				if (oauthResponse.contains("SUCCESS")) {
					request += "_DELIM" + source;
					request += "_DELIM" + reqUrl;
					request += "_DELIM" + user;
					LOGGER.info("request::" + request);
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();

					Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getChangeEsimExchange(),
							inboundQueueProperties.getChangeEsimQueue(), message);

					// Message result = inbound.ChangeEsimResponse(message);

					if (responseHeader(result)) {
						res.setStatus(HttpStatus.SC_BAD_REQUEST);
						responseString = new String(result.getBody());
					}
					responseString = new String(result.getBody());
					LOGGER.info("Response : " + responseString);
				} else {
					String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
					if (user.isEmpty()) {
						user = "User not available";
					}
					errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
					responseString = errorMsg;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
				responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} catch (NotAuthorizedException e) {
			String authErrorResponse = ((NotAuthorizedException) e).getResponse().getEntity().toString();
//				throw	new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(authErrorResponse).build());
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getSwRetrieveDeviceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String swRetrieveDeviceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("swRetrieveDeviceCall");
		String responseString = null;
		// boolean status=false;

		try {
			// status = transactionDAO.getStatusFromDB("Retrieve Device Details","POST");
			// if (status) {
			if (token != null) {
				/*
				 * String oauthResponse = authHandler.checkOAuthTokenServiceCall(token,
				 * "Retrieve Device Details", "POST", inboundProperties.getServer(),
				 * inboundProperties.getApplicationName()); String user = ""; if
				 * ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) { user =
				 * oauthResponse.substring(oauthResponse.indexOf("~") + 1,
				 * oauthResponse.length()); } if (oauthResponse.contains("SUCCESS")) {
				 * 
				 * request += "_DELIM" + source; Message message =
				 * MessageBuilder.withBody(request.getBytes())
				 * .setContentType(MediaType.APPLICATION_JSON_VALUE).build(); Message result =
				 * customRabbitTemplate.sendAndReceive(
				 * inboundQueueProperties.getSwRetrieveDeviceExchange(),
				 * inboundQueueProperties.getSwRetrieveDeviceQueue(), message); if
				 * (responseHeader(result)) { res.setStatus(HttpStatus.SC_BAD_REQUEST);
				 * responseString = new String(result.getBody()); } responseString = new
				 * String(result.getBody());
				 * 
				 * } else { String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE; if
				 * (user.isEmpty()) { user = "User not available"; } errorMsg =
				 * errorMsg.replace("\"userNameValue\"", "\"" + user + "\""); // throw new
				 * NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).
				 * build()); responseString = errorMsg;
				 * res.setStatus(HttpStatus.SC_UNAUTHORIZED); } LOGGER.info("Response :: " +
				 * responseString);
				 */

				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					request += "_DELIM" + source;
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getSwRetrieveDeviceExchange(),
							inboundQueueProperties.getSwRetrieveDeviceQueue(), message);
					if (responseHeader(result)) {
						res.setStatus(HttpStatus.SC_BAD_REQUEST);
						responseString = new String(result.getBody());
					}
					responseString = new String(result.getBody());
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			/*
			 * } else { LOGGER.info("Inside Token checck else:: "); responseString =
			 * Constants.INACTIVE; res.setStatus(HttpStatus.SC_UNAUTHORIZED); }
			 */
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getTransferWearableurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String transferWearableCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("transferWearableCall");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("Transfer Wearable", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				// if(true) {
				if (token != null) {
					// if(true) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "Transfer Wearable", "POST",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {
						// if(true) {
						request += "_DELIM" + source + "_DELIM" + user;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();

						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getTransferWearableExchange(),
								inboundQueueProperties.getTransferWearableQueue(), message);
						// Message result = inbound.transferWearableCallResponse(message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
		
	@RequestMapping(value = "#{inboundProperties.getTransferWearableAsyncurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String transferWearableAsync(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token, @RequestHeader(value = "User-Agent", required = false) String source,HttpServletResponse res) {
		LOGGER.info("transferWearableAsync"+request);
		String responseString = null;
		try {
			 if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) { 
						request += "_DELIM"+source;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						LOGGER.info("PortabilityasyncCall Message :: "+message);
						
						/*   Message result = customRabbitTemplate.sendAndReceive(
						  inboundQueueProperties.getTransferWearableAsyncQueue(),
						  inboundQueueProperties.getTransferWearableAsyncExchange(), message);	 */	 
								
						Message result = inboundConsumer.transferWearableAsync(message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());
				 	} else {
						responseString = utilityClass.invalidToken(token);
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				LOGGER.info("Invalid Token " + responseString);
			} 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	
	/*public void smartwatchValidation(String request) throws JSONException {
		JSONObject object1 = new JSONObject();
		JSONObject object2 = new JSONObject(request);
     
		String transactionName="";
		String mdn = "";
		String referenceNumber = "";
		if (object2.has("asyncResponse")) {
			object1 = object2.getJSONObject("asyncResponse");
			if (object1.has("mdn")) {
				mdn = object1.getString("mdn");
				System.out.println("newObj additionAttrArr::" + mdn);
			}
		}
		if (object2.has("messageHeader")) {
			object1 = object2.getJSONObject("messageHeader");
			if (object1.has("referenceNumber")) {
				referenceNumber = object1.getString("referenceNumber");
				System.out.println("newObj referenceNumber::" + referenceNumber);
			}
		}
		if (!referenceNumber.isEmpty() && referenceNumber != null) {
			
	        transactionName = transactionDAO.getTransactionNameFromCSR(referenceNumber);
			String accountNumber = "";
			String contextId = "";
			String accountType = "";
			String billCycleDay = "";
			String subOrderId = "";
			String lineId = "";
			String transaction_id ="";

			List<Map<String, Object>> result = transactionDAO.getAdditionalValues(referenceNumber);

			if (result != null && result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {
					accountNumber = (String) result.get(i).get("ACCOUNT_NUMBER");
					contextId = (String) result.get(i).get("contextId");
					accountType = (String) result.get(i).get("ACCOUNTTYPE");
					billCycleDay = (String) result.get(i).get("BILLCYCLEDAY");
					subOrderId = (String) result.get(i).get("SUBORDERID");
					lineId = (String) result.get(i).get("LINEID");
					BigDecimal trans_id=(BigDecimal) result.get(i).get("TRANSACTION_ID");
					transaction_id=trans_id.toString();
				}
			}
			 
			 
			if (!mdn.isEmpty() && mdn != null) {
				int count = transactionDAO.getHostMdnCount(mdn);
				ArrayList smartWatchmdn1 = (ArrayList) transactionDAO.getMdnValues(mdn);

				Random rand = new Random();
				if (count > 0) {
					for (int i = 0; i < smartWatchmdn1.size(); i++) {
						int n = rand.nextInt(999999999);
						int n2 = rand.nextInt(999999999);
						referenceNumber = String.valueOf(n) + String.valueOf(n2);
						String smartWatchmdn = smartWatchmdn1.get(i).toString();
						constructJson(smartWatchmdn, referenceNumber, accountNumber, contextId, accountType,
								billCycleDay, subOrderId, lineId, transactionName,transaction_id);
					}
				} else {
					LOGGER.info("NO HOSTMDN AVAILABLE");
				}
			}
		}
	}  */
	
	/*public void constructJson(String mdn, String referenceNumber, String accountNumber, String contextId,
			String accountType, String billCycleDay, String subOrderId, String lineId, String transactionName,String transaction_id) {
		StringBuilder parameterJson = new StringBuilder();
		String request = "";
		try {
		
		
			parameterJson.append("{\r\n");
			parameterJson.append(" \"messageHeader\": {\r\n");
			parameterJson.append(" \"serviceId\": \"SPECTRUM_MOBILE\",\r\n");
			parameterJson.append(" \"requestType\": \"MNO\",\r\n");
			parameterJson.append(" \"referenceNumber\": \"" + referenceNumber + "\",\r\n");
			parameterJson.append(
					" \"returnURL\": \"https://mobileapi-dev2.spectrummobile.com:4443/mbosasyncresponsecallback-sit/api/provisioning/v1/async-response\",\r\n");
			parameterJson.append(
					" \"asyncErrorURL\": \"https://mobileapi-dev2.spectrummobile.com:4443/mbosasyncresponsecallback-sit/api/provisioning/v1/async-response-error\"\r\n");
			parameterJson.append(" },\r\n");
			parameterJson.append(" \"data\": {\r\n");
			if (transactionName != null && !transactionName.isEmpty()) {
				if (transactionName.equalsIgnoreCase("Restore Service")) {
					parameterJson.append(" \"transactionType\": \"RS\",\r\n");
				} else if (transactionName.equalsIgnoreCase("Suspend Subscriber")) {
					parameterJson.append(" \"transactionType\": \"SS\",\r\n");
				} else if (transactionName.equalsIgnoreCase("Deactivate Subscriber")) {
					parameterJson.append(" \"transactionType\": \"SD\",\r\n");
				} else if (transactionName.equalsIgnoreCase("Reconnect Service")) {
					parameterJson.append(" \"transactionType\": \"RM\",\r\n");
				} else if (transactionName.equalsIgnoreCase("Hotline Subscriber")) {
					parameterJson.append(" \"transactionType\": \"SH\",\r\n");
				} else if (transactionName.equalsIgnoreCase("Remove Hotline")) {
					parameterJson.append(" \"transactionType\": \"RH\",\r\n");
				} else {
					parameterJson.append(" \"transactionType\": \"RH\",\r\n");
				}
			}
			parameterJson.append(" \"transactionTimeStamp\": \"2020-02-03T18:42:37Z\",\r\n");
			parameterJson.append(" \"account\": {\r\n");
			parameterJson.append(" \"accountNumber\": \"" + accountNumber + "\",\r\n");
			parameterJson.append(" \"contextId\": \"" + contextId + "\",\r\n");
			parameterJson.append(" \"type\": \"" + accountType + "\",\r\n");
			parameterJson.append(" \"pin\": \"56023\"\r\n" + " },\r\n");
			parameterJson.append(" \"subOrder\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"id\": \"" + subOrderId + "\",\r\n");
			parameterJson.append(" \"lineId\": \"" + lineId + "\",\r\n");
			parameterJson.append(" \"mdn\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"type\": \"mdn\",\r\n");
			parameterJson.append(" \"value\": \"" + mdn + "\"\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append(" ]\r\n");
			if (transactionName.equalsIgnoreCase("Restore Service")
					|| transactionName.equalsIgnoreCase("Remove Hotline")) {
				parameterJson.append(" ,\"resetBillCycleDay\": \"Y\",\r\n");
				parameterJson.append(" \"billCycleResetDay\": \"" + billCycleDay + "\"\r\n");
			} else if (transactionName.equalsIgnoreCase("Hotline Subscriber")) {
				parameterJson.append(",\"hotline\": {\r\n");
				parameterJson.append(" \"type\": \"CHARTERCOMMLLCROAMING\",\r\n");
				parameterJson.append(" \"phoneNumber\": \"1234567890\"\r\n");
				parameterJson.append(" }");
			} else if (transactionName.equalsIgnoreCase("Reconnect Service")) {
				parameterJson.append(",\"deviceId\": [\r\n");
				parameterJson.append(" {\r\n");
				parameterJson.append(" \"type\": \"IMEI\",\r\n");
				parameterJson.append(" \"value\": \"663456908\"\r\n");
				parameterJson.append(" }\r\n");
				parameterJson.append(" ],\r\n");
				parameterJson.append(" \"simId\": [\r\n");
				parameterJson.append(" {\r\n");
				parameterJson.append(" \"type\": \"oldICCID\",\r\n");
				parameterJson.append(" \"value\": \"9876543210897680\"\r\n");
				parameterJson.append(" }\r\n");
				parameterJson.append(" ]");
			}
			parameterJson.append(" }\r\n");
			parameterJson.append(" ]\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append("}");
			request = parameterJson.toString();
			request =request +"~"+transaction_id;
			LOGGER.info("Request end from construct json::" + request);
			smartWatchTransactionTypeValidation(request);
		} catch (Exception e) {
			LOGGER.info("Exception::" + e.getMessage());
		}
	} */
	
	/*public void smartWatchTransactionTypeValidation(String request) throws JSONException {
		JSONObject object1 = new JSONObject();
		JSONObject object2 = new JSONObject(request);
		String transactionType = "";
		String source = "NSL";

		if (object2.has("data")) {
			object1 = object2.getJSONObject("data");
			if (object1.has("transactionType")) {
				transactionType = object1.getString("transactionType");
				System.out.println("newObj transactionType::" + transactionType);
				if (transactionType.equalsIgnoreCase("RS") || transactionType.equalsIgnoreCase("RM")
						|| transactionType.equalsIgnoreCase("RH")) {
					restoreServiceRequestCallForSmartWatchValidation(request, source);
				} else if (transactionType.equalsIgnoreCase("SS") || transactionType.equalsIgnoreCase("SD")
						|| transactionType.equalsIgnoreCase("SH")) {
					nslSuspendDeactivateCallForSmartWatchValidation(request, source);
				}
			}
		}
	}*/
	
	/*public String restoreServiceRequestCallForSmartWatchValidation(String request,String source) {
		LOGGER.info("restoreServiceRequestCall");
		String responseString = "";
		try {
			request += "_DELIM"+source;
			Message message = MessageBuilder.withBody(request.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		
		  Message result = inbound.restoreHostMdnResponse(message);
			if (responseHeader(result)) {
				// res.setStatus(HttpStatus.SC_BAD_REQUEST);
				responseString = new String(result.getBody());
			}
			responseString = new String(result.getBody());
		} catch (Exception e) {
			LOGGER.error("Exception in restoreService " + e);
		}
		return responseString;
	}*/
	
	/*public String nslSuspendDeactivateCallForSmartWatchValidation(String request, String source) {
		LOGGER.info("Suspenddeactive");
		String responseString = "";
		try {
			request += "_DELIM" +source;
			Message message = MessageBuilder.withBody(request.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();					
			Message result = inbound.SuspendDeactiveMDN(message);
			if (responseHeader(result)) {
				// res.setStatus(HttpStatus.SC_BAD_REQUEST);
				responseString = new String(result.getBody());
			}
			responseString = new String(result.getBody());
			LOGGER.info("Response :: " + responseString);
		} catch (Exception e) {
			LOGGER.error("Exception in nslSuspendDeactivateCall " + e);
		}
		return responseString;
	}*/
	
	@SuppressWarnings("unchecked")
	public boolean responseHeader(Message msg) throws NslCustomException, NotAuthorizedException {
		try {
			byte[] body = msg.getBody();
			String req = new String(body);
			if (!req.isEmpty()) {
				String codeStr = "";
				String status = "";
				if (req.startsWith("{")) {

					JSONObject reqJson = new JSONObject(req);
					Iterator<String> reqJsonItr = reqJson.keys();
					while (reqJsonItr.hasNext()) {
						String reqKey = reqJsonItr.next();
						if (Constants.DATA.equalsIgnoreCase(reqKey)) {
							JSONObject dataJson = (JSONObject) reqJson.get(reqKey);
							Iterator<String> dataJsonItr = dataJson.keys();
							while (dataJsonItr.hasNext()) {
								String dataKey = dataJsonItr.next();
								if (Constants.CODE.equalsIgnoreCase(dataKey)) {
									codeStr = dataJson.getString(dataKey);
								} else if (Constants.STATUS.equalsIgnoreCase(dataKey)) {
									status = dataJson.getString(dataKey);
								}
							}
						}
					}
					if (StringUtils.hasText(codeStr)) {
						int code = Integer.parseInt(codeStr);
						if (code >= 400 && code <= 600) {
							return true;
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
		return false;
	}
	
	private String customJsonFormatter(String request) {
		String quotes = Character.toString((char) 34);
		String slash = Character.toString((char) 92);
		String slashQuotes = slash + quotes;
		String braceQuotes = Character.toString((char) 125) + Character.toString((char) 34);
		String quotesbrace = Character.toString((char) 34) + Character.toString((char) 123);
		String temp1 = request.replace(slashQuotes, quotes);
		String temp2 = temp1.replace(braceQuotes, Character.toString((char) 125));
		String requestJson = temp2.replace(quotesbrace, Character.toString((char) 123));
		return requestJson;
	}

	private String getFullUrl(HttpServletRequest req) {
		StringBuffer url = req.getRequestURL();
		String queryString = req.getQueryString();
		if (queryString != null) {
			url.append('?');
			url.append(queryString);
		}
		return url.toString();
	}
	
	
	
	
	
	
	
	
	@RequestMapping(value = "#{inboundProperties.getLoginauthwsurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String loginauthwsCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("getLoginauthwsurl");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("loginAuthService", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
		   if (status) {
				// if(true) {
			if (token != null) {
			//	if(true) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "loginAuthService", "POST",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					
					  if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) { user =
					  oauthResponse.substring(oauthResponse.indexOf("~") + 1,
					  oauthResponse.length()); }
					 
			if (oauthResponse.contains("SUCCESS")) {
			//	if(true) {
						//request += "_DELIM" + source + "_DELIM" + "ABC";
						request += "_DELIM" + source + "_DELIM" + user;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();

					 	Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getLoginauthwsExchange(),
								inboundQueueProperties.getLoginauthwsQueue(), message); 
		//	Message result = inbound.loginauthwsCallResponse(message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getSearchEnvironmenturl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String searchEnvironmentCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res) {
		LOGGER.info("searchEnvironmentCall");
		String responseString = null;
		boolean status = false;
		try {
			LOGGER.info("token:: " + token);
			status = transactionDAO.getStatusFromDB("Search Environment", "POST");
			LOGGER.info("responseId controller::::::::::" + status);
			if (status) {
				// if (true) {
				if (token != null) {
					// if(true) {
					String oauthResponse = authHandler.checkOAuthTokenServiceCall(token, "Search Environment", "POST",
							inboundProperties.getServer(), inboundProperties.getApplicationName());
					String user = "";
					if ((!oauthResponse.isEmpty()) && oauthResponse.contains("~")) {
						user = oauthResponse.substring(oauthResponse.indexOf("~") + 1, oauthResponse.length());
					}
					if (oauthResponse.contains("SUCCESS")) {
					//if (true) {
						request += "_DELIM" + source;
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getSearchEnvironmentExchange(),
								inboundQueueProperties.getSearchEnvironmentQueue(), message);
						//Message result = inbound.searchEnvironmentCallResponse(message);
						LOGGER.info("response from the result one:::"+result);
						if (responseHeader(result)) {
							LOGGER.info("inside if");
							responseString = new String(result.getBody());
							if(responseString.contains("500")) {
								res.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
							}else {
								res.setStatus(HttpStatus.SC_BAD_REQUEST);
							}
							LOGGER.info("inside if response from the result two:::"+responseString);
						}
						responseString = new String(result.getBody());
						LOGGER.info("response from the result three:::"+responseString);

					} else {
						String errorMsg = Constants.OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE;
						if (user.isEmpty()) {
							user = "User not available";
						}
						errorMsg = errorMsg.replace("\"userNameValue\"", "\"" + user + "\"");
//					throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(errorMsg).build());
						responseString = errorMsg;
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
//				throw new NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
					responseString = Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE;
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				LOGGER.info("Inside Token checck else:: ");
				responseString = Constants.INACTIVE;
				res.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
				// throw new
				// NotAuthorizedException(Response.status(Status.UNAUTHORIZED).entity(Constants.OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE).build());
			}
		} catch (Exception e) {
			
			LOGGER.error(e.getMessage(), e);
			responseString = Constants.SEARCH_ENV_ERROR_MESSAGE;
			res.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
		return responseString;
	}
	
	
	
}