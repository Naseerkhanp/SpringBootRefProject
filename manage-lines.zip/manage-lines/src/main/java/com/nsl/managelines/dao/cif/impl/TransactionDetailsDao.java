/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import java.util.List;
import java.util.Set;

import com.nsl.managelines.dao.cif.entity.TransactionDetails;

/**
 * @author Dhayanand.B
 *
 */
public interface TransactionDetailsDao {

	Set<TransactionDetails> findTransactionDetailsByErrorCode(String errorCode);

	Set<TransactionDetails> findTransactionDetailsByTransactionNameAndStatus(String status, List<String> transactionName);

	TransactionDetails findByTransactionId(Long transactionId);

	int findCountByExtTransactionIdAndTransactionTypeAndTransactionName(String extTransactionId, String transactionType,
			java.util.List<String> transactionName);

	void clearNotifiEntityStatus(Long transactionId, String notifiEntityStatus);
}
