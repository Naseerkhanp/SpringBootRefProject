package com.nsl.usagereport.transaction.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.RefFileUpload;

@Repository
public interface RefFileUploadRepository extends JpaRepository<RefFileUpload, Integer> {

	@Query("select d from REF_FILE_UPLOAD d where d.fileName = :fileName")
	List<RefFileUpload> findByFilterID(@Param("fileName") String fileName);

	@Query("select d from REF_FILE_UPLOAD d where d.fileName = :fileName order by d.columnIndex asc")
	List<RefFileUpload> findByColumns(@Param("fileName") String fileName);
	
	@Query("select d from REF_FILE_UPLOAD d where d.fileName = :fileName AND d.filterValue = :filterValue AND ROWNUM=1")
	RefFileUpload findByFilterValue(@Param("fileName") String fileName,@Param("filterValue") long filterValue);

}
