package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

@Entity(name = "ROUTER_INFO")
@Table(name = "ROUTER_INFO")
public class RouterInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ROUTER_INFO_ID")
	private Integer router_info_id;

	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;

	@Column(name = "MAC_ADDRESS")
	private String macAddress;

	@Column(name = "ROUTER_ID")
	private String routerId;

	@Column(name = "SIM_ID1")
	private String simId1;

	@Column(name = "SIM_ID2")
	private String simId2;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date created_date = new java.sql.Date(new java.util.Date().getTime());;

	@Column(name = "CREAATED_BY")
	private String created_by;
	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modified_date = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "MODIFIED_BY")
	private String modified_by;

	public Integer getRouter_info_id() {
		return router_info_id;
	}

	public void setRouter_info_id(Integer router_info_id) {
		this.router_info_id = router_info_id;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getRouterId() {
		return routerId;
	}

	public void setRouterId(String routerId) {
		this.routerId = routerId;
	}

	public String getSimId1() {
		return simId1;
	}

	public void setSimId1(String simId1) {
		this.simId1 = simId1;
	}

	public String getSimId2() {
		return simId2;
	}

	public void setSimId2(String simId2) {
		this.simId2 = simId2;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getModified_date() {
		return modified_date;
	}

	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
