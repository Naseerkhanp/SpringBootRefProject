package com.excelacom.servicegateway.service;

import java.util.Iterator;
import java.util.Map;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Calendar;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.StatusType;
import com.excelacom.servicegateway.bean.TransactionHistory;
import java.sql.Timestamp;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.bean.Account;
import com.excelacom.servicegateway.bean.Line;
import com.excelacom.servicegateway.bean.RequestBean;
import com.excelacom.servicegateway.bean.Sim;
import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.consumer.InboundSWMessageConsumer;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.exception.NslCustomException;
import com.excelacom.servicegateway.exception.NslStatusCode;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import java.util.Set;
import java.util.Map.Entry;

@Component
public class ExternalServiceClient {

	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	InboundSWMessageConsumer inboundSWMessageConsumer;

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	RequestBean requestBean;
	
	@Autowired
	private JdbcTemplate centuryCIFTemplate;
	
	@Autowired
	ResourceServiceClient resourceServiceClient;
	
	
//	@Autowired
//	private Sim sim; 
	
//	@Autowired
//	private Line line; 
	
	


	@Autowired
	private TransactionHistory transactionHistory; 
	
	Logger LOGGER = LoggerFactory.getLogger(ExternalServiceClient.class);

	/**
	 * Gets the response from client.
	 *
	 * @param requestJson the request json
	 * @param transId     the trans id
	 * @param responseId  the response id
	 * @return the response from client
	 */
	public String getResponseFromClient(String requestJson, String transId, String responseId, String serviceName,
			String operationName) {
		String request = null;
		String groupId = null;
		String Id = null;
		String entityId = "0";
		String processPlanId = "";
		String url = inboundProperties.getRouterserviceurl();
		String frameworkResponse = "";
		String referenceNumber=null;
		String referenceNumberReq = null;
		String referenceNumberRes = null;
		List<Map<String, Object>> result = null;
		String line_id="";
		String line_type="";
		String lineId="";
		String lineType="";
		String updateType = "";
		JSONObject newObj = new JSONObject();
		JSONArray suborderArr1 = new JSONArray();
		

		try {
			LOGGER.info("Inside getResponseFromClient >>>>>> "+serviceName+"operationName >>>>>"+operationName);

			if(!(serviceName.equalsIgnoreCase("MnoValidateService")||
					serviceName.equalsIgnoreCase("mnoAsyncProgrammingService") ||
					serviceName.equalsIgnoreCase("MNOActivateServicesAsync")||
					serviceName.equalsIgnoreCase("Change-BCD-Async")||
					serviceName.equalsIgnoreCase("HmnoAsyncService")||
					serviceName.equalsIgnoreCase("Reconnect-Subscriber")||
					serviceName.equalsIgnoreCase("Activate-Subscriber")||
					serviceName.equalsIgnoreCase("Manage-Subscriber") ||
					serviceName.equalsIgnoreCase("AddwearableAsyncTW")
					)){
				LOGGER.info("Inside Condition >>>>>> "+serviceName);
				
				transactionDAO.insertMNORequestDetails(requestJson, responseId);
				/*ExecutorService executor = Executors.newSingleThreadExecutor();
				executor.execute(new Runnable() {
					@Override
					public void run() {

						transactionDAO.insertMNORequestDetails(requestJson, responseId);
					}
				});*/
				}else {
				if (serviceName.equalsIgnoreCase("AddwearableAsyncTW")) {
					LOGGER.info("AddwearableAsyncTW serviceName..."+serviceName);
					JSONObject requestobj = new JSONObject();
					String formattedrequest = inboundSWMessageConsumer.jsonFormat(requestJson);
					JSONArray jsonArrayInner = new JSONArray(formattedrequest);
					requestobj = jsonArrayInner.getJSONObject(0);
					RequestBean bean = null;
					Gson gson = new Gson();
					bean = gson.fromJson(requestobj.toString(), RequestBean.class);
					requestJson=changeReferenceNumToTransId(requestJson,bean.getReferenceNumber());
					if (bean != null && bean.getErrorDescription() != null) {
						String asyncResponse = bean.getErrorDescription();
						String mdn = bean.getMdn();
						if (asyncResponse.equalsIgnoreCase("success")) {
							LOGGER.info("AddwearableAsyncTW insertMNODomainDetails..."+asyncResponse);
							resourceServiceClient.insertMNODomainDetails(bean);
						}else {
							String notificationStatus = Constants.FAILED;
							LOGGER.info("notificationStatus::: :::" + notificationStatus);
							LOGGER.info("transactionId::: rootId:::" + responseId);
							transactionHistory.setTransactionId(responseId);
							transactionHistory.setTransactionStatus(Constants.FAILED);
							transactionHistory.setNotificationStatus(notificationStatus);
							LOGGER.info("transactionHistory in SWinbound::" + transactionHistory);
							resourceServiceClient.updateTransactionHistoryForNSUrl(transactionHistory);
						}
					}
				}
			}
			if (serviceName.equalsIgnoreCase("mnoAsyncProgrammingService")) {
				requestJson = changeReferenceNumToTransId(requestJson, responseId);
			}			
			request = getRequestJson(requestJson, serviceName, operationName, transId, responseId);
			LOGGER.info(" request :: " + request + " URL :: " + url);
			frameworkResponse = utilityClass.callRestAPI(request, url);
			LOGGER.info(" frameworkResponse :: " + frameworkResponse);
			Id = frameworkResponse.substring(frameworkResponse.lastIndexOf("}~") + 2, frameworkResponse.length());
			LOGGER.info("frameworkResponse ID" +Id);
			groupId = Id.substring(Id.indexOf("~") + 1, Id.length());
			serviceName = groupId.substring(groupId.indexOf("~")+1,groupId.length());
			groupId = groupId.substring(0,groupId.indexOf("~"));
			processPlanId = Id.substring(0, Id.indexOf("~"));
			frameworkResponse = frameworkResponse.substring(0, frameworkResponse.lastIndexOf("}~")+1); 
			LOGGER.info(" serviceName :: " + serviceName);			
			
			// Insert Transaction History
						if(frameworkResponse != null) {
							LOGGER.info("Transaction History Insertion");
							if(serviceName != null) {
								//Transaction History Insertion
								if(!(serviceName.equalsIgnoreCase("MnoValidateService")||
										serviceName.equalsIgnoreCase("mnoAsyncProgrammingService") ||
										serviceName.equalsIgnoreCase("MNOActivateServicesAsync")||
										serviceName.equalsIgnoreCase("Change-BCD-Async")||
										serviceName.equalsIgnoreCase("HmnoAsyncService")||
										serviceName.equalsIgnoreCase("Reconnect-Subscriber")||
										serviceName.equalsIgnoreCase("Activate-Subscriber")||
										serviceName.equalsIgnoreCase("Manage-Subscriber") ||
										serviceName.equalsIgnoreCase("AddwearableAsyncTW") ||
										serviceName.equalsIgnoreCase("loginAuthService"))) {
									LOGGER.info("requestJson::::::" + requestJson);
									JSONObject requestobj = new JSONObject();
									String value = "success";
									String formattedrequest =inboundSWMessageConsumer.jsonFormat(requestJson);
									JSONArray jsonArrayInner = new JSONArray(formattedrequest);
									requestobj = jsonArrayInner.getJSONObject(0);
									RequestBean bean = null;
									Gson gson = new Gson();
									bean = gson.fromJson(requestobj.toString(), RequestBean.class);
									bean.setErrorDescription(value);
									if (bean != null && bean.getErrorDescription() != null) {
									
											String inboundResponse = bean.getErrorDescription();
												LOGGER.info("inboundResponse:::" +inboundResponse);
												LOGGER.info("requestJson for Transaction History insertion::" +requestJson);
												if (inboundResponse.equalsIgnoreCase("success")) {
													LOGGER.info("responseId::" +responseId);
													resourceServiceClient.insertTransactionHistory(responseId, serviceName,requestJson);	
										}
									}
							}
						}
						
					}
			
			
			if(serviceName.equalsIgnoreCase("Retrieve-Device-Details")){
				LOGGER.info("frameworkResponse Retrieve-Device-Details:::: "+frameworkResponse);
				if (frameworkResponse.contains("\"responseCode\":\"ERR07\"")) {
					LOGGER.info("frameworkResponse in add and chnage "+frameworkResponse);
					frameworkResponse=frameworkResponse.replace("\"responseCode\":\"ERR07\"","\"responseCode\":\"ERWS006\"");
					
				}
			}
			
			if (serviceName.equalsIgnoreCase("Transfer-Wearable")) {
				if (frameworkResponse.contains("\"8A\"")) {
					frameworkResponse = frameworkResponse.replace("\"8A\"", "\"ERR01\"");
					
				}
			}
		/*	if((serviceName.equalsIgnoreCase("Add-Wearable") || serviceName.equalsIgnoreCase("Transfer-Wearable"))){
				LOGGER.info("frameworkResponse in add and chnage first IF "+frameworkResponse);
				if (frameworkResponse.contains("\"responseCode\":\"ERR07\"")) {
					LOGGER.info("frameworkResponse in add and chnage "+frameworkResponse);
					frameworkResponse=frameworkResponse.replace("\"responseCode\":\"ERR07\"","\"responseCode\":\"ERAW001\"");
					
				}*/
			 if (serviceName.equals("Get-Wifi-Address")
					&& operationName.equals("swqueryaddressserviceworkflow")) {
				JSONObject object3 = new JSONObject(frameworkResponse);
				String requestTypeValue = "MNO";
				Gson gson = new Gson();
				JSONObject object4 = new JSONObject();
				JSONObject object1 = new JSONObject();
				String mdn = Constants.EMPTYSTRING;
				JSONArray mdnArr = new JSONArray();
				String mdnValue = Constants.EMPTYSTRING;
				LOGGER.info("object3::" + object3);
				if (object3.has("data")) {
					object4 = object3.getJSONObject("data");
					if (object4.has("transactionId")) {
						String resTransId = object4.getString("transactionId");
						if (frameworkResponse.contains("\"transactionId\":\"" + resTransId + "\"")) {
							frameworkResponse = frameworkResponse.replace("\"transactionId\":\"" + resTransId + "\"",
									"\"transactionId\":\"" + responseId + "\"");
						}
						LOGGER.info("response::" + frameworkResponse);
					}
					if (object4.has("mdn")) {
						mdnArr = object4.getJSONArray("mdn");
						object4 = mdnArr.getJSONObject(0);
						if (object4.has("value")) {
							mdnValue = object4.getString("value");
							if (mdnValue == null || mdnValue.equalsIgnoreCase("") || mdnValue.isEmpty()) {
								String addMDNValue = "\"value\":\"" + mdn + "\"";
								if (frameworkResponse.contains("\"value\":\"\"")) {
									frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addMDNValue);
								}
							}
						}
						LOGGER.info("response::" + frameworkResponse);
					}
				}
				String addRequestType = "\"requestType\":\"" + requestTypeValue + "\"";
				if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
					frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"", addRequestType);
				}
				if (frameworkResponse.contains("\"responseCode\":\"NOTFOUND\"")) {
					frameworkResponse = frameworkResponse.replace("\"code\":\"200\"", "\"code\":\"404\"");
					frameworkResponse = frameworkResponse.replace("\"reason\":\"OK\"",
							"\"reason\":\"No record found\"");
				}
			} else if (serviceName.equals("Update-Wifi-Address")) {
				JSONObject object2 = new JSONObject(frameworkResponse);
				LOGGER.info("Update-Wifi object2 "+object2);
				JSONObject object1 = new JSONObject();
				String additionaAttrType = Constants.EMPTYSTRING;
				String additionaAttrValue = Constants.EMPTYSTRING;
				String requestTypeValue = Constants.EMPTYSTRING;
				String mdn = Constants.EMPTYSTRING;
				JSONObject object5 = new JSONObject();
				JSONArray additionAttrArr = new JSONArray();
				JSONArray suborderArr = new JSONArray();
				JSONArray mdnArr = new JSONArray();
				JSONObject object4 = new JSONObject();
				String mdnValue = Constants.EMPTYSTRING;
				if (object2.has("messageHeader")) {
					object1 = object2.getJSONObject("messageHeader");
					if (object1.has("requestType")) {
						requestTypeValue = object1.getString("requestType");
					}
				}
				if (object2.has("data")) {
					object1 = object2.getJSONObject("data");
					if (object1.has("subOrder")) {
						suborderArr = object1.getJSONArray("subOrder");
						object2 = suborderArr.getJSONObject(0);
						
					}
					if (object1.has("additionalData")) {
						additionAttrArr = object1.getJSONArray("additionalData");
						object2 = additionAttrArr.getJSONObject(0);
						LOGGER.info("newObj additionAttrArr::" + object2);
						if (object2.has("name")) {
							additionaAttrType = object2.getString("name");
						}
						if (object2.has("value")) {
							additionaAttrValue = object2.getString("value");
						}
					}
					if (object2.has("mdn")) {
						mdnArr = object2.getJSONArray("mdn");
						object5 = mdnArr.getJSONObject(0);
						if (object5.has("value")) {
							mdn = object5.getString("value");
							LOGGER.info("mdn from request::" + mdn);
						}
					}
				}
				String addType = "\"name\":\"" + additionaAttrType + "\"";
				if (frameworkResponse.contains("\"name\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"name\":\"\"", addType);
				}
				String addValue = "\"value\":\"" + additionaAttrValue + "\"";
				if (frameworkResponse.contains("\"value\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addValue);
				}
				String addRequestType = "\"requestType\":\"" + requestTypeValue + "\"";
				/*
				 * if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
				 * frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"",
				 * addRequestType); }
				 */
				
				
				
				if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
					//frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"", addRequestType);
					frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"", "\"requestType\":\"MNO\"");
				}
				
				  if (!frameworkResponse.contains("\"responseCode\":\"SUCCESS\"") && !frameworkResponse.contains("\"responseCode\":\"WARNING\"")) {
				  frameworkResponse = frameworkResponse.replace("\"code\":\"200\"",
				  "\"code\":\"400\""); 
				  frameworkResponse = frameworkResponse.replace("\"reason\":\"OK\"", "\"reason\":\"Bad Request\"");
				  }
				 
				JSONObject object3 = new JSONObject(frameworkResponse);
				LOGGER.info("object3 SWUpdateWifiAddressCall::" + object3);
				if (object3.has("data")) {
					object4 = object3.getJSONObject("data");
					if (object4.has("transactionId")) {
						String resTransId = object4.getString("transactionId");
						if (frameworkResponse.contains("\"transactionId\":\"" + resTransId + "\"")) {
							frameworkResponse = frameworkResponse.replace("\"transactionId\":\"" + resTransId + "\"",
									"\"transactionId\":\"" + responseId + "\"");
						}
						LOGGER.info("response SWUpdateWifiAddressCall::" + frameworkResponse);
					}
					if (object4.has("mdn")) {
						mdnArr = object4.getJSONArray("mdn");
						object4 = mdnArr.getJSONObject(0);
						if (object4.has("value")) {
							mdnValue = object4.getString("value");
							if (mdnValue == null || mdnValue.equalsIgnoreCase("") || mdnValue.isEmpty()) {
								String addMDNValue = "\"value\":\"" + mdn + "\"";
								if (frameworkResponse.contains("\"value\":\"\"")) {
									frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addMDNValue);
								}
							}
						}
						LOGGER.info("response::" + frameworkResponse);
					}
				}

			} else if (serviceName.equals("Validate-Wifi-Address")) {
				JSONObject object2 = new JSONObject(frameworkResponse);
				LOGGER.info("Validate object2>>>>>>"+object2);
				JSONObject object1 = new JSONObject();
				JSONObject object4 = new JSONObject();
			    JSONArray additionAttrArr = new JSONArray();
				String additionaAttrType = "";
				String additionaAttrValue = "";
				String requestTypeValue = "";
				if (object2.has("messageHeader")) {
					object1 = object2.getJSONObject("messageHeader");
					if (object1.has("requestType")) {
						requestTypeValue = object1.getString("requestType");
					}
				}
				if (object2.has("data")) {
					object1 = object2.getJSONObject("data");
					
					
	                      if (object1.has("additionalData")) {
						additionAttrArr = object1.getJSONArray("additionalData");
						object2 = additionAttrArr.getJSONObject(0);
						LOGGER.info("newObj additionAttrArr::" + object2);
						if (object2.has("name")) {
							additionaAttrType = object2.getString("name");
						}
						if (object2.has("value")) {
							additionaAttrValue = object2.getString("value");
						}
					}
				}
				String addType = "\"name\":\"" + additionaAttrType + "\"";
				if (frameworkResponse.contains("\"name\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"name\":\"\"", addType);
				}
				String addValue = "\"value\":\"" + additionaAttrValue + "\"";
				if (frameworkResponse.contains("\"value\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addValue);
				}
				String addRequestType = "\"requestType\":\"" + requestTypeValue + "\"";
				/*
				 * if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
				 * frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"",
				 * addRequestType); //frameworkResponse =
				 * frameworkResponse.replace("\"requestType\":\"MNO\"", addRequestType); }
				 */
				if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
					//frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"", addRequestType);
					frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"", "\"requestType\":\"MNO\"");
				}
				
				
				if (!frameworkResponse.contains("\"responseCode\":\"VALID\"")) {
					frameworkResponse = frameworkResponse.replace("\"code\":\"200\"", "\"code\":\"400\"");
					frameworkResponse = frameworkResponse.replace("\"reason\":\"OK\"", "\"reason\":\"Bad Request\"");
				}
				
				
				  if (frameworkResponse.contains("\"responseCode\":\"INVALID\"")) {
				  frameworkResponse = frameworkResponse.replace("\"code\":\"400\"",
				  "\"code\":\"200\""); frameworkResponse =
				  frameworkResponse.replace("\"reason\":\"Bad Request\"", "\"reason\":\"OK\"");
				  System.out.println("Validate wifi IF condition>>>>>>"+frameworkResponse); }
				 
				 
				JSONObject object3 = new JSONObject(frameworkResponse);
				LOGGER.info("object3::" + object3);
				if (object3.has("data")) {
					object4 = object3.getJSONObject("data");
					if (object4.has("transactionId")) {
						String resTransId = object4.getString("transactionId");
						if (frameworkResponse.contains("\"transactionId\":\"" + resTransId + "\"")) {
							frameworkResponse = frameworkResponse.replace("\"transactionId\":\"" + resTransId + "\"",
									"\"transactionId\":\"" + responseId + "\"");
						}
						LOGGER.info("response::" + frameworkResponse);
					}
				}
			}else if (serviceName.equals("Add-Wearable")) {
				LOGGER.info("frameworkResponse::::"+frameworkResponse);
				JSONObject object4 = new JSONObject();
				JSONArray additionAttrArr = new JSONArray();
				String additionaAttrType = "";
				String additionaAttrValue = "";
				String requestTypeValue = "";
				String addType = "\"name\":\"" + additionaAttrType + "\"";
				if (frameworkResponse.contains("\"name\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"name\":\"\"", addType);
				}
				String addValue = "\"value\":\"" + additionaAttrValue + "\"";
				if (frameworkResponse.contains("\"value\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addValue);
				} 
				String addRequestType = "\"requestType\":\"" + requestTypeValue + "\"";
				if (frameworkResponse.contains("\"requestType\":\"\"")) {
					LOGGER.info("inside RequestType empty::::");
					frameworkResponse = frameworkResponse.replace("\"requestType\":\"\"", "\"requestType\":\"MNO\"");

					LOGGER.info("inside request type:::");
				}
				if (frameworkResponse.contains("\"requestType\":\"SM-VZW\"")) {
					LOGGER.info("inside RequestType SM-VZW::::");
					frameworkResponse = frameworkResponse.replace("\"requestType\":\"SM-VZW\"","\"requestType\":\"MNO\"" );

				}


				if(!frameworkResponse.contains("\"responseCode\":\"SUC00\"")) {
					frameworkResponse=frameworkResponse.replace("\"code\":\"200\"","\"code\":\"400\"");
					frameworkResponse=frameworkResponse.replace("\"reason\":\"OK\"","\"reason\":\"Bad Request\"");
				}
				JSONObject object3 = new JSONObject(frameworkResponse);
				LOGGER.info("object3::" + object3);
				if (object3.has("data")) {
					object4 = object3.getJSONObject("data");
					if (object4.has("transactionId")) {
						String resTransId=object4.getString("transactionId");
						if (frameworkResponse.contains("\"transactionId\":\""+resTransId+"\"")) {
							frameworkResponse = frameworkResponse.replace("\"transactionId\":\""+resTransId+"\"", "\"transactionId\":\""+responseId+"\"");
						}
						LOGGER.info("response::" + frameworkResponse);
					}
				}
			}else if (serviceName.equals("Retrieve-Device-Details")) {
				LOGGER.info("frameworkResponse Retrieve-Device-Details::::"+frameworkResponse);
				JSONArray additionAttrArr = new JSONArray();
				JSONArray messageArr = new JSONArray();
				JSONObject messageObject = new JSONObject();
				String additionaAttrType = "";
				String additionaAttrValue = "";
				String responseCode = "";
				JSONObject object3 = new JSONObject(frameworkResponse);
				String addType = "\"name\":\"" + additionaAttrType + "\"";
				if (frameworkResponse.contains("\"name\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"name\":\"\"", addType);
				}
				String addValue = "\"value\":\"" + additionaAttrValue + "\"";
				if (frameworkResponse.contains("\"value\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addValue);
				}
				if(object3.has("data")) {
					object3=object3.getJSONObject("data");
					if(object3.has("message")) {
						messageArr=object3.getJSONArray("message");
						messageObject=messageArr.getJSONObject(0);
						if(messageObject.has("responseCode")) {
							responseCode=messageObject.getString("responseCode");
							LOGGER.info("responseCode Retrieve-Device-Details::::"+responseCode);
						}
					}
				}				
				if(!responseCode.startsWith("E")) {
					frameworkResponse=transactionDAO.constructFinalResponse(responseId);
				}			
			}
			else if (serviceName.equals("loginAuthService")) {
				LOGGER.info("frameworkResponse loginAuthService::::"+frameworkResponse);
				JSONArray additionAttrArr = new JSONArray();
				JSONArray messageArr = new JSONArray();
				JSONObject messageObject = new JSONObject();
				JSONObject reqObject = new JSONObject(requestJson);
				String additionaAttrType = "";
				String additionaAttrValue = "";
				String responseCode = "";
				String serviceId="";
				String requestType="";
				String description="";
				String reason="OK";
				String code="200";
				String simType = "";
				String simValue = "";
				Line line = null;
				JSONObject simIdObj = new JSONObject();
				JSONArray simIdArr = new JSONArray();
				JSONObject object3 = new JSONObject(frameworkResponse);
				JSONObject object1 = new JSONObject();
				JSONObject object2 = new JSONObject();
				JSONObject object4 = new JSONObject();
				Sim sim=new Sim();
				String outputString=null;
			   String accountId=null;
				 String accountNumber=null;
				 String elined=null;
				 List<String> simDetailsList = new ArrayList<String>();
				 List<String> lineDetailsList = new ArrayList<String>();
				List<Map<String, Object>> lineDetailsMap = null;
				String addType = "\"name\":\"" + additionaAttrType + "\"";
				if (frameworkResponse.contains("\"name\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"name\":\"\"", addType);
				}
				String addValue = "\"value\":\"" + additionaAttrValue + "\"";
				if (frameworkResponse.contains("\"value\":\"\"")) {
					frameworkResponse = frameworkResponse.replace("\"value\":\"\"", addValue);
				}
				
				if (reqObject.has("messageHeader")) {
					object1 = reqObject.getJSONObject("messageHeader");
					if (object1.has("serviceId")) {
						serviceId = object1.getString("serviceId");
					}
					if (object1.has("requestType")) {
						requestType = object1.getString("requestType");
					}
					if (object1.has("referenceNumber")) {
						referenceNumber = object1.getString("referenceNumber");
					}
					
					if (object1.has("additionalData")) {
						additionAttrArr = object1.getJSONArray("additionalData");
						object2 = additionAttrArr.getJSONObject(0);
						LOGGER.info("newObj additionAttrArr::" + object2);
						if (object2.has("name")) {
							additionaAttrType = object2.getString("name");
						}
						if (object2.has("value")) {
							additionaAttrValue = object2.getString("value");
						}
					}
					
					
					
				}
					if(object3.has("data")) {
					object3=object3.getJSONObject("data");
					
					reason=	object3.getString("reason");
					code=object3.getString("code");
					
					if(object3.has("message")) {
						messageArr=object3.getJSONArray("message");
						messageObject=messageArr.getJSONObject(0);
						description=messageObject.getString("description");
						LOGGER.info("description loginAuthService::::"+description);
					     String substr = description.substring(8);  
					        LOGGER.info(substr);  
					        String[] split = substr.split("#");
					        responseCode=split[0];
					        description=split[1];
						
					if (frameworkResponse.contains("\"ERR07\"")) {
							frameworkResponse = frameworkResponse.replace("\"ERR07\"", "\""+responseCode+"\"");
							
						}
						if (frameworkResponse.contains("\"description\":\"Invalid ERLW_INVALID_CREDS#Invalid Credentials\"")) {
					frameworkResponse = frameworkResponse.replace("\"description\":\"Invalid ERLW_INVALID_CREDS#Invalid Credentials\"","\"description\":\""+description+"\"");
							
						}
						
						if (frameworkResponse.contains("\"description\":\"Invalid ERLW_IP_LOCKED#Max Login Attempt Exceeded\"")) {
							frameworkResponse = frameworkResponse.replace("\"description\":\"Invalid ERLW_IP_LOCKED#Max Login Attempt Exceeded\"","\"description\":\""+description+"\"");
									
						}
						
						if (frameworkResponse.contains("\"description\":\"Invalid ERLW_FAIL#Login Failed\"")) {
							frameworkResponse = frameworkResponse.replace("\"description\":\"Invalid ERLW_FAIL#Login Failed\"","\"description\":\""+description+"\"");
									
						}
						
						if (frameworkResponse.contains("\"description\":\"Invalid ERLW_+status#Login Failed\"")) {
							frameworkResponse = frameworkResponse.replace("\"description\":\"Invalid ERLW_+status#Login Failed\"","\"description\":\""+description+"\"");
									
						}
					}
					
				} 
					
				
					accountId=object3.getString("accountId");
					LOGGER.info("accountId>>>>>>"+accountId);
				
					if (reqObject.has("data")) {
						object3=reqObject.getJSONObject("data");
						LOGGER.info("inside object3" + object3.toString());
						simIdArr = object3.getJSONArray("simId");
						LOGGER.info("inside jsonarr1" + simIdArr.toString());
						simIdObj = simIdArr.getJSONObject(0);
						simType = simIdObj.getString("type");
						simValue = simIdObj.getString("value");
						LOGGER.info("simValue>>>"+simValue);
						sim.setIccid(simValue);
						/*String resourceResultforSimDetails = resourceServiceClient.getsimdetailsListbyiccid(simValue);
						if (resourceResultforSimDetails != null) {
							if (!resourceResultforSimDetails.equals("null")) {
								JSONArray result1 = new JSONArray(resourceResultforSimDetails);
								if (result1 != null && result1.length() > 0) {
									for (int i = 0; i < result1.length(); i++) {
											if (result1.getJSONObject(i).has("eLineId")) {
												simDetailsList.add(result1.getJSONObject(i).getString("eLineId"));
											}
										
									}
								}
							}
						}
						// sim=resourceServiceClient.getsimdetailsbyiccid(sim);
							 simValue=sim.getIccid();
							 elined =sim.geteLineId();*/
						lineDetailsMap=transactionDAO.getAccountNumberUsingIccid(simValue);
						if (lineDetailsMap != null && lineDetailsMap.size() > 0) {
							for (int j = 0; j < lineDetailsMap.size(); j++) {
								String Account_Number = (String) lineDetailsMap.get(j).get("ACCOUNT_NUMBER");
								lineDetailsList.add(Account_Number);
							}
						}
							   
						/*	  String resourceResultforLineDetails = resourceServiceClient.getLinedetailListbyLineIdList(simDetailsList);
						if (resourceResultforSimDetails != null) {
							if (!resourceResultforLineDetails.equals("null")) {
								JSONArray result = new JSONArray(resourceResultforLineDetails);
								if (result != null && result.length() > 0) {
									for (int i = 0; i < result.length(); i++) {
										for (int t = 0; t < retailArr.length; t++) {
											if (result.getJSONObject(i).getString("accountNumber")) {
												LOGGER.info("accountNumber>>>>>>"+accountNumber);
												lineDetailsList.add(result.getJSONObject(i).getString("accountNumber"));
												LOGGER.info("lineDetailsList>>>>>>"+lineDetailsList);
											}
										}
									}
								}
							}
						}*/
							 /* LOGGER.info("elined>>>>>>"+elined);
							  Line lineLogin = new Line();
							  lineLogin.seteLineId(elined);
							  line = resourceServiceClient.getLineAccountNumber(lineLogin);
							  accountNumber = line.getAccountNumber();
							  LOGGER.info("accountNumber>>>>>>" + accountNumber);
							*/  
							   
					}
					LOGGER.info("lineDetailsList>>>"+lineDetailsList);
			if(lineDetailsList!=null){
				if(lineDetailsList.contains(accountId)) {
					LOGGER.info("lineDetailsList>>>"+true);
				responseCode= "SUCCLW01";
				description= "Authentication and Validation success";
				}else {
				responseCode= "ERLW_VFAIL";
				description= "Validation Failed";
              }
			}else {
				
				responseCode= "ERLW_VFAIL";
				description= "Validation Failed";
              }
			
				
			
					frameworkResponse="{\r\n" + 
				"  \"messageHeader\": {\r\n" + 
				"    \"serviceId\": \""+serviceId+"\",\r\n" + 
				"    \"requestType\": \""+requestType+"\",\r\n" + 
				"    \"referenceNumber\": \""+referenceNumber+"\"\r\n" + 
				"  },\r\n" + 
				"  \"data\": {\r\n" + 
				"    \"transactionId\": \""+responseId+"\",\r\n" + 
				"    \"code\": \""+code+"\",\r\n" + 
				"    \"reason\": \""+reason+"\",\r\n" + 
				"    \"message\": [\r\n" + 
				"      {\r\n" + 
				"        \"responseCode\": \""+responseCode+"\",\r\n" + 
				"        \"description\": \""+description+"\"\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }\r\n" + 
				"}";
				
				
					if(frameworkResponse.contains("\"responseCode\": \"ERLW_VFAIL\"")) {
						frameworkResponse=frameworkResponse.replace("\"code\": \"200\"","\"code\":\"400\"");
						frameworkResponse=frameworkResponse.replace("\"reason\": \"OK\"","\"reason\":\"Bad Request\"");
					}
						
			}
			
			LOGGER.info("serviceName ::: "+ serviceName + " frameworkResponse:: "+ frameworkResponse + " transId:: "+ transId);
			//Update Sync Call Transaction History
			if(serviceName.equalsIgnoreCase("Retrieve-Device-Details") || serviceName.equals("Update-Wifi-Address")) {
				if(frameworkResponse != null) {
					LOGGER.info("Inside Update Sync Call Transaction History");
					LOGGER.info("responseID for update TH :::" +responseId);
					 transactionHistory.setTransactionId(responseId);
					 transactionHistory = resourceServiceClient.getTransactionHistoryDetails(transactionHistory);
					 LOGGER.info("transactionHistory inside update SYnc cal :::" +transactionHistory);
					transactionHistory.setTransactionEndDate(getTimeStamp());
					transactionHistory.setModifiedDate(getTimeStamp());
					 transactionHistory.setModifiedBy(Constants.MODITY_BY);
					 
					if (frameworkResponse.startsWith("{")) {
						JSONObject responseObj = new JSONObject(frameworkResponse);
						LOGGER.info("responseObj :::" +responseObj);
						if (responseObj.toString().contains("success")||responseObj.toString().contains("Success")||responseObj.toString().contains("SUCCESS") || responseObj.toString().contains("\"code\":\"200\"")) 
						{
							transactionHistory.setTransactionStatus(Constants.COMPLETED);
							transactionHistory.setNotificationStatus(Constants.SUCCESS);
							 LOGGER.info("transactionHistory in externalServiceClient::" + transactionHistory);
							 resourceServiceClient.updateTransactionHistory(transactionHistory);
						} else {
							transactionHistory.setTransactionStatus(Constants.FAILED);
							 transactionHistory.setNotificationStatus(Constants.FAILED);
							 LOGGER.info("transactionHistory in externalServiceClient::" + transactionHistory);
							 resourceServiceClient.updateTransactionHistoryForNSUrl(transactionHistory);
						 }
					}
					
				} else {

					LOGGER.info("responseID for update TH :::" +responseId);
					 transactionHistory.setTransactionId(responseId);
					 transactionHistory.setNotificationStatus(Constants.FAILED);
					 transactionHistory.setTransactionStatus(Constants.FAILED);
					 LOGGER.info("transactionHistory in externalServiceClient::" + transactionHistory);
					 resourceServiceClient.updateTransactionHistoryForNSUrl(transactionHistory);
				
				}
			}	
			
			if(serviceName.equalsIgnoreCase("AddwearableAsyncTW")) {

				LOGGER.info("frameworkResponse :::" +frameworkResponse);
				if(frameworkResponse != null) {
					LOGGER.info("Inside Update Sync Call Transaction History");
					LOGGER.info("responseID for update TH :::" +responseId);
					if (frameworkResponse.startsWith("{")) {
						JSONObject responseObj = new JSONObject(frameworkResponse);
						LOGGER.info("responseObj :::" +responseObj);
						if (!(responseObj.toString().contains("success")||responseObj.toString().contains("Success")||responseObj.toString().contains("SUCCESS") || responseObj.toString().contains("\"code\":\"200\"") || responseObj.toString().contains("Certified"))) 
						{
						 transactionHistory.setTransactionId(responseId);
						 transactionHistory.setNotificationStatus(Constants.FAILED);
						 transactionHistory.setTransactionStatus(Constants.FAILED);
						 LOGGER.info("transactionHistory inside update ASYnc cal :::" +transactionHistory);
						 resourceServiceClient.updateTransactionHistoryForNSUrl(transactionHistory);
						}
					}
				} else {
					LOGGER.info("responseID for update TH :::" +responseId);
					 transactionHistory.setTransactionId(responseId);
					 transactionHistory.setNotificationStatus(Constants.FAILED);
					 transactionHistory.setTransactionStatus(Constants.FAILED);
					 LOGGER.info("transactionHistory in externalServiceClient::" + transactionHistory);
					 resourceServiceClient.updateTransactionHistoryForNSUrl(transactionHistory);
				}
			
			}
			
			if(serviceName.equalsIgnoreCase("Search-Environment")) {
				if (frameworkResponse!=null && frameworkResponse.contains("\"responseCode\":\"8A\"")) {
					String requestType = "\"responseCode\":\"ERR06\"";
					frameworkResponse = frameworkResponse.replace("\"responseCode\":\"8A\"", requestType);
				}
			}
			
			
			LOGGER.info("serviceName ::: "+ serviceName + " frameworkResponse:: "+ frameworkResponse + " transId:: "+ transId);
				asyncUpdateNorthBoundTransaction(transId, entityId, frameworkResponse, groupId, processPlanId, serviceName);
			
			
		}catch (Exception e) {
			transactionDAO.updateNorthBoundTransactionFailure(transId, entityId, groupId, processPlanId, serviceName,frameworkResponse);
			LOGGER.error(e.getMessage(), e);
		}
		return frameworkResponse;
	}

	public String responseFromClient(String response, String transId, String responseId, String serviceName,
			String operationName,String frameworkResponse) {
		String groupId = "";
		String entityId = "0";
		String processPlanId = "";
		try {
			// String Id = response.substring(response.indexOf("~") + 1, response.length());
			serviceName = "MnoDeactivateService";
			transactionDAO.updateNorthBoundTransaction(transId, entityId, response, groupId, processPlanId,
					serviceName);
			LOGGER.info("response::: " + response);
		} catch (Exception e) {
			transactionDAO.updateNorthBoundTransactionFailure(transId, entityId, groupId, processPlanId, serviceName, frameworkResponse);
			LOGGER.error("Exception in mnodeactivateserviceCall" + e.getMessage());
		}
		return response;
	}

	public String getRequestJson(String requestJson, String serviceName, String operationName, String transId,
			String responseId) {
		String request = "";
		if (serviceName.equalsIgnoreCase("Activate-Subscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=validateDevice4Activation";
		} else if (serviceName.equalsIgnoreCase("Reconnect-Subscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId ;
		} else if (serviceName.equalsIgnoreCase("GetDevicesStatus")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId ;
		}else if (serviceName.equalsIgnoreCase("Manage-Subscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=manageSubscriber" ;
		} else if (serviceName.equalsIgnoreCase("gdConfOrder")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=Available";
		} else if (serviceName.equalsIgnoreCase("HmnoAsyncService")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=genericAsyncMetdaData";
		} else if (serviceName.equalsIgnoreCase("Change-Feature")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("MnoValidateService")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=genericAsyncMetdaData";
		} else if (serviceName.equalsIgnoreCase("AddwearableAsyncTW")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=genericAsyncMetdaData";
		} 
		
		else if (serviceName.equalsIgnoreCase("MNOActivateServicesAsync")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=genericAsyncMetdaData";
		} else if (serviceName.equalsIgnoreCase("Change-Rate-Plan")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		}else if (serviceName.equalsIgnoreCase("ManageAccountSubscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=manageAccountRule";
		} 
		else if (serviceName.equalsIgnoreCase("Change-SIM")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=changeSimServiceMetaData";
		} else if (serviceName.equalsIgnoreCase("SIM-Inquiry")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=Available";
		} else if (serviceName.equalsIgnoreCase("Line-History")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=getlineHistoryMetaData";
		}else if (serviceName.equalsIgnoreCase("Search-Environment")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=getSearchEnvironmentMetaData";
		}else if (serviceName.equalsIgnoreCase("SubscriberGroup-Inquiry")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=getSubscriberGroupInquiryMetaData";
		}else if (serviceName.equalsIgnoreCase("Search-Environment")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=getSearchEnvironmentMetaData";
		} else if (serviceName.equalsIgnoreCase("Portin-Inquiry")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId;
		} else if (serviceName.equalsIgnoreCase("Promotion-Inquiry")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=Available";
		} else if (serviceName.equalsIgnoreCase("mnopromotionservice")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("Reset-Feature")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("Change-BCD")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("Validate-SIM")) {
			if(operationName.equals("ValidateSimWorkflow"))
			{
				request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=Available";
			}
			else{
				request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
			}

		} else if (serviceName.equalsIgnoreCase("Update-Port-In")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=updatePortInMetaData";
		} else if (serviceName.equalsIgnoreCase("Update-Port-Out")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("Validate-Device")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=validateDeviceDetailsCheck";
		} else if (serviceName.equalsIgnoreCase("Validate-Device-Byod")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=validateDeviceDetailsCheck";
		} else if ((serviceName.equalsIgnoreCase("Validate-MDN-Portability")) || (serviceName.equalsIgnoreCase("Manage-Promotion"))) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		} else if (serviceName.equalsIgnoreCase("DeviceInquiry")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=Available";
		} else if (serviceName.equalsIgnoreCase("MnoUnsolicitedPortOutCancel")
				|| operationName.equalsIgnoreCase("MnoUnsolicitedWorkFlow")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId
					+ "&ruleParam=unsolicitedPortOutServiceMetaData";
		}else if (serviceName.equalsIgnoreCase("MnoUnsolicitedPortOutCancel")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId
					+ "&ruleParam=unsolicitedPortOutServiceMetaData";
		}else if(serviceName.equalsIgnoreCase("DPFO-Notification")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName 
					+ "&transId=" +transId + "&responseId=" + responseId +"&ruleParam=dpfoNotificationMetaData";
		} else if (serviceName.equalsIgnoreCase("Device-Detection")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=deviceDetectionServiceMetaData";
		}else if (serviceName.equalsIgnoreCase("Change-MDN")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=splitterServiceMetaData";
		}else if (serviceName.equalsIgnoreCase("HmnoManagingSubscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=serviceMetaData";
		}else if (serviceName.equalsIgnoreCase("MnoUnsolicitedProcessPlan") && operationName.equalsIgnoreCase("MnoUnsolicitedProcessPlan") ) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=unsolicitedPortOutServiceMetaData";
		}else if (serviceName.equalsIgnoreCase("Create-Subscriber") || serviceName.equalsIgnoreCase("EmmUpdateSubscriber") || serviceName.equalsIgnoreCase("Get-Subscriber")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=emmSubscriberMetaData";
		}

		else if (serviceName.equalsIgnoreCase("MnoUnsolicitedProcessPlan")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=unsolicitedPortOutServiceMetaData";
		}else if (serviceName.equalsIgnoreCase("mnoAsyncProgrammingService")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=genericAsyncMetdaData";
		}else if(serviceName.equals("mnolinehistoryservice")&&operationName.equals("mnolinehistoryserviceworkflow")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId+ "&responseId=" + responseId +"&ruleParam=getlineHistoryMetaData";
		}else if(serviceName.equals("Retrieve-Device")&&operationName.equals("RetrieveDeviceWorkflow")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId + "&responseId=" + responseId +"&ruleParam=retrieveDeviceMetaData";
		}else if(serviceName.equals("Add-Wearable")&&operationName.equals("AddWearableWF")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}
		else if(serviceName.equals("ChangeESIM")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}else if(serviceName.equals("Retrieve-Device-Details") && operationName.equalsIgnoreCase("RetrieveDeviceDetailsWorkflow")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}  else if(serviceName.equals("Transfer-Wearable")&&operationName.equals("TransferWearableWF")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		} else if(serviceName.equals("UpdateAccChge")&&operationName.equals("UpdateAccountChangeWorkflow")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=updateAccountChangeMetaData";
		}	else if(serviceName.equals("Account-Summary")&&operationName.equals("Account-SummaryWF")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=accountSummaryMetaData";
		}else if(serviceName.equals("line-summary")&&operationName.equals("LineSummaryWF")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}else if(serviceName.equals("Promo-Details")&&operationName.equals("PromoDetailsWF")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=promoDetailsMetaData";
		}
		else if(serviceName.equals("Update-Wifi-Address")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}
		else if(serviceName.equals("Validate-Wifi-Address")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=swRuleCheck";
		}
		else if(serviceName.equals("loginAuthService")) {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId +"&responseId=" + responseId+ "&ruleParam=loginAuthRuleCheck";
		}
	
		
		
		else {
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId;
		}

		return request;

	}

	/**
	 * Async update north bound transaction.
	 *
	 * @param responseId the response id
	 * @param entityId   the entity id
	 * @param respJson   the resp json
	 * @param grpId      the grp id
	 * @param processId  the process id
	 * @param servName   the serv name
	 */
	private void asyncUpdateNorthBoundTransaction(String responseId, String entityId, String respJson, String grpId,
			String processId, String servName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransaction(responseId, entityId, respJson, grpId, processId, servName);
			}
		});
	}

	public String formatReqPortin(String request, String response, String responseId) {
		try {
			JSONObject requestObj = new JSONObject(request);
			JSONObject jsonObj = new JSONObject(requestObj.get("messageHeader").toString());
			String refNo = "";
			if (jsonObj.has("referenceNumber")) {
				refNo = jsonObj.getString("referenceNumber");
			}
			LOGGER.info("referenceNumber ::" + refNo);
			if (response.contains("\"transactionId\":\"\"")) {
				LOGGER.info("Inside replace");
				response = response.replace("\"transactionId\":\"\"", "\"transactionId\":\"" + responseId + "\"");
			}
			if (response.contains("\"referenceNumber\":\"\"")) {
				LOGGER.info("Inside replace");
				response = response.replace("\"referenceNumber\":\"\"", "\"referenceNumber\":\"" + refNo + "\"");
			}
			if (response.contains("\"serviceId\":\"\"")) {
				String serviceId = "\"serviceId\":\"SPECTRUM_MOBILE\"";
				response = response.replace("\"serviceId\":\"\"", serviceId);
			}
			if (response.contains("\"requestType\":\"\"")) {
				String requestType = "\"requestType\":\"MNO\"";
				response = response.replace("\"requestType\":\"\"", requestType);
			} else if (response.contains("\"requestType\":\"SM-VZW\"")) {
				String requestType = "\"requestType\":\"MNO\"";
				response = response.replace("\"requestType\":\"SM-VZW\"", requestType);
			}
		} catch (Exception e) {
			LOGGER.info(e.getMessage(), e);
		}
		return response;
	}

	

	public boolean isValidJson(String inputJson) {
		LOGGER.info("inputJson:::::" + inputJson);
		String response = "";
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					finalObj = jsonarr.getJSONObject(i);
				}
				if (finalObj != null && finalObj.length() > 0) {
					return true;
				}
			} else if (inputJson.startsWith("{")) {
				finalObj = new JSONObject(inputJson);
				if (finalObj != null && finalObj.length() > 0) {
					return true;
				}
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage());
			LOGGER.info("jsonFormatterforRequest.............." + inputJson);
			// response =false;
			return false;
		}
		return false;
	}

	public String getServciesRemoveGroupParams(String req) throws NslCustomException, NotAuthorizedException {
		JsonObject reqJson =new JsonObject();
		try {
			Gson gson =new Gson();
			boolean isDataPresent =false;
			if (req.startsWith("{")) {
				reqJson =  new JsonParser().parse(req).getAsJsonObject();
				JsonObject modifydata =new JsonObject();
				for(Map.Entry<String, JsonElement> entry : reqJson.entrySet()) {
					String reqKey = entry.getKey();
					if (Constants.DATA.equalsIgnoreCase(reqKey)) {
						JsonObject dataJson = (JsonObject) reqJson.getAsJsonObject(reqKey);
						isDataPresent=true;
						for(Map.Entry<String, JsonElement> dataentry : dataJson.entrySet()) {
							String dataKey = dataentry.getKey();
							if((Constants.CODE.equalsIgnoreCase(dataKey)||Constants.REASON.equalsIgnoreCase(dataKey)||Constants.TRANSACTIONID.equalsIgnoreCase(dataKey)||Constants.MESSAGE.equalsIgnoreCase(dataKey))) {
								modifydata.add(dataKey,dataentry.getValue());
							}
						}
					}
				}
				if(isDataPresent) {
					reqJson.remove(Constants.DATA);
					reqJson.add(Constants.DATA,modifydata);
				}
			}

		}catch(Exception e) {
			if(e instanceof NslCustomException) {
				String authErrorResponse = ((NslCustomException) e).getResponse().getEntity().toString();
				StatusType info = ((NslCustomException) e).getResponse().getStatusInfo();
				throw new NslCustomException(Response.status(info).entity(authErrorResponse).build());
			}

		}
		return reqJson.toString();

	}

	@SuppressWarnings("unchecked")
	public void responseHeader(Message msg) throws NslCustomException, NotAuthorizedException {
		try {
			byte[] body = msg.getBody();
			String req = new String(body);

			String codeStr = "";
			String status = "";
			if (req.startsWith("{")) {

				JSONObject reqJson = new JSONObject(req);
				Iterator<String> reqJsonItr = reqJson.keys();
				while (reqJsonItr.hasNext()) {
					String reqKey = reqJsonItr.next();
					if (Constants.DATA.equalsIgnoreCase(reqKey)) {
						JSONObject dataJson = (JSONObject) reqJson.get(reqKey);
						Iterator<String> dataJsonItr = dataJson.keys();
						while (dataJsonItr.hasNext()) {
							String dataKey = dataJsonItr.next();
							if (Constants.CODE.equalsIgnoreCase(dataKey)) {
								codeStr = dataJson.getString(dataKey);
								break;
							} else if (Constants.STATUS.equalsIgnoreCase(dataKey)) {
								status = dataJson.getString(dataKey);
							}
						}
					}
				}
				if (StringUtils.hasText(codeStr)) {
					int code = Integer.parseInt(codeStr);
					if (code >= 400 && code <= 600) {
						throw new NslCustomException(
								Response.status(new NslStatusCode(code, status)).entity(req).build());
					}
				} else {
					MessageBuilder.withBody(req.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				}

			} else {
				MessageBuilder.withBody(req.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			}

		} catch (Exception e) {
			if (e instanceof NslCustomException) {
				String authErrorResponse = ((NslCustomException) e).getResponse().getEntity().toString();

				StatusType info = ((NslCustomException) e).getResponse().getStatusInfo();
				MessageBuilder.withBody(authErrorResponse.getBytes());
				throw new NslCustomException(Response.status(info).entity(authErrorResponse).build());
			}

		}

	}
	
	
	public ArrayList getLineId(String request){
		JSONObject object3 = new JSONObject();
		JSONArray suborderArr = new JSONArray();
		JSONArray suborderArray = new JSONArray();
		String lineId="";
		ArrayList lineIdValue = new ArrayList();
		try{
			JSONObject object1 = new JSONObject(request);
			if (object1.has("data")) {
				object1 = object1.getJSONObject("data");
		if (object1.has("subOrder")) {
						suborderArr= object1.getJSONArray("subOrder");
						object3 = suborderArr.getJSONObject(0);
						
						}if(object3.has("mdns"))
						{
							suborderArr = object3.getJSONArray("mdns");
							int jsonLength=suborderArr.length();
							for(int i=0;i<jsonLength;i++)
							{
							object3 = suborderArr.getJSONObject(i);
							if(object3.has("lineId")){
							
								lineId = object3.getString("lineId");
								lineIdValue.add(lineId);
								
							}
							
						}
						}
			}
			
					return lineIdValue;
	}
	catch(Exception e){
		LOGGER.error(e.getMessage(), e);
	}return null;
	}
	
 public String lineInquiryFeat(String responseId,String frameworkResponse){
								JSONArray featRespArray=new JSONArray();
								JSONArray featArray=new JSONArray();
								try{
								String lineInquiryResponse=transactionDAO.getLineResponse(responseId);
								LOGGER.info(" featArray::::"+featArray.toString()+":::"+lineInquiryResponse);
								String wholeFeat="";
								String retailFeat="";
								String retailArr[];	
								if(lineInquiryResponse.startsWith("{")){
									JSONObject respObject =new JSONObject(lineInquiryResponse);
									respObject = respObject.getJSONObject("data");
									List<String> whFeatList = new ArrayList<String>();
									if(respObject.has("feature")) {
										featRespArray=respObject.getJSONArray("feature");
										LOGGER.info(" featRespArray::::"+featRespArray.toString());
										
										if (featRespArray.length() > 0) {
										List<String> featureArrayList = new ArrayList<String>();
										
										for (int j = 0; j < featRespArray.length(); j++) {
											respObject = featRespArray.getJSONObject(j);
											
											Iterator a = respObject.keys();
											while (a.hasNext()) {
												String keyStr = a.next().toString();
												if (keyStr.equalsIgnoreCase("featureCode")) {
													featureArrayList.add(respObject.getString(keyStr));
												}
										}
									LOGGER.info(" featureArrayList:::"+featureArrayList.toString());
										}
										//String wholeSaleFeatures = inboundProperties.getWholesaleFeatures();
									 String wholeSaleFeatures = "NOINT_ROAM#R00_DATATIER,R20_ROAM_TIER~DOMESTIC_ROAM#R01_DATATIER,R21_ROAM_TIER~CANMEX_ROAM#R03_DATATIER,R23_ROAM_TIER~INTL_ROAM#R05_DATATIER,R25_ROAM_TIER,INTCALL";									
									String wholeSaleFeat[] = wholeSaleFeatures.split("~");
										for (int mpa = 0; mpa < wholeSaleFeat.length; mpa++) {
											String wholeSaleFt=wholeSaleFeat[mpa];
											LOGGER.info(" wholeSaleFt:::"+		wholeSaleFt);	
											if(!wholeSaleFt.isEmpty() && wholeSaleFt!=null){
											wholeFeat = wholeSaleFt.substring(0,wholeSaleFt.indexOf('#',0));
											retailFeat = wholeSaleFt.substring(wholeSaleFt.indexOf("#",1)+1,wholeSaleFt.length());
										    }
											LOGGER.info("retailFeat"+retailFeat+":::"+wholeFeat);
											retailArr=retailFeat.split(",");
											for(String feature:featureArrayList){
												for (int t = 0; t < retailArr.length; t++) {
														if(feature.equalsIgnoreCase(retailArr[t])){
															whFeatList.add(wholeFeat);
														featArray=new JSONArray("[{\"featureCode\":\""+wholeFeat+"\",\"includedWithPlan\":\"N\",\"subscribe\":\"T\"}]");
														}
												}
											}
										}
										}
									}
										LOGGER.info(" whFeatList:::"+whFeatList.toString());
									if(whFeatList.size()>0){
										frameworkResponse = frameworkResponse.replace("[{\"featureCode\":\"CANMEX_ROAM\",\"includedWithPlan\":\"N\",\"subscribe\":\"F\"}]",featArray.toString());
									}else{
										frameworkResponse = frameworkResponse.replace("\"feature\":[{\"featureCode\":\"CANMEX_ROAM\",\"includedWithPlan\":\"N\",\"subscribe\":\"F\"}],","");
									
									}
										
									
									
										}
									
								return frameworkResponse;}catch(JSONException e){
									e.getMessage();
									
								}return null;
	}
	 
 	public String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		Calendar cal = Calendar.getInstance();
		LOGGER.debug("Current Date: " + sdf.format(cal.getTime()));
		String date=sdf.format(cal.getTime());
		return date;
	}
	
	@SuppressWarnings("unchecked")
	public String changeReferenceNumToTransId(String requestJson, String transId) {
		LOGGER.info("inside changeReferenceNumToTransId:: requestJson"+requestJson+" transId::"+transId);

		try {
			String refNum = centuryCIFTemplate.queryForObject(Constants.IB_REF_NUM, new Object[] { transId },
					String.class);
			JsonObject jsonObj = new JsonParser().parse(requestJson).getAsJsonObject();
			jsonObj.get(Constants.MESSAGE_HEADER).getAsJsonObject().addProperty(Constants.REF_NUM, refNum);
			requestJson = jsonObj.toString();
			LOGGER.info("changeReferenceNumToTransId requestJson::" + requestJson);
		} catch (Exception e) {
			LOGGER.error("Error in convertJsonForInboundResponse Method " + e.getMessage(), e);
		}
		return requestJson;
	}
}
