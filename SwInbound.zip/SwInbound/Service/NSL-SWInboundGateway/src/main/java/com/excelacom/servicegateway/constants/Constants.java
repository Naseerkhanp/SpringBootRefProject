package com.excelacom.servicegateway.constants;

public interface Constants {

	String INVALID_TOKEN_1 = "{\"status\":{\"code\":\"401\",\"reason\":\"Unauthorized\",\"message\":\"User account access privileges issue or Token is missing or invalid/expired\"},"
			+ "\"userProfile\":{\"userName\":\"hmnouser\",\"userRole\":\"API_USER\"},\"token\":\"";

	String INVALID_TOKEN_2 = "\"}";
	String TOKEN_UNAVAILABLE = "Not Available";
	/** The Constant ENDPOINTURL. */
	String ENDPOINTURL = "/nsl/provisioning/mno/v1/line-inquiry";

	/** The Constant EMPTYSTRING. */
	String EMPTYSTRING = "";

	String EMPTY_ARRAY = "[]";

	/** The Constant SUCCESS. */
	String SUCCESS = "SUCCESS";

	String FAILURE = "FAILURE";

	/** The Constant OPERATIONNAME. */
	String OPERATIONNAME = "mnolineinquiryserviceworkflow";

	/** The Constant SERVICENAME. */
	String SERVICENAME = "mnolineinquiryservice";

	String HTTP_POST = "POST";

	String SOURCE = "source";

	/** The Constant TRANSGROUPID. */
	String TRANSGROUPID = "TRANSGROUPID";

	/** The Constant GROUPID. */
	String GROUPID = "GROUPID";

	/** The Constant STATUS. */
	String STATUS = "status";

	/** The Constant TRANSACTION_ID. */
	String TRANSACTION_ID = "TRANSACTION_ID";
	
	String MDN = "MDN";

	/** The Constant TRANSACTION_UID. */
	String TRANSACTION_UID = "TRANSACTION_UID";

	/** The Constant ENTITY_ID. */
	String ENTITY_ID = "ENTITY_ID";

	/** The Constant ENTITY_ID. */
	String DEVICE_TYPE = "DEVICE_TYPE";
	
	/** The Constant APPLICATION_NAME. */
	String APPLICATION_NAME = "APPLICATION_NAME";

	/** The Constant TRANSACTION_TYPE. */
	String TRANSACTION_TYPE = "TRANSACTION_TYPE";

	String INBOUND = "INBOUND";

	String GETTRANSACTIONID = "SELECT SEQ_TRANSACTION_ID.nextval from dual";

	String GETFALLOUTID = "SELECT fallout_id_seq.nextval from dual";

	String TENANT_ID = "TENANT_ID";

	String DELTA = "~";

	String HTTPMETHOD = "httpmethod";

	String AMP = "&";

	String EQUALTO = "=";

	String RESPONSEID = "responseId=";

	String INSERT_TRANSACTION = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , " + "	  APPLICATION_NAME,"
			+ "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , " + "    REQ_SENT_DATE , "
			+ "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , " + "    MODIFIED_DATE , "
			+ "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ," + "    TRANSACTION_UID,"
			+ "    TENANT_ID" + "  ) " + "  VALUES " + "  ( " + "    :TRANSACTION_ID , " + "    NULL , "
			+ "    :APPLICATION_NAME , " + "	  :APPLICATIONNAME," + "    NULL, " + "    :TRANSACTION_TYPE , "
			+ "    'INITIATED', " + "    systimestamp , " + "    NULL , " + "    systimestamp , " + "    'NSL' , "
			+ "    NULL , " + "    NULL , " + "      NULL," + "    :REQUEST_MSG ," + "    :ENTITY_ID ,"
			+ "    :TRANSACTION_UID," + "    :TENANT_ID" + "  )";

	String INSERT_NORTH_BOUND_TRANSACTION1 = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , " + "	  APPLICATION_NAME,"
			+ "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , " + "    REQ_SENT_DATE , "
			+ "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , " + "    MODIFIED_DATE , "
			+ "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ," + "    TRANSACTION_UID,"
			+ "    TENANT_ID" + "  ) " + "  VALUES " + "  ( " + "     nextval('SEQ_TRANSACTION_ID') , " + "    NULL , "
			+ "    ? , " + "	  ?," + "    NULL, " + "    ? , " + "    'INITIATED', " + "    systimestamp , "
			+ "    NULL , " + "    systimestamp , " + "    'NSL' , " + "    NULL , " + "    NULL , " + "      NULL,"
			+ "    ? ," + "    ? ," + "    ? ," + "    ? " + "  )";

	String INSERT_NORTH_BOUND_TRANSACTION = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    ROOT_TRANSACTION_ID , " + "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , "
			+ "	  APPLICATION_NAME," + "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , "
			+ "    REQ_SENT_DATE , " + "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , "
			+ "    MODIFIED_DATE , " + "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ,"
			+ "    CHANNEL,"
			+ "    TRANSACTION_UID," + "    TENANT_ID" + "  ) " + "  VALUES " + "  ( "
			+ "     :TRANSACTION_ID ,   :ROOT_TRANSACTION_ID ,  " + "    NULL , " + "    :APPLICATION_NAME , "
			+ "	  :APPLICATIONNAME," + "    NULL, " + "    :TRANSACTION_TYPE , " + "    'INITIATED', "
			+ "    systimestamp , " + "    NULL , " + "    systimestamp , " + "    'NSL' , " + "    NULL , "
			+ "    NULL , " + "      NULL," + "    :REQUEST_MSG ," 
			+ "    :ENTITY_ID ,"
			+ "    :CHANNEL ,"
			+ "    :TRANSACTION_UID,"
			+ "    :TENANT_ID" + "  )";

	public static final String INSERT_MNO_NORTH_BOUND = "INSERT INTO transaction_details  (TRANSACTION_ID , "
			+ "    REL_TRANSACTION_ID , TRANSACTION_NAME ,  APPLICATION_NAME,"
			+ "    EXT_TRANSACTION_ID , TRANSACTION_TYPE , STATUS ,REQ_SENT_DATE , "
			+ "    RESP_RECEIVED_DATE , CREATED_DATE ,  CREATED_BY , MODIFIED_DATE , "
			+ "    MODIFIED_BY ,ICC_VAL,REQUEST_MSG ,ENTITY_ID , TRANSACTION_UID,TENANT_ID)"
			+ "VALUES ((SEQ_TRANSACTION_ID.nextval), NULL , :APPLICATION_NAME , :APPLICATIONNAME, NULL, :TRANSACTION_TYPE , "
			+ "    'INITIATED', " + " systimestamp , " + " NULL , " + "systimestamp , " + "    'NSL', "
			+ "NULL ,NULL ,NULL," + ":REQUEST_MSG ," + ":ENTITY_ID ," + "    :TRANSACTION_UID, :TENANT_ID)";

	public static final String INSERT_REQUESTS = "INSERT " + "INTO rh_csr_request" + "  ( " + "    TRANSACTION_ID , "
			+ "    CUSTOMER_ID , " + "    CUSTOMER_REQUEST_ID , " + "    MDN , " + "    IMEI , " + "    PICCID ,"
			+ "    EID," + "    CREATED_DATE , " + "    CREATED_BY , " + "    MODIFIED_DATE ," + "    MODIFIED_BY, "
			+ "    REFERENCE_NUMBER , " + "    ASYNC_URL , " + "    RETURN_URL ," + "    ACCOUNT_NUMBER, "
			+ "    SUBORDERID, " + "    RETAILPLANCODE, " + "    LINEID, " + "    CONTEXTID, " + "    ACCOUNTTYPE, "
			+ "    BILLCYCLEDAY, " + " HOSTMDN " + " ) " + "  VALUES " + "  ( " + "    :TRANSACTION_ID , "
			+ "    :CUSTOMER_ID , " + "    :CUSTOMER_REQUEST_ID , " + "    :MDN, " + "    :IMEI , " + "    :PICCID, "
			+ "    :EID , " + "    systimestamp, " + "    'NSL' , " + "    NULL, " + "    NULL,  "
			+ "    :REFERENCENUMBER,  " + "    :ASYNCURL,  " + "    :RETURNURL,  " + "    :ACCOUNTNUMBER , "
			+ "    :ID,  " + "    :RETAILPLANCODE,  " + "    :LINEID,  " + "    :CONTEXTID,  " + "    :ACCOUNTTYPE,  "
			+ "    :BILLCYCLEDAY, " + "  :HOSTMDN " + " )";
	String UPDATE_SUCCESS_TRANSACTION = "update transaction_details set status = :status , RESPONSE_MSG = :RESPONSE_MSG, HTTP_RESPONSE=:httpCode, NOTES = '' ,RESP_RECEIVED_DATE=systimestamp ,ENTITY_ID = :ENTITY_ID ,TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID, SERVICENAME = :SERVICENAME where transaction_uid = :TRANSACTION_ID";

	public static final String INSERT_MNO_NORTH_BOUND_TRANSACTION = "INSERT " 
    +"INTO transaction_details " 
    +"  ( " 
    +"    TRANSACTION_ID , " 
    +"    ROOT_TRANSACTION_ID , "
    +"    TRANSACTION_NAME , " 
    +"	  APPLICATION_NAME,"
    +"    EXT_TRANSACTION_ID , " 
    +"    TRANSACTION_TYPE , " 
    +"    STATUS , " 
    +"    REQ_SENT_DATE , " 
    +"    RESP_RECEIVED_DATE , " 
    +"    CREATED_DATE , " 
    +"    CREATED_BY , " 
    +"    MODIFIED_DATE , " 
    +"    MODIFIED_BY , " 
    +"    ICC_VAL,"
    +"    REQUEST_MSG ," 
    +"    ENTITY_ID ," 
			+"    HTTP_REQUEST,"
			+"    HTTP_RESPONSE ,"
    +"    SOURCE_SYSTEM ," 
			+"    TARGET_SYSTEM ,"
    +"    NOTES ,"
			+"    TENANT_ID,"
    +"    TRANSACTION_UID,"
    +"    REL_TRANSACTION_ID,"
			+"    ORDERTIMESTAMP,"
			+"    CHANNEL,"
			+"    AGENT_ID"
    +"  ) " 
    +"  VALUES " 
    +"  ( " 
    +"    :TRANSACTION_ID , " 
    +"    :ROOT_TRANSACTION_ID , "
    +"    :APPLICATION_NAME , " 
    +"	  :APPLICATIONNAME,"
    +"    NULL, " 
    +"    :TRANSACTION_TYPE , " 
    +"    'INITIATED', " 
    +"    systimestamp , " 
    +"    NULL , " 
    +"    systimestamp , " 
    +"    'NSL' , " 
    +"    NULL , " 
    +"    NULL , " 
    +"      NULL,"
    +"    :REQUEST_MSG ,"
    +"    :ENTITY_ID ,"
		    +"    :httpmethod , " 
    +"    NULL , " 
			+"    :SOURCE_SYSTEM , "
    +"    :TARGET_SYSTEM ,"   			
    +"    NULL, " 
    +"    :TENANT_ID,"
			+"    :TRANSACTION_UID,"
			+"    :REL_TRANSACTION_ID,"
			+"    :TRANSACTION_TIMESTAMP,"
			+"    :CHANNEL,"
			+"    :AGENT_ID"
    +"  )";

	// public static final String UPDATE_SUCCESS_TRANSACTION = "update
	// transaction_details set status = :status , RESPONSE_MSG = :RESPONSE_MSG,
	// HTTP_RESPONSE=:httpCode where transaction_uid = :TRANSACTION_ID";

	public static final String GET_TRANS_ID = "SELECT TRANSACTION_ID " + "FROM rh_csr_request "
			+ "WHERE created_date = " + "  (SELECT MAX(created_date) " + "  FROM rh_csr_request "
			+ "  WHERE REFERENCE_NUMBER=? " + "  ) " + "AND REFERENCE_NUMBER=?";
	public static final String GET_BASIC_COUNT = "select count(*) from BASIC_AUTH_DETAILS where USER_NAME= ? and passcode=?";

	public static final String GET_TRANSACTIONID_COUNT = "Select count(TRANSACTION_ID) From rh_csr_request where TRANSACTION_ID=? ";

	public static final String GET_TRANSACTIONID = "Select REFERENCE_NUMBER,TRANSACTION_ID From rh_csr_request where TRANSACTION_ID=? ";

	public static final String GET_TRANS_ID_COUNT = "SELECT count(TRANSACTION_ID) " + "FROM rh_csr_request "
			+ "WHERE created_date = " + "  (SELECT MAX(created_date) " + "  FROM rh_csr_request "
			+ "  WHERE REFERENCE_NUMBER=? " + "  ) " + "AND REFERENCE_NUMBER=?";

	public static final String GET_REL_TRANSACTIONID_RES="Select * From Transaction_Details where created_date =(SELECT MAX(created_date) FROM Transaction_Details where Rel_Transaction_Id=? and transaction_type=?)";

	public static final String GET_STATUS = "SELECT * FROM rh_csr_response WHERE created_date =(SELECT MAX(created_date) FROM rh_csr_response where transaction_id=?)";

	public static final String INSERT_FALLOUT = "INSERT " + "INTO FALLOUT_TRANSACTION " + "  ( " + "    FALLOUT_ID, "
			+ "    PROCESSPLANNAME, " + "    SERVICENAME, " + "    PROCESSPLANINSTID, " + "    INPUT, " + "    OUTPUT, "
			+ "    TASKNAME, " + "    STATUS, " + "    CREATEDDATE ," + "    REQ_JSON," + "   TRANSACTION_ID,"
			+ " TENANT_ID " + "   ) " + "  VALUES " + "  ( " + "    :FALLOUT_ID , " + "    :PROCESSPLAN, "
			+ "    :SERVICENAME, " + "    :PROCESSPLANID, " + "    :REQUEST, " + "    :RESPONSE, " + "    :TASKNAME, "
			+ "    'FALLOUT', " + "    systimestamp ," + "    :REQJSON," + "    :TRANSID," + "    :TENANTID" + "  )";

	public static final String REFERENCE_NUMBER = "referenceNumber";

	String JSON_FORMATTER = "jsonFormatter";

	String TRANSACTIONID = "transactionId";

	String REFERENCENUMBER = "REFERENCE_NUMBER";

	public static final String MNO_TRANSACTION_NAME = "Update Port-In";

	public static final String MNO_APPLICATION_NAME = "MNO";

	String json = "[{\"description\":\"object\",\"parameterList\":[],\"groupParamList\":[{\"entityName\":\"Connection\",\"description\":\"\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"EndpointURL\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNOLineInquiry_URL\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"EndpointURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"122\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNOLineInquiry_URL\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"UserName\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"UserName\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"122\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"2\",\"defaultValue\":\"\"},{\"name\":\"Password\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"Password\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"40\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"3\",\"defaultValue\":\"\"},{\"name\":\"endpointServiceType\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"REST\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"endpointServiceType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"REST\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"},{\"name\":\"SSL\",\"description\":\"\",\"value\":\"No\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Reference\",\"editable\":\"no \",\"subType\":\"RadioButton\",\"columnName\":\"\",\"valueList\":[\"No\",\"Yes\"],\"tableType\":\"\",\"property\":\"single\",\"displayName\":\"SSL\",\"sequenceId\":\"\",\"minLength\":\"0\",\"maxLength\":\"\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"parameterCondition\":[],\"dependParameter\":[],\"name\":\"No\",\"default_value\":\"No\",\"defaultValues\":[{\"name\":\"No\",\"id\":\"1\"}]},{\"parameterCondition\":[],\"dependParameter\":[],\"name\":\"Yes\",\"default_value\":\"No\",\"defaultValues\":[{\"name\":\"No\",\"id\":\"1\"}]}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"5\",\"defaultValue\":\"No\"},{\"name\":\"EndpointOperation\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNOLineInquiry\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"EndpointOperation\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNOLineInquiry\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"6\",\"defaultValue\":\"\"},{\"name\":\"RetryLimit\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"3\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"RetryLimit\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"3\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"7\",\"defaultValue\":\"\"},{\"name\":\"AuthenticationType\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"AuthenticationType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"8\",\"defaultValue\":\"\"},{\"name\":\"southboundurl\",\"description\":\"tag\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNO_URL\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"southboundurl\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNO_URL\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"9\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"Connection\",\"sequence\":\"1\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false},{\"entityName\":\"MNOLineInquiry\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[],\"groupParamList\":[{\"entityName\":\"messageHeader\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"serviceId\",\"description\":\"tag\",\"value\":\"2323434\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"serviceId\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"requestType\",\"description\":\"tag\",\"value\":\"MNO\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"requestType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"},{\"name\":\"referenceNumber\",\"description\":\"tag\",\"value\":\"QS.20191127161950416.ActivatePortIn.113240450.60226.R67.99\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"referenceNumber\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"6\",\"defaultValue\":\"\"},{\"name\":\"returnURL\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"returnURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"7\",\"defaultValue\":\"\"},{\"name\":\"asyncErrorURL\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"asyncErrorURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"8\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"messageHeader\",\"sequence\":\"1\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false},{\"entityName\":\"data\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"transactionType\",\"description\":\"tag\",\"value\":\"LIN\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"transactionType\",\"sequenceId\":\"\",\"minLength\":\"3\",\"maxLength\":\"3\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"transactionTimeStamp\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"transactionTimeStamp\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"2\",\"defaultValue\":\"\"},{\"name\":\"mdn\",\"description\":\"tag\",\"value\":\"9876543210\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"mdn\",\"sequenceId\":\"\",\"minLength\":\"10\",\"maxLength\":\"10\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"3\",\"defaultValue\":\"\"},{\"name\":\"min\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"min\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"data\",\"sequence\":\"2\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false}],\"displayName\":\"MNOLineInquiry\",\"sequence\":\"2\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false}],\"displayName\":\"MNOLineInquiryRequest\",\"mergeFlag\":false}]&soapAction=SendRequest&destName=MNOLineInquiryRequest&entityId=1001814~5ba6e3b3-452b-4c70-8964-9ec853f487a6&destination=externalSystem&EndpointURL=MNOLineInquiry_URL&EndpointOperation=MNOLineInquiry&requestJson="
			+ "{ \"messageHeader\": {\"serviceId\": \"2323434\",\"requestType\": \"MNO\",\"referenceNumber\": \"QS.20191127161950416.ActivatePortIn.113240450.60226.R67.99\",\"returnURL\": \"string\",\"asyncErrorURL\": \"string\"},\"data\": {\"transactionType\": \"LIN\",\"transactionTimeStamp\": \"string\",\"mdn\": \"9876543210\",\"min\": \"string\"}}";

	public static final String FCONDITION = "{\r\n" + "  \"code\": \"202\",\r\n" + "  \"status\": \"Accepted\",\r\n"
			+ "  \"message\": \"Processing is still INPROGRESS\"\r\n" + "}";
	String jsonValue = "[{\"code\": \"" + "405" + "\",\"status\": \"" + "METHOD_NOT_ALLOWED" + "\",\"message\": \""
			+ "Not a CBRS Capable Device" + "\"}]";

	public static final String PREPAREPROFILEMUSTANG_SERVICENAME = "Sp5ActivateServiceMustangflow";

	public static final String PREPAREPROFILEMUSTANG_OPERATIONNAME = "Sp5ActivateServiceMustangWorkflowflow";

	public static final String MDNACTIVATESERVICEASYNC_OPERATIONNAME = "MNOActivateServicesAsyncWF";

	public static final String MDNACTIVATESERVICEASYNC_SERVICENAME = "MNOActivateServicesAsync";

	public static final String MDNACTIVATEPORTINASYNC_OPERATIONNAME = "MNOActivatePortInAsyncWF";

	public static final String MDNACTIVATEPORTINASYNC_SERVICENAME = "MNOActivateServicesAsync";

	public static final String INSERT_EVENT_NOTIFICATION = "INSERT\r\n" + "INTO event_notification\r\n" + "  (\r\n"
			+ "    event_id, " + "    event_type, "

			+ "    event_name , " + "    event_desc, " + "    event_group, " + "    event_status , "
			+ "    notification_type , " + "    value , " + "    event_source , " + "    event_time , "
			+ "    external_id , " + "    acknowledge_status , " + "    acknowledge_id , " + "    acknowledged_by , "
			+ "    appliaction_name , " + "    transaction_type ," + "    event_destination ," + "    sent_date, "
			+ "    sent_status " + "  )\r\n" + "  VALUES\r\n" + "  (\r\n" + "  EVENT_ID_SEQ.nextval , "
			+ "    :event_type , " + "    :event_name, " + "    null , " + "    null , " + "    :event_status , "
			+ "   :notification_type , " + "    :value , " + "    :event_source , " + "    systimestamp, "
			+ "    :external_id , " + "    null , " + "    null , " + "    null , " + "    :appliaction_name , "
			+ "    :transaction_type ," + "     null, " + "    null, " + "     null " + "  )";

	public static final String EVENT_NAME = "SELECT TRANSACTION_NAME " + "FROM transaction_details "
			+ "WHERE transaction_id =? ";

	/** The Constant INSERT_ASYNC_TRANSACTION. */
	public static final String INSERT_ASYNC_TRANSACTION = "INSERT " 
    +"INTO transaction_details " 
    +"  ( " 
    +"    TRANSACTION_ID , " 
    +"    ROOT_TRANSACTION_ID , "
    +"    REL_TRANSACTION_ID , " 
    +"    TRANSACTION_NAME , " 
    +"	  APPLICATION_NAME,"
    +"    EXT_TRANSACTION_ID , " 
    +"    TRANSACTION_TYPE , " 
    +"    STATUS , " 
    +"    REQ_SENT_DATE , " 
    +"    RESP_RECEIVED_DATE , " 
    +"    CREATED_DATE , " 
    +"    CREATED_BY , " 
    +"    MODIFIED_DATE , " 
    +"    MODIFIED_BY , " 
    +"      ICC_VAL,"
    +"    REQUEST_MSG ," 
    +"    ENTITY_ID ,"
    +"    TRANSACTION_UID,"
    +"    TENANT_ID ,"
			+"    SOURCE_SYSTEM , "
    +"    TARGET_SYSTEM "  
    +"  ) " 
    +"  VALUES " 
    +"  ( " 
    +"    :TRANSACTION_ID , " 
    +"    :ROOT_TRANSACTION_ID , "
    +"    :REL_TRANSACTION_ID, " 
    +"    :APPLICATION_NAME , " 
    +"	  :APPLICATIONNAME,"
    +"    NULL, " 
    +"    :TRANSACTION_TYPE , " 
    +"    'INITIATED', " 
    +"    systimestamp , " 
    +"    NULL , " 
    +"    systimestamp , " 
    +"    'NSL' , " 
    +"    NULL , " 
    +"    NULL , " 
    +"      NULL,"
    +"    :REQUEST_MSG ,"
    +"    :ENTITY_ID ,"
    +"    :TRANSACTION_UID,"
    +"    :TENANT_ID ,"
			+"    :SOURCE_SYSTEM , "
    +"    :TARGET_SYSTEM "  
    +"  )";

	public static final String ROOT_TRANS_ID = "SELECT ROOT_TRANSACTION_ID FROM transaction_details  WHERE TRANSACTION_ID =:REFERENCE_NUMBER";
	
	public static final String REF_TRANS_ID_COUNT = "SELECT count(*)  \r\n" + 
			"	 		  FROM  \r\n" + 
			"	 		    (SELECT ROOT_TRANSACTION_ID  \r\n" + 
			"	 		    FROM transaction_details  \r\n" + 
			"	 		    WHERE TRANSACTION_ID =:REFERENCE_NUMBER\r\n" + 
			"	 		    ),    \r\n" + 
			"	 		  (SELECT REFERENCE_NUMBER  \r\n" + 
			"	 		  FROM RH_CSR_REQUEST  \r\n" + 
			"	 		  WHERE TRANSACTION_ID=  \r\n" + 
			"	 		    (SELECT ROOT_TRANSACTION_ID  \r\n" + 
			"	 		    FROM transaction_details  \r\n" + 
			"	 		    WHERE TRANSACTION_ID =:REFERENCE_NUMBER \r\n" + 
			"	 		    )) ";
	
	public static final String GET_MDN_SCHEDULER_STATUS = "SELECT MNO_STATUS FROM RH_CSR_RESPONSE WHERE created_date=(SELECT MAX(created_date) FROM rh_csr_response WHERE MDN=? and MNO_STATUS is not null)";
	
	public static final String TRANS_ID_COUNT = "SELECT COUNT(TRANSACTION_ID) FROM RH_CSR_REQUEST WHERE REFERENCE_NUMBER=:REFERENCE_NUMBER";

	public static final String UPDATEPORTOUT_OPERATIONNAME = "updateportoutserviceworkflow";

	public static final String UPDATEPORTOUT_SERVICENAME = "Update-Port-Out";

	public static final String UPDATE_FAIL_TRANSACTION = "update transaction_details set status = :status,RESPONSE_MSG = :RESPONSE_MSG, RESP_RECEIVED_DATE=systimestamp,ENTITY_ID = :ENTITY_ID , TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID,SERVICENAME = :SERVICENAME "
			+ "where transaction_uid = :TRANSACTION_ID";

	public static final String ID_COUNT_RETRIEVE = "select count(meid) from rh_ref_tac_device_data where meid=?";

	// public static final String RABBITLISTENER_CONTAINER =
	// "customSimpleRabbitListenerContainer";

	public static final String LINEINQUIRY_SERVICENAME = "Line-Inquiry";

	public static final String LINEINQUIRY_OPERATIONNAME = "lineinquiryserviceworkflow";

	public static final String DEVICEINQUIRY_OPERATIONNAME = "DeviceInquiryWF";

	public static final String DEVICEINQUIRY_SERVICENAME = "Device-Inquiry";

	public static final String VALIDATESIM_OPERATIONNAME = "MNOValidateSimWorkflow";

	public static final String VALIDATESIM_SERVICENAME = "Validate-SIM";
    
	public static final String VALIDATESIMGET_OPERATIONNAME = "ValidateSimWorkflow";

	public static final String VALIDATEMDN_SERVICENAME = "Validate-MDN-Portability";

	public static final String VALIDATEMDN_OPERATIONNAME = "validateMdnportabilityworkflow";

	public static final String BILLCYCLE_OPERATIONNAME = "MNOUpdateBillCycleDayWorkflow";

	public static final String BILLCYCLE_SERVICENAME = "Change-BCD";

	public static final String DYANMICCPFNOTIFY_OPERATIONNAME = "DynamicPFONotificationWorkflow";

	public static final String DYANMICCPFNOTIFY_SERVICENAME = "DPFO-Notification";

	public static final String UNSOLICITED_SERVICENAME = "MnoUnsolicitedProcessPlan";

	public static final String UNSOLICITED_OPERATIONNAME = "MnoUnsolicitedWorkFlow";

	public static final String MNORESETFEATURE_OPERATIONNAME = "MNOResetFeatureServiceWorkFlow";

	public static final String MNORESETFEATURE_SERVICENAME = "Reset-Feature";

	public static final String CHANGERATEPLAN_OPERATIONNAME = "MnoChangeRatePlanWorkFlow";

	public static final String CHANGERATEPLAN_SERVICENAME = "MnoChangeRatePlanProcess";

	public static final String CHANGEMDN_OPERATIONNAME = "changemdnworkflow";

	public static final String CHANGEMDN_SERVICENAME = "Change-MDN";

	public static final String UPDATEPORTIN_OPERATIONNAME = "updatePortServiceworkflow";

	public static final String UPDATEPORTIN_SERVICENAME = "Update-Port-In";

	public static final String PROMOTIONINQUIRY_SERVICENAME = "Promotion-Inquiry";

	public static final String MESSAGE = "message";
	
	public static final String PROMOTIONINQUIRY_OPERATIONNAME = "promotioninquiryserviceWorkflow";

	public static final String PROMOTIONDETAIL_SERVICENAME = "promotioninquiryservice";

	public static final String PROMOTIONDETAIL_OPERATIONNAME = "promotioninquiryserviceWorkflow";

	public static final String LINEHISTORY_SERVICENAME = "Line-History";
	
	public static final String REASON = "reason";

	public static final String LINEHISTORY_OPERATION_NAME = "mnolinehistoryserviceworkflow";

	public static final String PORTININ_SERVICENAME = "Portin-Inquiry";

	public static final String PORTININ_OPERATIONNAME = "mnoportininquiryworkflow";

	public static final String PORTININQUIRY_SERVICENAME = "portininquiryservice";

	public static final String PORTININQUIRY_OPERATIONNAME = "portininquiryserviceworkflow";

	public static final String HMNOCHANGEFEATURE_OPERATIONNAME = "HmnoChangeFeatureServiceWorkflow";

	public static final String HMNOCHANGEFEATURE_SERVICE = "Change-Feature";

	public static final String HMNOASYNC_OPERATIONNAME = "HmnoAsyncServiceWorkflow";
	
	public static final String HMNOASYNC_RECONNECTMDN_OPERATIONNAME = "reconnectMDNWorkFlow";

	public static final String HMNOASYNC_SERVICENAME = "HmnoAsyncService";

	public static final String CHANGESIM_OPERATIONNAME = "mnochangesimworkflow";

	public static final String CHANGESIM_SERVICENAME = "Change-SIM";

	public static final String SIMINQUIRY_OPERATIONNAME = "mnodeviceinquiryserviceworkflow";

	public static final String SIMINQUIRY_SERVICENAME = "SIM-Inquiry";

	public static final String VALIDATEDEVICE_OPERATIONNAME = "ValidateDeviceInquiryWorkflow";

	public static final String VALIDATEDEVICE_SERVICENAME = "Validate-Device";

	public static final String MNOACTIVE_SERVICENAME = "Activate-Subscriber";

	public static final String MNOACTIVATE_OPERATIONNAME = "MNOactivatesubscriberworkflow";

	public static final String MANAGESUBSCRIBER_SERVICENAME = "HmnoManagingSubscriber";

	public static final String MANAGESUBSCRIBER_OPERATIONNAME = "HmnoManagingSubscriberWorkflow";

	public static final String RESTORESERVICE_OPERATIONNAME = "RestoreServiceRequestWorkflow";

	public static final String RESTORESERVICE_SERVICENAME = "Reconnect-Subscriber";

	public static final String SUSPENDDEACTIVESUB_OPERATIONNAME = "suspenddeactivatehotlinesubscriberserviceworkflow";

	public static final String SUSPENDDEACTIVESUB_SERVICENAME = "Manage-Subscriber";

	public static final String CHANGENETWORK_OPERATION = "ChangeNWParamAsyncWF";

	public static final String CHANGENETWORK_SERVICENAME = "ChangeNetworkParamAsyncRequest";

	public static final String RESELLERORDER_OPERATIONNAME = "resellerchangeorderservice";

	public static final String RESELLERORDER_SERVICENAME = "resellerchangeorderserviceworkflow";

	public static final String DEACTIVATESERVICE_OPERATIONNAME = "Sp4MnoDeactivateServiceWorkflow";

	public static final String DEACTIVATE_SERVICENAME = "Sp4MnoDeactivateServiceflow";

	public static final String DEVICESTATSUS_OPERATIONNAME = "GetDeviceStatusWorkflow";

	public static final String DEVICESTATSUS_SERVICENAME = "GetDevicesStatus";

	public static final String FIXEDSERVICE_SERVICENAME = "FixedwirelessActivateService";

	public static final String FIXEDSERVICE_OPERATIONNAME = "FixedWirelessActivateServiceWorkflow";

	public static final String CHGNTWSERV_OPERATIONNAME = "changenetworkparameterworkflow";

	public static final String CHGNTWSERV_SERVICENAME = "changenetworkparameterservice";

	public static final String DYNAMICCPFEVENT_OPERATIONNAME = "DynamicNotificationWorkflow";

	public static final String DYNAMICCPFEVENT_SERVICENAME = "DynamicNotification";

	public static final String SUSPEND_OPERATIONNAME = "Sp4MnoSuspendServiceWorkflow";

	public static final String SUSPEND_SERVICENAME = "Sp4MnoSuspendService";

	public static final String ESIM_OPERATIONNAME = "EsimActivationWorkflow";

	public static final String ESIM_SERVICENAME = "EsimActivation";

	public static final String CHANGEESN_OPERATIONNAME = "Sp5ChangeesnWorkflow";

	public static final String CHANGEESN_SERVICENAME = "Sp5ChangeesnService";

	public static final String MNOCHANGERATEPLAN_SERVICENAME = "Change-Rate-Plan";

	public static final String UPDATEWIFIADDRESS = "Update Wifi Address";
	
	public static final String SWUPDATEADDRESSSERVICE="swupdateaddressserviceworkflow";

	public static final String DATA = "data";

	public static final String CODE = "code";

	public static final String MDNPORTABILITYASYNC_SERVICENAME = "MnoValidateService";

	public static final String MDNPORTABILITYASYNC_OPERATIONNAME = "ActivatePortInWF";
	
	public static final String MDNCHANGEMDNASYNC_OPERATIONNAME = "changeMDNPortMediationFlow";
	
	public static final String MDNPORTABILITY_OPERATIONNAME = "MnoValidateServiceWorkflow";

	public static final String ACTIVATESUBSCRIBERPORTIN = "Activate Subscriber Port-in";

	public static final String ACTIVATESUBSCRIBERMDN = "Activate Subscriber";

	public static final String DEACTIVATESUBSCRIBER = "Deactivate Subscriber";

	public static final String SUSPENDSUBSCRIBER = "Suspend Subscriber";

	public static final String HOTLINESUBSCRIBER = "Hotline Subscriber";

	public static final String REMOVEHOTLINE = "Remove Hotline";

	public static final String RESTORESERVICE = "Restore Service";

	public static final String RECONNECTSERVICE = "Reconnect Service";

	public static final String UPDATEPORTOUT = "Update Port-Out";

	public static final String CANCELPORTIN = "Cancel Port-In";

	public static final String UPDATEDUEDATE = "Update Due-Date";

	public static final String ACTIVATESERVICEMUSTANG_SERVICENAME = "ActivateService";

	public static final String ACTIVATESERVICEMUSTANG_OPERATIONNAME = "ActivateService";

	public static final String UPDATECUSTOMER_INFO = "Update Customer Information";

	public static final String RETRIEVE_PSCODE = "RETRIEVE_PSCODE";

	public static final String TRANSACTION_TIMESTAMP = "TRANSACTION_TIMESTAMP";

	public static final String ROOT_TRANSACTION_ID = "ROOT_TRANSACTION_ID";

	public static final String INSERT_REF_ADD_DATA = "INSERT " + "INTO ref_additional_data " + "  ( "
			+ "    TRANSACTIONID , " + "    REFNAME , " + "    REFVALUE ," + "    CREATED_DATE , " + "    CREATED_BY , "
			+ "    MODIFIED_DATE , " + "    MODIFIED_BY  " + "  ) " + "  VALUES " + "  ( " + "    :TRANSACTION_ID , "
			+ "    :REFNAME, " + "    :REFVALUE ," + "    systimestamp , " + "    'NSL' , " + "    systimestamp , "
			+ "    'NSL'  " + "  )";

	String GET_TOKEN = "select count(*) from ACCESSTOKEN_INFO where TOKEN=:TOKEN";

	String APPLICATION_HMNO = "HMNO";

	String APPLICATION_SMB = "SMB";

	String GET_MDN_TRANS_COUNT = "SELECT count(TRANSACTION_ID) FROM RH_CSR_RESPONSE WHERE created_date=(SELECT MAX(created_date) FROM rh_csr_response WHERE MDN=?)";

	public static final String GETCOUNTTRANSACTIONSTATUS = "select COUNT(TRANSACTION_STATUS) from line where line_id= ? and TRANSACTION_STATUS in ('INPROGRESS','INITIATED')";

	public static final String SWCHANGEESIM_OPERATIONNAME = "ChangeESIMworkflow";


	public static final String CHANGEESIM_OPERATIONNAME = "ChangeESIMValidateBYODworkflow";

	public static final String CHANGEESIM_SERVICENAME = "ChangeESIM";

	public static final String UPDATE_EVENT_NOTIFICATION = "update event_notification set event_status = :event_status , acknowledge_status= :acknowledge_status ,event_destination= :event_destination , sent_status =:sent_status where external_id = :external_id";

	public static final String UPDATE_EVENT_NOTIFICATION_FAILURE = "update event_notification set sent_date = systimestamp where external_id = :external_id";

	public static final String  EXTERNAL_ID="SELECT transaction_id " 
			+"FROM transaction_details " 
			+"WHERE transaction_uid =? ";

	public static final String UPDATE_WIFI_CASE = "Add or Update Location request has been processed successfully but the address was not validated successfully";
 
	public static final String UPDATE_WIFI_WARNING_CASE="Result Code=3736 with Description: RC=[WARNING] RM=[Add or Update Location request has been processed successfully but the address was not validated successfully] ER=[]";
	
	public static final String TOKEN = "token";

	public static final String RESPONSE_PARAM_ACTIVE = "active";

	public static final String GET_ADDITONAL_DATA="SELECT * FROM ref_additional_data WHERE created_date =(SELECT MAX(created_date) FROM ref_additional_data where TRANSACTIONID=?)";

	public static final String GET_TRANSACTIONID_RES="Select REQUEST_MSG From Transaction_Details where created_date =(SELECT MAX(created_date) FROM Transaction_Details where Transaction_Id=?)";
	
	public static final String EMMCREATESUBSCRIBER_OPERATIONNAME = "EmmCreateSubscriberWorkflow";

	public static final String EMMCREATESUBSCRIBER_SERVICENAME = "Create-Subscriber";
	
	public static final String EMMUPDATESUBSCRIBER_SERVICENAME = "Update-Subscriber";

	public static final String EMMUPDATESUBSCRIBER_OPERATIONNAME = "EmmUpdateSubscriberWorkflow";

	public static final String EMMDELETESUBSCRIBER_SERVICENAME = "EmmDeleteSubscriber";

	public static final String EMMDELETESUBSCRIBER_OPERATIONNAME = "EmmDeleteSubscriberWorkflow";

	public static final String EMMCHANGEMDNSUBSCRIBER_SERVICENAME = "Create-Subscriber";

	public static final String EMMCHANGEMDNSUBSCRIBER_OPERATIONNAME = "changeMDNMediationFlow";

	public static final String EMMUSAGEINQUIRY_SERVICENAME = "Create-Subscriber";

	public static final String EMMUSAGEINQUIRY_OPERATIONNAME = "EmmUsageInquiry";

	public static final String EMMGETSUBSCRIBER_SERVICENAME = "Get-Subscriber";

	public static final String EMMGETSUBSCRIBER_OPERATIONNAME = "EmmGetSubscriberWorkflow";
	
	public static final String RETRIEVE_ASYNC_SERVICE_NAME ="HmnoAsyncService";
	
	public static final String RETRIEVE_ASYNC_OPERATION_NAME ="retrieveDeviceWF";
	
	public static final String TRANSFER_WEARABLE_SERVICE_NAME ="Transfer-Wearable";
	
	public static final String TRANSFER_WEARABLE_OPERATION_NAME ="TransferWearableWF";

	public static final String EQUIPMENTINFO = "equipmentInfo";

	public static final String MAKE = "make";

	public static final String MODE ="mode";

	public static final String MODEL = "model";

	public static final String TYPE = "type";

	public static final String VALUE = "value";

	public static final String RESPONSECODE = "responseCode";
	
	public static final String MESSAGEHEADER = "messageHeader";
	
	public static final String PRODTYPE ="prodType";

	public static final String DEVICECATEGORY = "deviceCategory";
	
	
	public static final String OAUTH_TOKEN_UNAVAILABLE_ERROR_MESSAGE="{\"status\":{\"code\":\"401\",\"reason\":\"Unauthorized\",\"message\":\"User account access privileges issue or Token is missing or invalid/expired\"},\"token\":\"Not Available\"}";

	public static final String OAUTH_TOKEN_MISMATCH_ERROR_MESSAGE="{\"status\":{\"code\":\"401\",\"reason\":\"Unauthorized\",\"message\":\"User account access privileges issue or Token is missing or invalid/expired\"},\"userProfile\":{\"userName\":\"userNameValue\",\"userRole\":\"API_USER\"}}";
	
	public static final String SEARCH_ENV_ERROR_MESSAGE="{\"messageHeader\":{\"serviceId\":\"SPECTRUM_MOBILE\",\"requestType\":\"MNO\",\"referenceNumber\":\"921914343343434343\"},\"data\":{\"code\":\"500\",\"reason\":\"Internal Server Error\",\"message\":[{\"responseCode\":\"ERR18\",\"description\":\"Request Timed Out. Try again later\"}]}}";
	
	public static final String SERVICE_MOVED_PERMANENTLY="{\"data\":{\"code\":\"301\",\"reason\":\"Moved Permanently\",\"message\": [{\"responseCode\": \"ERROR\",\"description\": \"API Retired. New API Location: /nsl/provisioning/mno/v1/sim/{iccid}/validate-sim\"}]}}";
	
	public static final String MOVED_PERMANENTLY_1="{\"data\":{\"code\":\"301\",\"reason\":\"Moved Permanently\",\"message\": [{\"responseCode\": \"ERROR\",\"description\":\"";
	
	public static final String MOVED_PERMANENTLY_2="\"}]}}";
	
	public static final String INACTIVE = "Service is temporarily Inactive";
	
	/** The Constant TRANSACTIONTYPE_BV. */
	public static final String TRANSACTIONTYPE_BV = "BV";
	
	/** The Constant TRANSACTIONTYPE_DV. */
	public static final String TRANSACTIONTYPE_DV = "DV";
	
	 public static final String GET_REF_TRANSID="SELECT * \r\n" + 
			"	 		  FROM  \r\n" + 
			"	 		    (SELECT ROOT_TRANSACTION_ID  \r\n" + 
			"	 		    FROM transaction_details  \r\n" + 
			"	 		    WHERE TRANSACTION_ID =?\r\n" + 
			"	 		    ),    \r\n" + 
			"	 		  (SELECT REFERENCE_NUMBER  \r\n" + 
			"	 		  FROM RH_CSR_REQUEST  \r\n" + 
			"	 		  WHERE TRANSACTION_ID=  \r\n" + 
			"	 		    (SELECT ROOT_TRANSACTION_ID  \r\n" + 
			"	 		    FROM transaction_details  \r\n" + 
			"	 		    WHERE TRANSACTION_ID =? \r\n" + 
			"	 		    ))";
	 
	public static final String INSERT_ASYNC_STATUS="INSERT\r\n" + 
				"INTO RH_CSR_RESPONSE\r\n"  
				+"  (\r\n" 
				+"    TRANSACTION_ID,\r\n" 
				+"    CREATED_DATE , " 
				+"    CREATED_BY , " 
				+"    MODIFIED_DATE , " 
				+"    MODIFIED_BY , "
				+"    MNO_ACTIVATION_DATE,"
				+"    MNO_LAST_UPDATED_DATE,"
				+"    MDN,"
				+"    REFNO,"
				+"    REQUESTNO,"
				+"    RESPONSETYPE,"
				+"    MNO_STATUS\r\n"  
				+"  )\r\n"  
				+"  VALUES\r\n" + 
				"  (\r\n" + 
				"    :TRANSACTION_ID,\r\n"  
				 +"    systimestamp , " 
				+"    'NSL' , " 
				+"    NULL , " 
				+"    NULL , "
				+"     systimestamp ,"
				+"     systimestamp ,"
				+"     :MDN,"
				+"     :REFNO,"
				+"     :REQUESTNO,"
				+"     :RESPONSETYPE,"
				+"    :MNO_STATUS\r\n" + 
				"  )";
	 
	public static final String INSERT_LINE_HISTORY_RECORDS ="INSERT " 
			+"INTO line_history" 
			+" ( " 				
			+"LINE_HISTORY_ID , "     
			+"ID      , "                          
			+"LINE_ID     , "               
			+"ACCOUNT_NUMBER,"            
			+"ACCT_STATUS, "                
			+"MDN , "                              
			+"LINE_STATUS , "               
			+"LTE_STATUS , "                
			+"OLD_VALUE  , "                 
			+"NEW_VALUE , "                 
			+"FIELD_TYPE , "                
			+"TRANSACTION_TYPE , "          
			+"ORD_TYPE , "                  
			+"START_DATE , "                  
			+"END_DATE , "                   
			+"CREATED_DATE , "               
			+"CREATED_BY " 
			+"  ) " 
			+"  VALUES " 
			+"  ( " 
			+"  line_history_id_seq.nextval ,"
			+"   :ID , " 
			+"  :LINEID ," 
			+"  :ACCOUNT_NUMBER ,"
			+" :ACC_STATUS ,"
			+" :MDN ,"
			+" :LINE_STATUS ,"
			+" NULL ,"
			+" :OLD_VALUE ,"
			+" :NEW_VALUE ,"
			+" :FIELD_TYPE , "
			+" :TRANSACTION_TYPE ,"
			+" :ORDER_TYPE ,"
			+" systimestamp ,"
			+" NULL ,"
			+" systimestamp ,"
			+" 'NSL' "
			+")";       
	
	public static final String SERVICETYPE = "SERVICETYPE";
	 
	public static final String GET_SERVICE_STATUS = "SELECT ACTION FROM SERVICE_INFO WHERE SERVICE_TYPE = :SERVICETYPE AND SERVICE_NAME = :SERVICENAME AND TYPE LIKE :METHOD";

	public static final String TRUE = "true";
	
	/** The Constant INSERT_MNO_RESPONSE. */
	public static final String INSERT_MNO_RESPONSE ="INSERT " 
    +"INTO rh_csr_response" 
    +"  ( " 
    +"    TRANSACTION_ID , " 
    +"    CUSTOMER_ID , " 
    +"    CUSTOMER_REQUEST_ID , " 
    +"    ICCID1 ,"
    +"    EID ,"
	+"	  MDN,"
	+"	  IMEI,"
	+"    SMDP_STATUS,"		
	+"    CBRS_STATUS, "
	+"    MNO_STATUS, "
	+"    CREATED_DATE , " 
    +"    CREATED_BY , " 
    +"    MODIFIED_DATE ,"
    +"    MATCHING_ID ,"
	+"	  WHOLESALEPLANCODE,"
	+"    MODIFIED_BY, "	
	+"    MODEL,"	
	+"    MANUFACTURER,"
	+"    OS_VERSION,"
	+"    DEVICE_MODE,"
	+"    CDMALESS_FLAG"
    +"  ) " 
    +"  VALUES " 
    +"  ( " 
    +"    :TRANSACTION_ID , " 
    +"    :CUSTOMER_ID , " 
    +"    :CUSTOMER_REQUEST_ID , " 
    +"    :ICCID, " 
    +"    :EID, " 
	+"	  :MDN,"
	+"	  :IMEI,"
    +"    NULL , " 
	+"    NULL , "
	+"    :MNO_STATUS , "	
	+"    systimestamp, " 
    +"    'NSL' , " 
    +"    NULL, " 
    +"    :MATCHING_ID, "
	+"	  :WHOLESALEPLANCODE,"	
	+"    NULL, " 
	+"	  :MODEL,"	
	+"	  :MANUFACTURER,"
	+"    NULL,"
	+"    NULL,"
	+"    :CDMALESS_FLAG"
    +"  )";

	public static final String MNOASYNCPROGRAMMINGSERVICE = "mnoAsyncProgrammingService";
	
	public static final String MNOASYNCPROGRAMMINGPORTINWF="mnoAsyncProgrammingPortInworkflow";
	
	public static final String GATEWAYWF="gatewayWF";
	
	public static final String MNOASYNCPROGRAMMINGWF="mnoAsyncProgrammingworkflow";
	
	public static final String GET_TRANS_ID_COUNTS="select count(*) from RH_CSR_REQUEST where TRANSACTION_ID in (select TRANSACTION_ID from RH_CSR_RESPONSE where TRANSACTION_ID in (select TRANSACTION_ID from RH_CSR_REQUEST where REFERENCE_NUMBER=?))";
	
	public static final String GET_TRANS_IDS="select TRANSACTION_ID from RH_CSR_REQUEST where TRANSACTION_ID in (select TRANSACTION_ID from RH_CSR_RESPONSE where TRANSACTION_ID in (select TRANSACTION_ID from RH_CSR_REQUEST where REFERENCE_NUMBER=?))";

	public static final String GET_ROOT_ID_COUNT = "SELECT COUNT(ROOT_TRANSACTION_ID) FROM TRANSACTION_DETAILS WHERE TRANSACTION_ID=:TRANSACTION_ID";
	
	public static final String GET_ROOT_ID = "SELECT ROOT_TRANSACTION_ID FROM TRANSACTION_DETAILS WHERE TRANSACTION_ID=:TRANSACTION_ID";
	
	public static final String RH_Batch_Transaction = "INSERT " + "INTO RH_Batch_Transaction" + "  ( " + "    ID ,"
			+ "    TRANSACTION_ID ," + "    batch_update_status ," + "    Ext_Batch_ID , " + "    Batch_Type , " + "    Exc_TimeStamp , "
			+ "    MDN , " + "    Sync  ," + "    Reference_Number , " + "    Service_Type ," + "    STATUS ," + "    Channel_ID," + "    Created_Date , "
			+ "    CREATED_BY , " + "    MODIFIED_DATE ," + "    MODIFIED_BY " + "  ) " + "  VALUES " + "  ( "
			+ "    RH_ID_SEQ.nextval ," + "    NULL ," + "    :batch_update_status , " + "    :Ext_Batch_ID , " + "    :Batch_Type , "
			+ "    :Exc_TimeStamp , " + "    TO_NUMBER(:MDN) ," + "	  :Sync ," + "    :Reference_Number , " + "    :Service_Type ," + "    :STATUS , "
			+ "    :Channel_ID , " + "    systimestamp, " + "    :Created_By , " + "    NULL, " + "    NULL  " + "  )";
			
    public static final String SERVICE_URL = "select SERVICE_URL from service_info where service_name=?";
	
	public static final String REL_TRANSACTION_ID="REL_TRANSACTION_ID";
	
	//public static final String GET_RETAIL_PLANCODE= "select retailplancode from rh_csr_request where transaction_id=(select transaction_id from rh_csr_response where created_date=(SELECT MAX(created_date)FROM rh_csr_response where transaction_id in (select transaction_id from rh_csr_response where mdn=?)and wholesaleplancode =?))"; 
		
	//public static final String COUNT_RETAIL_PLANCODE= "select count(*) from rh_csr_request where transaction_id=(select transaction_id from rh_csr_response where created_date=(SELECT MAX(created_date)FROM rh_csr_response where transaction_id in (select transaction_id from rh_csr_response where mdn=?)and wholesaleplancode =?))"; 
		
	public static final String GET_RETAIL_PLANCODE="SELECT retailplancode FROM rh_csr_request WHERE  transaction_id in (select max(transaction_id) from rh_csr_request WHERE transaction_id in (SELECT transaction_id FROM rh_csr_response WHERE   mdn= ? and retailplancode is not null))";
	
	public static final String COUNT_RETAIL_PLANCODE="SELECT count(*) FROM rh_csr_request WHERE  transaction_id in (select max(transaction_id) from rh_csr_request WHERE transaction_id in (SELECT transaction_id FROM rh_csr_response WHERE   mdn= ? and retailplancode is not null))";
	
	public static final String RETRIEVE_TRANSACTIONID = "select transaction_id from rh_csr_Request where reference_number = ?";
	
	public static final String GET_TRANSACTIONTYPE_COUNT = "select count(*) from transaction_details where  servicename='Change-BCD' and transaction_id =?";
	
	public static final String GET_RELTRANS_ID_COUNT = "SELECT COUNT(REL_TRANSACTION_ID) FROM TRANSACTION_DETAILS WHERE REL_TRANSACTION_ID=?";
	
	public static final String GET_RESPONSE_MSG = "SELECT RESPONSE_MSG FROM TRANSACTION_DETAILS WHERE REL_TRANSACTION_ID=? and TRANSACTION_TYPE=? and TRANSACTION_NAME=?";
	
	public static final String GET_HOSTMDN_COUNT = "SELECT count(*) from rh_csr_request where hostMdn = ?";
	
	public static final String GET_LINE_INQUIRY_DETAILS_MDN ="select * from line where mdn=?";
	
	public static final String GET_TRANSACTION_NAME = "SELECT transaction_name FROM transaction_details WHERE rel_transaction_id = ( SELECT transaction_id FROM rh_csr_request WHERE reference_number = ? ) AND transaction_name NOT IN ('AsyncService') and rownum=1";
	
	public static final String GET_ACCOUNT_NUMBER = "select ACCOUNT_NUMBER from rh_csr_Request where reference_number = ?";
	
	public static final String GET_CONTEXT_ID = "select CONTEXTID from rh_csr_Request where reference_number = ?";
	
	public static final String GET_ACCOUNT_TYPE = "select ACCOUNTTYPE from rh_csr_Request where reference_number = ?";
	
	public static final String GET_BILL_CYCLE_DAY = "select BILLCYCLEDAY from rh_csr_Request where reference_number = ?";
	
	public static final String GET_SUBORDER_ID = "select SUBORDERID from rh_csr_Request where reference_number = ?";
	
	public static final String GET_LINE_ID = "select LINEID from rh_csr_Request where reference_number = ?";
	
	public static final String GET_MDN_VALUES = "SELECT DISTINCT mdn FROM rh_csr_response WHERE transaction_id IN (SELECT transaction_id FROM rh_csr_request WHERE hostmdn = ?) and mdn is not null and mdn <> ?";
	
	
	public static final String GET_HOST_MDN="SELECT MDN FROM RH_CSR_REQUEST  WHERE REFERENCE_NUMBER=?";
	
	public static final String UPDATE_HOSTMDN="UPDATE RH_CSR_REQUEST SET HOSTMDN = :MDN WHERE TRANSACTION_ID in (SELECT TRANSACTION_ID FROM RH_CSR_REQUEST WHERE HOSTMDN = :HOSTMDN)";

	public static final String GET_HOSTMDN_TRANS_ID ="SELECT * FROM RH_CSR_REQUEST  WHERE HOSTMDN=?";
	
	public static final String GET_HOSTMDN_DETAILS="SELECT * FROM RH_CSR_REQUEST  WHERE MDN=?";
	
	public static final String COUNT_TRANSACTIONID_RESPONSETABLE="Select count(*) FROM rh_csr_response  WHERE transaction_id=? ";
	
	public static final String GET_MDN_FROM_RESPONSETABLE="SELECT MDN FROM rh_csr_response WHERE created_date = (SELECT MAX(created_date) FROM rh_csr_response  WHERE transaction_id=? and mdn is not null)";
	
	public static final String GET_WHOLESALE_FROM_RESPONSETABLE="SELECT wholesaleplancode FROM RH_CSR_RESPONSE WHERE created_date = (SELECT MAX(created_date) FROM rh_csr_response  WHERE transaction_id=? and wholesaleplancode is not null)";
	
	public static final String UPDATE_ROOT_ID="UPDATE TRANSACTION_DETAILS SET REL_TRANSACTION_ID= :REL_TRANSACTION_ID , ROOT_TRANSACTION_ID = :ROOT_TRANSACTION_ID where TRANSACTION_ID = :TRANSACTION_ID ";
	
	public static final String GET_ADDITIONAL_DETAILS = "select ACCOUNT_NUMBER,CONTEXTID ,ACCOUNTTYPE ,BILLCYCLEDAY ,SUBORDERID ,LINEID,TRANSACTION_ID from rh_csr_Request where reference_number = ?";
	
	public static final String GET_MDN_COUNTS = "select count(*) from RH_CSR_REQUEST where hostmdn=?";
	
	public static final String GET_HOST_MDN_VALUE = "SELECT hostMdn FROM RH_CSR_REQUEST where transaction_id IN (SELECT max(transaction_id) FROM rh_csr_response WHERE mdn=? and mno_status in('Active','ACTIVE'))";
	
	public static final String GET_MDN_STATUS_COUNTS = "SELECT count(*) FROM RH_CSR_REQUEST where transaction_id IN (SELECT transaction_id FROM rh_csr_response WHERE mdn=? and mno_status in('Active','ACTIVE'))";
	
	public static final String GET_MDN_TRANS_IDS = "SELECT MAX(transaction_id) FROM rh_csr_response WHERE mdn=? and mno_status=?";
	
	
	public static final String GETACCOUNTID = "ACCOUNT_ID_SEQ.nextval";
	
	public static final String INSERT_ACCOUNT = "INSERT " + "INTO ACCOUNT" + "  ( " + "    ACCT_ID , "
			+ "    ACCOUNT_NUMBER , "+ "    ACCT_STATUS , " + "    CONTEXT_ID , " + "    ACCT_TYPE , " + "    PIN ,"
			+ "    CREATED_DATE ," + "    CREATED_BY "+ " ) " + "  VALUES " + "  ( " + "    ACCT_ID_SEQ.nextval, "
			+ "    :ACCOUNT_NUMBER , "+ "    :ACC_STATUS , " + "    :CONTEXT_ID , " + "    :ACCT_TYPE, " + "   :PIN, "
			+ "    systimestamp ," + "    'NSL' "  + " )";
				
	public static final String INSERT_DEVICE_DETAILS = "INSERT " + "INTO DEVICE_DETAILS" + "  ( " + "    LINE_ID , "
			+ "    IMEI " + " ) " + "  VALUES " + "  ( " + "    :LINEID , "
			+ "    :IMEI  " + " )";
			
	public static final String INSERT_DEVICE_DATA = "INSERT " + "INTO DEVICE" + "  ( "+ 
			"    DEVICE_ID , " + 
			"    ID , " + 
			"    LINE_ID , "  +
			 "    IMEI, " + 
			 "MAKE," +       
			"MODEL ,  " +   
			"MODE_VALUE, " +
			"CDMALESS  ,    " +  
			"EUICC_ID ," +  
			"EID ," +
			"ACTIVATION_DATE  ,   " +
			"DEACTIVATION_DATE ,  " +
			"CREATED_DATE," +
			"LAST_UPDATED," +
			"DEVICE_TYPE," +
			"EQUIPMENT_TYPE ,    " +
			"OS_VERSION," + 
			"DEVICE_NAME ,      " + 
			"MAC_ADDRESS , " +      
			"ISBYOD , " +   
			"DEVICE_CATEGORY ,   " +
			"PRODUCT_TYPE    ,   " +
			"EUICC_CAPABLE    ,  " +
			"IS_DSDS   , " +
			"START_DATE ,    " +
			"END_DATE" + " ) " + 
			 "  VALUES " + 
			 "  ( " + 
			 "    DEVICE_ID_SEQ.nextval	 , " + 
			 "    :ID , "+ 
			 "    :LINEID , "+ 
			 "    :IMEI,  " + 
			 "    :MAKE , " +
			"    :MODEL , " +
			"    :MODE  ," +
			"    :CDMALESS , " +
			"    NULL  ," +
			"    NULL  ," +
			"    :ACTIVATION_DATE , " +
			"    :DEACTIVATION_DATE , " +
			"    systimestamp  ," +
			"    systimestamp  ," +
			"    :DEVICE_TYPE  ," +
			"    NULL  ," +
			"    NULL , " +
			"    NULL  ," +
			"    NULL , " +
			"    NULL  ," +
			"    :DEVICE_CATEGORY  ," +
			"    :PRODTYPE  ," +
			"    NULL , " +
			"    NULL  ," +
			"    systimestamp , " +
			"    NULL  " + " )";
	
	public static final String INSERT_SIM_DETAILS = "INSERT " + "INTO SIM_DETAILS" + "  ( " + "    LINE_ID , "
			+ "    ICCID " + " ) " + "  VALUES " + "  ( " + "    :LINEID , "
			+ "    :ICCID  " + " )";
	
	public static final String INSERT_SIM_DATA = "INSERT " + "INTO SIM" + "  ( " 
			+ "    SIM_ID , "
			+ "    ID , "  
			+ "    LINE_ID , "
			+ "    SIM_TYPE , "
			+ "    ICCID, " 
			+ "    IMSI ," 
			+ "    SIM_STATUS ," 
			+ "    MATCHING_ID ," 
			+ "    ACTIVATION_DATE ," 
			+ "    DEACTIVATION_DATE, " 
			+ "    CREATED_DATE ," 
			+ "    LAST_UPDATED " 
			+ " ) " + "  VALUES " + "  ( "
			+ "    SIM_ID_SEQ.nextval	 , "  
			+ "    :ID , " 
			+ "    :LINEID , "
			+ "    :SIM_TYPE , "
			+ "    :ICCID,  "
			+ "    :IMSI  ,"
			+ "    :SIM_STATUS,  "
			+ "    NULL , "
			+ "    :ACTIVATION_DATE,  "
			+ "    :DEACTIVATION_DATE  ,"
			+ "    systimestamp , "
			+ "    systimestamp  " 
			+ " )";

	public static final String INSERT_LINE_PLAN_ASSOC = "INSERT " + "INTO LINE_PLAN_ASSOC" + "  ( " 
			+ "    LINE_PLAN_ID , "
			+ "    ID , "
			+ "    LINE_ID , "
			+ "    WHS_PLAN, "
			+ "    RETAIL_PLAN, " 
			+ "    FEATURE_CODES, " 
			+ "    IS_ACTIVE, " 
			+ "    START_DATE, " 
			+ "    END_DATE, " 
			+ "    DATA_LIMIT " + " ) " + "  VALUES " + "  ( " 
			+ "    LINE_PLAN_ID_SEQ.nextval , "
			+ "    NULL, "
			+ "    :LINEID , "
			+ "    :WHOLESALEPLANCODE, "
			+ "    :RETAIL_PLANCODE, "
			+ "    :FEATURECODES, "
			+ "    :ISACTIVE, "
			+ "    systimestamp, "
			+ "    NULL, "
			+ "    NULL "+ " )";
	
	public static final String INSERT_LINE_PLAN_DATA = "INSERT " + "INTO LINE_PLAN" + "  ( " 
			+ "    LINE_PLAN_ID , "
			+ "    ID , "
			+ "    LINE_ID , "
			+ "    WHS_PLAN, "
			+ "    RETAIL_PLAN, " 
			+ "    FEATURE_CODES, " 
			+ "    IS_ACTIVE, " 
			+ "    START_DATE, " 
			+ "    END_DATE, " 
			+ "    DATA_LIMIT " + " ) " + "  VALUES " + "  ( " 
			+ "    LINE_PLAN_ID_SEQ.nextval , "
			+ "    :ID, "
			+ "    :LINEID , "
			+ "    :WHOLESALE_PLAN, "
			+ "    :RETAIL_PLANCODE, "
			+ "    :FEATURECODES, "
			+ "    :ISACTIVE, "
			+ "    systimestamp, "
			+ "    NULL, "
			+ "    NULL "+ " )";
			
	public static final String INSERT_LINE_DATA = "INSERT " + "INTO LINE" + "  ( " 
			+ "    ID , "
			+ "    ACCT_ID , "
			+ "    ACCOUNT_NUMBER , "
			+ "    MDN , " 
			+ "    LINE_ID , " 
			+ "    LINE_STATUS , " 
			+ "    LTE_STATUS , " 
			+ "    LINE_NAME ,"
			+ "    ACTIVATION_TYPE," 
			+ "    HOST_MDN  , " 
			+ "    ACTIVATION_DATE , " 
			+ "    DEACTIVATION_DATE ," 
			+ "    LAST_UPDATED, "
			+ "    BCD , "
			+ "    MIN , "
			+ "    HOTLINE_STATUS , "
			+ "    HOTLINE_TYPE , "
			+ "    ISPORTED , "
			+ "    SUBGROUPCD , "
			+ "    LINETYPE , "
			+ "    SERVICE_TYPE , "
			+ "    REFERENCENUMBER,"
			+ "    CREATED_DATE, "
			+"     FIRST_ACTIVATED_NETWORK"
			+ "    ) " 
			+ "    VALUES " 
			+ "  ( " 
			+ "    LINE_ID_SEQ.nextval	 , " 
			+ "    :ACCT_ID , "
			+ "    :ACCOUNT_NUMBER , "
			+ "    :MDN , " 
			+ "    :LINEID , " 
			+ "    :LINE_STATUS, " 
			+ "    NULL , " 
			+ "    NULL, "
			+ "    NULL , " 
			+ "    :HOSTMDN, " 
			+ "    :ACTIVATION_DATE , " 
			+ "    :DEACTIVATION_DATE, " 
			+ "    systimestamp,  "
			+ "    :BILLCYCLEDAY,"
			+ "    :MIN , "
			+ "    NULL, "
			+ "    NULL, "
			+ "    NULL, "
			+ "    :SUBGROUPCD, "
			+ "    :LINETYPE, "
			+ "    NULL, "
			+" 		:REFERENCENUMBER,"	
			+ "    systimestamp, "
			+ "    :DEVICE_TYPE " + "  )";
	
	public static final String INSERT_PROMOTION_DATA = "INSERT " + "INTO PROMOTION" + "  ( " 
			+ "    PROMOTION_ID,"
			+ "    ID , "
			+ "    LINE_ID , " 
			+ "    PROMO_ID , " 
			+ "    PROMO_TYPE , " 
			+ "    PROMO_ALLOWANCE ,"
			+ "    START_DATE ," 
			+ "    END_DATE , "
			+ "    STATUS , "
			+ "    EXPIRED_DATE "
			+ "    ) " 
			+ "    VALUES " 
			+ "  ( " 
			+"     PROMOTION_ID_SEQ.nextval,"
			+ "    :ID	 , " 
			+ "    :LINEID , "
			+ "    :PROMO_ID , "
			+ "    :PROMO_TYPE , "
			+ "    :PROMO_ALLOWANCE , " 
			+ "    :START_DATE , " 
			+ "    :END_DATE, " 
			+ "    :STATUS , " 
			+ "    :EXPIRED_DATE "  + "  )";
	
	public static final String INSERT_LINE_DETAILS = "INSERT " + "INTO LINE_DETAILS" + "  ( " + "    ACCOUNT_NUMBER , "
			+ "    MDN , " + "    LINE_ID , " + "    LINE_STATUS , " + "    LTE_STATUS , " + "    LINE_NAME ,"
			+ "    ACTIVATION_TYPE," + "    HOST_MDN  , " + "    ACTIVATION_DATE , " + "    DEACTIVATION_DATE ," + "    LAST_UPDATED, "
			+ "    BILL_CYCLE_DAY , " + "    START_DATE , " + "  END_DATE, "+ "    CREATED_DATE, "+"  CREATED_BY, "
			+ "    MODIFIED_BY , " + "    MODIFIED_DATE ," + "    REFERENCE_NUMBER  "+") " + "  VALUES " + "  ( " + "    :ACCOUNT_NUMBER , "
			+ "    :MDN , " + "    :LINEID , " + "    NULL, " + "    NULL , " + "    NULL, "
			+ "    NULL , " + "    :HOSTMDN, " + "    NULL , " + "    NULL, " + "    systimestamp,  "+" :BILLCYCLEDAY,"
			+ "    NULL,  " + "    NULL, " + "  systimestamp , " + "   NULL , " + "   NULL , " + "   NULL ,"+"   :ReferenceNumber " + "  )";
			
	public static final String GET_ACCOUNT_NUMBER_COUNTS = "select count(*) from ACCOUNT where ACCOUNT_NUMBER=?";
	
	public static final String GET_LINE_ID_COUNTS = "select count(*) from LINE where LINE_ID=? and mdn=? and account_number=?";
	
	public static final String GET_LINE_MDN_COUNTS = "select count(*) from LINE where LINE_ID=? and mdn=?";
	
	public static final String GET_LINE_ID_DUP_COUNTS = "select count(*) from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String GETOBREQUEST = "select request_msg,transaction_name from transaction_details where rel_transaction_id=? and transaction_name<>'AsyncService' order by transaction_id asc";
	
	public static final String GETIBREQUEST_RETRIEVEDEVICE = "select request_msg from transaction_details where transaction_id=?";
	
	public static final String GETIBREQUEST = "select request_msg,transaction_name from transaction_details where transaction_id=?";
	
public static final String  GETDEVICEREQ_COUNT = "select count(*) from (SELECT response_msg,transaction_name FROM transaction_details WHERE rel_transaction_id=? AND transaction_name='Validate Device' UNION ALL SELECT REQUEST_MSG,transaction_name FROM transaction_details WHERE transaction_id =?)";
	
	public static final String  GETDEVICEREQUEST = "select * from (SELECT response_msg,transaction_name FROM transaction_details WHERE rel_transaction_id=? AND transaction_name='Validate Device' UNION ALL SELECT REQUEST_MSG,transaction_name FROM transaction_details WHERE transaction_id =?)";
	
	public static final String GETNBTRANSID = "SELECT ROOT_TRANSACTION_ID FROM transaction_details  WHERE TRANSACTION_ID =?";

	
	public static final String GETLINEIDFROMID = "select distinct(ID) from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String  GETACCID = "select max(ACCT_ID) from ACCOUNT where ACCOUNT_NUMBER=?";
	
	public static final String  GETACCIDCOUNT = "select count(*) from ACCOUNT where ACCOUNT_NUMBER=?";
	
	public static final String  GETLINEIDCOUNT = "select count(*) from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String  GETACTIVELINESCOUNT = "select count(distinct(line_id)) from line where ACCOUNT_NUMBER=?";
	
	public static final String  GETSUSPENDLINESCOUNT = "select count(distinct(line_id)) from line where ACCOUNT_NUMBER=?";
	
	public static final String  GETOLDBCD ="select bcd from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String  GETOLDMDN ="select mdn from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String  GETOLDEVICEID ="select imei from LINE where LINE_ID=? and HOST_MDN is null";
	
	public static final String UPDATE_ACCOUNT_AS = "update account set acct_status=:ACC_STATUS,MODIFIED_BY='NSL',MODIFIED_DATE=systimestamp where acct_id=:ACCT_ID";
	
	public static final String UPDATE_ACCOUNT_DS = "update account set acct_status=:ACC_STATUS,MODIFIED_BY='NSL',MODIFIED_DATE=systimestamp where acct_id=:ACCT_ID";
	
	public static final String UPDATE_LINE_DS ="update line set line_status=:LINE_STATUS,hotline_status=null,TRANSACTION_STATUS=:TRANSACTION_STATUS,REFERENCENUMBER=:REFERENCENUMBER,DEACTIVATION_DATE=:DEACTIVATION_DATE,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String GET_REQUEST="SELECT REQUEST_MSG from transaction_details where transaction_id=?";

	public static final String UPDATE_REFNO = "update line set REFERENCENUMBER=:REFERENCENUMBER,LAST_UPDATED=:LAST_UPDATED,FIRST_ACTIVATED_NETWORK=:DEVICE_TYPE where id=:ID";
	
	public static final String UPDATE_ACC = "update line set ACCOUNT_NUMBER=:ACCOUNT_NUMBER,LAST_UPDATED=systimestamp where LINE_ID=:LINE_ID and MDN=:MDN";
	
	public static final String UPDATE_LINE_HIS ="update line_history set OLD_VALUE=:OLDACCT,NEW_VALUE=:ACCOUNT_NUMBER where LINE_ID=:LINE_ID and MDN=:MDN";
	
	public static final String UPDATE_HOTLINE = "update line set HOTLINE_STATUS=:HOTLINE_STATUS,HOTLINE_TYPE=:HOTLINETYPE,TRANSACTION_STATUS=:TRANSACTION_STATUS,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_SIM_DS ="update sim set sim_status=:SIM_STATUS,DEACTIVATION_DATE=:DEACTIVATION_DATE,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_DEVICE_DS ="update device set DEACTIVATION_DATE=:DEACTIVATION_DATE,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_LINE_PLAN_DS ="update line_plan set END_DATE=:DEACTIVATION_DATE where id=:ID";
	
	public static final String UPDATE_LINE_PLAN_RS ="update line_plan set END_DATE=null,START_DATE=:START_DATE where id=:ID";
	
	public static final String UPDATE_ACCOUNT_SS = "update account set acct_status=:ACC_STATUS,MODIFIED_BY='NSL',MODIFIED_DATE=systimestamp where acct_id=:ACCT_ID";
	
	public static final String UPDATE_LINE_SS ="update line set line_status=:LINE_STATUS,hotline_status=null,TRANSACTION_STATUS=:TRANSACTION_STATUS,REFERENCENUMBER=:REFERENCENUMBER,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_SIM_SS ="update sim set sim_status=:SIM_STATUS,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_LINE_CB = "update line set BCD=:BILLCYCLEDAY,REFERENCENUMBER=:REFERENCENUMBER,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String UPDATE_RECONNECT = "update line set line_status=:LINE_STATUS,REFERENCENUMBER=:REFERENCENUMBER,LAST_UPDATED=:LAST_UPDATED where id=:ID";

	public static final String CHANGE_LINE_MDN = "update line set MDN=:MDN,REFERENCENUMBER=:REFERENCENUMBER,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String CHANGE_LINE_DEVICE = "update device set IMEI=:IMEI,LAST_UPDATED=:LAST_UPDATED,DEVICE_TYPE=:DEVICE_TYPE where id=:ID";
	
	public static final String UPDATE_ENDDATE_OD = "update line_history set end_Date=systimestamp where field_type='DEVICEID' and new_value=:OLDIMEI and id=:ID";
	
	public static final String UPDATE_ENDDATE_OS = "update line_history set end_Date=systimestamp where field_type='ICCID' and new_value=:OLDICCID and id=:ID";
	
	public static final String CHANGE_LINE_SIM = "update sim set ICCID=:ICCID,LAST_UPDATED=:LAST_UPDATED where id=:ID";
	
	public static final String VALIDATE_CF_FEATURES = "select count(*) from line_plan where feature_codes=:FEAT_DEL and ID=:ID";
	
	public static final String VALIDATE_FEAT_ADD = "select count(*) from line_plan where feature_codes=:FEAT_ADD and ID=:ID";
	
	public static final String UPDATE_CF_FEATURES = "update line_plan set IS_ACTIVE=:ISACTIVE where ID=:ID and feature_codes=:FEATURECODES";
	
	public static final String GETWHSCODE = "select distinct(whs_plan) from line_plan where line_id=?";
	
	public static final String GETTRANSACTIONSTATUS ="select TRANSACTION_STATUS from line where line_id=? and HOST_MDN is null";
	
	public static final String OLDACCOUNTVALUE ="select ACCOUNT_NUMBER from line where line_id=?";
	
	public static final String GETRETAILCODE = "select distinct(retail_plan) from line_plan where line_id=?";
	
	public static final String RH_BATCH_SCHEDULER_TRANSACTION = "INSERT " + "INTO rh_batch_scheduler_transaction" + "  ( " + "    ID ,"
			+ "    scheduled_status ," + "    Batch_ID ," + "    Exc_TimeStamp , "
			+ "    MDN , " + "    Sync  , " + "    Service_Type ," + "    Created_Date , "
			+ "    CREATED_BY , " + "    MODIFIED_DATE ," + "    MODIFIED_BY " + "  ) " + "  VALUES " + "  ( "
			+ "    (Rh_Batch_ID_SEQ.nextval) ," + "    :scheduled_status , " + "    :Ext_Batch_ID , "
			+ "    :Exc_TimeStamp , " + "    TO_NUMBER(:MDN) ," + "	  :Sync, " + "    :Service_Type , "
			+ "    systimestamp, " + "    :Created_By , " + "    NULL, " + "    NULL  " + "  )";
			
			public static final String GET_STATUS_COUNT="select COUNT(TRANSACTION_ID) from RH_CSR_RESPONSE where mdn=(select mdn from RH_CSR_REQUEST where REFERENCE_NUMBER=?) and MNO_STATUS='ACTIVE'";

	public static final String UPDATE_MNO_STATUS="UPDATE RH_CSR_RESPONSE set MNO_STATUS='DEACTIVE' WHERE MNO_STATUS='ACTIVE' AND TRANSACTION_ID=(select max(TRANSACTION_ID) from RH_CSR_RESPONSE where mdn=(select mdn from RH_CSR_REQUEST where REFERENCE_NUMBER=:REFERENCE_NUMBER) and MNO_STATUS='ACTIVE')";

	public static final String GET_ACTIVATED_DATAS="SELECT res.WHOLESALEPLANCODE,\r\n" + 
			"  res.IMEI,\r\n" + 
			"  res.ICCID1,\r\n" + 
			"  res.MODEL,\r\n" + 
			"  res.MANUFACTURER,\r\n" + 
			"  res.DEVICE_MODE,\r\n" + 
			"  req.RETAILPLANCODE,\r\n" + 
			"  req.FEATURECODES,\r\n" + 
			"  req.BILLCYCLEDAY\r\n" + 
			"FROM\r\n" + 
			"  (SELECT * FROM RH_CSR_RESPONSE\r\n" + 
			"  )res,\r\n" + 
			"  (SELECT * FROM RH_CSR_REQUEST\r\n" + 
			"  )req\r\n" + 
			"WHERE req.TRANSACTION_ID IN \r\n" + 
			"  (SELECT TRANSACTION_ID\r\n" + 
			"  FROM RH_CSR_RESPONSE\r\n" + 
			"  WHERE mdn IN \r\n" + 
			"    (SELECT mdn\r\n" + 
			"    FROM RH_CSR_REQUEST\r\n" + 
			"    WHERE REFERENCE_NUMBER=?\r\n" + 
			"    )\r\n" + 
			"  )\r\n" + 
			"AND res.TRANSACTION_ID IN \r\n" + 
			"  (SELECT TRANSACTION_ID\r\n" + 
			"  FROM RH_CSR_RESPONSE\r\n" + 
			"  WHERE mdn IN \r\n" + 
			"    (SELECT mdn\r\n" + 
			"    FROM RH_CSR_REQUEST\r\n" + 
			"    WHERE REFERENCE_NUMBER=?\r\n" + 
			"    )\r\n" + 
			"  )";

	public static final String UPDATE_CHANGEMDN_RESPONSE="UPDATE RH_CSR_RESPONSE\r\n" + 
			"SET WHOLESALEPLANCODE=:WHOLESALEPLANCODE,\r\n" + 
			"  IMEI               =:IMEI,\r\n" + 
			"  ICCID1             =:ICCID1,\r\n" + 
			"  MODEL              =:MODEL,\r\n" + 
			"  MANUFACTURER       =:MANUFACTURER,\r\n" + 
			"  DEVICE_MODE        =:DEVICE_MODE\r\n" + 
			"WHERE TRANSACTION_ID =\r\n" + 
			"  (SELECT TRANSACTION_ID\r\n" + 
			"  FROM RH_CSR_REQUEST\r\n" + 
			"  WHERE REFERENCE_NUMBER=:REFERENCE_NUMBER\r\n" + 
			"  )\r\n" + 
			"AND MNO_STATUS='INPROGRESS'";
	
	
	public static final String UPDATE_CHANGEMDN_REQUEST="UPDATE RH_CSR_REQUEST\r\n" + 
	"SET RETAILPLANCODE   =:RETAILPLANCODE,\r\n" + 
	"  FEATURECODES       =:FEATURECODES,\r\n" +
	"  BILLCYCLEDAY       =:BILLCYCLEDAY\r\n" + 
	"WHERE TRANSACTION_ID =\r\n" + 
	"  (SELECT TRANSACTION_ID\r\n" + 
	"  FROM RH_CSR_REQUEST\r\n" + 
	"  WHERE REFERENCE_NUMBER=:REFERENCE_NUMBER\r\n" + 
	"  )";
	
	public static final String GET_LINE_RESPONSE= "select response_msg from transaction_details where transaction_name='Line Inquiry' and transaction_type='OUTBOUND' and rel_transaction_id=:REL_ID";

	public static final String ACCOUNT_NUM = "select account_number from line where  mdn= ? and rownum = 1";
	
	public static final String LINEID = "select FIRST_ACTIVATED_NETWORK from line where line_id = ?";
	
	public static final String LINEID_NUM= "select line_id from line where  mdn= ? and rownum = 1";
	
	public static final String RESPONSEMSG_FROMTRANSDEATILS= "select response_msg from transaction_details where rel_transaction_id = ?";
	
	public static final String CHANGE_RATE_PLAN="Change-Rate-Plan";
	
	public static final String ACTIVATE_SUBSCRIBER="Activate-Subscriber";
	
	public static final String ADDITIONAL_DATA="additionalData";
	
	public static final String ERR_VALIDATION="responseCode\":\"ERR";
	
	public static final String GET_HOST_MDN_ADDWEARABLE="SELECT HOSTMDN FROM RH_CSR_REQUEST  WHERE REFERENCE_NUMBER=?";
	
	public static final String HOSTMDN_LINE_DETAILS="select * from line where created_date=(select max(created_date) from line where mdn=?) and mdn=?";
	
	public static final String HOSTMDN_LINEHISTORY_DETAILS="select * from line_history where line_id=? and transaction_Type in('AS','SP')";
	
	public static final String CHANGE_HOST_MDN = "update line set HOST_MDN=:MDN,LAST_UPDATED=:LAST_UPDATED where line_id=(select line_id from line where id=:ID) and HOST_MDN is not null";

	public static final String SUBORDER="subOrder";
	
	public static final String NAME = "name";
	
	public static final String AddwearableAsyncTW = "AddwearableAsyncTW";
	
	public static final String AddwearableAsyncTWWorkflow = "AddwearableAsyncTWWorkflow";
	
	public static final String TRANSACTION_NAME="transaction_name";
	
	public static final String RESPONSE_MSG="response_msg";
	
	public static final String REQUEST_MSG="response_msg";
	
	public static final String ACTIVATE_SUB="Activate Subscriber";

	public static final String CHANNEL= "CHANNEL";
	public static final String AGENT_ID="AGENT_ID";
	public static final String ACCOUNT_NUMBER ="ACCOUNT_NUMBER";
	public static final String LINE_ID= "LINE_ID";
	public static final String IMEI ="IMEI";
	public static final String ICCID="ICCID";
	public static final String AGENT_PHONE_NUMBER = "AGENT_PHONE_NUMBER";
	public static final String AGENT_FIRST_NAME = "AGENT_FIRST_NAME";
	public static final String AGENT_LAST_NAME = "AGENT_LAST_NAME";
	public static final String AGENT_EMAIL_ID = "AGENT_EMAIL_ID";
	public static final String AGENT_ADDRESSLINE1 = "AGENT_ADDRESSLINE1";
	public static final String AGENT_ADDRESSLINE2 = "AGENT_ADDRESSLINE2";
	public static final String AGENT_CITY = "AGENT_CITY";
	public static final String AGENT_STATE = "AGENT_STATE";
	public static final String AGENT_ZIPCODE = "AGENT_ZIPCODE";
	
	public static final String INSERT_TRANSACTION_LINE_ASSOC ="INSERT " 
		    +"INTO TRANSACTION_LINE_ASSOC " 
		    +"  ( " 
		     +"    TRANSACTION_ID , " 
		     +"    LINE_ID , " 
		     +"    ACCOUNT_NUMBER , " 
		     +"    MDN , " 
		     +"    IMEI , " 
		     +"    ICCID , " 
		     +"    AGENT_ID , " 
		     +"    AGENT_FIRST_NAME , " 
		     +"    AGENT_LAST_NAME , " 
		     +"    AGENT_EMAIL_ID , " 
		     +"    AGENT_ADDRESSLINE1 , " 
		     +"    AGENT_ADDRESSLINE2 , " 
		     +"    AGENT_CITY , " 
		     +"    AGENT_STATE , " 
		     +"    AGENT_ZIPCODE , " 
		     +"    CHANNEL , " 
		     +"    AGENT_PHONE_NUMBER , " 
		     +"    REFERENCENUMBER , " 
		     +"    CREATED_DATE , " 
		     +"    CREATED_BY , " 
		     +"    MODIFIED_DATE , "
		     +"    MODIFIED_BY  " 
		    +"  ) " 
		    +"  VALUES " 
		    +"  ( " 
		    +"    :TRANSACTION_ID , " 
		    +"    :LINE_ID , "
		    +"    :ACCOUNT_NUMBER , " 
		    +"	  :MDN,"
		    +"    :IMEI, " 
		    +"    :ICCID , " 
		    +"    :AGENT_ID , " 
		    +"    :AGENT_FIRST_NAME , " 
		    +"    :AGENT_LAST_NAME , " 
		    +"    :AGENT_EMAIL_ID , " 
		    +"    :AGENT_ADDRESSLINE1 , " 
		    +"    :AGENT_ADDRESSLINE2 , " 
		    +"    :AGENT_CITY , " 
		    +"    :AGENT_STATE,"
		    +"    :AGENT_ZIPCODE ,"
		    +"    :CHANNEL ,"
		    +"    :AGENT_PHONE_NUMBER , " 
		    +"    :REFERENCENUMBER , " 
		    +"    systimestamp , "
		    +"    'NSL' ,"   			
		    +"    NULL , " 
		    +"    NULL  "			
		    +"  )";
	String REFERENCENUMBER1 = "REFERENCENUMBER";
	
	public static final String INSERT_MNO_NORTH_BOUND_TRANSACTION_LOGINID = "INSERT " 
		    +"INTO transaction_details " 
		    +"  ( " 
		    +"    TRANSACTION_ID , " 
		    +"    ROOT_TRANSACTION_ID , "
		    +"    TRANSACTION_NAME , " 
		    +"	  APPLICATION_NAME,"
		    +"    EXT_TRANSACTION_ID , " 
		    +"    TRANSACTION_TYPE , " 
		    +"    STATUS , " 
		    +"    REQ_SENT_DATE , " 
		    +"    RESP_RECEIVED_DATE , " 
		    +"    CREATED_DATE , " 
		    +"    CREATED_BY , " 
		    +"    MODIFIED_DATE , " 
		    +"    MODIFIED_BY , " 
		    +"    ICC_VAL,"
		    +"    REQUEST_MSG ," 
		    +"    ENTITY_ID ," 
					+"    HTTP_REQUEST,"
					+"    HTTP_RESPONSE ,"
		    +"    SOURCE_SYSTEM ," 
					+"    TARGET_SYSTEM ,"
		    +"    NOTES ,"
					+"    TENANT_ID,"
		    +"    TRANSACTION_UID,"
		    +"    REL_TRANSACTION_ID,"
					+"    ORDERTIMESTAMP,"
					+"    CHANNEL,"
					+"    AGENT_ID,"
					+"    USER_LOGIN_ID"
		    +"  ) " 
		    +"  VALUES " 
		    +"  ( " 
		    +"    :TRANSACTION_ID , " 
		    +"    :ROOT_TRANSACTION_ID , "
		    +"    :APPLICATION_NAME , " 
		    +"	  :APPLICATIONNAME,"
		    +"    NULL, " 
		    +"    :TRANSACTION_TYPE , " 
		    +"    'INITIATED', " 
		    +"    systimestamp , " 
		    +"    NULL , " 
		    +"    systimestamp , " 
		    +"    'NSL' , " 
		    +"    NULL , " 
		    +"    NULL , " 
		    +"      NULL,"
		    +"    :REQUEST_MSG ,"
		    +"    :ENTITY_ID ,"
				    +"    :httpmethod , " 
		    +"    NULL , " 
					+"    :SOURCE_SYSTEM , "
		    +"    :TARGET_SYSTEM ,"   			
		    +"    NULL, " 
		    +"    :TENANT_ID,"
					+"    :TRANSACTION_UID,"
					+"    :REL_TRANSACTION_ID,"
					+"    :TRANSACTION_TIMESTAMP,"
					+"    :CHANNEL,"
					+"    :AGENT_ID,"
					+"    :USER_LOGIN_ID"
		    +"  )";
	
	

	public static final String GETWHSCODEUSINGMDN = "SELECT UNIQUE *\r\n" + 
			"FROM\r\n" + 
			"  (SELECT *\r\n" + 
			"  FROM\r\n" + 
			"    (SELECT *\r\n" + 
			"    FROM\r\n" + 
			"      (SELECT RETAIL_PLAN AS OLD_RPC,\r\n" + 
			"        WHS_PLAN          AS OLD_WHS\r\n" + 
			"      FROM line_plan\r\n" + 
			"      WHERE id=\r\n" + 
			"        (SELECT ID FROM line WHERE mdn=?\r\n" + 
			"        )\r\n" + 
			"      ),\r\n" + 
			"      (SELECT id, LINE_ID, ACCT_ID, ACCOUNT_NUMBER FROM line WHERE mdn=?\r\n" + 
			"      )\r\n" + 
			"    ),\r\n" + 
			"    (SELECT RETAILPLANCODE AS NEW_RPC FROM RH_CSR_REQUEST WHERE TRANSACTION_ID=\r\n" + 
			"(SELECT max(TRANSACTION_ID)\r\n" + 
			"    FROM RH_CSR_REQUEST\r\n" + 
			"    WHERE (MDN=?\r\n" + 
			"    AND RETAILPLANCODE IS NOT NULL) or TRANSACTION_ID=(\r\n" + 
			"select max(TRANSACTION_ID) from RH_CSR_REQUEST where TRANSACTION_ID in \r\n" + 
			"(select TRANSACTION_ID from RH_CSR_RESPONSE where mdn=?) and RETAILPLANCODE is not null))\r\n" + 
			"    )\r\n" + 
			"  ),\r\n" + 
			"  (SELECT MAKE,\r\n" + 
			"    MODE_VALUE,\r\n" + 
			"    CDMALESS,\r\n" + 
			"    DEVICE_TYPE,\r\n" + 
			"    DEVICE_CATEGORY,\r\n" + 
			"    PRODUCT_TYPE\r\n" + 
			"  FROM DEVICE\r\n" + 
			"  WHERE id=\r\n" + 
			"    (SELECT ID FROM line WHERE mdn=?\r\n" + 
			"    )\r\n" + 
			"  )\r\n" + 
			"";
	
	public static final String UPDATE_WHS="update line_history\r\n" + 
			"set OLD_VALUE=(select NEW_VALUE from line_history where mdn=:MDN and FIELD_TYPE='WHOLESALE_PLAN'),NEW_VALUE=:WHOLESALE_PLAN\r\n" + 
			"where mdn=:MDN and FIELD_TYPE='WHOLESALE_PLAN'";
	
	public static final String UPDATE_RPC="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_RPC,NEW_VALUE=:NEW_RPC WHERE MDN=:MDN AND FIELD_TYPE='RETAIL_PLAN'";

	public static final String UPDATE_MAKE="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_MAKE,NEW_VALUE=:NEW_MAKE WHERE MDN=:MDN AND FIELD_TYPE='MAKE'";
	
	public static final String UPDATE_MODE_VALUE="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_MODE_VALUE,NEW_VALUE=:NEW_MODE_VALUE WHERE MDN=:MDN AND FIELD_TYPE='MODE_VALUE'";
	
	public static final String UPDATE_CDMALESS="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_CDMALESS,NEW_VALUE=:NEW_CDMALESS WHERE MDN=:MDN AND FIELD_TYPE='CDMALESS'";
	
	public static final String UPDATE_DEVICE_TYPE="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_DEVICE_TYPE,NEW_VALUE=:NEW_DEVICE_TYPE WHERE MDN=:MDN AND FIELD_TYPE='DEVICE_TYPE'";
	
	public static final String UPDATE_DEVICE_CATEGORY="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_DEVICE_CATEGORY,NEW_VALUE=:NEW_DEVICE_CATEGORY WHERE MDN=:MDN AND FIELD_TYPE='DEVICE_CATEGORY'";
	
	public static final String UPDATE_PRODUCT_TYPE="UPDATE LINE_HISTORY SET OLD_VALUE=:OLD_DEVICE_CATEGORY,NEW_VALUE=:NEW_DEVICE_CATEGORY WHERE MDN=:MDN AND FIELD_TYPE='PRODUCT_TYPE'";
	
	public static final String UPDATE_DEVICE_DETAILS="UPDATE DEVICE SET MAKE=:NEW_MAKE,MODE_VALUE=:NEW_MODE_VALUE,CDMALESS=:NEW_CDMALESS,DEVICE_TYPE=:NEW_DEVICE_TYPE,DEVICE_CATEGORY=:NEW_DEVICE_CATEGORY,PRODUCT_TYPE=:NEW_PRODUCT_TYPE WHERE ID=(SELECT ID FROM LINE WHERE MDN=:MDN)";

	public static final String UPDATE_WHS_RPC="UPDATE LINE_PLAN SET RETAIL_PLAN=:NEW_RPC,WHS_PLAN=:WHOLESALE_PLAN WHERE ID=:ID";
	
	String INSERT_NORTH_BOUND_TRANSACTION_LOGIN_ID = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    ROOT_TRANSACTION_ID , " + "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , "
			+ "	  APPLICATION_NAME," + "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , "
			+ "    REQ_SENT_DATE , " + "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , "
			+ "    MODIFIED_DATE , " + "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ,"
			+ "    CHANNEL,"
			+ "    TRANSACTION_UID," + "    TENANT_ID," + " AGENT_ID,"+" USER_LOGIN_ID "+"   ) " + "  VALUES " + "  ( "
			+ "     :TRANSACTION_ID ,   :ROOT_TRANSACTION_ID ,  " + "    NULL , " + "    :APPLICATION_NAME , "
			+ "	  :APPLICATIONNAME," + "    NULL, " + "    :TRANSACTION_TYPE , " + "    'INITIATED', "
			+ "    systimestamp , " + "    NULL , " + "    systimestamp , " + "    'NSL' , " + "    NULL , "
			+ "    NULL , " + "      NULL," + "    :REQUEST_MSG ," 
			+ "    :ENTITY_ID ,"
			+ "    :CHANNEL ,"
			+ "    :TRANSACTION_UID,"
			+ "    :TENANT_ID,"  
			+ "    :AGENT_ID," 
			+ "    :USER_LOGIN_ID" + ")";

	public static final String GET_HOST_MDN_SMARTWATCH="Select hostmdn from rh_csr_request where transactionId=?";
	
	public static final String TRANS_NAME = "transaction_name";
	
	public static final String REQ_MSG ="request_msg";
	
	public static final String VALIDATE_DEVICE="Validate Device";
	
	public static final String OS_APL = "APL";
	
	public static final String NO = "NO";
	
	String DEVICEDETECTION = "simOtaDeviceChangeNotification";

	String UNSOLICITEDPORTOUT = "portOutRequest";
	
	String DPFONOTIFICATION = "DPFOEventNotification";
	
	String MDNDETAILS = "mdnDetail";

	String TRANSACTION_NAME_TW = "Transfer Wearable";

	public static final String  LTE_STATUS_RS = "RS";

	public static final String MSWAP = "MSWAP";

	public static final String YES = "YES";
	
	public static final String TRANSACTION_HISTORY_CREATED_BY="NSL";
	
	public static final String TRANSACTION_TYPE_TW="TW";
	
	public static final String ORDER_TYPE_TW = "TRANSFER_WATCH";
	
	public static final String MODITY_BY = "NSL";

	public static final String CREATED_BY = "NSL";
	
	public static final String LINETYPE_SMARTWATCH = "SMARTWATCH";
	  public static final String LOGINAUTH_SERVICE_NAME ="loginAuthService";
		
		public static final String LOGINAUTH_OPERATION_NAME ="loginAuthWF";

	public static final String FAILED = "Failed";
	
	public static final String RETURNCODE ="returnCode";
	
	public static final String COMPLETED = "COMPLETED";
	
	public static final String CODE1 = "200";
	
	public static final String TRANSACTION_NAME_CW="ChangeESIM";
	
	public static final String ORDER_TYPE_CW = "DEV_ESIM_CHG";
	
	public static final String TRANSACTION_TYPE_CW="CW";
	
	public static final String ESIM="ESIM";
	
	public static final String ACCOUNT_STATUS = "ACTIVE";
	
	public static final String LINE_STATUS = "ACTIVE";
	
	public static final String ACCOUNTNUMBER_USING_ICCID ="select * from line where e_Line_id in(select e_Line_id from sim where iccid=?)";
	
	public static final String REF_NUM="referenceNumber";
	
	public static final String MESSAGE_HEADER="messageHeader";

	public static final String REFERENCE_NUM="REFERENCE_NUMBER";
		   
	public static final String IB_REF_NUM="SELECT REFERENCE_NUMBER FROM RH_CSR_REQUEST WHERE TRANSACTION_ID=(SELECT ROOT_TRANSACTION_ID FROM transaction_details  WHERE TRANSACTION_ID =?)";
	
	public static final String UPDATE_SEARCHENV_SUCCESS_TRANSACTION="update transaction_details set status = :status , RESPONSE_MSG = :RESPONSE_MSG, RESP_RECEIVED_DATE=systimestamp where transaction_id = :TRANSACTION_ID";
}

