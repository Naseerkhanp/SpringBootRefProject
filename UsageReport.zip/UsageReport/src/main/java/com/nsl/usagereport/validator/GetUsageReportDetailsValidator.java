package com.nsl.usagereport.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.nsl.usagereport.dto.GetUsageReportDetails;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class GetUsageReportDetailsValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(GetUsageReportDetails.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		log.info("validating {}", target);
		GetUsageReportDetails reqModel = (GetUsageReportDetails) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mdn", "1", new String[] { "'mdn'" });
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startdate", "1", new String[] { "'startdate'" });
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "enddate", "1", new String[] { "'enddate'" });
		if (reqModel.getStartDate() == null) {
			errors.rejectValue("startdate", "1", new String[] { "'startdate'" }, " startdate can't be null or empty");
			return;
		}
		if (reqModel.getEndDate() == null) {
			errors.rejectValue("enddate", "1", new String[] { "'enddate'" }, " enddate can't be null or empty");
			return;
		}
		if (reqModel.getMdn() == null) {
			errors.rejectValue("mdn", "1", new String[] { "'mdn'" }, " mdn can't be null or empty");
			return;
		}
	}

}
