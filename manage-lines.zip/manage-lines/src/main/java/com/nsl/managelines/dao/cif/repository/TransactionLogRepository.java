package com.nsl.managelines.dao.cif.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.managelines.dao.cif.entity.TransactionLog;

@Repository
public interface TransactionLogRepository extends CrudRepository<TransactionLog, Long> {

	@Query("Select count(*) from TransactionLog b where b.fileName=:fileName and status=:status")
	int findCountByFileName(@Param("fileName") String fileName,@Param("status") String status);

}
