package com.nsl.managelines;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.google.gson.Gson;
import com.nsl.managelines.batch.bean.LineInquiryResponse;
import com.nsl.managelines.batch.bean.OutboundRequest;
import com.nsl.managelines.batch.bean.RetrieveDeviceAyncResponse;
import com.nsl.managelines.batch.constants.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class Sample {

	public static void main(String[] args) {
		String request = "{\"status\":\"NE-REQUEUED\",\"transactionName\":[\"Activate Subscriber\",\"Esim ActivateSubcriber\",\"Activate Subscriber Port-in\",\"Esim Activate Subscriber Port-in\"]}";
		Gson gson = new Gson();
		LineInquiryResponse outRequestBean = null;
		try {
			outRequestBean = gson.fromJson(request, LineInquiryResponse.class);
		} catch (Exception e) {
			log.error("Invalid JSON format...", e);
		}
		log.info(outRequestBean);
	}

}
