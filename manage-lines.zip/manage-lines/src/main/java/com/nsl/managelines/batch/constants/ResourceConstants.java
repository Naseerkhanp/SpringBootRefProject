package com.nsl.managelines.batch.constants;

public interface ResourceConstants {

	
	enum resourceUpdateServiceUrl{
		
		GETLINEDETAILSUSINGMDN("/getlinedetailsbymdn"),GETLINEPLANBYLINEID("/getlineplanbylineid"),
		UPDATEMIGRATIONELIGIBILITY("/updateLineDetailsList"),GETLINEDETAILSBYPLANMIGRATIONELIGIBILE("/getlinedetailsbyPlanMigrationEligibile"),UPDATESTGPLANMIGRATION("/saveStgPlanMigrationList"),
		GETSTGPLANMIGRATIONLIST("/getStgPlanMigrationList"),GETREFPLANMIGRATIONLIST("/getRefPlanMigrationList"), GETLSTGPLANMIGCOUNT("/getStgPlanMigrationCount"),UPDATELINEPLANCATEGORY("/updateLinePlanCategory");
		
		private String serviceUrl;

		
		public String getServiceUrl() {
			return serviceUrl;
		}

		private void setServiceUrl(String serviceUrl) {
			this.serviceUrl = serviceUrl;
		}

		resourceUpdateServiceUrl(String serviceUrl) {
			this.serviceUrl = serviceUrl;
		}	
	}
	
	
}
