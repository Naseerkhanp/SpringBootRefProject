package com.nsl.usagereport.cif.dao.repository;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.nsl.usagereport.cif.entity.TransFailureLog;
import com.nsl.usagereport.cif.entity.TransactionFileLog;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.nbos.entity.WibInfo;
import com.nsl.usagereport.transaction.entity.ResourceInfo;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class TransactionFileLogDaoImpl {
	@Autowired
	private TransactionFileLogRepository transactionFileLogRepository;

	@Autowired
	private TransFailureLogRepository transFailureLogRepository;

	@Transactional
	public TransactionFileLog saveTransactionDetails(UsageReportDetails usageReportDetails, String fileName, String extension,
			String status) {
		TransactionFileLog transactionFileLog = new TransactionFileLog();
		transactionFileLog.setFileName(fileName);
		transactionFileLog.setFileType(usageReportDetails.getFileType());
		transactionFileLog.setFileExtension(extension);
		transactionFileLog.setModifiedBy(usageReportDetails.getUserID());
		transactionFileLog.setCreatedBy(usageReportDetails.getUserID());
		transactionFileLog.setStatus(status);
		return transactionFileLogRepository.save(transactionFileLog);

	}

	@Transactional
	public void updateTransactionDetails(String status, int totalRecords, int totalRecordsProcessed,
			int totalRecordsfailed, String fileName, Map<String, Map<Object, Long>> recordsStatus, String errorMsg, UsageReportDetails usageReportDetails,String fileContent)
			throws Exception {
		log.info(this.getClass() + " updateTransactionDetails method called .");
		long totalRecord = (recordsStatus != null) ? totalRecords : 0;
		long totalRecordsPrcssed = (recordsStatus != null) ? totalRecordsProcessed : 0;
		long totalRecrdsfailed = (recordsStatus != null) ? totalRecordsfailed : 0;
		Set<TransFailureLog> transFailureLogLST = new HashSet<TransFailureLog>();
		try {
			TransactionFileLog transactionFileLog = transactionFileLogRepository.findByFileName(fileName,
					NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
			transactionFileLog.setTotalRecords(totalRecord);
			transactionFileLog.setTotalRecordsProcessed(totalRecordsPrcssed);
			transactionFileLog.setTotalRecordsfailed(totalRecrdsfailed);
			if(fileContent!=null && !fileContent.isEmpty()) {
				transactionFileLog.setResponseMsg(fileContent);
			}
			if (recordsStatus != null && recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size() > 0) {
				transactionFileLog.setStatus(NslFileUploadConstants.PARSED_STATUS_FAILED);
			} else {
				transactionFileLog.setStatus(status);
			}
			if (status.equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_SUCCESS)) {
				transactionFileLog.setReason(NslFileUploadConstants.EMPTY);
			} else {
				transactionFileLog.setReason(errorMsg);
			}
			if (recordsStatus != null) {
				recordsStatus.entrySet().stream()
						.filter(e -> e.getKey().equalsIgnoreCase(NslFileUploadConstants.TOTALRECORDSFAILED))
						.forEach(e -> e.getValue().forEach((object, rowNumber) -> {
							try {
								if(usageReportDetails.getFileType().equalsIgnoreCase("NBOP")) {
									ResourceInfo resourceInfo = (ResourceInfo) object;
									ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
									String json = ow.writeValueAsString(resourceInfo);
									TransFailureLog transFailureLog = new TransFailureLog();
									transFailureLog.setTransactionId(transactionFileLog.getTransactionId());
									transFailureLog.setEntityID(rowNumber);
									transFailureLog.setStatus(NslFileUploadConstants.PARSED_STATUS_FAILED);
									transFailureLog.setErrorMsg(resourceInfo.getErrorMsg());
									transFailureLog.setErrorCode(resourceInfo.getErrorCode());
									transFailureLog.setModifiedBy(transactionFileLog.getCreatedBy());
									transFailureLog.setCreatedBy(transactionFileLog.getCreatedBy());
									transFailureLog.setErrorDetails(json);
									transFailureLogLST.add(transFailureLog);
								}else {
								WibInfo wibInfo = (WibInfo) object;
								ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
								String json = ow.writeValueAsString(wibInfo);
								TransFailureLog transFailureLog = new TransFailureLog();
								transFailureLog.setTransactionId(transactionFileLog.getTransactionId());
								transFailureLog.setEntityID(rowNumber);
								transFailureLog.setStatus(NslFileUploadConstants.PARSED_STATUS_FAILED);
								transFailureLog.setErrorMsg(wibInfo.getErrorMsg());
								transFailureLog.setErrorCode(wibInfo.getErrorCode());
								transFailureLog.setModifiedBy(transactionFileLog.getCreatedBy());
								transFailureLog.setCreatedBy(transactionFileLog.getCreatedBy());
								transFailureLog.setErrorDetails(json);
								transFailureLogLST.add(transFailureLog);
								}
							} catch (JsonProcessingException e1) {
								log.error(this.getClass() + " Internal Error: Unable to update data to DB :: ", e);
							}
						}));
				if (transFailureLogLST.size() > 0)
					transactionFileLog.setReason(transFailureLogLST.stream().findFirst().get().getErrorMsg());
			}
			transFailureLogRepository.saveAll(transFailureLogLST);
			transactionFileLogRepository.save(transactionFileLog);

		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to update data to DB :: ", e);
			throw new Exception(" Internal Error: Unable to update data to DB ::", e);
		}
		log.info(this.getClass() + " updateTransactionDetails method called .");
	}

	public TransactionFileLog findByFileName(String fileName) throws Exception {
		TransactionFileLog transactionFileLog = null;
		log.info(this.getClass() + " findByFileName method called .");
		try {
			transactionFileLog = transactionFileLogRepository.findByFileName(fileName);
		} catch (Exception e) {
			log.info(this.getClass() + "Unable to find search data by fileName ::", e);
		}
		log.info(this.getClass() + " findByFileName method called .");
		return transactionFileLog;
	}

	public TransactionFileLog findByFileName(String fileName, String status) throws Exception {
		TransactionFileLog transactionFileLog = null;
		log.info(this.getClass() + " findByFileName method called .");
		try {
			transactionFileLog = transactionFileLogRepository.findByFileName(fileName, status);
		} catch (Exception e) {
			log.info(this.getClass() + "Unable to find search data by fileName ::", e);
		}
		log.info(this.getClass() + " findByFileName method called .");
		return transactionFileLog;
	}
	
	@Transactional
	public void saveFailureLogs(List<Object> list) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<TransFailureLog> dataDetails = list.stream().map(s -> (TransFailureLog) s).collect(Collectors.toList());
			log.info("TransFailure Details:: " + dataDetails);
			transFailureLogRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

}
