package com.excelacom.servicegateway.dao;


public interface TransactionDAO {
	
	String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName);
		
	String insertMNORequestDetails(String request, String responseId);
	
	void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId, String transGroupId, String serviceName);
	
	public String updateNorthBoundTransactionNcm(String transId, String entityId, String response, String groupId, String processPlanId,
			String serviceName, String status,String externalId, String responseId);
	

	public void updateNorthBoundTransactionFailure(String transId, String entityId,String groupId,String processPlanId,String serviceName, String responseId);
	
	public String tokenCheck(String token);

	void updateKOREAsyncSouthboundUrl(String returnUrl);
}
