package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String speedTestQueue;
	
	private String speedTestExchange;
	
	private String deleteSpeedTestQueue;
	
	private String deleteSpeedTestExchange;
	
	private String getConfigManagerQueue;
	
	private String getConfigManagerExchange;
	
    private String ncmDeviceAppIntegrationQueue;
	
	private String ncmDeviceAppIntegrationExchange;
	
	private String ncmNetDeviceHealthIntegrationQueue;
		
	private String ncmNetDeviceHealthIntegrationExchange;
	
	private String ncmProductIntegrationExchange;
	
	private String ncmproductIntegrationQueue;
	
    private String netDeviceIntegrationQueue;
	
	private String netDeviceIntegrationExchange;
	
    private String netDeviceMetricsQueue;
		
	private String netDeviceMetricsExchange;
	
	private String NcmNetDeviceSampleQueue;
	
	private String NcmNetDeviceSampleExchange;
	
    private String ncmGroupDeleteQueue;
	
	private String ncmGroupDeleteExchange;
	
    private String ncmAccountGetQueue;
	
	private String ncmAccountGetExchange;
	
	private String ncmPushNotificationQueue;

	private String ncmPushNotificationExchange;

	private String ncmAccountDeleteQueue;
		
    private String ncmAccountDeleteExchange;
    
	private String ncmDeviceAppsStateServiceQueue;
	
    private String ncmDeviceAppsStateServiceExchange;
	
    private String ncmGetRouterStateServiceQueue;
	
    private String ncmGetRouterStateServiceExchange;
    
    private String DeleteLocationServiceQueue;
	
    private String DeleteLocationServiceExchange;
    
    private String RouterLogsQueue;
	
    private String RouterLogsExchange;
    
    private String LocationServiceQueue;
	
    private String LocationServiceExchange;
    
    private String NcmFirmwareQueue;
	
    private String NcmFirmwareExchange;
    
    private String ncmnetdeviceusagesampleserviceQueue;
	
    private String ncmnetdeviceusagesampleserviceExchange;
    
    private String NcmLocationServiceCreateQueue;
	
    private String NcmLocationServiceCreateExchange;
    
    private String RouterStreamUsageSamplesIntegrationQueue;
	
    private String RouterStreamUsageSamplesIntegrationExchange;
    
    private String ncmRoutersallertsIntegrationQueue;
	
    private String ncmRoutersallertsIntegrationExchange;
    
    private String ncmGetGroupServiceQueue;
	
    private String ncmGetGroupServiceExchange;
    
    private String NCMGroupUpdateServiceQueue;
	
    private String NCMGroupUpdateServiceExchange;
    
    private String ncmGetDeviceAppVersionQueue;
	
    private String ncmGetDeviceAppVersionExchange;
    
    private String NcmgetRouterQueue;
	
    private String NcmgetrouterExchange;
    
    private String NcmgetactivitylogQueue;
	
    private String NcmgetactivitylogExchange;
    
    private String ncmAccountCreateQueue;
	
    private String ncmAccountCreateExchange;
    
    private String ncmRouterUpdateQueue;
	
    private String ncmRouterUpdateExchange;
    
    private String DeleteDeviceAppBindingsQueue;
	
    private String DeleteDeviceAppBindingsExchange;
    
    private String UpdateLocationServiceQueue;
	
    private String UpdateLocationServiceExchange;
	 
    private String ncmCreateGroupServiceQueue;
	
    private String ncmCreateGroupServiceExchange;
     
    private String ncmUpdateAccountSystemQueue;
	
    private String ncmUpdateAccountSystemExchange;
    
    private String NcmgetdeviceappbindinglogQueue;
	
    private String NcmgetdeviceappbindinglogExchange;
    
    private String NcmCreateSpeedlogQueue;
	
    private String NcmCreateSpeedlogExchange;
    
    private String ncmRouterDeleteQueue;
	
    private String ncmRouterDeleteExchange;
    
    private String nslDeviceAppsIntegrationServiceQueue;
	
    private String nslDeviceAppsIntegrationServiceExchange;
    
    private String deleteDeviceAppVersionQueue;
	
    private String deleteDeviceAppVersionExchange;
    
    private String NcmFailoversIntegrationServiceQueue;
	
    private String NcmFailoversIntegrationServiceExchange;
    
    private String NcmrebootQueue;
	
    private String NcmrebootExchange;
    
    private String NcmcreatedeviceappbindinglogExchange;
	
    private String NcmcreatedeviceappbindinglogQueue;
    
    private String NcmhistoricalloclogQueue;
	
    private String NcmhistoricalloclogExchange;
    
    private String NCMAllertIntegrationServiceQueue;
	
    private String NCMAllertIntegrationServiceExchange;
    
    private String NCMUpdateConfigMangerServiceQueue;
	
    private String NCMUpdateConfigMangerServiceExchange;
	
   
	
	

}
