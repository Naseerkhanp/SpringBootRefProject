package com.nsl.usagereport.uio;

import java.util.Date;

public class DataDetailsUIO {

	private String eventStart;
	public void setEventStart(String eventStart) {
		this.eventStart = eventStart;
	}

	private String eventStop;
	private Long timeZone;
	private Long techType;
	private Long dataUsed;
	

	private String footPrint;
	private String country;
	private Long recordType;
	
	private String dSource;


	public String getdSource() {
		return dSource;
	}

	public void setdSource(String dSource) {
		this.dSource = dSource;
	}

	public String getEventStart() {
		return eventStart;
	}

	public String getEventStop() {
		return eventStop;
	}

	public void setEventStop(String eventStop) {
		this.eventStop = eventStop;
	}

	public Long getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(Long timeZone) {
		this.timeZone = timeZone;
	}

	public Long getTechType() {
		return techType;
	}

	public void setTechType(Long techType) {
		this.techType = techType;
	}

	public String getFootPrint() {
		return footPrint;
	}

	public void setFootPrint(String footPrint) {
		this.footPrint = footPrint;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Long getRecordType() {
		return recordType;
	}

	public void setRecordType(Long recordType) {
		this.recordType = recordType;
	}
	
	public Long getDataUsed() {
		return dataUsed;
	}

	public void setDataUsed(Long dataUsed) {
		this.dataUsed = dataUsed;
	}

}
