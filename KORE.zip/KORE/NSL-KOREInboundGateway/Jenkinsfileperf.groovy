pipeline {
    agent any
	
    stages {
       
	   stage('Image Fetch') {
            steps {
            script {
            properties([
            parameters([
            string(
            name: 'Image_Name', 
            trim: true
            )
            ])
            ])
            }
            }
            }   
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-PERF-CICD@excelacom.in',
			to: 'devops@excelacom.in',
			subject: "NSL PERF kore Service Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }
	
	
        
		stage('NSL PERF - Configmap Inject') {
			steps {
			echo 'Applying DEVQAR1 Properties and Datasource Configurations...'
			sh 'kubectl create configmap perf-kore-properties --from-file=propertiesperf -n default -o yaml --dry-run | kubectl apply -f -'
			sh 'kubectl get configmaps perf-kore-properties -o yaml -n default'
                  }
        }
		stage('NSL PERF - EKS POD Deploy') {
			steps {
			echo 'kore Service POD Deployment has been started...'
			sh 'echo "pwd = $(pwd)"'
			sh 'sed -i "s/imagename/${Image_Name}/g" perf-kore-deployment.yaml '
			sh 'kubectl apply -f perf-kore-deployment.yaml'
			sh 'kubectl apply -f perf-kore-service.yaml'
			sh 'kubectl apply -f perf-kore-service-apm.yaml'
			
                  }
        }
		stage('NSL PERF - EKS POD Status') {
		    steps {
			echo 'kore Service POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep kore-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-PERF-CICD@excelacom.in',
		  to: 'devops@excelacom.in',
		  attachLog: true,
		  //attachmentsPattern: 'CodeQuality.txt',
		  subject: "NSL PERF kore Service Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-PERF-CICD@excelacom.in',
		  to: 'devops@excelacom.in',
		  attachLog: true,
		  //attachmentsPattern: 'CodeQuality.txt',
		  subject: "NSL PERF kore Service Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }