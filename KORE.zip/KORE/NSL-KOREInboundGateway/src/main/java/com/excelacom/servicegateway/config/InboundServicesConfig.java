package com.excelacom.servicegateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.util.ErrorHandler;

import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import com.excelacom.servicegateway.properties.InboundQueueProperties;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;

	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}

	@Bean
	public Queue activateDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getActivateDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange activateDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getActivateDeviceExchange());
	}

	@Bean
	Binding activateDeviceBinding() {
		return BindingBuilder.bind(activateDeviceQueue()).to(activateDeviceExchange())
				.with(inboundQueueProperties.getActivateDeviceQueue());
	}
	
	@Bean
	public Queue simAssociateToGroupQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSimAssociateToGroupQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange simAssociateToGroupExchange() {
		return new DirectExchange(inboundQueueProperties.getSimAssociateToGroupExchange());
	}

	@Bean
	Binding simAssociateToGroupBinding() {
		return BindingBuilder.bind(simAssociateToGroupQueue()).to(simAssociateToGroupExchange())
				.with(inboundQueueProperties.getSimAssociateToGroupQueue());
	}
	
		@Bean
	public Queue queryDeviceUsageBySimQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryDeviceUsageBySimQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryDeviceUsageBySimExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryDeviceUsageBySimExchange());
	}

	@Bean
	Binding queryDeviceUsageBySimBinding() {
		return BindingBuilder.bind(queryDeviceUsageBySimQueue()).to(queryDeviceUsageBySimExchange())
				.with(inboundQueueProperties.getQueryDeviceUsageBySimQueue());
	}
	
	
	@Bean
	public Queue activateToStateQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getActivateToStateQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange activateToStateExchange() {
		return new DirectExchange(inboundQueueProperties.getActivateToStateExchange());
	}

	@Bean
	Binding activateToStateBinding() {
		return BindingBuilder.bind(activateToStateQueue()).to(activateToStateExchange())
				.with(inboundQueueProperties.getActivateToStateQueue());
	}
	@Bean
	public ErrorHandler errorHandler() {
		return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}

	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
		return new CustomFatalExceptionStrategy();
	}

	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}
	
		@Bean
	public Queue QueryFeatureCodesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryFeatureCodesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange QueryFeatureCodesExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryFeatureCodesExchange());
	}

	@Bean
	Binding QueryFeatureCodesBinding() {
		return BindingBuilder.bind(QueryFeatureCodesQueue()).to(QueryFeatureCodesExchange())
				.with(inboundQueueProperties.getQueryFeatureCodesQueue());
	}
	
	

	@Bean
	public Queue KoreQueryDeviceUsageQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreQueryDeviceUsageQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreQueryDeviceUsageExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreQueryDeviceUsageExchange());
	}

	@Bean
	Binding KoreQueryDeviceUsageBinding() {
		return BindingBuilder.bind(KoreQueryDeviceUsageQueue()).to(KoreQueryDeviceUsageExchange())
			.with(inboundQueueProperties.getKoreQueryDeviceUsageQueue());
	}
	
	@Bean
	public Queue ncmModifyDevicePlanForNxtPrdQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange ncmModifyDevicePlanForNxtPrdExchange() {
		return new DirectExchange(inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdExchange());
	}

	@Bean
	Binding ncmModifyDevicePlanForNxtPrdBinding() {
		return BindingBuilder.bind(ncmModifyDevicePlanForNxtPrdQueue()).to(ncmModifyDevicePlanForNxtPrdExchange())
				.with(inboundQueueProperties.getNCMModifyDevicePlanForNxtPrdQueue());
	}
	
	@Bean
	public Queue KoreChangeSimStatusQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreChangeSimStatusQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreChangeSimStatusExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreChangeSimStatusExchange());
	}

	@Bean
	Binding KoreChangeSimStatusStateBinding() {
		return BindingBuilder.bind(KoreChangeSimStatusQueue()).to(KoreChangeSimStatusExchange())
				.with(inboundQueueProperties.getKoreChangeSimStatusQueue());
	}
	
	
	@Bean
	public Queue KoreQueryAvailableReportFilesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreQueryAvailableReportFilesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreQueryAvailableReportFilesExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreQueryAvailableReportFilesExchange());
	}

	@Bean
	Binding KoreQueryAvailableReportFilesBinding() {
		return BindingBuilder.bind(KoreQueryAvailableReportFilesQueue()).to(KoreQueryAvailableReportFilesExchange())
				.with(inboundQueueProperties.getKoreQueryAvailableReportFilesQueue());
	}
	
	@Bean
	public Queue koreUnbarToStateQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreUnbarToStateQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange koreUnbarToStateExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreUnbarToStateExchange());
	}

	@Bean
	Binding koreUnbarToStateExchangeBinding() {
		return BindingBuilder.bind(koreUnbarToStateQueue()).to(koreUnbarToStateExchange())
				.with(inboundQueueProperties.getKoreUnbarToStateQueue());
	}

	
	@Bean
	public Queue acknowlegdeAlertBySimAndRuleQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange acknowlegdeAlertBySimAndRuleExchange() {
		return new DirectExchange(inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleExchange());
	}

	@Bean
	Binding acknowlegdeAlertBySimAndRuleBinding() {
		return BindingBuilder.bind(acknowlegdeAlertBySimAndRuleQueue()).to(acknowlegdeAlertBySimAndRuleExchange())
				.with(inboundQueueProperties.getAcknowlegdeAlertBySimAndRuleQueue());
	}

	@Bean(name = "ConnectionFactory")
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}

	@Bean("customRabbitTemplate")
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}
	
	
	@Bean
	public Queue KoreQuerygetEapCodeQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreQuerygetEapCodeQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreQuerygetEapCodeExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreQuerygetEapCodeExchange());
	}

	@Bean
	Binding KoreQuerygetEapCodeBinding() {
		return BindingBuilder.bind(KoreQuerygetEapCodeQueue()).to(KoreQuerygetEapCodeExchange())
				.with(inboundQueueProperties.getKoreQuerygetEapCodeQueue());
	}
	
	
	@Bean
	public Queue KoreQuerygetEapDetailsQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreQuerygetEapDetailsQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreQuerygetEapDetailsExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreQuerygetEapDetailsExchange());
	}

	@Bean
	Binding KoreQuerygetEapDetailsBinding() {
		return BindingBuilder.bind(KoreQuerygetEapDetailsQueue()).to(KoreQuerygetEapDetailsExchange())
				.with(inboundQueueProperties.getKoreQuerygetEapDetailsQueue());
	}
	
	//KoreQueryPlanCodeNextPeriod
	@Bean
	public Queue KoreQueryPlanCodeNextPeriodQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreQueryPlanCodeNextPeriodQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreQueryPlanCodeNextPeriodExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreQueryPlanCodeNextPeriodExchange());
	}

	@Bean
	Binding KoreQueryPlanCodeNextPeriodBinding() {
		return BindingBuilder.bind(KoreQueryPlanCodeNextPeriodQueue()).to(KoreQueryPlanCodeNextPeriodExchange())
				.with(inboundQueueProperties.getKoreQueryPlanCodeNextPeriodQueue());
	}
	
	//SIM Radius Query
	@Bean
	public Queue KoreSIMRadiusQueryQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKoreSIMRadiusQueryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange KoreSIMRadiusQueryExchange() {
		return new DirectExchange(inboundQueueProperties.getKoreSIMRadiusQueryExchange());
	}

	@Bean
	Binding KoreSIMRadiusQueryBinding() {
		return BindingBuilder.bind(KoreSIMRadiusQueryQueue()).to(KoreSIMRadiusQueryExchange())
				.with(inboundQueueProperties.getKoreSIMRadiusQueryQueue());
	}
	
	@Bean
	public Queue costCentersQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getCostCentersQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange costCentersExchange() {
		return new DirectExchange(inboundQueueProperties.getCostCentersExchange());
	}

	@Bean
	Binding costCentersBinding() {
		return BindingBuilder.bind(costCentersQueue()).to(costCentersExchange())
				.with(inboundQueueProperties.getCostCentersQueue());
	}
	
	@Bean
	public Queue queryRequestStatusQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryRequestStatusQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryRequestStatusExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryRequestStatusExchange());
	}

	@Bean
	Binding queryRequestStatusBinding() {
		return BindingBuilder.bind(queryRequestStatusQueue()).to(queryRequestStatusExchange())
				.with(inboundQueueProperties.getQueryRequestStatusQueue());
	}
	
	@Bean
	public Queue queryServiceTypeCodesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryServiceTypeCodesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryServiceTypeCodesExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryServiceTypeCodesExchange());
	}

	@Bean
	Binding queryServiceTypeCodesBinding() {
		return BindingBuilder.bind(queryServiceTypeCodesQueue()).to(queryServiceTypeCodesExchange())
				.with(inboundQueueProperties.getQueryServiceTypeCodesQueue());
	}
	
	@Bean
	public Queue acknowledgeAlertsbyGroupQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getAcknowledgeAlertsbyGroupQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange acknowledgeAlertsbyGroupExchange() {
		return new DirectExchange(inboundQueueProperties.getAcknowledgeAlertsbyGroupExchange());
	}

	@Bean
	Binding acknowledgeAlertsbyGroupBinding() {
		return BindingBuilder.bind(acknowledgeAlertsbyGroupQueue()).to(acknowledgeAlertsbyGroupExchange())
				.with(inboundQueueProperties.getAcknowledgeAlertsbyGroupQueue());
	}
	@Bean
	public Queue mdCustomInfoQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getMdCustomInfoQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange mdCustomInfoExchange() {
		return new DirectExchange(inboundQueueProperties.getMdCustomInfoExchange());
	}

	@Bean
	Binding mdCustomInfoBinding() {
		return BindingBuilder.bind(mdCustomInfoQueue()).to(mdCustomInfoExchange())
				.with(inboundQueueProperties.getMdCustomInfoQueue());
	}
	
	@Bean(name = "getCostCentersConnectionFactory")
	public ConnectionFactory getCostCentersrabbitMQConnectionFactory() {
		CachingConnectionFactory getCostCentersconnectionFactory = new CachingConnectionFactory(host);
		getCostCentersconnectionFactory.setPort(Integer.parseInt(port));
		getCostCentersconnectionFactory.setUsername(username);
		getCostCentersconnectionFactory.setPassword(password);
		getCostCentersconnectionFactory.setConnectionTimeout(30000);
		return getCostCentersconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getCostCentersRabbitAdmin(){
        return new RabbitAdmin(getCostCentersrabbitMQConnectionFactory());
    }
	
	
	@Bean("getCostCentersrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getCostCentersrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getCostCentersfactory = new SimpleRabbitListenerContainerFactory();
		getCostCentersfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getCostCentersfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getCostCentersfactory.setPrefetchCount(1);
		getCostCentersfactory.setReceiveTimeout((long) 50000);
		getCostCentersfactory.setConnectionFactory(getCostCentersrabbitMQConnectionFactory());
		return getCostCentersfactory;
	}

	
	
	@Bean()
	public RabbitTemplate getCostCenterscustomRabbitTemplate() {
		RabbitTemplate getCostCentersrabbitTemplate = new RabbitTemplate();
		getCostCentersrabbitTemplate.setReplyTimeout(30000L);
		getCostCentersrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getCostCentersrabbitTemplate.setConnectionFactory(getCostCentersrabbitMQConnectionFactory());
		return getCostCentersrabbitTemplate;
	}
	
	@Bean(name = "queryRequestStatusConnectionFactory")
	public ConnectionFactory queryRequestStatusrabbitMQConnectionFactory() {
		CachingConnectionFactory queryRequestStatusconnectionFactory = new CachingConnectionFactory(host);
		queryRequestStatusconnectionFactory.setPort(Integer.parseInt(port));
		queryRequestStatusconnectionFactory.setUsername(username);
		queryRequestStatusconnectionFactory.setPassword(password);
		queryRequestStatusconnectionFactory.setConnectionTimeout(30000);
		return queryRequestStatusconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin queryRequestStatusRabbitAdmin(){
        return new RabbitAdmin(queryRequestStatusrabbitMQConnectionFactory());
    }
	
	
	@Bean("queryRequestStatusrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory queryRequestStatusrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory queryRequestStatusfactory = new SimpleRabbitListenerContainerFactory();
		queryRequestStatusfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		queryRequestStatusfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		queryRequestStatusfactory.setPrefetchCount(1);
		queryRequestStatusfactory.setReceiveTimeout((long) 50000);
		queryRequestStatusfactory.setConnectionFactory(queryRequestStatusrabbitMQConnectionFactory());
		return queryRequestStatusfactory;
	}

	
	
	@Bean()
	public RabbitTemplate queryRequestStatuscustomRabbitTemplate() {
		RabbitTemplate queryRequestStatusrabbitTemplate = new RabbitTemplate();
		queryRequestStatusrabbitTemplate.setReplyTimeout(30000L);
		queryRequestStatusrabbitTemplate.setMessageConverter(jsonMessageConverter());
		queryRequestStatusrabbitTemplate.setConnectionFactory(queryRequestStatusrabbitMQConnectionFactory());
		return queryRequestStatusrabbitTemplate;
	}
	
	
	@Bean(name = "queryServiceTypeCodesConnectionFactory")
	public ConnectionFactory queryServiceTypeCodesrabbitMQConnectionFactory() {
		CachingConnectionFactory queryServiceTypeCodesconnectionFactory = new CachingConnectionFactory(host);
		queryServiceTypeCodesconnectionFactory.setPort(Integer.parseInt(port));
		queryServiceTypeCodesconnectionFactory.setUsername(username);
		queryServiceTypeCodesconnectionFactory.setPassword(password);
		queryServiceTypeCodesconnectionFactory.setConnectionTimeout(30000);
		return queryServiceTypeCodesconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin queryServiceTypeCodesRabbitAdmin(){
        return new RabbitAdmin(queryServiceTypeCodesrabbitMQConnectionFactory());
    }
	
	
	@Bean("queryServiceTypeCodesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory queryServiceTypeCodesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory queryServiceTypeCodesfactory = new SimpleRabbitListenerContainerFactory();
		queryServiceTypeCodesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		queryServiceTypeCodesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		queryServiceTypeCodesfactory.setPrefetchCount(1);
		queryServiceTypeCodesfactory.setReceiveTimeout((long) 50000);
		queryServiceTypeCodesfactory.setConnectionFactory(queryServiceTypeCodesrabbitMQConnectionFactory());
		return queryServiceTypeCodesfactory;
	}

	
	
	@Bean()
	public RabbitTemplate queryServiceTypeCodescustomRabbitTemplate() {
		RabbitTemplate queryServiceTypeCodesrabbitTemplate = new RabbitTemplate();
		queryServiceTypeCodesrabbitTemplate.setReplyTimeout(30000L);
		queryServiceTypeCodesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		queryServiceTypeCodesrabbitTemplate.setConnectionFactory(queryServiceTypeCodesrabbitMQConnectionFactory());
		return queryServiceTypeCodesrabbitTemplate;
	}
	
	@Bean(name = "acknowledgeAlertsbyGroupConnectionFactory")
	public ConnectionFactory acknowledgeAlertsbyGrouprabbitMQConnectionFactory() {
		CachingConnectionFactory acknowledgeAlertsbyGroupconnectionFactory = new CachingConnectionFactory(host);
		acknowledgeAlertsbyGroupconnectionFactory.setPort(Integer.parseInt(port));
		acknowledgeAlertsbyGroupconnectionFactory.setUsername(username);
		acknowledgeAlertsbyGroupconnectionFactory.setPassword(password);
		acknowledgeAlertsbyGroupconnectionFactory.setConnectionTimeout(30000);
		return acknowledgeAlertsbyGroupconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin acknowledgeAlertsbyGroupRabbitAdmin(){
        return new RabbitAdmin(acknowledgeAlertsbyGrouprabbitMQConnectionFactory());
    }
	
	
	@Bean("acknowledgeAlertsbyGrouprabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory acknowledgeAlertsbyGrouprabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory acknowledgeAlertsbyGroupfactory = new SimpleRabbitListenerContainerFactory();
		acknowledgeAlertsbyGroupfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		acknowledgeAlertsbyGroupfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		acknowledgeAlertsbyGroupfactory.setPrefetchCount(1);
		acknowledgeAlertsbyGroupfactory.setReceiveTimeout((long) 50000);
		acknowledgeAlertsbyGroupfactory.setConnectionFactory(acknowledgeAlertsbyGrouprabbitMQConnectionFactory());
		return acknowledgeAlertsbyGroupfactory;
	}

	
	
	@Bean()
	public RabbitTemplate acknowledgeAlertsbyGroupcustomRabbitTemplate() {
		RabbitTemplate acknowledgeAlertsbyGrouprabbitTemplate = new RabbitTemplate();
		acknowledgeAlertsbyGrouprabbitTemplate.setReplyTimeout(30000L);
		acknowledgeAlertsbyGrouprabbitTemplate.setMessageConverter(jsonMessageConverter());
		acknowledgeAlertsbyGrouprabbitTemplate.setConnectionFactory(acknowledgeAlertsbyGrouprabbitMQConnectionFactory());
		return acknowledgeAlertsbyGrouprabbitTemplate;
	}
	
	
	@Bean(name = "getMdCustomInfoConnectionFactory")
	public ConnectionFactory getMdCustomInforabbitMQConnectionFactory() {
		CachingConnectionFactory getMdCustomInfoconnectionFactory = new CachingConnectionFactory(host);
		getMdCustomInfoconnectionFactory.setPort(Integer.parseInt(port));
		getMdCustomInfoconnectionFactory.setUsername(username);
		getMdCustomInfoconnectionFactory.setPassword(password);
		getMdCustomInfoconnectionFactory.setConnectionTimeout(30000);
		return getMdCustomInfoconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getMdCustomInfoRabbitAdmin(){
        return new RabbitAdmin(getMdCustomInforabbitMQConnectionFactory());
    }
	
	
	@Bean("getMdCustomInforabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getMdCustomInforabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getMdCustomInfofactory = new SimpleRabbitListenerContainerFactory();
		getMdCustomInfofactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getMdCustomInfofactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getMdCustomInfofactory.setPrefetchCount(1);
		getMdCustomInfofactory.setReceiveTimeout((long) 50000);
		getMdCustomInfofactory.setConnectionFactory(getMdCustomInforabbitMQConnectionFactory());
		return getMdCustomInfofactory;
	}

	
	@Bean()
	public RabbitTemplate getMdCustomInfocustomRabbitTemplate() {
		RabbitTemplate getMdCustomInforabbitTemplate = new RabbitTemplate();
		getMdCustomInforabbitTemplate.setReplyTimeout(30000L);
		getMdCustomInforabbitTemplate.setMessageConverter(jsonMessageConverter());
		getMdCustomInforabbitTemplate.setConnectionFactory(getMdCustomInforabbitMQConnectionFactory());
		return getMdCustomInforabbitTemplate;
	}
	

	@Bean
	public Queue disconnectDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDisconnectDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange disconnectDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getDisconnectDeviceExchange());
	}

	@Bean
	Binding disconnectDeviceBinding() {
		return BindingBuilder.bind(disconnectDeviceQueue()).to(disconnectDeviceExchange())
				.with(inboundQueueProperties.getDisconnectDeviceQueue());
	}

	@Bean("disconnectDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory disconnectDevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory disconnectDevicefactory = new SimpleRabbitListenerContainerFactory();
		disconnectDevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		disconnectDevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		disconnectDevicefactory.setPrefetchCount(1);
		disconnectDevicefactory.setReceiveTimeout((long) 50000);
		disconnectDevicefactory.setConnectionFactory(disconnectDevicerabbitMQConnectionFactory());
		disconnectDevicefactory.setErrorHandler(errorHandler());
		return disconnectDevicefactory;
	}

	@Bean()
	public RabbitTemplate disconnectDevicecustomRabbitTemplate() {
		RabbitTemplate disconnectDevicerabbitTemplate = new RabbitTemplate();
		disconnectDevicerabbitTemplate.setReplyTimeout(30000L);
		disconnectDevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		disconnectDevicerabbitTemplate.setConnectionFactory(disconnectDevicerabbitMQConnectionFactory());
		return disconnectDevicerabbitTemplate;
	}

	@Bean(name = "disconnectDeviceConnectionFactory")
	public ConnectionFactory disconnectDevicerabbitMQConnectionFactory() {
		CachingConnectionFactory disconnectDeviceconnectionFactory = new CachingConnectionFactory(host);
		disconnectDeviceconnectionFactory.setPort(Integer.parseInt(port));
		disconnectDeviceconnectionFactory.setUsername(username);
		disconnectDeviceconnectionFactory.setPassword(password);
		disconnectDeviceconnectionFactory.setConnectionTimeout(30000);
		return disconnectDeviceconnectionFactory;
	}

	@Bean()
	RabbitAdmin disconnectDeviceRabbitAdmin() {
		return new RabbitAdmin(disconnectDevicerabbitMQConnectionFactory());
	}
	
	@Bean(name = "getKoreQueryEapCodeConnectionFactory")
	public ConnectionFactory getKoreQueryEapCoderabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreQueryEapCodeconnectionFactory = new CachingConnectionFactory(host);
		getKoreQueryEapCodeconnectionFactory.setPort(Integer.parseInt(port));
		getKoreQueryEapCodeconnectionFactory.setUsername(username);
		getKoreQueryEapCodeconnectionFactory.setPassword(password);
		getKoreQueryEapCodeconnectionFactory.setConnectionTimeout(30000);
		return getKoreQueryEapCodeconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getKoreQueryEapCodeRabbitAdmin(){
        return new RabbitAdmin(getKoreQueryEapCoderabbitMQConnectionFactory());
    }
	
	@Bean("getKoreQueryEapCoderabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKoreQueryEapCoderabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreQueryEapCodefactory = new SimpleRabbitListenerContainerFactory();
		getKoreQueryEapCodefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreQueryEapCodefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreQueryEapCodefactory.setPrefetchCount(1);
		getKoreQueryEapCodefactory.setReceiveTimeout((long) 50000);
		getKoreQueryEapCodefactory.setConnectionFactory(getKoreQueryEapCoderabbitMQConnectionFactory());
		return getKoreQueryEapCodefactory;
	}

	
	@Bean()
	public RabbitTemplate getKoreQueryEapCodecustomRabbitTemplate() {
		RabbitTemplate getKoreQueryEapCoderabbitTemplate = new RabbitTemplate();
		getKoreQueryEapCoderabbitTemplate.setReplyTimeout(30000L);
		getKoreQueryEapCoderabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreQueryEapCoderabbitTemplate.setConnectionFactory(getKoreQueryEapCoderabbitMQConnectionFactory());
		return getKoreQueryEapCoderabbitTemplate;
	}
	
	@Bean(name = "getKoreQueryEapDetailsConnectionFactory")
	public ConnectionFactory getKoreQueryEapDetailsrabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreQueryEapDetailsconnectionFactory = new CachingConnectionFactory(host);
		getKoreQueryEapDetailsconnectionFactory.setPort(Integer.parseInt(port));
		getKoreQueryEapDetailsconnectionFactory.setUsername(username);
		getKoreQueryEapDetailsconnectionFactory.setPassword(password);
		getKoreQueryEapDetailsconnectionFactory.setConnectionTimeout(30000);
		return getKoreQueryEapDetailsconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getKoreQueryEapDetailsRabbitAdmin(){
        return new RabbitAdmin(getKoreQueryEapDetailsrabbitMQConnectionFactory());
    }
	
	@Bean("getKoreQueryEapDetailsrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKoreQueryEapDetailsrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreQueryEapDetailsfactory = new SimpleRabbitListenerContainerFactory();
		getKoreQueryEapDetailsfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreQueryEapDetailsfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreQueryEapDetailsfactory.setPrefetchCount(1);
		getKoreQueryEapDetailsfactory.setReceiveTimeout((long) 50000);
		getKoreQueryEapDetailsfactory.setConnectionFactory(getKoreQueryEapDetailsrabbitMQConnectionFactory());
		return getKoreQueryEapDetailsfactory;
	}

	
	@Bean()
	public RabbitTemplate getKoreQueryEapDetailscustomRabbitTemplate() {
		RabbitTemplate getKoreQueryEapDetailsrabbitTemplate = new RabbitTemplate();
		getKoreQueryEapDetailsrabbitTemplate.setReplyTimeout(30000L);
		getKoreQueryEapDetailsrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreQueryEapDetailsrabbitTemplate.setConnectionFactory(getKoreQueryEapDetailsrabbitMQConnectionFactory());
		return getKoreQueryEapDetailsrabbitTemplate;
	} 
	
	//QueryPlanCodeNextPeriod
	@Bean(name = "getKoreQueryPlanCodeNextPeriodConnectionFactory")
	public ConnectionFactory getKoreQueryPlanCodeNextPeriodrabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreQueryPlanCodeNextPeriodconnectionFactory = new CachingConnectionFactory(host);
		getKoreQueryPlanCodeNextPeriodconnectionFactory.setPort(Integer.parseInt(port));
		getKoreQueryPlanCodeNextPeriodconnectionFactory.setUsername(username);
		getKoreQueryPlanCodeNextPeriodconnectionFactory.setPassword(password);
		getKoreQueryPlanCodeNextPeriodconnectionFactory.setConnectionTimeout(30000);
		return getKoreQueryPlanCodeNextPeriodconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getKoreQueryPlanCodeNextPeriodRabbitAdmin(){
        return new RabbitAdmin(getKoreQueryPlanCodeNextPeriodrabbitMQConnectionFactory());
    }
	
	@Bean("getKoreQueryPlanCodeNextPeriodrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKoreQueryPlanCodeNextPeriodrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreQueryPlanCodeNextPeriodfactory = new SimpleRabbitListenerContainerFactory();
		getKoreQueryPlanCodeNextPeriodfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreQueryPlanCodeNextPeriodfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreQueryPlanCodeNextPeriodfactory.setPrefetchCount(1);
		getKoreQueryPlanCodeNextPeriodfactory.setReceiveTimeout((long) 50000);
		getKoreQueryPlanCodeNextPeriodfactory.setConnectionFactory(getKoreQueryPlanCodeNextPeriodrabbitMQConnectionFactory());
		return getKoreQueryPlanCodeNextPeriodfactory;
	}

	
	@Bean()
	public RabbitTemplate getKoreQueryPlanCodeNextPeriodcustomRabbitTemplate() {
		RabbitTemplate getKoreQueryPlanCodeNextPeriodrabbitTemplate = new RabbitTemplate();
		getKoreQueryPlanCodeNextPeriodrabbitTemplate.setReplyTimeout(30000L);
		getKoreQueryPlanCodeNextPeriodrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreQueryPlanCodeNextPeriodrabbitTemplate.setConnectionFactory(getKoreQueryPlanCodeNextPeriodrabbitMQConnectionFactory());
		return getKoreQueryPlanCodeNextPeriodrabbitTemplate;
	}
	
	//SIM Radius Query
	@Bean(name = "getKoreSIMRadiusQueryConnectionFactory")
	public ConnectionFactory getKoreSIMRadiusQueryrabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreSIMRadiusQueryconnectionFactory = new CachingConnectionFactory(host);
		getKoreSIMRadiusQueryconnectionFactory.setPort(Integer.parseInt(port));
		getKoreSIMRadiusQueryconnectionFactory.setUsername(username);
		getKoreSIMRadiusQueryconnectionFactory.setPassword(password);
		getKoreSIMRadiusQueryconnectionFactory.setConnectionTimeout(30000);
		return getKoreSIMRadiusQueryconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getKoreSIMRadiusQueryRabbitAdmin(){
        return new RabbitAdmin(getKoreSIMRadiusQueryrabbitMQConnectionFactory());
    }
	
	
	@Bean("getKoreSIMRadiusQueryrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKoreSIMRadiusQueryrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreSIMRadiusQueryThresholdfactory = new SimpleRabbitListenerContainerFactory();
		getKoreSIMRadiusQueryThresholdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreSIMRadiusQueryThresholdfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreSIMRadiusQueryThresholdfactory.setPrefetchCount(1);
		getKoreSIMRadiusQueryThresholdfactory.setReceiveTimeout((long) 50000);
		getKoreSIMRadiusQueryThresholdfactory.setConnectionFactory(getKoreSIMRadiusQueryrabbitMQConnectionFactory());
		return getKoreSIMRadiusQueryThresholdfactory;
	}

	
	@Bean()
	public RabbitTemplate getKoreSIMRadiusQuerycustomRabbitTemplate() {
		RabbitTemplate getKoreSIMRadiusQueryrabbitTemplate = new RabbitTemplate();
		getKoreSIMRadiusQueryrabbitTemplate.setReplyTimeout(30000L);
		getKoreSIMRadiusQueryrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreSIMRadiusQueryrabbitTemplate.setConnectionFactory(getKoreSIMRadiusQueryrabbitMQConnectionFactory());
		return getKoreSIMRadiusQueryrabbitTemplate;
	}
	
	@Bean
	public Queue changemsisdnQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getChangemsisdnQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange changemsisdnExchange() {
		return new DirectExchange(inboundQueueProperties.getChangemsisdnExchange());
	}

	@Bean
	Binding changemsisdnBinding() {
		return BindingBuilder.bind(changemsisdnQueue()).to(changemsisdnExchange())
				.with(inboundQueueProperties.getChangemsisdnQueue());
	}

	@Bean
	public Queue deactivatedeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDeactivatedeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange deactivatedeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getDeactivatedeviceExchange());
	}

	@Bean
	Binding deactivatedeviceBinding() {
		return BindingBuilder.bind(deactivatedeviceQueue()).to(deactivatedeviceExchange())
				.with(inboundQueueProperties.getDeactivatedeviceQueue());
	}
	
		@Bean(name = "getChangemsisdnConnectionFactory")
	public ConnectionFactory getChangemsisdnrabbitMQConnectionFactory() {
		CachingConnectionFactory getChangemsisdnconnectionFactory = new CachingConnectionFactory(host);
		getChangemsisdnconnectionFactory.setPort(Integer.parseInt(port));
		getChangemsisdnconnectionFactory.setUsername(username);
		getChangemsisdnconnectionFactory.setPassword(password);
		getChangemsisdnconnectionFactory.setConnectionTimeout(30000);
		return getChangemsisdnconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getChangemsisdnRabbitAdmin(){
        return new RabbitAdmin(getChangemsisdnrabbitMQConnectionFactory());
    }
	
	
	@Bean("getChangemsisdnrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getChangemsisdnrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getChangemsisdnfactory = new SimpleRabbitListenerContainerFactory();
		getChangemsisdnfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getChangemsisdnfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getChangemsisdnfactory.setPrefetchCount(1);
		getChangemsisdnfactory.setReceiveTimeout((long) 50000);
		getChangemsisdnfactory.setConnectionFactory(getChangemsisdnrabbitMQConnectionFactory());
		return getChangemsisdnfactory;
	}

	
	@Bean()
	public RabbitTemplate getChangemsisdncustomRabbitTemplate() {
		RabbitTemplate getChangemsisdnrabbitTemplate = new RabbitTemplate();
		getChangemsisdnrabbitTemplate.setReplyTimeout(30000L);
		getChangemsisdnrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getChangemsisdnrabbitTemplate.setConnectionFactory(getChangemsisdnrabbitMQConnectionFactory());
		return getChangemsisdnrabbitTemplate;
	}
	
	@Bean(name = "getDeactivatedeviceConnectionFactory")
	public ConnectionFactory getDeactivatedevicerabbitMQConnectionFactory() {
		CachingConnectionFactory getDeactivatedeviceconnectionFactory = new CachingConnectionFactory(host);
		getDeactivatedeviceconnectionFactory.setPort(Integer.parseInt(port));
		getDeactivatedeviceconnectionFactory.setUsername(username);
		getDeactivatedeviceconnectionFactory.setPassword(password);
		getDeactivatedeviceconnectionFactory.setConnectionTimeout(30000);
		return getDeactivatedeviceconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getDeactivatedeviceRabbitAdmin(){
        return new RabbitAdmin(getDeactivatedevicerabbitMQConnectionFactory());
    }
	
	
	@Bean("getDeactivatedevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getDeactivatedevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getDeactivatedevicefactory = new SimpleRabbitListenerContainerFactory();
		getDeactivatedevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getDeactivatedevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getDeactivatedevicefactory.setPrefetchCount(1);
		getDeactivatedevicefactory.setReceiveTimeout((long) 50000);
		getDeactivatedevicefactory.setConnectionFactory(getDeactivatedevicerabbitMQConnectionFactory());
		return getDeactivatedevicefactory;
	}

	
	@Bean()
	public RabbitTemplate getDeactivatedevicecustomRabbitTemplate() {
		RabbitTemplate getDeactivatedevicerabbitTemplate = new RabbitTemplate();
		getDeactivatedevicerabbitTemplate.setReplyTimeout(30000L);
		getDeactivatedevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		getDeactivatedevicerabbitTemplate.setConnectionFactory(getDeactivatedevicerabbitMQConnectionFactory());
		return getDeactivatedevicerabbitTemplate; 
	}
		
	@Bean(name = "getActivateDeviceConnectionFactory")
	public ConnectionFactory getActivateDevicerabbitMQConnectionFactory() {
		CachingConnectionFactory getActivateDeviceConnectionFactory = new CachingConnectionFactory(host);
		getActivateDeviceConnectionFactory.setPort(Integer.parseInt(port));
		getActivateDeviceConnectionFactory.setUsername(username);
		getActivateDeviceConnectionFactory.setPassword(password);
		getActivateDeviceConnectionFactory.setConnectionTimeout(30000);
		return getActivateDeviceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getActivateDeviceRabbitAdmin(){
        return new RabbitAdmin(getActivateDevicerabbitMQConnectionFactory());
    }
	
	
	@Bean("getActivateDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getActivateDevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getActivateDeviceFactory = new SimpleRabbitListenerContainerFactory();
		getActivateDeviceFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getActivateDeviceFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getActivateDeviceFactory.setPrefetchCount(1);
		getActivateDeviceFactory.setReceiveTimeout((long) 50000);
		getActivateDeviceFactory.setConnectionFactory(getActivateDevicerabbitMQConnectionFactory());
		return getActivateDeviceFactory;
	}

	
	@Bean()
	public RabbitTemplate getActivateDevicecustomRabbitTemplate() {
		RabbitTemplate getActivateDevicerabbitTemplate = new RabbitTemplate();
		getActivateDevicerabbitTemplate.setReplyTimeout(30000L);
		getActivateDevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		getActivateDevicerabbitTemplate.setConnectionFactory(getActivateDevicerabbitMQConnectionFactory());
		return getActivateDevicerabbitTemplate;
	}
	
	
	
	
	
	@Bean(name = "getSimAssociateToGroupConnectionFactory")
	public ConnectionFactory getSimAssociateToGrouprabbitMQConnectionFactory() {
		CachingConnectionFactory getSimAssociateToGroupConnectionFactory = new CachingConnectionFactory(host);
		getSimAssociateToGroupConnectionFactory.setPort(Integer.parseInt(port));
		getSimAssociateToGroupConnectionFactory.setUsername(username);
		getSimAssociateToGroupConnectionFactory.setPassword(password);
		getSimAssociateToGroupConnectionFactory.setConnectionTimeout(30000);
		return getSimAssociateToGroupConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getSimAssociateToGroupRabbitAdmin(){
        return new RabbitAdmin(getSimAssociateToGrouprabbitMQConnectionFactory());
    }
	
	@Bean("getSimAssociateToGrouprabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getSimAssociateToGrouprabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getSimAssociateToGroupFactory = new SimpleRabbitListenerContainerFactory();
		getSimAssociateToGroupFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getSimAssociateToGroupFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getSimAssociateToGroupFactory.setPrefetchCount(1);
		getSimAssociateToGroupFactory.setReceiveTimeout((long) 50000);
		getSimAssociateToGroupFactory.setConnectionFactory(getSimAssociateToGrouprabbitMQConnectionFactory());
		return getSimAssociateToGroupFactory;
	}
	
	@Bean()
	public RabbitTemplate getSimAssociateToGroupcustomRabbitTemplate() {
		RabbitTemplate getSimAssociateToGrouprabbitTemplate = new RabbitTemplate();
		getSimAssociateToGrouprabbitTemplate.setReplyTimeout(30000L);
		getSimAssociateToGrouprabbitTemplate.setMessageConverter(jsonMessageConverter());
		getSimAssociateToGrouprabbitTemplate.setConnectionFactory(getSimAssociateToGrouprabbitMQConnectionFactory());
		return getSimAssociateToGrouprabbitTemplate;
	}
	
	@Bean(name = "getActivateToStateConnectionFactory")
	public ConnectionFactory getActivateToStaterabbitMQConnectionFactory() {
		CachingConnectionFactory getActivateToStateConnectionFactory = new CachingConnectionFactory(host);
		getActivateToStateConnectionFactory.setPort(Integer.parseInt(port));
		getActivateToStateConnectionFactory.setUsername(username);
		getActivateToStateConnectionFactory.setPassword(password);
		getActivateToStateConnectionFactory.setConnectionTimeout(30000);
		return getActivateToStateConnectionFactory;
	}

	@Bean()
	RabbitAdmin getActivateToStateRabbitAdmin() {
		return new RabbitAdmin(getActivateToStaterabbitMQConnectionFactory());
	}

	@Bean("getActivateToStaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getActivateToStaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getActivateToStateFactory = new SimpleRabbitListenerContainerFactory();
		getActivateToStateFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getActivateToStateFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getActivateToStateFactory.setPrefetchCount(1);
		getActivateToStateFactory.setReceiveTimeout((long) 50000);
		getActivateToStateFactory.setConnectionFactory(getActivateToStaterabbitMQConnectionFactory());
		return getActivateToStateFactory;
	}

	@Bean()
	public RabbitTemplate getActivateToStatecustomRabbitTemplate() {
		RabbitTemplate getActivateToStaterabbitTemplate = new RabbitTemplate();
		getActivateToStaterabbitTemplate.setReplyTimeout(30000L);
		getActivateToStaterabbitTemplate.setMessageConverter(jsonMessageConverter());
		getActivateToStaterabbitTemplate.setConnectionFactory(getActivateToStaterabbitMQConnectionFactory());
		return getActivateToStaterabbitTemplate;
	}
	
	//modifydevicethreshold
	
	@Bean
	public Queue modifyDeviceThresholdQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getModifyDeviceThresholdQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange modifyDeviceThresholdExchange() {
		return new DirectExchange(inboundQueueProperties.getModifyDeviceThresholdExchange());
	}

	@Bean
	Binding modifyDeviceThresholdBinding() {
		return BindingBuilder.bind(modifyDeviceThresholdQueue()).to(modifyDeviceThresholdExchange())
				.with(inboundQueueProperties.getModifyDeviceThresholdQueue());
	}
	
	@Bean(name = "getModifyDeviceThresholdConnectionFactory")
	public ConnectionFactory getModifyDeviceThresholdrabbitMQConnectionFactory() {
		CachingConnectionFactory getModifyDeviceThresholdconnectionFactory = new CachingConnectionFactory(host);
		getModifyDeviceThresholdconnectionFactory.setPort(Integer.parseInt(port));
		getModifyDeviceThresholdconnectionFactory.setUsername(username);
		getModifyDeviceThresholdconnectionFactory.setPassword(password);
		getModifyDeviceThresholdconnectionFactory.setConnectionTimeout(30000);
		return getModifyDeviceThresholdconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getModifyDeviceThresholdRabbitAdmin(){
        return new RabbitAdmin(getModifyDeviceThresholdrabbitMQConnectionFactory());
    }
	
	
	@Bean("getModifyDeviceThresholdrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getModifyDeviceThresholdrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getModifyDeviceThresholdfactory = new SimpleRabbitListenerContainerFactory();
		getModifyDeviceThresholdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getModifyDeviceThresholdfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getModifyDeviceThresholdfactory.setPrefetchCount(1);
		getModifyDeviceThresholdfactory.setReceiveTimeout((long) 50000);
		getModifyDeviceThresholdfactory.setConnectionFactory(getModifyDeviceThresholdrabbitMQConnectionFactory());
		return getModifyDeviceThresholdfactory;
	}

	
	@Bean()
	public RabbitTemplate getModifyDeviceThresholdcustomRabbitTemplate() {
		RabbitTemplate getModifyDeviceThresholdrabbitTemplate = new RabbitTemplate();
		getModifyDeviceThresholdrabbitTemplate.setReplyTimeout(30000L);
		getModifyDeviceThresholdrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getModifyDeviceThresholdrabbitTemplate.setConnectionFactory(getModifyDeviceThresholdrabbitMQConnectionFactory());
		return getModifyDeviceThresholdrabbitTemplate;
	}
	
	//KorePing
	
	@Bean
	public Queue korePingQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getKorePingQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange korePingExchange() {
		return new DirectExchange(inboundQueueProperties.getKorePingExchange());
	}

	@Bean
	Binding korePingBinding() {
		return BindingBuilder.bind(korePingQueue()).to(korePingExchange())
				.with(inboundQueueProperties.getKorePingQueue());
	}
	
	@Bean(name = "getKorePingConnectionFactory")
	public ConnectionFactory getKorePingrabbitMQConnectionFactory() {
		CachingConnectionFactory getKorePingconnectionFactory = new CachingConnectionFactory(host);
		getKorePingconnectionFactory.setPort(Integer.parseInt(port));
		getKorePingconnectionFactory.setUsername(username);
		getKorePingconnectionFactory.setPassword(password);
		getKorePingconnectionFactory.setConnectionTimeout(30000);
		return getKorePingconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getKorePingRabbitAdmin(){
        return new RabbitAdmin(getKorePingrabbitMQConnectionFactory());
    }
	
	
	@Bean("getKorePingrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKorePingrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKorePingThresholdfactory = new SimpleRabbitListenerContainerFactory();
		getKorePingThresholdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKorePingThresholdfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKorePingThresholdfactory.setPrefetchCount(1);
		getKorePingThresholdfactory.setReceiveTimeout((long) 50000);
		getKorePingThresholdfactory.setConnectionFactory(getKorePingrabbitMQConnectionFactory());
		return getKorePingThresholdfactory;
	}

	
	@Bean()
	public RabbitTemplate getKorePingcustomRabbitTemplate() {
		RabbitTemplate getKorePingrabbitTemplate = new RabbitTemplate();
		getKorePingrabbitTemplate.setReplyTimeout(30000L);
		getKorePingrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKorePingrabbitTemplate.setConnectionFactory(getKorePingrabbitMQConnectionFactory());
		return getKorePingrabbitTemplate;
	}
	
	@Bean
	public Queue queryDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryDeviceExchange());
	}

	@Bean
	Binding queryDeviceBinding() {
		return BindingBuilder.bind(queryDeviceQueue()).to(queryDeviceExchange())
				.with(inboundQueueProperties.getQueryDeviceQueue());
	}

	
	@Bean
	public Queue queryDeviceDetailsExtQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryDeviceDetailsExtQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryDeviceDetailsExtExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryDeviceDetailsExtExchange());
	}

	@Bean
	Binding queryDeviceDetailsExtBinding() {
		return BindingBuilder.bind(queryDeviceDetailsExtQueue()).to(queryDeviceDetailsExtExchange())
				.with(inboundQueueProperties.getQueryDeviceDetailsExtQueue());
	}
	
	@Bean
	public Queue koreModifyDeviceFeaturesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getModifyDeviceFeaturesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange koreModifyDeviceFeaturesExchange() {
		return new DirectExchange(inboundQueueProperties.getModifyDeviceFeaturesExchange());
	}

	@Bean
	Binding koreModifyDeviceFeaturesBinding() {
		return BindingBuilder.bind(koreModifyDeviceFeaturesQueue()).to(koreModifyDeviceFeaturesExchange())
				.with(inboundQueueProperties.getModifyDeviceFeaturesQueue());
	}
	
	@Bean
	public Queue koreRestoreDevicesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getRestoreDevicesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange koreRestoreDevicesExchange() {
		return new DirectExchange(inboundQueueProperties.getRestoreDevicesExchange());
	}

	@Bean
	Binding koreRestoreDevicesBinding() {
		return BindingBuilder.bind(koreRestoreDevicesQueue()).to(koreRestoreDevicesExchange())
				.with(inboundQueueProperties.getRestoreDevicesQueue());
	}
	
	@Bean
	public Queue koreSimChangeDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSimChangeDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange koreSimChangeDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getSimChangeDeviceExchange());
	}

	@Bean
	Binding koreSimChangeDeviceBinding() {
		return BindingBuilder.bind(koreSimChangeDeviceQueue()).to(koreSimChangeDeviceExchange())
				.with(inboundQueueProperties.getSimChangeDeviceQueue());
	}
	@Bean(name = "getQueryDeviceConnectionFactory")
	public ConnectionFactory getQueryDevicerabbitMQConnectionFactory() {
		CachingConnectionFactory getQueryDeviceConnectionFactory = new CachingConnectionFactory(host);
		getQueryDeviceConnectionFactory.setPort(Integer.parseInt(port));
		getQueryDeviceConnectionFactory.setUsername(username);
		getQueryDeviceConnectionFactory.setPassword(password);
		getQueryDeviceConnectionFactory.setConnectionTimeout(30000);
		return getQueryDeviceConnectionFactory;
	}
	
	@Bean(name = "getQueryDeviceDetailsExtConnectionFactory")
	public ConnectionFactory getQueryDeviceDetailsExtrabbitMQConnectionFactory() {
		CachingConnectionFactory getQueryDeviceDetailsExtConnectionFactory = new CachingConnectionFactory(host);
		getQueryDeviceDetailsExtConnectionFactory.setPort(Integer.parseInt(port));
		getQueryDeviceDetailsExtConnectionFactory.setUsername(username);
		getQueryDeviceDetailsExtConnectionFactory.setPassword(password);
		getQueryDeviceDetailsExtConnectionFactory.setConnectionTimeout(30000);
		return getQueryDeviceDetailsExtConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getQueryDeviceRabbitAdmin(){
        return new RabbitAdmin(getQueryDevicerabbitMQConnectionFactory());
    }
	
	@Bean()
    RabbitAdmin getQueryDeviceDetailsExtRabbitAdmin(){
        return new RabbitAdmin(getQueryDeviceDetailsExtrabbitMQConnectionFactory());
    }
	
	@Bean("getQueryDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getQueryDevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getQueryDevicefactory = new SimpleRabbitListenerContainerFactory();
		getQueryDevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getQueryDevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getQueryDevicefactory.setPrefetchCount(1);
		getQueryDevicefactory.setReceiveTimeout((long) 50000);
		getQueryDevicefactory.setConnectionFactory(getQueryDevicerabbitMQConnectionFactory());
		return getQueryDevicefactory;
	}
	
	@Bean("getQueryDeviceDetailsExtrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getQueryDeviceDetailsExtrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getQueryDeviceDetailsExtfactory = new SimpleRabbitListenerContainerFactory();
		getQueryDeviceDetailsExtfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getQueryDeviceDetailsExtfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getQueryDeviceDetailsExtfactory.setPrefetchCount(1);
		getQueryDeviceDetailsExtfactory.setReceiveTimeout((long) 50000);
		getQueryDeviceDetailsExtfactory.setConnectionFactory(getQueryDeviceDetailsExtrabbitMQConnectionFactory());
		return getQueryDeviceDetailsExtfactory;
	}
	
	@Bean()
	public RabbitTemplate getQueryDevicecustomRabbitTemplate() {
		RabbitTemplate getQueryDevicerabbitTemplate = new RabbitTemplate();
		getQueryDevicerabbitTemplate.setReplyTimeout(30000L);
		getQueryDevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		getQueryDevicerabbitTemplate.setConnectionFactory(getQueryDevicerabbitMQConnectionFactory());
		return getQueryDevicerabbitTemplate;
	}

	
	@Bean()
	public RabbitTemplate getQueryDeviceDetailsExtcustomRabbitTemplate() {
		RabbitTemplate getQueryDeviceDetailsExtrabbitTemplate = new RabbitTemplate();
		getQueryDeviceDetailsExtrabbitTemplate.setReplyTimeout(30000L);
		getQueryDeviceDetailsExtrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getQueryDeviceDetailsExtrabbitTemplate.setConnectionFactory(getQueryDeviceDetailsExtrabbitMQConnectionFactory());
		return getQueryDeviceDetailsExtrabbitTemplate;
	}
	
	@Bean(name = "getQueryDeviceUsageBySimConnectionFactory")
	public ConnectionFactory getQueryDeviceUsageBySimrabbitMQConnectionFactory() {
		CachingConnectionFactory getQueryDeviceUsageBySimconnectionFactory = new CachingConnectionFactory(host);
		getQueryDeviceUsageBySimconnectionFactory.setPort(Integer.parseInt(port));
		getQueryDeviceUsageBySimconnectionFactory.setUsername(username);
		getQueryDeviceUsageBySimconnectionFactory.setPassword(password);
		getQueryDeviceUsageBySimconnectionFactory.setConnectionTimeout(30000);
		return getQueryDeviceUsageBySimconnectionFactory;
	}
	
	//QueryDeviceUsageBySim
	@Bean()
    RabbitAdmin getQueryDeviceUsageBySimRabbitAdmin(){
        return new RabbitAdmin(getQueryDeviceUsageBySimrabbitMQConnectionFactory());
    }
	
	//QueryDeviceUsageBySim
	@Bean("getQueryDeviceUsageBySimrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getQueryDeviceUsageBySimrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getQueryDeviceUsageBySimfactory = new SimpleRabbitListenerContainerFactory();
		getQueryDeviceUsageBySimfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getQueryDeviceUsageBySimfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getQueryDeviceUsageBySimfactory.setPrefetchCount(1);
		getQueryDeviceUsageBySimfactory.setReceiveTimeout((long) 50000);
		getQueryDeviceUsageBySimfactory.setConnectionFactory(getQueryDeviceUsageBySimrabbitMQConnectionFactory());
		return getQueryDeviceUsageBySimfactory;
	}

	//QueryDeviceUsageBySim
	@Bean()
	public RabbitTemplate getQueryDeviceUsageBySimcustomRabbitTemplate() {
		RabbitTemplate getQueryDeviceUsageBySimrabbitTemplate = new RabbitTemplate();
		getQueryDeviceUsageBySimrabbitTemplate.setReplyTimeout(30000L);
		getQueryDeviceUsageBySimrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getQueryDeviceUsageBySimrabbitTemplate.setConnectionFactory(getQueryDeviceUsageBySimrabbitMQConnectionFactory());
		return getQueryDeviceUsageBySimrabbitTemplate;
	}
	
	@Bean(name = "getQueryFeatureCodesConnectionFactory")
	public ConnectionFactory getQueryFeatureCodesrabbitMQConnectionFactory() {
		CachingConnectionFactory getQueryFeatureCodesconnectionFactory = new CachingConnectionFactory(host);
		getQueryFeatureCodesconnectionFactory.setPort(Integer.parseInt(port));
		getQueryFeatureCodesconnectionFactory.setUsername(username);
		getQueryFeatureCodesconnectionFactory.setPassword(password);
		getQueryFeatureCodesconnectionFactory.setConnectionTimeout(30000);
		return getQueryFeatureCodesconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getQueryFeatureCodesRabbitAdmin(){
        return new RabbitAdmin(getQueryFeatureCodesrabbitMQConnectionFactory());
    }
	
	@Bean("getQueryFeatureCodesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getQueryFeatureCodesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getQueryFeatureCodesfactory = new SimpleRabbitListenerContainerFactory();
		getQueryFeatureCodesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getQueryFeatureCodesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getQueryFeatureCodesfactory.setPrefetchCount(1);
		getQueryFeatureCodesfactory.setReceiveTimeout((long) 50000);
		getQueryFeatureCodesfactory.setConnectionFactory(getQueryFeatureCodesrabbitMQConnectionFactory());
		return getQueryFeatureCodesfactory;
	}
	
	@Bean()
	
	public RabbitTemplate getQueryFeatureCodescustomRabbitTemplate() {
		RabbitTemplate getQueryFeatureCodesrabbitTemplate = new RabbitTemplate();
		getQueryFeatureCodesrabbitTemplate.setReplyTimeout(30000L);
		getQueryFeatureCodesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getQueryFeatureCodesrabbitTemplate.setConnectionFactory(getQueryFeatureCodesrabbitMQConnectionFactory());
		return getQueryFeatureCodesrabbitTemplate;
	}
	
	@Bean(name = "getkoreQueryDeviceUsageConnectionFactory")
	public ConnectionFactory getKoreQueryDeviceUsagerabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreQueryDeviceUsageconnectionFactory = new CachingConnectionFactory(host);
		getKoreQueryDeviceUsageconnectionFactory.setPort(Integer.parseInt(port));
		getKoreQueryDeviceUsageconnectionFactory.setUsername(username);
		getKoreQueryDeviceUsageconnectionFactory.setPassword(password);
		getKoreQueryDeviceUsageconnectionFactory.setConnectionTimeout(30000);
		return getKoreQueryDeviceUsageconnectionFactory;
	}

	@Bean()
    RabbitAdmin getQueryDeviceUsageRabbitAdmin(){
        return new RabbitAdmin(getKoreQueryDeviceUsagerabbitMQConnectionFactory());
    }

	
	@Bean("getKoreQueryDeviceUsagerabbitListenerContainerFactory")
	
	public SimpleRabbitListenerContainerFactory getKoreQueryDeviceUsagerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreQueryDeviceUsagefactory = new SimpleRabbitListenerContainerFactory();
		getKoreQueryDeviceUsagefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreQueryDeviceUsagefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreQueryDeviceUsagefactory.setPrefetchCount(1);
		getKoreQueryDeviceUsagefactory.setReceiveTimeout((long) 50000);
		getKoreQueryDeviceUsagefactory.setConnectionFactory(getKoreQueryDeviceUsagerabbitMQConnectionFactory());
		return getKoreQueryDeviceUsagefactory;
	}

	@Bean()
	
	public RabbitTemplate getkoreQueryDeviceUsagecustomRabbitTemplate() {
		RabbitTemplate getKoreQueryDeviceUsagerabbitTemplate = new RabbitTemplate();
		getKoreQueryDeviceUsagerabbitTemplate.setReplyTimeout(30000L);
		getKoreQueryDeviceUsagerabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreQueryDeviceUsagerabbitTemplate.setConnectionFactory(getKoreQueryDeviceUsagerabbitMQConnectionFactory());
		return getKoreQueryDeviceUsagerabbitTemplate;
	}
	
	@Bean(name = "ncmmodifydeviceplanfornxtprdConnectionFactory")
	public ConnectionFactory ncmmodifydeviceplanfornxtprdrabbitMQConnectionFactory() {
		CachingConnectionFactory ncmmodifydeviceplanfornxtprdConnectionFactory = new CachingConnectionFactory(host);
		ncmmodifydeviceplanfornxtprdConnectionFactory.setPort(Integer.parseInt(port));
		ncmmodifydeviceplanfornxtprdConnectionFactory.setUsername(username);
		ncmmodifydeviceplanfornxtprdConnectionFactory.setPassword(password);
		ncmmodifydeviceplanfornxtprdConnectionFactory.setConnectionTimeout(30000);
		return ncmmodifydeviceplanfornxtprdConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmmodifydeviceplanfornxtprdRabbitAdmin(){
        return new RabbitAdmin(ncmmodifydeviceplanfornxtprdrabbitMQConnectionFactory());
    }
	
	@Bean("ncmmodifydeviceplanfornxtprdrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory ncmmodifydeviceplanfornxtprdrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmrebootfactory = new SimpleRabbitListenerContainerFactory();
		ncmrebootfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmrebootfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmrebootfactory.setPrefetchCount(1);
		ncmrebootfactory.setReceiveTimeout((long) 50000);
		ncmrebootfactory.setConnectionFactory(ncmmodifydeviceplanfornxtprdrabbitMQConnectionFactory());
		return ncmrebootfactory;
	}
	
	@Bean()
	public RabbitTemplate ncmmodifydeviceplanfornxtprdcustomRabbitTemplate() {
		RabbitTemplate ncmrebootrabbitTemplate = new RabbitTemplate();
		ncmrebootrabbitTemplate.setReplyTimeout(30000L);
		ncmrebootrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmrebootrabbitTemplate.setConnectionFactory(ncmmodifydeviceplanfornxtprdrabbitMQConnectionFactory());
		return ncmrebootrabbitTemplate;
	}
	
	@Bean(name = "koremodifydevicefeaturesConnectionFactory")
	public ConnectionFactory koremodifydevicefeaturesrabbitMQConnectionFactory() {
		CachingConnectionFactory koremodifydevicefeaturesConnectionFactory = new CachingConnectionFactory(host);
		koremodifydevicefeaturesConnectionFactory.setPort(Integer.parseInt(port));
		koremodifydevicefeaturesConnectionFactory.setUsername(username);
		koremodifydevicefeaturesConnectionFactory.setPassword(password);
		koremodifydevicefeaturesConnectionFactory.setConnectionTimeout(30000);
		return koremodifydevicefeaturesConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin ncmmodifydevicefeaturesRabbitAdmin(){
        return new RabbitAdmin(koremodifydevicefeaturesrabbitMQConnectionFactory());
    }
	
	@Bean("koremodifydevicefeaturesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory koremodifydevicefeaturesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory koremodifydevicefeaturesfactory = new SimpleRabbitListenerContainerFactory();
		koremodifydevicefeaturesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		koremodifydevicefeaturesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		koremodifydevicefeaturesfactory.setPrefetchCount(1);
		koremodifydevicefeaturesfactory.setReceiveTimeout((long) 50000);
		koremodifydevicefeaturesfactory.setConnectionFactory(koremodifydevicefeaturesrabbitMQConnectionFactory());
		koremodifydevicefeaturesfactory.setErrorHandler(errorHandler());
		return koremodifydevicefeaturesfactory;
	}
	
	@Bean()
	public RabbitTemplate koremodifydevicefeaturescustomRabbitTemplate() {
		RabbitTemplate koremodifydevicefeaturesrabbitTemplate = new RabbitTemplate();
		koremodifydevicefeaturesrabbitTemplate.setReplyTimeout(30000L);
		koremodifydevicefeaturesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		koremodifydevicefeaturesrabbitTemplate.setConnectionFactory(koremodifydevicefeaturesrabbitMQConnectionFactory());
		return koremodifydevicefeaturesrabbitTemplate;
	}
	
	@Bean
	public Queue queryAllDevicesQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getQueryAllDevicesQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange queryAllDevicesExchange() {
		return new DirectExchange(inboundQueueProperties.getQueryAllDevicesExchange());
	}

	@Bean
	Binding queryAllDevicesBinding() {
		return BindingBuilder.bind(queryAllDevicesQueue()).to(queryAllDevicesExchange())
				.with(inboundQueueProperties.getQueryAllDevicesQueue());
	}
	
	@Bean(name = "getQueryAllDevicesConnectionFactory")
	public ConnectionFactory getQueryAllDevicesrabbitMQConnectionFactory() {
		CachingConnectionFactory getQueryAllDevicesConnectionFactory = new CachingConnectionFactory(host);
		getQueryAllDevicesConnectionFactory.setPort(Integer.parseInt(port));
		getQueryAllDevicesConnectionFactory.setUsername(username);
		getQueryAllDevicesConnectionFactory.setPassword(password);
		getQueryAllDevicesConnectionFactory.setConnectionTimeout(30000);
		return getQueryAllDevicesConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getQueryAllDevicesRabbitAdmin(){
        return new RabbitAdmin(getQueryAllDevicesrabbitMQConnectionFactory());
    }
	
	@Bean("getQueryAllDevicesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getQueryAllDevicesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getQueryAllDevicesfactory = new SimpleRabbitListenerContainerFactory();
		getQueryAllDevicesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getQueryAllDevicesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getQueryAllDevicesfactory.setPrefetchCount(1);
		getQueryAllDevicesfactory.setReceiveTimeout((long) 50000);
		getQueryAllDevicesfactory.setConnectionFactory(getQueryAllDevicesrabbitMQConnectionFactory());
		return getQueryAllDevicesfactory;
	}
	
	@Bean()
	public RabbitTemplate getQueryAllDevicescustomRabbitTemplate() {
		RabbitTemplate getQueryAllDevicesrabbitTemplate = new RabbitTemplate();
		getQueryAllDevicesrabbitTemplate.setReplyTimeout(30000L);
		getQueryAllDevicesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getQueryAllDevicesrabbitTemplate.setConnectionFactory(getQueryAllDevicesrabbitMQConnectionFactory());
		return getQueryAllDevicesrabbitTemplate;
	}
	
	@Bean
	public Queue reactivateDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getReactivateDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange reactivateDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getReactivateDeviceExchange());
	}

	@Bean
	Binding reactivateDeviceBinding() {
		return BindingBuilder.bind(reactivateDeviceQueue()).to(reactivateDeviceExchange())
				.with(inboundQueueProperties.getReactivateDeviceQueue());
	}
	
	@Bean(name = "getReactivateDeviceConnectionFactory")
	public ConnectionFactory getReactivateDevicerabbitMQConnectionFactory() {
		CachingConnectionFactory getReactivateDeviceConnectionFactory = new CachingConnectionFactory(host);
		getReactivateDeviceConnectionFactory.setPort(Integer.parseInt(port));
		getReactivateDeviceConnectionFactory.setUsername(username);
		getReactivateDeviceConnectionFactory.setPassword(password);
		getReactivateDeviceConnectionFactory.setConnectionTimeout(30000);
		return getReactivateDeviceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getReactivateDeviceRabbitAdmin(){
        return new RabbitAdmin(getReactivateDevicerabbitMQConnectionFactory());
    }
	
	@Bean("getReactivateDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getReactivateDevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getReactivateDevicefactory = new SimpleRabbitListenerContainerFactory();
		getReactivateDevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getReactivateDevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getReactivateDevicefactory.setPrefetchCount(1);
		getReactivateDevicefactory.setReceiveTimeout((long) 50000);
		getReactivateDevicefactory.setConnectionFactory(getReactivateDevicerabbitMQConnectionFactory());
		return getReactivateDevicefactory;
	}
	
	@Bean()
	public RabbitTemplate getReactivateDevicecustomRabbitTemplate() {
		RabbitTemplate getReactivateDevicerabbitTemplate = new RabbitTemplate();
		getReactivateDevicerabbitTemplate.setReplyTimeout(30000L);
		getReactivateDevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		getReactivateDevicerabbitTemplate.setConnectionFactory(getReactivateDevicerabbitMQConnectionFactory());
		return getReactivateDevicerabbitTemplate;
	}
	
	@Bean
	public Queue suspendDeviceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSuspendDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange suspendDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getSuspendDeviceExchange());
	}

	@Bean
	Binding suspendDeviceBinding() {
		return BindingBuilder.bind(suspendDeviceQueue()).to(suspendDeviceExchange())
				.with(inboundQueueProperties.getSuspendDeviceQueue());
	}

	@Bean("suspendDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory suspendDevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory suspendDevicefactory = new SimpleRabbitListenerContainerFactory();
		suspendDevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		suspendDevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		suspendDevicefactory.setPrefetchCount(1);
		suspendDevicefactory.setReceiveTimeout((long) 50000);
		suspendDevicefactory.setConnectionFactory(suspendDevicerabbitMQConnectionFactory());
		suspendDevicefactory.setErrorHandler(errorHandler());
		return suspendDevicefactory;
	}

	@Bean()
	public RabbitTemplate suspendDevicecustomRabbitTemplate() {
		RabbitTemplate suspendDevicerabbitTemplate = new RabbitTemplate();
		suspendDevicerabbitTemplate.setReplyTimeout(30000L);
		suspendDevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		suspendDevicerabbitTemplate.setConnectionFactory(suspendDevicerabbitMQConnectionFactory());
		return suspendDevicerabbitTemplate;
	}

	@Bean(name = "suspendDeviceConnectionFactory")
	public ConnectionFactory suspendDevicerabbitMQConnectionFactory() {
		CachingConnectionFactory suspendDeviceconnectionFactory = new CachingConnectionFactory(host);
		suspendDeviceconnectionFactory.setPort(Integer.parseInt(port));
		suspendDeviceconnectionFactory.setUsername(username);
		suspendDeviceconnectionFactory.setPassword(password);
		suspendDeviceconnectionFactory.setConnectionTimeout(30000);
		return suspendDeviceconnectionFactory;
	}

	@Bean()
	RabbitAdmin suspendDeviceRabbitAdmin() {
		return new RabbitAdmin(suspendDevicerabbitMQConnectionFactory());
	}	
	
	@Bean
	public Queue downloadReportingQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getDownloadReportingQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange downloadReportingExchange() {
		return new DirectExchange(inboundQueueProperties.getDownloadReportingExchange());
	}

	@Bean
	Binding downloadReportingBinding() {
		return BindingBuilder.bind(downloadReportingQueue()).to(downloadReportingExchange())
				.with(inboundQueueProperties.getDownloadReportingQueue());
	}

	@Bean("downloadReportingrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory downloadReportingrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory downloadReportingfactory = new SimpleRabbitListenerContainerFactory();
		downloadReportingfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		downloadReportingfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		downloadReportingfactory.setPrefetchCount(1);
		downloadReportingfactory.setReceiveTimeout((long) 50000);
		downloadReportingfactory.setConnectionFactory(downloadReportingrabbitMQConnectionFactory());
		downloadReportingfactory.setErrorHandler(errorHandler());
		return downloadReportingfactory;
	}

	@Bean()
	public RabbitTemplate downloadReportingcustomRabbitTemplate() {
		RabbitTemplate downloadReportingrabbitTemplate = new RabbitTemplate();
		downloadReportingrabbitTemplate.setReplyTimeout(30000L);
		downloadReportingrabbitTemplate.setMessageConverter(jsonMessageConverter());
		downloadReportingrabbitTemplate.setConnectionFactory(downloadReportingrabbitMQConnectionFactory());
		return downloadReportingrabbitTemplate;
	}

	@Bean(name = "downloadReportingConnectionFactory")
	public ConnectionFactory downloadReportingrabbitMQConnectionFactory() {
		CachingConnectionFactory downloadReportingconnectionFactory = new CachingConnectionFactory(host);
		downloadReportingconnectionFactory.setPort(Integer.parseInt(port));
		downloadReportingconnectionFactory.setUsername(username);
		downloadReportingconnectionFactory.setPassword(password);
		downloadReportingconnectionFactory.setConnectionTimeout(30000);
		return downloadReportingconnectionFactory;
	}

	@Bean()
	RabbitAdmin downloadReportingRabbitAdmin() {
		return new RabbitAdmin(downloadReportingrabbitMQConnectionFactory());
	}	

	
	@Bean(name = "getkoreChangeSimStatusConnectionFactory")
	public ConnectionFactory getkoreChangeSimStatusrabbitMQConnectionFactory() {
		CachingConnectionFactory getkoreChangeSimStatusConnectionFactory = new CachingConnectionFactory(host);
		getkoreChangeSimStatusConnectionFactory.setPort(Integer.parseInt(port));
		getkoreChangeSimStatusConnectionFactory.setUsername(username);
		getkoreChangeSimStatusConnectionFactory.setPassword(password);
		getkoreChangeSimStatusConnectionFactory.setConnectionTimeout(30000);
		return getkoreChangeSimStatusConnectionFactory;
	}

	@Bean()
	RabbitAdmin getkoreChangeSimStatusRabbitAdmin() {
		return new RabbitAdmin(getkoreChangeSimStatusrabbitMQConnectionFactory());
	}

	@Bean("getkoreChangeSimStatusrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getkoreChangeSimStatusrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getkoreChangeSimStatusFactory = new SimpleRabbitListenerContainerFactory();
		getkoreChangeSimStatusFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getkoreChangeSimStatusFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getkoreChangeSimStatusFactory.setPrefetchCount(1);
		getkoreChangeSimStatusFactory.setReceiveTimeout((long) 50000);
		getkoreChangeSimStatusFactory.setConnectionFactory(getkoreChangeSimStatusrabbitMQConnectionFactory());
		return getkoreChangeSimStatusFactory;
	}

	@Bean()
	public RabbitTemplate getkoreChangeSimStatuscustomRabbitTemplate() {
		RabbitTemplate getkoreChangeSimStatusrabbitTemplate = new RabbitTemplate();
		getkoreChangeSimStatusrabbitTemplate.setReplyTimeout(30000L);
		getkoreChangeSimStatusrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getkoreChangeSimStatusrabbitTemplate.setConnectionFactory(getkoreChangeSimStatusrabbitMQConnectionFactory());
		return getkoreChangeSimStatusrabbitTemplate;
	}
	
	
	@Bean(name = "getkoreQueryAvailableReportFilesConnectionFactory")
	public ConnectionFactory getkoreQueryAvailableReportFilesrabbitMQConnectionFactory() {
		CachingConnectionFactory getkoreQueryAvailableReportFilesConnectionFactory = new CachingConnectionFactory(host);
		getkoreQueryAvailableReportFilesConnectionFactory.setPort(Integer.parseInt(port));
		getkoreQueryAvailableReportFilesConnectionFactory.setUsername(username);
		getkoreQueryAvailableReportFilesConnectionFactory.setPassword(password);
		getkoreQueryAvailableReportFilesConnectionFactory.setConnectionTimeout(30000);
		return getkoreQueryAvailableReportFilesConnectionFactory;
	}

	@Bean()
	RabbitAdmin getkoreQueryAvailableReportFilesRabbitAdmin() {
		return new RabbitAdmin(getkoreQueryAvailableReportFilesrabbitMQConnectionFactory());
	}

	@Bean("getkoreQueryAvailableReportFilesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getkoreQueryAvailableReportFilesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getkoreQueryAvailableReportFilesFactory = new SimpleRabbitListenerContainerFactory();
		getkoreQueryAvailableReportFilesFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getkoreQueryAvailableReportFilesFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getkoreQueryAvailableReportFilesFactory.setPrefetchCount(1);
		getkoreQueryAvailableReportFilesFactory.setReceiveTimeout((long) 50000);
		getkoreQueryAvailableReportFilesFactory.setConnectionFactory(getkoreQueryAvailableReportFilesrabbitMQConnectionFactory());
		return getkoreQueryAvailableReportFilesFactory;
	}

	@Bean()
	public RabbitTemplate getkoreQueryAvailableReportFilescustomRabbitTemplate() {
		RabbitTemplate getkoreQueryAvailableReportFilesrabbitTemplate = new RabbitTemplate();
		getkoreQueryAvailableReportFilesrabbitTemplate.setReplyTimeout(30000L);
		getkoreQueryAvailableReportFilesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getkoreQueryAvailableReportFilesrabbitTemplate.setConnectionFactory(getkoreQueryAvailableReportFilesrabbitMQConnectionFactory());
		return getkoreQueryAvailableReportFilesrabbitTemplate;
	}
	
		@Bean(name = "korerestoredevicesConnectionFactory")
	public ConnectionFactory korerestoredevicesrabbitMQConnectionFactory() {
		CachingConnectionFactory korerestoredevicesConnectionFactory = new CachingConnectionFactory(host);
		korerestoredevicesConnectionFactory.setPort(Integer.parseInt(port));
		korerestoredevicesConnectionFactory.setUsername(username);
		korerestoredevicesConnectionFactory.setPassword(password);
		korerestoredevicesConnectionFactory.setConnectionTimeout(30000);
		return korerestoredevicesConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin korerestoredevicesRabbitAdmin(){
        return new RabbitAdmin(korerestoredevicesrabbitMQConnectionFactory());
    }
	
	@Bean("korerestoredevicesrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory korerestoredevicesrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory korerestoredevicesfactory = new SimpleRabbitListenerContainerFactory();
		korerestoredevicesfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		korerestoredevicesfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		korerestoredevicesfactory.setPrefetchCount(1);
		korerestoredevicesfactory.setReceiveTimeout((long) 50000);
		korerestoredevicesfactory.setConnectionFactory(korerestoredevicesrabbitMQConnectionFactory());
		korerestoredevicesfactory.setErrorHandler(errorHandler());
		return korerestoredevicesfactory;
	}
	
	@Bean()
	public RabbitTemplate korerestoredevicescustomRabbitTemplate() {
		RabbitTemplate korerestoredevicesrabbitTemplate = new RabbitTemplate();
		korerestoredevicesrabbitTemplate.setReplyTimeout(30000L);
		korerestoredevicesrabbitTemplate.setMessageConverter(jsonMessageConverter());
		korerestoredevicesrabbitTemplate.setConnectionFactory(korerestoredevicesrabbitMQConnectionFactory());
		return korerestoredevicesrabbitTemplate;
	}
	
	@Bean(name = "koresimchangedeviceConnectionFactory")
	public ConnectionFactory koresimchangedevicerabbitMQConnectionFactory() {
		CachingConnectionFactory koresimchangedeviceConnectionFactory = new CachingConnectionFactory(host);
		koresimchangedeviceConnectionFactory.setPort(Integer.parseInt(port));
		koresimchangedeviceConnectionFactory.setUsername(username);
		koresimchangedeviceConnectionFactory.setPassword(password);
		koresimchangedeviceConnectionFactory.setConnectionTimeout(30000);
		return koresimchangedeviceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin koresimchangedeviceRabbitAdmin(){
        return new RabbitAdmin(koresimchangedevicerabbitMQConnectionFactory());
    }
	
	@Bean("koresimchangedevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory koresimchangedevicerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory koresimchangedevicefactory = new SimpleRabbitListenerContainerFactory();
		koresimchangedevicefactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		koresimchangedevicefactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		koresimchangedevicefactory.setPrefetchCount(1);
		koresimchangedevicefactory.setReceiveTimeout((long) 50000);
		koresimchangedevicefactory.setConnectionFactory(koresimchangedevicerabbitMQConnectionFactory());
		koresimchangedevicefactory.setErrorHandler(errorHandler());
		return koresimchangedevicefactory;
	}
	
	@Bean()
	public RabbitTemplate koresimchangedevicecustomRabbitTemplate() {
		RabbitTemplate koresimchangedevicerabbitTemplate = new RabbitTemplate();
		koresimchangedevicerabbitTemplate.setReplyTimeout(30000L);
		koresimchangedevicerabbitTemplate.setMessageConverter(jsonMessageConverter());
		koresimchangedevicerabbitTemplate.setConnectionFactory(koresimchangedevicerabbitMQConnectionFactory());
		return koresimchangedevicerabbitTemplate;
	}
	
	@Bean(name = "koreUnbarToStateConnectionFactory")
	public ConnectionFactory koreUnbarToStaterabbitMQConnectionFactory() {
		CachingConnectionFactory koreUnbarToStateConnectionFactory = new CachingConnectionFactory(host);
		koreUnbarToStateConnectionFactory.setPort(Integer.parseInt(port));
		koreUnbarToStateConnectionFactory.setUsername(username);
		koreUnbarToStateConnectionFactory.setPassword(password);
		koreUnbarToStateConnectionFactory.setConnectionTimeout(30000);
		return koreUnbarToStateConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin koreUnbarToStateRabbitAdmin(){
        return new RabbitAdmin(koreUnbarToStaterabbitMQConnectionFactory());
    }
	
	@Bean("koreUnbarToStaterabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory koreUnbarToStaterabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory ncmrebootfactory = new SimpleRabbitListenerContainerFactory();
		ncmrebootfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		ncmrebootfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		ncmrebootfactory.setPrefetchCount(1);
		ncmrebootfactory.setReceiveTimeout((long) 50000);
		ncmrebootfactory.setConnectionFactory(koreUnbarToStaterabbitMQConnectionFactory());
		return ncmrebootfactory;
	}
	
	@Bean()
	public RabbitTemplate koreUnbarToStatecustomRabbitTemplate() {
		RabbitTemplate ncmrebootrabbitTemplate = new RabbitTemplate();
		ncmrebootrabbitTemplate.setReplyTimeout(30000L);
		ncmrebootrabbitTemplate.setMessageConverter(jsonMessageConverter());
		ncmrebootrabbitTemplate.setConnectionFactory(koreUnbarToStaterabbitMQConnectionFactory());
		return ncmrebootrabbitTemplate;
	}
	
	@Bean
	public Queue reportingPingQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getReportingPingQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange reportingPingExchange() {
		return new DirectExchange(inboundQueueProperties.getReportingPingExchange());
	}

	@Bean
	Binding reportingPingBinding() {
		return BindingBuilder.bind(reportingPingQueue()).to(reportingPingExchange())
				.with(inboundQueueProperties.getReportingPingQueue());
	}

	@Bean("reportingPingrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory reportingPingrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory reportingPingfactory = new SimpleRabbitListenerContainerFactory();
		reportingPingfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		reportingPingfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		reportingPingfactory.setPrefetchCount(1);
		reportingPingfactory.setReceiveTimeout((long) 50000);
		reportingPingfactory.setConnectionFactory(reportingPingrabbitMQConnectionFactory());
		reportingPingfactory.setErrorHandler(errorHandler());
		return reportingPingfactory;
	}

	@Bean()
	public RabbitTemplate reportingPingcustomRabbitTemplate() {
		RabbitTemplate reportingPingrabbitTemplate = new RabbitTemplate();
		reportingPingrabbitTemplate.setReplyTimeout(30000L);
		reportingPingrabbitTemplate.setMessageConverter(jsonMessageConverter());
		reportingPingrabbitTemplate.setConnectionFactory(reportingPingrabbitMQConnectionFactory());
		return reportingPingrabbitTemplate;
	}

	@Bean(name = "reportingPingConnectionFactory")
	public ConnectionFactory reportingPingrabbitMQConnectionFactory() {
		CachingConnectionFactory reportingPingconnectionFactory = new CachingConnectionFactory(host);
		reportingPingconnectionFactory.setPort(Integer.parseInt(port));
		reportingPingconnectionFactory.setUsername(username);
		reportingPingconnectionFactory.setPassword(password);
		reportingPingconnectionFactory.setConnectionTimeout(30000);
		return reportingPingconnectionFactory;
	}

	@Bean()
	RabbitAdmin reportingPingRabbitAdmin() {
		return new RabbitAdmin(reportingPingrabbitMQConnectionFactory());
	}
	
	
	@Bean
	public Queue removeSimAssociationQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getRemoveSimAssociationQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange removeSimAssociationExchange() {
		return new DirectExchange(inboundQueueProperties.getRemoveSimAssociationExchange());
	}

	@Bean
	Binding removeSimAssociationBinding() {
		return BindingBuilder.bind(removeSimAssociationQueue()).to(removeSimAssociationExchange())
				.with(inboundQueueProperties.getRemoveSimAssociationQueue());
	}

	@Bean("removeSimAssociationrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory removeSimAssociationrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory removeSimAssociationfactory = new SimpleRabbitListenerContainerFactory();
		removeSimAssociationfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		removeSimAssociationfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		removeSimAssociationfactory.setPrefetchCount(1);
		removeSimAssociationfactory.setReceiveTimeout((long) 50000);
		removeSimAssociationfactory.setConnectionFactory(removeSimAssociationrabbitMQConnectionFactory());
		removeSimAssociationfactory.setErrorHandler(errorHandler());
		return removeSimAssociationfactory;
	}

	@Bean()
	public RabbitTemplate removeSimAssociationcustomRabbitTemplate() {
		RabbitTemplate removeSimAssociationrabbitTemplate = new RabbitTemplate();
		removeSimAssociationrabbitTemplate.setReplyTimeout(30000L);
		removeSimAssociationrabbitTemplate.setMessageConverter(jsonMessageConverter());
		removeSimAssociationrabbitTemplate.setConnectionFactory(removeSimAssociationrabbitMQConnectionFactory());
		return removeSimAssociationrabbitTemplate;
	}

	@Bean(name = "removeSimAssociationConnectionFactory")
	public ConnectionFactory removeSimAssociationrabbitMQConnectionFactory() {
		CachingConnectionFactory removeSimAssociationconnectionFactory = new CachingConnectionFactory(host);
		removeSimAssociationconnectionFactory.setPort(Integer.parseInt(port));
		removeSimAssociationconnectionFactory.setUsername(username);
		removeSimAssociationconnectionFactory.setPassword(password);
		removeSimAssociationconnectionFactory.setConnectionTimeout(30000);
		return removeSimAssociationconnectionFactory;
	}

	@Bean()
	RabbitAdmin removeSimAssociationRabbitAdmin() {
		return new RabbitAdmin(removeSimAssociationrabbitMQConnectionFactory());
	}
	
	//koreretrievegroupbycompanyid
	
	@Bean
	public Queue retrieveGroupByCompanyIdQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getRetrieveGroupByCompanyIdQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange retrieveGroupByCompanyIdExchange() {
		return new DirectExchange(inboundQueueProperties.getRetrieveGroupByCompanyIdExchange());
	}

	@Bean
	Binding retrieveGroupByCompanyIdBinding() {
		return BindingBuilder.bind(retrieveGroupByCompanyIdQueue()).to(retrieveGroupByCompanyIdExchange())
				.with(inboundQueueProperties.getRetrieveGroupByCompanyIdQueue());
	}

	@Bean(name = "getKoreRetrieveGroupByCompanyIdConnectionFactory")
	public ConnectionFactory getKoreRetrieveGroupByCompanyIdrabbitMQConnectionFactory() {
		CachingConnectionFactory getKoreRetrieveGroupByCompanyIdconnectionFactory = new CachingConnectionFactory(host);
		getKoreRetrieveGroupByCompanyIdconnectionFactory.setPort(Integer.parseInt(port));
		getKoreRetrieveGroupByCompanyIdconnectionFactory.setUsername(username);
		getKoreRetrieveGroupByCompanyIdconnectionFactory.setPassword(password);
		getKoreRetrieveGroupByCompanyIdconnectionFactory.setConnectionTimeout(30000);
		return getKoreRetrieveGroupByCompanyIdconnectionFactory;
	}

	@Bean()
	RabbitAdmin getKoreRetrieveGroupByCompanyIdRabbitAdmin() {
		return new RabbitAdmin(getKoreRetrieveGroupByCompanyIdrabbitMQConnectionFactory());
	}

	@Bean("getKoreRetrieveGroupByCompanyIdrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getKoreRetrieveGroupByCompanyIdrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getKoreRetrieveGroupByCompanyIdThresholdfactory = new SimpleRabbitListenerContainerFactory();
		getKoreRetrieveGroupByCompanyIdThresholdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getKoreRetrieveGroupByCompanyIdThresholdfactory
				.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getKoreRetrieveGroupByCompanyIdThresholdfactory.setPrefetchCount(1);
		getKoreRetrieveGroupByCompanyIdThresholdfactory.setReceiveTimeout((long) 50000);
		getKoreRetrieveGroupByCompanyIdThresholdfactory.setConnectionFactory(getKorePingrabbitMQConnectionFactory());
		return getKoreRetrieveGroupByCompanyIdThresholdfactory;
	}

	@Bean()
	public RabbitTemplate getKoreRetrieveGroupByCompanyIdcustomRabbitTemplate() {
		RabbitTemplate getKoreRetrieveGroupByCompanyIdrabbitTemplate = new RabbitTemplate();
		getKoreRetrieveGroupByCompanyIdrabbitTemplate.setReplyTimeout(30000L);
		getKoreRetrieveGroupByCompanyIdrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getKoreRetrieveGroupByCompanyIdrabbitTemplate.setConnectionFactory(getKorePingrabbitMQConnectionFactory());
		return getKoreRetrieveGroupByCompanyIdrabbitTemplate;
	}
	
	@Bean
	public Queue getAlertsBySimIdQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getGetAlertsBySimIdQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange getAlertsBySimIdExchange() {
		return new DirectExchange(inboundQueueProperties.getGetAlertsBySimIdExchange());
	}

	@Bean
	Binding getAlertsBySimIdBinding() {
		return BindingBuilder.bind(getAlertsBySimIdQueue()).to(getAlertsBySimIdExchange())
				.with(inboundQueueProperties.getGetAlertsBySimIdQueue());
	}
	
	@Bean(name = "getAlertsBySimIdConnectionFactory")
	public ConnectionFactory getAlertsBySimIdrabbitMQConnectionFactory() {
		CachingConnectionFactory getAlertsBySimIdConnectionFactory = new CachingConnectionFactory(host);
		getAlertsBySimIdConnectionFactory.setPort(Integer.parseInt(port));
		getAlertsBySimIdConnectionFactory.setUsername(username);
		getAlertsBySimIdConnectionFactory.setPassword(password);
		getAlertsBySimIdConnectionFactory.setConnectionTimeout(30000);
		return getAlertsBySimIdConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getAlertsBySimIdRabbitAdmin(){
        return new RabbitAdmin(getAlertsBySimIdrabbitMQConnectionFactory());
    }
	
	@Bean("getAlertsBySimIdrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getAlertsBySimIdrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getAlertsBySimIdfactory = new SimpleRabbitListenerContainerFactory();
		getAlertsBySimIdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getAlertsBySimIdfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getAlertsBySimIdfactory.setPrefetchCount(1);
		getAlertsBySimIdfactory.setReceiveTimeout((long) 50000);
		getAlertsBySimIdfactory.setConnectionFactory(getAlertsBySimIdrabbitMQConnectionFactory());
		return getAlertsBySimIdfactory;
	}
	
	@Bean()
	public RabbitTemplate getAlertsBySimIdcustomRabbitTemplate() {
		RabbitTemplate getAlertsBySimIdrabbitTemplate = new RabbitTemplate();
		getAlertsBySimIdrabbitTemplate.setReplyTimeout(30000L);
		getAlertsBySimIdrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getAlertsBySimIdrabbitTemplate.setConnectionFactory(getAlertsBySimIdrabbitMQConnectionFactory());
		return getAlertsBySimIdrabbitTemplate;
	}
	
	@Bean(name = "AcknowlegdeAlertBySimAndRuleConnectionFactory")
	public ConnectionFactory AcknowlegdeAlertBySimAndRulerabbitMQConnectionFactory() {
		CachingConnectionFactory acknowlegdeAlertBySimAndRuleConnectionFactory = new CachingConnectionFactory(host);
		acknowlegdeAlertBySimAndRuleConnectionFactory.setPort(Integer.parseInt(port));
		acknowlegdeAlertBySimAndRuleConnectionFactory.setUsername(username);
		acknowlegdeAlertBySimAndRuleConnectionFactory.setPassword(password);
		acknowlegdeAlertBySimAndRuleConnectionFactory.setConnectionTimeout(30000);
		return acknowlegdeAlertBySimAndRuleConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin AcknowlegdeAlertBySimAndRulerabbitMQConnectionFactoryRabbitAdmin(){
        return new RabbitAdmin(AcknowlegdeAlertBySimAndRulerabbitMQConnectionFactory());
    }
	
	@Bean("AcknowlegdeAlertBySimAndRuleContainerFactory")
	public SimpleRabbitListenerContainerFactory AcknowlegdeAlertBySimAndRuleContainerFactory() {
		SimpleRabbitListenerContainerFactory acknowlegdeAlertBySimAndRule = new SimpleRabbitListenerContainerFactory();
		acknowlegdeAlertBySimAndRule.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		acknowlegdeAlertBySimAndRule.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		acknowlegdeAlertBySimAndRule.setPrefetchCount(1);
		acknowlegdeAlertBySimAndRule.setReceiveTimeout((long) 50000);
		acknowlegdeAlertBySimAndRule.setConnectionFactory(AcknowlegdeAlertBySimAndRulerabbitMQConnectionFactory());
		return acknowlegdeAlertBySimAndRule;
	}
	
	@Bean()
	public RabbitTemplate AcknowlegdeAlertBySimAndRulecustomRabbitTemplate() {
		RabbitTemplate acknowlegdeAlertBySimAndRulerabbitTemplate = new RabbitTemplate();
		acknowlegdeAlertBySimAndRulerabbitTemplate.setReplyTimeout(30000L);
		acknowlegdeAlertBySimAndRulerabbitTemplate.setMessageConverter(jsonMessageConverter());
		acknowlegdeAlertBySimAndRulerabbitTemplate.setConnectionFactory(AcknowlegdeAlertBySimAndRulerabbitMQConnectionFactory());
		return acknowlegdeAlertBySimAndRulerabbitTemplate;
	}
	
	@Bean
	public Queue sendAcknowledgeQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getSendAcknowledgeQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange sendAcknowledgeExchange() {
		return new DirectExchange(inboundQueueProperties.getSendAcknowledgeExchange());
	}

	@Bean
	Binding sendAcknowledgeBinding() {
		return BindingBuilder.bind(sendAcknowledgeQueue()).to(sendAcknowledgeExchange())
				.with(inboundQueueProperties.getSendAcknowledgeQueue());
	}

	@Bean(name = "sendAcknowledgeConnectionFactory")
	public ConnectionFactory sendAcknowledgeConnectionFactory() {
		CachingConnectionFactory sendAcknowledgeConnectionFactory = new CachingConnectionFactory(host);
		sendAcknowledgeConnectionFactory.setPort(Integer.parseInt(port));
		sendAcknowledgeConnectionFactory.setUsername(username);
		sendAcknowledgeConnectionFactory.setPassword(password);
		sendAcknowledgeConnectionFactory.setConnectionTimeout(30000);
		return sendAcknowledgeConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin sendAcknowledgeConnectionFactoryRabbitAdmin(){
        return new RabbitAdmin(sendAcknowledgeConnectionFactory());
    }
	
	@Bean("sendAcknowledgerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory sendAcknowledgerabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory sendAcknowledgerabbitListenerContainerFactory = new SimpleRabbitListenerContainerFactory();
		sendAcknowledgerabbitListenerContainerFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		sendAcknowledgerabbitListenerContainerFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		sendAcknowledgerabbitListenerContainerFactory.setPrefetchCount(1);
		sendAcknowledgerabbitListenerContainerFactory.setReceiveTimeout((long) 50000);
		sendAcknowledgerabbitListenerContainerFactory.setConnectionFactory(sendAcknowledgeConnectionFactory());
		return sendAcknowledgerabbitListenerContainerFactory;
	}

	@Bean()
	public RabbitTemplate sendAcknowledgecustomRabbitTemplate() {
		RabbitTemplate sendAcknowledgecustomRabbitTemplate = new RabbitTemplate();
		sendAcknowledgecustomRabbitTemplate.setReplyTimeout(30000L);
		sendAcknowledgecustomRabbitTemplate.setMessageConverter(jsonMessageConverter());
		sendAcknowledgecustomRabbitTemplate.setConnectionFactory(sendAcknowledgeConnectionFactory());
		return sendAcknowledgecustomRabbitTemplate;
	}
	

	@Bean
	public Queue alertByCompanyIdGroupIdQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getAlertByCompanyIdGroupIdQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange alertByCompanyIdGroupIdExchange() {
		return new DirectExchange(inboundQueueProperties.getAlertByCompanyIdGroupIdExchange());
	}

	@Bean
	Binding alertByCompanyIdGroupIdBinding() {
		return BindingBuilder.bind(alertByCompanyIdGroupIdQueue()).to(alertByCompanyIdGroupIdExchange())
				.with(inboundQueueProperties.getAlertByCompanyIdGroupIdQueue());
	}

	@Bean(name = "getAlertByCompanyIdGroupIdConnectionFactory")
	public ConnectionFactory getAlertByCompanyIdGroupIdrabbitMQConnectionFactory() {
		CachingConnectionFactory getAlertByCompanyIdGroupIdconnectionFactory = new CachingConnectionFactory(host);
		getAlertByCompanyIdGroupIdconnectionFactory.setPort(Integer.parseInt(port));
		getAlertByCompanyIdGroupIdconnectionFactory.setUsername(username);
		getAlertByCompanyIdGroupIdconnectionFactory.setPassword(password);
		getAlertByCompanyIdGroupIdconnectionFactory.setConnectionTimeout(30000);
		return getAlertByCompanyIdGroupIdconnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getAlertByCompanyIdGroupIdRabbitAdmin(){
        return new RabbitAdmin(getAlertByCompanyIdGroupIdrabbitMQConnectionFactory());
    }
	
	@Bean("getAlertByCompanyIdGroupIdrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getAlertByCompanyIdGroupIdrabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory getAlertByCompanyIdGroupIdfactory = new SimpleRabbitListenerContainerFactory();
		getAlertByCompanyIdGroupIdfactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		getAlertByCompanyIdGroupIdfactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		getAlertByCompanyIdGroupIdfactory.setPrefetchCount(1);
		getAlertByCompanyIdGroupIdfactory.setReceiveTimeout((long) 50000);
		getAlertByCompanyIdGroupIdfactory.setConnectionFactory(getAlertByCompanyIdGroupIdrabbitMQConnectionFactory());
		return getAlertByCompanyIdGroupIdfactory;
	}

	@Bean()
	public RabbitTemplate getAlertByCompanyIdGroupIdcustomRabbitTemplate() {
		RabbitTemplate getAlertByCompanyIdGroupIdrabbitTemplate = new RabbitTemplate();
		getAlertByCompanyIdGroupIdrabbitTemplate.setReplyTimeout(30000L);
		getAlertByCompanyIdGroupIdrabbitTemplate.setMessageConverter(jsonMessageConverter());
		getAlertByCompanyIdGroupIdrabbitTemplate.setConnectionFactory(getAlertByCompanyIdGroupIdrabbitMQConnectionFactory());
		return getAlertByCompanyIdGroupIdrabbitTemplate;
	}

	
}
