package com.nsl.usagereport.constants;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import java.util.Base64;
import org.json.JSONObject;


@Component
public class UtilityClass {
	
	Logger LOGGER = LoggerFactory.getLogger(UtilityClass.class);

	
	

	public boolean isEmpty(String str){
		boolean valRet=true;
		if(str!=null && str.trim().length()>0){
			valRet= false;
		}
		return valRet;
	}
	
}
