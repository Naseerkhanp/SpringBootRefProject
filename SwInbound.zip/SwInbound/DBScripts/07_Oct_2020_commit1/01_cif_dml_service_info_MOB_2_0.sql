spool 01_cif_dml_service_info_MOB_2_0.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;  

Insert into service_info (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,SERVICE_REQUEST,TYPE,ACTION,RETRYLIMIT,TIMEDELAY,SERVER,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP,SERVICE_DESCRIPTION,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE)
values (3022,'ActivatePortInSubscriber_URL','http://mobile-2-0-stub-service:9999/activatePortInSubscriberCall',null,null,null,'OUTBOUND',null,null,null,null,null, EMPTY_CLOB(),null,null,null,null,'NSL_UPG','SUCCESS',systimestamp,systimestamp,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

Insert into service_info (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values
(3023,'MNOValidateDeviceAsync_URL','http://mobile-2-0-stub-service:9999/validateDeviceFlow/imei/${imei}',null,null,null,'OUTBOUND',null,null,null,null,null,null,null, EMPTY_CLOB(),null,null,'NSL_UPG',null,null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

Insert into service_info (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,SERVICE_REQUEST,TYPE,ACTION,RETRYLIMIT,TIMEDELAY,SERVER,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP,SERVICE_DESCRIPTION,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values
(3024,'DEVICEDETECTION_URL','http://mobile-2-0-stub-service:9999/sendAck',null,null,null,'OUTBOUND',null,null,null,null,null, EMPTY_CLOB(),null,null,'3',3000,'NSL_UPG','SUCCESS',null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

Insert into service_info (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE)
values (3025,'MNOValidateDeviceAsync_URL','http://mobile-2-0-stub-service/validateDeviceFlow/imei/${imei}',null,null,null,'OUTBOUND',null,null,null,null,null,null,null, EMPTY_CLOB(),null,null,'LOCAL',null,null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

update service_info set SERVICE_URL='http://mobile-2-0-stub-service:9999/restoreService' where service_id=2485;

commit;
spool off;
