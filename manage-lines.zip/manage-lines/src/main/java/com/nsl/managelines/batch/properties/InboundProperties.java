package com.nsl.managelines.batch.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String routerserviceurl;
	
	private String generateReportManagement;
	
	private String resourceBaseServiceURL;

	private String authserver;

	private String IntrernalServerURL;

	private String changerateplanurl;

	private String changefeatureurl;
	
		private String serverUrl;

}