package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.entity.Data4;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("Data4Handler")
public class Data4Handler implements Handler {

	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst,UsageReportDetails usageReportDetails) throws Exception {
		long id = NslFileUploadUtils.nullCheck(column[0]);
		try {
			Data4 data4Details = new Data4();
			data4Details.setAcctStatusType(id);
			data4Details.setCallingStationId(NslFileUploadUtils.nullChecker(column[1]));
			data4Details.setFramedIpAddress(NslFileUploadUtils.nullChecker(column[2]));
			data4Details.setUserName(NslFileUploadUtils.nullChecker(column[3]));
			data4Details.setAcctSessionId(NslFileUploadUtils.nullChecker(column[4]));
			data4Details.setGpp2CorrelationId(NslFileUploadUtils.nullChecker(column[5]));
			data4Details.setGpp2ServiceOption(NslFileUploadUtils.nullCheck(column[6]));
			data4Details.setGpp2ForeignAgentAddress(NslFileUploadUtils.nullChecker(column[7]));
			data4Details.setAcctOutputOctets(NslFileUploadUtils.nullCheck(column[8]));
			data4Details.setAcctInputOctets(NslFileUploadUtils.nullCheck(column[9]));
			data4Details.setAcctOutputGigawords(NslFileUploadUtils.nullCheck(column[10]));
			data4Details.setAcctInputGigawords(NslFileUploadUtils.nullCheck(column[11]));
			data4Details.setEvent_timestamp(NslFileUploadUtils.convertIntToDate(column[12]));
			data4Details.setData4_class(NslFileUploadUtils.nullChecker(column[13]));
			data4Details.setCreated_by(NslFileUploadConstants.NSL);

			if (detailsBuiler.containsKey(id)) {
				List<Object> li = detailsBuiler.get(id);
				li.add(data4Details);
				detailsBuiler.put(id, li);
			} else {
				List<Object> li = new ArrayList<>();
				li.add(data4Details);
				detailsBuiler.put(id, li);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

}
