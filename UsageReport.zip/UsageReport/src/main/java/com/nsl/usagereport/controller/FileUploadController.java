package com.nsl.usagereport.controller;

import java.io.IOException;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.nsl.usagereport.constants.JWTHandler;
import com.nsl.usagereport.constants.UtilityClass;
import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.service.FileUploadService;
import com.nsl.usagereport.validator.GetUsageReportDetailsValidator;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/nsl/file-uploader-services")
public class FileUploadController {
	@Autowired
	FileUploadService fileUploadService;
	@Autowired
	private Gson gson;

	@Autowired
	private JWTHandler jwtHandler;

	@Autowired
	private UtilityClass utilityClass;

	@InitBinder("getUsageReportDetails")
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(new GetUsageReportDetailsValidator());
	}

	@PostMapping("/fileDataUploader")
	public ResponseEntity<String> readFile(@RequestBody UsageReportDetails usageReportDetails) throws IOException {
		log.info(this.getClass() + " readFile method called .");
		return fileUploadService.extractDataFrmFile(usageReportDetails);
	}
	
	@PostMapping("/fileDataLoader")
	public void uploadFile(@RequestBody UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " readFile method called .");
		fileUploadService.downloadFromSFTP(usageReportDetails);
	}

	@PostMapping("/smbFileDataUploader")
	public ResponseEntity<String> readSMBFile(@RequestParam("file") MultipartFile file,
			@RequestParam("usageReportDetails") String jsonString) throws Exception {
		log.info(this.getClass() + " readSMBFile method called .");
		UsageReportDetails usageReportDetails = gson.fromJson(jsonString, UsageReportDetails.class);
		return fileUploadService.extractDataFrmSmbFile(usageReportDetails, file);
	}
	@PostMapping("/deleteDetails")
	public ResponseEntity<String> deleteDetails(
			 @RequestBody GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " deleteDetails method called .");
		return fileUploadService.deleteData(getUsageReportDetails);
	}
	/*@GetMapping("/getDataDetails")
	public ResponseEntity<List<DataDetailsUIO>> getDataDetails(
			@Valid @RequestBody GetUsageReportDetails getUsageReportDetails,
			@RequestHeader(value = "Authorization", required = false) String token,
			@RequestHeader(value = "User-Agent", required = false) String source, HttpServletResponse res)
			throws Exception {
		String responseString = null;
		List<DataDetailsUIO> dataDetailsUIO = null;
		try {
			if (token != null) {
				if (jwtHandler.validateToken(token)) {
					dataDetailsUIO = fileUploadService.getDataDetails(getUsageReportDetails);
				} else {
					responseString = utilityClass.invalidToken(token);
					return new ResponseEntity(responseString, HttpStatus.UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				return new ResponseEntity(responseString, HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception e) {
			log.error("Error in uploadFiles Service :", e);
			responseString = utilityClass.internalServerError(token);
			return new ResponseEntity(responseString, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<DataDetailsUIO>>(dataDetailsUIO, HttpStatus.OK);
	}

	@GetMapping("/getSmsDetails")
	public ResponseEntity<List<SmsDetailsUIO>> getSmsDetails(
			@Valid @RequestBody GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " getSmsDetails method called .");
		List<SmsDetailsUIO> smsDetailsUIO = fileUploadService.getSmsDetails(getUsageReportDetails);
		return new ResponseEntity<List<SmsDetailsUIO>>(smsDetailsUIO, HttpStatus.OK);
	}

	@GetMapping("/getVoiceDetails")
	public ResponseEntity<List<VoiceDetailsUIO>> getVoiceDetails(
			@Valid @RequestBody GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " getVoiceDetails method called .");
		List<VoiceDetailsUIO> voiceDetailsUIO = fileUploadService.getVoiceDetails(getUsageReportDetails);
		return new ResponseEntity<List<VoiceDetailsUIO>>(voiceDetailsUIO, HttpStatus.OK);
	}*/
	
	//Implementing for Outbound//
	@PostMapping("/getUsageReport")
	public String getUsageReport(@RequestParam("request") String request) {
		log.info("Result : " + request);
		String responseString = null;
		try {
			Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			// Message result = customRabbitTemplate.sendAndReceive(exchange.getName(), queue.getName(), message);
			Message result = fileUploadService.initiateCallResponse(message);
			responseString = new String(result.getBody());
			log.info("Result : " + responseString);

		} catch (Exception e) {
			log.error("Exception in initiateCall Controller : ", e);
			//e.printStackTrace();
		}
		return responseString;
	}
}
