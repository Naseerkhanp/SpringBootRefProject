package com.excelacom.servicegateway.constants;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class UtilityClass {

	Logger LOGGER = LoggerFactory.getLogger(UtilityClass.class);

	public String invalidToken(String token) {
		String msg = Constants.INVALID_TOKEN_1 + token + Constants.INVALID_TOKEN_2;
		return msg;
	}

	public String unavailableToken() {
		String msg = Constants.INVALID_TOKEN_1 + Constants.TOKEN_UNAVAILABLE + Constants.INVALID_TOKEN_2;
		return msg;
	}

	/**
	 * This method is used for invoking the rest api
	 * @param request
	 * @param url
	 * @return String response
	 */
	public String callRestAPI(String request,String url){
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		try {
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
		 } catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if(conn!=null) {
			conn.disconnect();
			conn = null;
			}
		}
		return outputString;
	}

}
