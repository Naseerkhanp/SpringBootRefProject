package com.nsl.usagereport.postgres.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.postgres.entity.DataDetails;

@Repository
@Transactional
public interface DataDetailsRepository extends JpaRepository<DataDetails, Integer> {

	@Query("select d from DATA_DETAILS d where d.billingNumber = :billingNumber and date(d.startDateTime) between :startDate AND :endDate AND  d.imsi = :imsi")
	List<DataDetails> findDataByDate(@Param("billingNumber") String billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") String imsi);

	@Query("select d from DATA_DETAILS d where d.billingNumber = :billingNumber and date(d.startDateTime) between :startDate AND :endDate")
	List<DataDetails> findDataByDateWithOutOptional(@Param("billingNumber") String billingNumber, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

	@Modifying
	@Query("delete from DATA_DETAILS d where  d.createdDate <= :startDate AND d.createdDate >=:endDate")
	void  deleteDataByDate(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query("select d from DATA_DETAILS d where d.billingNumber = :billingNumber")
	List<DataDetails> findDataByWithOutStartEnddateAndImsi(@Param("billingNumber") String billingNumber);

	@Query("select d from DATA_DETAILS d where d.billingNumber = :billingNumber AND  d.imsi = :imsi")
	List<DataDetails> findDataByMdnAndImsi(@Param("billingNumber") String billingNumber, @Param("imsi") String imsi);

}
