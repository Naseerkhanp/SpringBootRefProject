package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String disconnectDeviceQueue;

	private String disconnectDeviceExchange;
	
	private String KoreQuerygetEapCodeQueue;
	
    private String KoreQuerygetEapCodeExchange;
	
	private String KoreQueryPlanCodeNextPeriodQueue;
	
    private String KoreQueryPlanCodeNextPeriodExchange;
	
	private String KoreSIMRadiusQueryQueue;
	
    private String KoreSIMRadiusQueryExchange;
    
	private String activateToStateQueue;
	 
	private String activateToStateExchange;
	
	private String activateDeviceQueue;
	 
	private String activateDeviceExchange;
	
    private String KoreQuerygetEapDetailsQueue;
	
    private String KoreQuerygetEapDetailsExchange;
	
	private String changemsisdnQueue;
	
	private String changemsisdnExchange;
	
	private String deactivatedeviceQueue;
	
	private String deactivatedeviceExchange;
	
	private String modifyDeviceThresholdQueue;
	
	private String modifyDeviceThresholdExchange;
	
	private String korePingQueue;
	
	private String korePingExchange;
	
	private String queryDeviceQueue;
	
	private String queryDeviceExchange;
	
	private String queryDeviceDetailsExtQueue;
	
	private String queryDeviceDetailsExtExchange;
	
    private String costCentersQueue;
	
	private String costCentersExchange;
	
	private String mdCustomInfoQueue;
	
	private String mdCustomInfoExchange;
	
	private String QueryDeviceUsageBySimQueue;
	
	private String QueryDeviceUsageBySimExchange;
	
	private String QueryFeatureCodesQueue;
	
	private String QueryFeatureCodesExchange;
	
	 private String KoreQueryDeviceUsageQueue;
		
	private String KoreQueryDeviceUsageExchange;
	
	private String NCMModifyDevicePlanForNxtPrdQueue;

	private String NCMModifyDevicePlanForNxtPrdExchange;
	
	private String ModifyDeviceFeaturesQueue;
    
    private String ModifyDeviceFeaturesExchange;
    
    private String queryRequestStatusQueue;
    
    private String queryRequestStatusExchange;
	
	private String RestoreDevicesQueue;
    
    private String RestoreDevicesExchange;
    
    private String SimChangeDeviceQueue;
    
    private String SimChangeDeviceExchange;
    
    private String queryServiceTypeCodesQueue;
    
    private String queryServiceTypeCodesExchange;
    
    private String queryAllDevicesQueue;
	
	private String queryAllDevicesExchange;
	
	private String reactivateDeviceQueue;
	 
	private String reactivateDeviceExchange;
    
    private String suspendDeviceQueue;
    
    private String suspendDeviceExchange;
    
    private String downloadReportingQueue;
    
    private String downloadReportingExchange;
	
	private String KoreChangeSimStatusQueue;
    
    private String KoreChangeSimStatusExchange;
    
    private String KoreQueryAvailableReportFilesQueue;
    
    private String KoreQueryAvailableReportFilesExchange;
    
    private String koreUnbarToStateQueue;
    
    private String koreUnbarToStateExchange;
    
    private String reportingPingQueue;
    
    private String reportingPingExchange;
    
    private String acknowledgeAlertsbyGroupQueue;
    
    private String acknowledgeAlertsbyGroupExchange;
	
	private String simAssociateToGroupQueue;
	 
	private String simAssociateToGroupExchange;
	private String removeSimAssociationQueue;
    
    private String removeSimAssociationExchange;
    
    private String retrieveGroupByCompanyIdQueue;

	private String retrieveGroupByCompanyIdExchange;
	
	private String getAlertsBySimIdQueue;

	private String getAlertsBySimIdExchange;
	
  private String  acknowlegdeAlertBySimAndRuleQueue;
    
    private String acknowlegdeAlertBySimAndRuleExchange;
	
	private String AlertByCompanyIdGroupIdQueue;
	
	private String AlertByCompanyIdGroupIdExchange;

	private String sendAcknowledgeQueue;
	
	private String sendAcknowledgeExchange;


}
