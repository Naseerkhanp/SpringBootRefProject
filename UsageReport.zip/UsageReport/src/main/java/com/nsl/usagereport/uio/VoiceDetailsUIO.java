package com.nsl.usagereport.uio;

import java.util.Date;

public class VoiceDetailsUIO {
	private String callStart;
	private Long timeZone;
	private String techType;
	private Long callType;
	private Long minutesOfUse;

	private String callDirection;
	private String otherPartyNumber;
	private String footprint;
	private String toCountry;
	private String fromCountry;
	private String dSource;


	public String getdSource() {
		return dSource;
	}

	public void setdSource(String dSource) {
		this.dSource = dSource;
	}
	public String getFromCountry() {
		return fromCountry;
	}

	public void setFromCountry(String fromCountry) {
		this.fromCountry = fromCountry;
	}

	public String getCallStart() {
		return callStart;
	}

	public void setCallStart(String callStart) {
		this.callStart = callStart;
	}

	public Long getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(Long timeZone) {
		this.timeZone = timeZone;
	}

	public String getTechType() {
		return techType;
	}

	public void setTechType(String techType) {
		this.techType = techType;
	}

	public Long getCallType() {
		return callType;
	}

	public void setCallType(Long callType) {
		this.callType = callType;
	}

	public String getOtherPartyNumber() {
		return otherPartyNumber;
	}

	public void setOtherPartyNumber(String otherPartyNumber) {
		this.otherPartyNumber = otherPartyNumber;
	}

	public String getFootprint() {
		return footprint;
	}

	public void setFootprint(String footprint) {
		this.footprint = footprint;
	}

	public String getToCountry() {
		return toCountry;
	}

	public void setToCountry(String toCountry) {
		this.toCountry = toCountry;
	}

	public Long getMinutesOfUse() {
		return minutesOfUse;
	}

	public void setMinutesOfUse(Long minutesOfUse) {
		this.minutesOfUse = minutesOfUse;
	}

	public String getCallDirection() {
		return callDirection;
	}

	public void setCallDirection(String callDirection) {
		this.callDirection = callDirection;
	}
}
