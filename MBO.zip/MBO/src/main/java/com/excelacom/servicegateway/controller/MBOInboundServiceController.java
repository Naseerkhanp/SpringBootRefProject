package com.excelacom.servicegateway.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.security.JWTHandler;
import com.google.gson.Gson;

@RestController
public class MBOInboundServiceController {
	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	private JWTHandler jwtHandler;

	Logger LOGGER = LoggerFactory.getLogger(MBOInboundServiceController.class);

	@RequestMapping(value = "#{inboundProperties.getEmmCreateSubscriberUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String emmCreateSubscriberCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("EMMCREATESUBSCRIBER");
		String responseString = null;
		try {
			if (token != null) {
				if (jwtHandler.validateToken(token)) {
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getEmmCreateSubscriberExchange(),
							inboundQueueProperties.getEmmCreateSubscriberQueue(), message);
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in EMMCREATESUBSCRIBER " + e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getEmmUpdateSubscriberUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String emmUpdateSubscriberCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("EMMUpdateSubscriberCall");
		String responseString = null;
		try {
			if (token != null) {
				if (jwtHandler.validateToken(token)) {
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					LOGGER.info(message.toString());
					LOGGER.info(inboundQueueProperties.getEmmUpdateSubscriberExchange()+" "+inboundQueueProperties.getEmmUpdateSubscriberQueue());
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getEmmUpdateSubscriberExchange(),
							inboundQueueProperties.getEmmUpdateSubscriberQueue(), message);
					LOGGER.info(result.toString());;
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	  
	  @RequestMapping(value = "#{inboundProperties.getEmmGetSubscriberUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	  @ResponseBody
	  public String emmGetSubscriberCall(@PathVariable("customerid") String customerid,@PathVariable("lineid") String lineid, @PathVariable("mdn") String mdn,@PathVariable("status") String status,@RequestHeader(value = "Authorization",required = false) String token) { 
		  LOGGER.info("emmGetSubscriberCall");
		  String  responseString = ""; 
		  try { 
			  if (token != null) { 
				  if (AuthHandler.checkToken(token)) {
				  
				 // String requestJson = "";
				  JSONObject dataJson = new JSONObject();
				  JSONObject requestJson = new JSONObject();
				 // HashMap<String, String> requestmap = new  HashMap<String, String>(); 
				  requestJson.put("accountNumber", customerid);
				  requestJson.put("lineId", lineid); 
				  requestJson.put("mdn", mdn);
				  requestJson.put("status", status); 
				 
				 // requestJson = new  Gson().toJson(dataJson);
				  dataJson.put("data", requestJson);
				  String data = dataJson.toString();
				  LOGGER.info(data);
				  Message message =  MessageBuilder.withBody(data.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				  Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getEmmGetSubscriberExchange(),
								inboundQueueProperties.getEmmGetSubscriberQueue(), message); 
				  responseString = new String(result.getBody());
				  
				  } else { 
					  	responseString = utilityClass.invalidToken(token); 
				  }
				  LOGGER.info("Response :: " + responseString);
			  	} else { 
			  		responseString = utilityClass.unavailableToken();
			  	}
			  } catch(Exception e) {
				  LOGGER.error("Exception in emmGetSubscriberCall "+ e); 
			  } 
		  return responseString; 
	  }
	 
	private String customJsonFormatter(String request) {
		String quotes = Character.toString((char) 34);
		String slash = Character.toString((char) 92);
		String slashQuotes = slash + quotes;
		String braceQuotes = Character.toString((char) 125) + Character.toString((char) 34);
		String quotesbrace = Character.toString((char) 34) + Character.toString((char) 123);
		String temp1 = request.replace(slashQuotes, quotes);
		String temp2 = temp1.replace(braceQuotes, Character.toString((char) 125));
		String requestJson = temp2.replace(quotesbrace, Character.toString((char) 123));
		return requestJson;
	}
	
	@RequestMapping(value = "#{inboundProperties.getEmmUsageinquiryUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ResponseBody
	public String emmUsageinquiryCall(@PathVariable String mdn,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("emmUsageinquiry");
		String responseString = null;
		try {
			if (token != null) {
				if (jwtHandler.validateToken(token)) {
					//String requestJson = "";
					JSONObject dataJson = new JSONObject();
					JSONObject requestJson = new JSONObject();
					  //HashMap<String, String> requestmap = new  HashMap<String, String>(); 
					requestJson.put("mdn", mdn);
					  
					  //requestJson = new  Gson().toJson(requestmap);
					  dataJson.put("data",requestJson);
					  String data = dataJson.toString();
					  LOGGER.info(data);
					Message message = MessageBuilder.withBody(data.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getEmmUsageinquiryExchange(),
							inboundQueueProperties.getEmmUsageinquiryQueue(), message);
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in emmUsageinquiryCall " + e);
		}
		return responseString;
	}
	
	
	@RequestMapping(value = "#{inboundProperties.getEmmChangemdnsubscriberUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String emmChangemdnsubscriberCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("emmChangemdnsubscriber");
		String responseString = null;
		try {
			if (token != null) {
				if (jwtHandler.validateToken(token)) {
					Message message = MessageBuilder.withBody(request.getBytes())
							.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(
							inboundQueueProperties.getEmmChangemdnsubscriberExchange(),
							inboundQueueProperties.getEmmChangemdnsubscriberQueue(), message);
					responseString = new String(result.getBody());

				} else {
					responseString = utilityClass.invalidToken(token);
				}
				LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in emmChangemdnsubscriber " + e);
		}
		return responseString;
	}
}
