package com.nsl.usagereport.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author HarshVardhan.M
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "potgresEntityManagerFactory", transactionManagerRef = "potgresTransactionManager", basePackages = {
		"com.nsl.usagereport.postgres" })

public class UsagreportPostgresSqlConfig {

	@LiquibaseDataSource
	@Bean(name = "potgresDataSource")
	@ConfigurationProperties(prefix = "spring.posgres.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "potgresEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("potgresDataSource") DataSource dataSource) {
		Map<String, String> propertyMap = new HashMap<String, String>();
		propertyMap.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
		return builder.dataSource(dataSource).packages("com.nsl.usagereport.postgres.entity").persistenceUnit("potgres")
				.properties(propertyMap).build();
	}

	@Bean(name = "potgresTransactionManager")
	public PlatformTransactionManager transactionManager(
			@Qualifier("potgresEntityManagerFactory") EntityManagerFactory barEntityManagerFactory) {
		return new JpaTransactionManager(barEntityManagerFactory);
	}

}
