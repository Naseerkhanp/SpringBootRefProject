package com.excelacom.servicegateway.bean;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class ResourceUpdateRequest {

	private String transationId;

	private String transactionName;
	
	private Account account;
	
	private Line lineDetails;
	
	private Sim simDetails;

	private LinePlan linePlan;
	
	private LineHistory lineHistory;

	private Map<String, String> featureMap;
		
	private Device deviceDetails;
	
	private Feature feature;
	
	private List<LineHistory> lineHistoryList;

	public List<LineHistory> getLineHistoryList() {
		return lineHistoryList;
	}

	public void setLineHistoryList(List<LineHistory> lineHistoryList) {
		this.lineHistoryList = lineHistoryList;
	}

	public Feature getFeature() {
		return feature;
	}

	public void setFeature(Feature feature) {
		this.feature = feature;
	}

	private TransactionHistory transactionHistory;

	public Account getAccount() {
		return account;
	}

	public LinePlan getLinePlan() {
		return linePlan;
	}

	public LineHistory getLineHistory() {
		return lineHistory;
	}

	public Line getLineDetails() {
		return lineDetails;
	}

	public void setLineDetails(Line lineDetails) {
		this.lineDetails = lineDetails;
	}	

	public Sim getSimDetails() {
		return simDetails;
	}

	public void setSimDetails(Sim simDetails) {
		this.simDetails = simDetails;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setLinePlan(LinePlan linePlan) {
		this.linePlan = linePlan;
	}

	public void setLineHistory(LineHistory lineHistory) {
		this.lineHistory = lineHistory;
	}

	public void setTransationId(String transationId) {
		this.transationId = transationId;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public TransactionHistory getTransactionHistory() {
		return transactionHistory;
	}

	public void setTransactionHistory(TransactionHistory transactionHistory) {
		this.transactionHistory = transactionHistory;
	}

	public String getTransationId() {
		return transationId;
	}

	public Device getDeviceDetails() {
		return deviceDetails;
	}

	public void setDeviceDetails(Device deviceDetails) {
		this.deviceDetails = deviceDetails;
	}

	public Map<String, String> getFeatureMap() {
		return featureMap;
	}

	public void setFeatureMap(Map<String, String> featureMap) {
		this.featureMap = featureMap;
	}
	
	// Added ReferenceValue Bean for EventType MWTGNSL-957
	private ReferenceValue referenceValue;

			public ReferenceValue getReferenceValue() {
				return referenceValue;
			}

			public void setReferenceValue(ReferenceValue referenceValue) {
				this.referenceValue = referenceValue;
			}

	@Override
	public String toString() {
		return "ResourceUpdateRequest [transationId=" + transationId + ", transactionName=" + transactionName
				+ ", account=" + account + ", lineDetails=" + lineDetails + ", simDetails=" + simDetails + ", linePlan="
				+ linePlan + ", lineHistory=" + lineHistory + ", featureMap=" + featureMap + ", deviceDetails="
				+ deviceDetails + ", transactionHistory=" + transactionHistory + ", getAccount()=" + getAccount()
				+ ", getLinePlan()=" + getLinePlan() + ", getLineHistory()=" + getLineHistory() + ", getLineDetails()="
				+ getLineDetails() + ", getSimDetails()=" + getSimDetails() + ", getTransactionName()="
				+ getTransactionName() + ", getTransactionHistory()=" + getTransactionHistory() + ", getTransationId()="
				+ getTransationId() + ", getDeviceDetails()=" + getDeviceDetails() + ", getFeature()=" + getFeatureMap()
				+ "]";
	}

	
}
