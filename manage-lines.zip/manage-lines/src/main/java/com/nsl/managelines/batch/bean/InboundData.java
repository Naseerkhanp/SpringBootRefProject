/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;
import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class InboundData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String transactionType;
	
	public String transactionTimeStamp;
	
	public ArrayList<SubOrder> subOrder;
}
