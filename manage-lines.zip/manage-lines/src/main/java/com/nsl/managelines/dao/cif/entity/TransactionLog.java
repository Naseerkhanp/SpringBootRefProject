package com.nsl.managelines.dao.cif.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TRANSACTION_LOG")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionLog implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "TRANSACTION_ID", updatable = false)
	private Long transactionId;

	@Column(name = "FILE_NAME")
	private String fileName;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "FILE_GEN_DATE")
	private Date fileGenDate =  new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "FILE_PROCESS_TIME")
	private Date fileProcessTime =  new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "DATA_FILE")
	private String DataFile;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "EXTERNAL_SYSTEM")
	private String externalSystem;

	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate = new java.sql.Date(new java.util.Date().getTime());

}
