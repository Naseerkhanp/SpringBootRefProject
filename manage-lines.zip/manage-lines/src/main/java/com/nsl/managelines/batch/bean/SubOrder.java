/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;
import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class SubOrder implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayList<KeyValueObj> simId;
	
	public ArrayList<KeyValueObj> deviceId;

}
