/**
 * 
 */
package com.nsl.managelines.batch.bean.async;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class GatewayResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String requestNo;

	public String responseType;

	public String lnpStatusCode;

	public String onsp;

	public String versionID;

	public MdnDetail mdnDetail;

}
