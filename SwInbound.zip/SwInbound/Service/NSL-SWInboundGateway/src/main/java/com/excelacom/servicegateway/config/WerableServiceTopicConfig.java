/**
 * 
 */
package com.excelacom.servicegateway.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.util.ErrorHandler;

import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import com.excelacom.servicegateway.properties.InboundQueueProperties;


/**
 * @author Dhayanand.B
 *
 */
@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class WerableServiceTopicConfig {

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;

	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	Logger LOGGER = LoggerFactory.getLogger(WerableServiceTopicConfig.class);

	@Bean (name = "searchEnvironmentWaitTopicExchange")
	public TopicExchange searchEnvironmentWaitTopicExchange() {
		return new TopicExchange(inboundQueueProperties.getSearchEnvWaitTopicExchange());
	}

	@Bean
	public ErrorHandler swerrorHandler() {
		return new ConditionalRejectingErrorHandler(swcustomExceptionStrategy());
	}

	@Bean
	FatalExceptionStrategy swcustomExceptionStrategy() {
		return new CustomFatalExceptionStrategy();
	}

	@Bean(name = "searchEnvironmentWaitConnectionFactory")
	public ConnectionFactory searchEnvironmentWaitRabbitMQConnectionFactory() {
		CachingConnectionFactory searchEnvironmentWaitConnectionFactory = new CachingConnectionFactory(host);
		searchEnvironmentWaitConnectionFactory.setPort(Integer.parseInt(port));
		searchEnvironmentWaitConnectionFactory.setUsername(username);
		searchEnvironmentWaitConnectionFactory.setPassword(password);
		searchEnvironmentWaitConnectionFactory.setConnectionTimeout(30000);
		return searchEnvironmentWaitConnectionFactory;
	}

	@Bean()
	RabbitAdmin searchEnvironmentWaitRabbitAdmin() {
		return new RabbitAdmin(searchEnvironmentWaitRabbitMQConnectionFactory());
	}

	@Bean("searchEnvironmentWaitrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory searchEnvironmentWaitRabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory searchEnvironmentWaitFactory = new SimpleRabbitListenerContainerFactory();
		searchEnvironmentWaitFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
		searchEnvironmentWaitFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
		searchEnvironmentWaitFactory.setPrefetchCount(1);
		searchEnvironmentWaitFactory.setReceiveTimeout((long) 30000);
		searchEnvironmentWaitFactory.setConnectionFactory(searchEnvironmentWaitRabbitMQConnectionFactory());
		searchEnvironmentWaitFactory.setErrorHandler(swerrorHandler());
		return searchEnvironmentWaitFactory;
	}

	@Bean()
	public RabbitTemplate searchEnvironmentWaitCustomRabbitTemplate() {
		RabbitTemplate searchEnvironmentWaitRabbitTemplate = new RabbitTemplate();
		searchEnvironmentWaitRabbitTemplate.setReplyTimeout(500000L);
		searchEnvironmentWaitRabbitTemplate.setMessageConverter(swjsonMessageConverter());
		searchEnvironmentWaitRabbitTemplate.setConnectionFactory(searchEnvironmentWaitRabbitMQConnectionFactory());
		searchEnvironmentWaitRabbitTemplate.setMandatory(true);
		return searchEnvironmentWaitRabbitTemplate;
	}
	
	@Bean()
    RabbitAdmin serchEnvWaitRabbitAdmin(){
        return new RabbitAdmin(searchEnvironmentWaitRabbitMQConnectionFactory());
    }

	@Bean
	public MessageConverter swjsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

}
