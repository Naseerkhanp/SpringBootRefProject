package com.nsl.usagereport.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerAdvice {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleException(MethodArgumentNotValidException ex) {
		List<String> details = new ArrayList<>();
		details.add(ex.getBindingResult().getFieldErrors().stream().filter(e -> e.getDefaultMessage() != null)
				.findFirst().map(e -> (String) e.getDefaultMessage()).orElse("Bad Request"));
		ErrorResponse error = new ErrorResponse("Server Error", details);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
	}

}