package com.excelacom.servicegateway.controller;

import java.security.MessageDigest;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.http.HttpStatus;*/
import org.apache.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.handler.JWTHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.exception.NslCustomException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javax.ws.rs.NotAuthorizedException;

import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;
import javax.xml.bind.DatatypeConverter;


@RestController
public class NcmInboundServiceController {

	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;
	
	@Autowired
	private InboundQueueProperties inboundQueueProperties;
	
	@Autowired
	private InboundProperties inboundProperties;
	
	@Autowired
	private JWTHandler jwtHandler;
	
	@Autowired
	private AuthHandler authHandler ;	
	

	@Autowired
	TransactionDAO transactionDAO;
	
	Logger LOGGER = LoggerFactory.getLogger(NcmInboundServiceController.class);
	
		
@RequestMapping(value = "#{inboundProperties.getGetspeedtesturl()}",produces = "application/json", method = RequestMethod.GET)
@ResponseBody
public String ncmSpeedTestsSystemCall(@PathVariable String id, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmSpeedTestsSystemCall");
	String requestJson = "";
	String responseString = "";
	try {       
       if (token != null) {
       	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){
        	 LOGGER.info("JWT TOken" +token);  
				HashMap<String, Object> data = new HashMap<String, Object>();
				data.put("id", id);
				HashMap<String,Object> req = new HashMap<String, Object>();
				req.put("getSpeedTestsRequest", data);
				HashMap<String, HashMap<String, Object>> datareq = new HashMap<String, HashMap<String, Object>>();
				datareq.put("data", req);
				requestJson = new Gson().toJson(datareq);
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getSpeedTestExchange(), inboundQueueProperties.getSpeedTestQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				System.out.println("Response : " + responseString);
              }else {
            	  responseString = utilityClass.invalidToken(token);
            	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              	}
       			LOGGER.info("Response :: " + responseString);
       			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
	}
	catch(Exception e) {
		LOGGER.error("Exception in ncmSpeedTestsSystemCall "+ e);
	}
	return responseString;
}

@RequestMapping(value ="#{inboundProperties.getDeletespeedtesturl()}", produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.DELETE)
@ResponseBody
public String ncmdeleteSpeedTestsSystemCall(@PathVariable String id,@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmdeleteSpeedTestsSystemCall");
	String requestJson = "";
	String responseString = "";
	try {
        if (token != null) {
        	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())){

		HashMap<String, String> data = new HashMap<String, String>();
		data.put("id", id);
		HashMap<String, HashMap<String, String>> req = new HashMap<String, HashMap<String, String>>();
		req.put("data", data);
		requestJson = new Gson().toJson(req);
		Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDeleteSpeedTestExchange(), inboundQueueProperties.getDeleteSpeedTestQueue(), message);
		if (responseHeader(result)) {
			res.setStatus(HttpStatus.SC_BAD_REQUEST);
			responseString = new String(result.getBody());
		}
		responseString = new String(result.getBody());
	   } else {
		   responseString = utilityClass.invalidToken(token);
		   res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	   	}
            LOGGER.info("Response :: " + responseString);
        } else {
        	responseString = utilityClass.unavailableToken();	
        	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
        	LOGGER.info("Invalid Token " + responseString);
        }
	}
	catch(Exception e) {
		LOGGER.error("Exception in ncmdeleteSpeedTestsSystemCall "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getConfigmanagerurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String ncmConfigManagerSystemCall(HttpServletRequest request,@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmConfigManagerSystemCall");
	String responseString = "";
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
		
		JSONObject requestObject = new JSONObject();
		JSONObject dataJson = new JSONObject();
		JSONObject getAccountRequestJson = new JSONObject();
		
		Enumeration<String> queryMap = request.getParameterNames();
		while(queryMap.hasMoreElements()) {
			String paramName = queryMap.nextElement();
			getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
		}
		dataJson.put("getConfigurationManagersRequest", getAccountRequestJson);
		requestObject.put("data", dataJson);
		String requestJson = requestObject.toString();
		Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getGetConfigManagerExchange(), inboundQueueProperties.getGetConfigManagerQueue(), message);
		if (responseHeader(result)) {
			res.setStatus(HttpStatus.SC_BAD_REQUEST);
			responseString = new String(result.getBody());
		}
		responseString = new String(result.getBody());
      	} else {
      		responseString = utilityClass.invalidToken(token);
      		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
	LOGGER.info("Response :: " + responseString);
} else {
	responseString = utilityClass.unavailableToken();
	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	LOGGER.info("Invalid Token " + responseString);
}
	}			
	catch(Exception e) {
		LOGGER.error("Exception in unsolicitednotificationsCall "+ e);
	}
	return responseString;
}



@RequestMapping(value = "#{inboundProperties.getDeviceappsintegrationurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String ncmDeviceAppsSystemCall(HttpServletRequest request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmDeviceAppsSystemCall");
	String responseString = "";
	try {
	if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
			LOGGER.info("token validation :: success");	
			JSONObject requestObject = new JSONObject();
			JSONObject dataJson = new JSONObject();
			JSONObject getAccountRequestJson = new JSONObject();
			
			Enumeration<String> queryMap = request.getParameterNames();
			while(queryMap.hasMoreElements()) {
				String paramName = queryMap.nextElement();
				getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
			}
			dataJson.put("getDeviceAppsRequest", getAccountRequestJson);
			requestObject.put("data", dataJson);
			String requestJson = requestObject.toString();
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmDeviceAppIntegrationExchange(), inboundQueueProperties.getNcmDeviceAppIntegrationQueue(), message);
			if (responseHeader(result)) {
				LOGGER.info("responseHeader :: " +result);
				res.setStatus(HttpStatus.SC_BAD_REQUEST);
				responseString = new String(result.getBody());
			}
			responseString = new String(result.getBody());
	      } else {
	    	  responseString = utilityClass.invalidToken(token);
	    	  res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		LOGGER.info("Response :: " + responseString);
	} else {
		responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		LOGGER.info("Invalid Token " + responseString);
	}
	
}
	catch(Exception e) {
		LOGGER.error("Exception in unsolicitednotificationsCall "+ e);
	}
	return responseString;
}

@RequestMapping(value ="#{inboundProperties.getNetdevicehealthurl()}", produces = "text/plain", method = RequestMethod.GET)
@ResponseBody
public String ncmNetDeviceHealthIntegrationCall(@RequestBody String request, @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmNetDeviceHealthIntegrationCall");
	String responseString = "";
	try {
        if (token != null) {
            if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
            	Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
            	Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmNetDeviceHealthIntegrationExchange(), inboundQueueProperties.getNcmDeviceAppIntegrationQueue(), message);
            	if (responseHeader(result)) {
    				LOGGER.info("responseHeader :: " +result);
    				res.setStatus(HttpStatus.SC_BAD_REQUEST);
    				responseString = new String(result.getBody());
    			}
    			responseString = new String(result.getBody());
              	LOGGER.info("Response :: " + responseString);
            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			 }
				 LOGGER.info("Response :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}
		}
	catch(Exception e) {
		LOGGER.error("Exception in unsolicitednotificationsCall "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getProductsintegrationurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String productIntegrationServiceCall(HttpServletRequest request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	
	LOGGER.info("productIntegrationServiceCall starts");
	String responseString = null;
	try {	
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getAccountRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getProductsRequest", getAccountRequestJson);
				requestObject.put("data", dataJson);
				String requestJson = requestObject.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmProductIntegrationExchange(), inboundQueueProperties.getNcmproductIntegrationQueue(), message);
				if (responseHeader(result)) {
    				LOGGER.info("responseHeader :: " +result);
    				res.setStatus(HttpStatus.SC_BAD_REQUEST);
    				responseString = new String(result.getBody());
    			}
    			responseString = new String(result.getBody());
	
			}else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}
	}
	catch(Exception e) {
		LOGGER.error("Exception in productIntegrationServiceCall "+ e);
	}
	return responseString;
}



@RequestMapping(value = "#{inboundProperties.getNetDeviceIntegrationurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String netDeviceIntegrationServiceCall(HttpServletRequest request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("netDeviceIntegrationServiceCall starts");
	String responseString = null;
	try {		
        if (token != null) {
        	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getNetDevicesRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getNetDevicesRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getNetDevicesRequest", getNetDevicesRequestJson);
				requestObject.put("data", dataJson);
				String requestJson = requestObject.toString();
				String limit = this.getNetDevicesRequest(requestJson);
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNetDeviceIntegrationExchange(), inboundQueueProperties.getNetDeviceIntegrationQueue(), message);
				if (responseHeader(result)) {
    				LOGGER.info("responseHeader :: " +result);
    				res.setStatus(HttpStatus.SC_BAD_REQUEST);
    				responseString = new String(result.getBody());
    			}
    			responseString = new String(result.getBody());
				
            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
            }
            LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}	
	}
	catch(Exception e) {
		LOGGER.error("Exception in netDeviceIntegrationServiceCall "+ e);
	}
	return responseString;
}
public String getNetDevicesRequest(String requestJson2) throws Exception{ 
	JSONObject requestJson = new JSONObject(requestJson2);
	Iterator<String> requestKeys = requestJson.keys();
	String limit = Constants.EMPTY;
	while(requestKeys.hasNext()){
		String key = requestKeys.next();
		if(Constants.DATA.equalsIgnoreCase(key) || 
				requestJson.get(key) instanceof JSONObject){
			JSONObject dataJson = requestJson.getJSONObject(key); 
			JSONObject dataJson1 = dataJson.getJSONObject("getNetDevicesRequest"); 
			if(dataJson1.has(Constants.Limit)){
				limit = dataJson1.getString(Constants.Limit);
			}
		}
		else
		{
			if(Constants.Limit.equalsIgnoreCase(key)){
				limit = requestJson.getString(Constants.Limit);
			}
		}
	}
	return limit;
}


@RequestMapping(value = "#{inboundProperties.getNetdevicemetricsurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String netDeviceMetricsCall(HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("netDeviceMetricsCall starts");
	String responseString = null;
	try {	
        if (token != null) {
        	if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = new JSONObject();
				JSONObject dataMap = new JSONObject();
				JSONObject requestMap = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					requestMap.put(paramName, request.getParameter(paramName).toString());
				}
							
				dataMap.put(Constants.GET_NET_DEVICE_METRICS_REQUEST, requestMap);
				requestObject.put(Constants.DATA, dataMap);
				String requestJson = requestObject.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNetDeviceMetricsExchange(), inboundQueueProperties.getNetDeviceMetricsQueue(), message);
				if (responseHeader(result)) {
    				LOGGER.info("responseHeader :: " +result);
    				res.setStatus(HttpStatus.SC_BAD_REQUEST);
    				responseString = new String(result.getBody());
    			}
    			responseString = new String(result.getBody());	
            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
            }
            LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}
	}
	catch(Exception e) {
		LOGGER.error("Exception in netDeviceMetricsCall "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getNetDeviceUsageSamplesurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String ncmNetDeviceUsageSampleCall(HttpServletRequest request,@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	System.out.println("ncmNetDeviceUsageSampleCall");
	String responseString=null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getAccountRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getNetDeviceUsageSample", getAccountRequestJson);
				requestObject.put("data", dataJson);
				String requestJson = requestObject.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmNetDeviceSampleExchange(), inboundQueueProperties.getNcmNetDeviceSampleQueue(), message);
				if (responseHeader(result)) {
    				LOGGER.info("responseHeader :: " +result);
    				res.setStatus(HttpStatus.SC_BAD_REQUEST);
    				responseString = new String(result.getBody());
    			}
    			responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;

	}



@RequestMapping(value = "#{inboundProperties.getNcmGroupDeleteurl()}",method = RequestMethod.DELETE)
@ResponseBody
public String ncmGroupSystemCall(@PathVariable String groupId,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("ncmGroupSystemCall");
	String request =  lineRequestHandle(groupId);
	String responseString = null;
	try {
		  if (token != null) { 
			  if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
		

					Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmGroupDeleteExchange(), inboundQueueProperties.getNcmGroupDeleteQueue(), message);
					if (responseHeader(result)) {
						res.setStatus(HttpStatus.SC_BAD_REQUEST);
						responseString = new String(result.getBody());
					}
	    			responseString = new String(result.getBody());
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}


public String lineRequestHandle(String groupId) {
	String request=null;
	try {
					JSONObject requestJson = new JSONObject();
					JSONObject dataJson = new JSONObject();
					request = groupId;
					LOGGER.info("Path Param:::::" + request);
					dataJson.put("groupId", request);
					requestJson.put("data", dataJson);
					request = requestJson.toString();
		
	} catch (Exception e) {
		LOGGER.error("Exception in linehosistory hanlde method:::"+e.getMessage());

	}
	return request;
}

public String lineRequestHandleAccount(String accountId) {
	String request=null;
	try {
					JSONObject requestJson = new JSONObject();
					JSONObject dataJson = new JSONObject();
					request = accountId;
					LOGGER.info("Path Param:::::" + request);
					dataJson.put("accountId", request);
					requestJson.put("data", dataJson);
					request = requestJson.toString();
		
	} catch (Exception e) {
		LOGGER.error("Exception in linehosistory hanlde method:::"+e.getMessage());

	}
	return request;
}


@RequestMapping(value = "#{inboundProperties.getNcmAccountGeturl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String ncmAccountSystemCall(HttpServletRequest request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) { 
	LOGGER.info("ncmAccountSystemCall");
	String responseString=null;
	try {

		  if (token != null) { 
			  if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
		
		JSONObject requestObject = new JSONObject();
		JSONObject dataJson = new JSONObject();
		JSONObject getAccountRequestJson = new JSONObject();
		
		Enumeration<String> queryMap = request.getParameterNames();
		while(queryMap.hasMoreElements()) {
			String paramName = queryMap.nextElement();
			getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
		}
		dataJson.put("getAccountRequest", getAccountRequestJson);
		requestObject.put("data", dataJson);
		String requestJson = requestObject.toString();
		Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmAccountGetExchange(), inboundQueueProperties.getNcmAccountGetQueue(), message);
		if (responseHeader(result)) {
			res.setStatus(HttpStatus.SC_BAD_REQUEST);
			responseString = new String(result.getBody());
		}
		responseString = new String(result.getBody());
	} else {
		responseString = utilityClass.invalidToken(token);
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
} else {
	responseString = utilityClass.unavailableToken();
	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	LOGGER.info("Invalid Token " + responseString);
}

} catch (Exception e) {
LOGGER.error(e.getMessage(), e);
}
return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getNcmPushNotificationurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public String NCMPushNotification(@RequestBody String request,
			@RequestHeader(value = "x-cp-signature", required = false) String token, HttpServletResponse res) {
		LOGGER.info("PushNotification controller starts");
		String responseString = null;
		try {
			LOGGER.info("PushNotification NCM SecretKey from ReqHed :" + token);
			String seqCode = inboundProperties.getSecCode();
			String msg = request.toString();
		    Mac hasher = Mac.getInstance("HmacSHA256");
		    hasher.init(new SecretKeySpec(seqCode.getBytes(), "HmacSHA256"));
		    byte[] hash = hasher.doFinal(msg.getBytes());
		    String ecodeVal =     DatatypeConverter.printHexBinary(hash);
			/*final MessageDigest digest = MessageDigest.getInstance("SHA-256");
			final byte[] hash = digest.digest(seqCode.getBytes("UTF-8"));
			final StringBuilder hexString = new StringBuilder();
			for (int i = 0; i < hash.length; i++) {
				final String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
			seqCode = hexString.toString();
			LOGGER.info("PushNotification seqCode :" + seqCode);
			seqCode = Constants.SecurityCode;*/
			//String seqCode = token;
			
			LOGGER.info("PushNotification Generated Secret Code :" + ecodeVal);
			if (token.equalsIgnoreCase(ecodeVal)) {
				Message message = MessageBuilder.withBody(request.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				LOGGER.info("PushNotification InputJson :" + message);
				Message result = customRabbitTemplate.sendAndReceive(
						inboundQueueProperties.getNcmPushNotificationExchange(),
						inboundQueueProperties.getNcmPushNotificationQueue(), message);
				LOGGER.info("PushNotification result :" + result);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = Constants.INVALID_Sec;
				res.setStatus(HttpStatus.SC_FORBIDDEN);
			}
			LOGGER.info("PushNotification controller Ends");
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}


@RequestMapping(value = "#{inboundProperties.getNcmAccountDeleteurl()}", method = RequestMethod.DELETE)
@ResponseBody
public String ncmAccountSystemdeleteCall(@PathVariable String accountId,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) { 
	System.out.println("ncmAccountSystemCall");
	String request =  lineRequestHandleAccount(accountId);
	String responseString=null;
	try {
		  if (token != null) { 
			  if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
		 
			
				  Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				  Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmAccountDeleteExchange(), inboundQueueProperties.getNcmAccountDeleteQueue(), message);
				  if (responseHeader(result)) {
						res.setStatus(HttpStatus.SC_BAD_REQUEST);
						responseString = new String(result.getBody());
					}
					responseString = new String(result.getBody());
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

@RequestMapping(value = "#{inboundProperties.getNcmDeviceAppsStateServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
public String deviceAppsStateServiceCall(@RequestHeader(value = "Authorization", required = false) String token,HttpServletRequest request, HttpServletResponse res) {
	LOGGER.info("deviceAppsIntegrationServiceCall");
	String Response = null;
	try {	
		  if (token != null) {
              if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName()))  {
                             
                             JSONObject requestObject = new JSONObject();
                             JSONObject dataJson = new JSONObject();
                             JSONObject getAccountRequestJson = new JSONObject();
                             
                             Enumeration<String> queryMap = request.getParameterNames();
                             while(queryMap.hasMoreElements()) {
                                            String paramName = queryMap.nextElement();
                                            getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
                             }
                             dataJson.put("getDeviceAppStatesRequest", getAccountRequestJson);
                             requestObject.put("data", dataJson);
                             String requestJson = requestObject.toString();
                             
                             Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
                             Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmDeviceAppsStateServiceExchange(), inboundQueueProperties.getNcmDeviceAppsStateServiceQueue(), message);
                             if (responseHeader(result)) {
         						res.setStatus(HttpStatus.SC_BAD_REQUEST);
         						Response = new String(result.getBody());
         					}
                             Response = new String(result.getBody());     
              }else {
                             Response = utilityClass.invalidToken(token);
                             res.setStatus(HttpStatus.SC_UNAUTHORIZED);
              }
              LOGGER.info("Response :: " + Response);
} else {
              Response = utilityClass.unavailableToken();
              res.setStatus(HttpStatus.SC_UNAUTHORIZED);
}

		}
	catch(Exception e) {
		LOGGER.error("Exception in deviceAppsIntegrationServiceCall "+ e);
	}
	return Response;
}


@RequestMapping( value = "#{inboundProperties.getNcmGetRouterStateServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
public String NCMGetRouterStateServiceCall(@RequestHeader(value = "Authorization", required = false) String token,HttpServletRequest request, HttpServletResponse res) {
	LOGGER.info("NCMGetRouterStateServiceCall");
	
	String Response = null;
	
	try {
	if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
			
			JSONObject requestObject = new JSONObject();
			JSONObject dataJson = new JSONObject();
			JSONObject getAccountRequestJson = new JSONObject();
			
			Enumeration<String> queryMap = request.getParameterNames();
			while(queryMap.hasMoreElements()) {
				String paramName = queryMap.nextElement();
				getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
			}
			dataJson.put("getRouterStateSamplesRequest", getAccountRequestJson);
			requestObject.put("data", dataJson);
			String requestJson = requestObject.toString();
			
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmGetRouterStateServiceExchange(), inboundQueueProperties.getNcmGetRouterStateServiceQueue(), message);
			 if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					Response = new String(result.getBody());
				}
            Response = new String(result.getBody()); 
		
		} else {
			Response = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		LOGGER.info("Response :: " + Response);
	} else {
		Response = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
	
}
	catch(Exception e) {
		LOGGER.error("Exception in NCMGetRouterStateServiceCall "+ e);
	}
	return Response;
}



@RequestMapping(value = "#{inboundProperties.getDeleteLocationServicurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
@ResponseBody 
public String LocationServiceCall(@RequestHeader(value = "Authorization", required = false) String token,
		@PathVariable String id, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;
	try {
		JSONObject request = new JSONObject();
		JSONObject dataJson=new JSONObject();
		dataJson.put(Constants.id, id);
		request.put(Constants.DATA, dataJson);
	    requestJson = request.toString();
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDeleteLocationServiceExchange(), inboundQueueProperties.getDeleteLocationServiceQueue(), message);
				 if (responseHeader(result)) {
						res.setStatus(HttpStatus.SC_BAD_REQUEST);
						responseString = new String(result.getBody());
					}
				responseString = new String(result.getBody()); 
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error( e.getMessage(), e);
	}
	return responseString;

}

@RequestMapping(value = "#{inboundProperties.getNcmRouterLogsurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody 
public String RouterLogsServiceCall(@RequestHeader(value = "Authorization", required = false) String token,
		HttpServletRequest request, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;
	try {
		Enumeration<String> queryMap = request.getParameterNames();
		JSONObject getRouterLogsJson = new JSONObject();
		while (queryMap.hasMoreElements()) {
			String paramName = queryMap.nextElement();
			getRouterLogsJson.put(paramName, request.getParameter(paramName).toString());
		}
	    JSONObject dataMap = new JSONObject();
		JSONObject reqJson = new JSONObject();
		dataMap.put("getRouterLogsRequest", getRouterLogsJson);
		reqJson.put(Constants.DATA, dataMap);
		requestJson = reqJson.toString();
	if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getRouterLogsExchange(), inboundQueueProperties.getRouterLogsQueue(), message);
			if (responseHeader(result)) {
				res.setStatus(HttpStatus.SC_BAD_REQUEST);
				responseString = new String(result.getBody());
			}
			responseString = new String(result.getBody());
		} else {
			responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} else {
		responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
}
	catch(Exception e) {
		LOGGER.error(e.getMessage() ,e);
	}
	return responseString;

}


@RequestMapping(value = "#{inboundProperties.getLocationServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE,  method = RequestMethod.GET)
@ResponseBody
public String LocationServiceCall(HttpServletRequest request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;
	try {
		Enumeration<String> queryMap = request.getParameterNames();
		JSONObject getLocationRequestJson = new JSONObject();
		while (queryMap.hasMoreElements()) {
			String paramName = queryMap.nextElement();
			getLocationRequestJson.put(paramName, request.getParameter(paramName).toString());
		}
		JSONObject dataMap = new JSONObject();
		JSONObject reqJson = new JSONObject();
		dataMap.put(Constants.GET_LOCATIONS_REQUEST, getLocationRequestJson);
		reqJson.put(Constants.DATA, dataMap);
		requestJson = reqJson.toString();
		LOGGER.info("JSONN ::" + requestJson);

		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getLocationServiceExchange(), inboundQueueProperties.getLocationServiceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}


@RequestMapping(value ="#{inboundProperties.getNcmFirmwareurl()}",produces = MediaType.APPLICATION_JSON_VALUE,  method = RequestMethod.GET)
@ResponseBody
public Object initiateFirmwarGetServiceCall(HttpServletRequest request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmFirmwareController");
	String requestJson = "";
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				
				LOGGER.info("request :: >>>>> "+ request);
				JSONObject getRequestJson =new JSONObject();
				Map<String, String[]> msgParam = request.getParameterMap();
				for (Entry<String, String[]> eachMap : msgParam.entrySet()) {
					LOGGER.info("eachMap.getKey() :: >>>>> "+ eachMap.getKey());
					LOGGER.info("eachMap.getValue() :: >>>>> "+ eachMap.getValue()[0]);
					getRequestJson.put(eachMap.getKey(), eachMap.getValue()[0]);
				}
				JSONObject reqJson = new JSONObject();
				JSONObject dataMap = new JSONObject();
				dataMap.put(Constants.GET_FIRMWARE_REQUEST, getRequestJson);
				reqJson.put(Constants.DATA, dataMap);
				requestJson = reqJson.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmFirmwareExchange(), inboundQueueProperties.getNcmFirmwareQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getNcmDeviceusagesampleurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public Object NcmNetDeviceUsageSampleServiceCall(HttpServletRequest request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmNetDeviceUsageSampleServiceController");
	String requestJson = "";
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				
				LOGGER.info("request :: >>>>> "+ request);
				JSONObject getRequestJson =new JSONObject();
				Map<String, String[]> msgParam = request.getParameterMap();
				for (Entry<String, String[]> eachMap : msgParam.entrySet()) {
					LOGGER.info("eachMap.getKey() :: >>>>> "+ eachMap.getKey());
					LOGGER.info("eachMap.getValue() :: >>>>> "+ eachMap.getValue()[0]);
					getRequestJson.put(eachMap.getKey(), eachMap.getValue()[0]);
				}
				JSONObject reqJson = new JSONObject();
				JSONObject dataMap = new JSONObject();
				dataMap.put(Constants.GET_NETDEVICEUSAGESAMPLE_REQUEST, getRequestJson);
				reqJson.put(Constants.DATA, dataMap);
				requestJson = reqJson.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmnetdeviceusagesampleserviceExchange(), inboundQueueProperties.getNcmnetdeviceusagesampleserviceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}



@RequestMapping(value = "#{inboundProperties.getNcmLocationServiceCreateurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public Object NcmLocationServiceCreateController(@RequestBody String request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmLocationServiceCreateController -- initiatePostServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				LOGGER.info("validateTransactionType(request) :: "+ validateTransactionType(request));
				Message result=null;
			
					Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					 result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmLocationServiceCreateExchange(), inboundQueueProperties.getNcmLocationServiceCreateQueue(), message);
					 if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
					 responseString = new String(result.getBody());
				
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}

public boolean validateTransactionType(String request) throws Exception {
	boolean transactionTypeFlag = false;
	LOGGER.info("validateTransactionType :: getTransactionType(request) ::: "+ getTransactionType(request) );
	transactionTypeFlag = "CL".equals(getTransactionType(request));

	return transactionTypeFlag;
}

public String getTransactionType(String request) throws Exception{ 
	JSONObject requestJson = new JSONObject(request);
	Iterator<String> requestKeys = requestJson.keys();
	String transactionType = Constants.EMPTY;
	while(requestKeys.hasNext()){
		String key = requestKeys.next();
		if(Constants.DATA.equalsIgnoreCase(key) || 
				requestJson.get(key) instanceof JSONObject){
			JSONObject dataJson = requestJson.getJSONObject(key); 
			if(dataJson.has(Constants.Transaction_typ)){
				transactionType = dataJson.getString(Constants.Transaction_typ);
			}
		}
		else
		{
			if(Constants.Transaction_typ.equalsIgnoreCase(key)){
				transactionType = requestJson.getString(Constants.Transaction_typ);
			}
		}
	}
	return transactionType;
}

@RequestMapping(value = "#{inboundProperties.getRouterStreamUsageSamplesIntegrationurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public Object initiateGetServiceCall(HttpServletRequest request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmRouterStreamUsageSamplesController  --  initiateGetServiceCall");
	String requestJson = "";
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				
				LOGGER.info("request :: >>>>> "+ request);
				JSONObject getRequestJson =new JSONObject();
				Map<String, String[]> msgParam = request.getParameterMap();
				for (Entry<String, String[]> eachMap : msgParam.entrySet()) {
					LOGGER.info("eachMap.getKey() :: >>>>> "+ eachMap.getKey());
					LOGGER.info("eachMap.getValue() :: >>>>> "+ eachMap.getValue()[0]);
					getRequestJson.put(eachMap.getKey(), eachMap.getValue()[0]);
				}
				JSONObject reqJson = new JSONObject();
				JSONObject dataMap = new JSONObject();
				dataMap.put(Constants.GET_ROUTER_STREAM_USAGE_SAMPLES, getRequestJson);
				reqJson.put(Constants.DATA, dataMap);
				requestJson = reqJson.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getRouterStreamUsageSamplesIntegrationExchange(), inboundQueueProperties.getRouterStreamUsageSamplesIntegrationQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}


                                       
@RequestMapping(value = "#{inboundProperties.getNcmRoutersallertsIntegrationurl()}",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
public String NcmRoutersAllertsIntegrationCall(HttpServletRequest request,@RequestHeader(value = "Authorization", required = false)  String token, HttpServletResponse res) {
	LOGGER.info("NcmRoutersAllertsIntegrationCall");
	String responseString = null;
	try {
		if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
		JSONObject requestObject = new JSONObject();
		JSONObject dataJson = new JSONObject();
		JSONObject getAccountRequestJson = new JSONObject();
		
		Enumeration<String> queryMap = request.getParameterNames();
		while(queryMap.hasMoreElements()) {
			String paramName = queryMap.nextElement();
			getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
		}
		dataJson.put("getRoutersAllertsRequest", getAccountRequestJson);
		requestObject.put("data", dataJson);
		String requestJson = requestObject.toString();
		Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmRoutersallertsIntegrationExchange(), inboundQueueProperties.getNcmRoutersallertsIntegrationQueue(), message);
		if (responseHeader(result)) {
			res.setStatus(HttpStatus.SC_BAD_REQUEST);
			responseString = new String(result.getBody());
		}
		responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in unsolicitednotificationsCall "+ e);
		}
		return responseString;
	}	


@RequestMapping(value = "#{inboundProperties.getNcmGetGroupServiceQueueurl()}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String NcmGetGroupServicessCall(HttpServletRequest request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmGetGroupServicessCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getAccountRequestJson = new JSONObject();
				
				Enumeration<String> queryMap = request.getParameterNames();
				while(queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getGroupRequest", getAccountRequestJson);
				requestObject.put("data", dataJson);
				String requestJson = requestObject.toString();
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmGetGroupServiceExchange(), inboundQueueProperties.getNcmGetGroupServiceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in NcmGetGroupServicessCall "+ e);
		}
		return responseString;
	}


@RequestMapping(value = "#{inboundProperties.getNCMGroupUpdateServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
@ResponseBody
public String NcmUpdateGroupServiceCall(@PathVariable String id,@RequestBody String request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmUpdateGroupServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			 if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject object = new JSONObject(request);
				JSONObject dataObj = object.getJSONObject("data");
				dataObj.put("groupId", id);
				object.put("data", dataObj);
				System.out.println(object.toString());
				 
				Message message = MessageBuilder.withBody(object.toString().getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNCMGroupUpdateServiceExchange(), inboundQueueProperties.getNCMGroupUpdateServiceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
					
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in NcmUpdateGroupServiceCall "+ e);
		}
		return responseString;
	}

@RequestMapping( value = "#{inboundProperties.getNcmGetDeviceAppVersionurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody

public String NCMGetDeviceAppVersionsCall(@RequestHeader(value = "Authorization", required = false) String token,HttpServletRequest request, HttpServletResponse res) {
	LOGGER.info("NCMGetDeviceAppVersionsCall");
	
	String Response = null;
	boolean transactionType = false;
	
	try {
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					JSONObject requestObject = new JSONObject();
					JSONObject dataJson = new JSONObject();
					JSONObject getAccountRequestJson = new JSONObject();

					Enumeration<String> queryMap = request.getParameterNames();
					while (queryMap.hasMoreElements()) {
						String paramName = queryMap.nextElement();
						getAccountRequestJson.put(paramName, request.getParameter(paramName).toString());
					}
					dataJson.put("getDeviceAppVersionsRequest", getAccountRequestJson);
					requestObject.put("data", dataJson);
					String requestJson = requestObject.toString();
					LOGGER.info(requestJson);
					if(requestJson.contains(Constants.Transaction_typ)) {
						transactionType=true;
					}

					if (!this.validateTransactionTypeUpdate1(requestJson) && transactionType==true) {
						Response = this.getTransactionError(requestJson);
					} else {

						Message message = MessageBuilder.withBody(requestJson.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();

						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getNcmGetDeviceAppVersionExchange(),
								inboundQueueProperties.getNcmGetDeviceAppVersionQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							Response = new String(result.getBody());
						}
						Response = new String(result.getBody());

					}
				} else {
					Response = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("Response :: " + Response);
			} else {
		Response = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
	
}
	catch(Exception e) {
		LOGGER.error("Exception in getDeviceAppVersionRequestCall "+ e);
	}
	return Response;
}




@RequestMapping(value = "#{inboundProperties.getNcmgetRouterurl()}", produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
@ResponseBody
public Object ncmgetrouterserviceCall(HttpServletRequest request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	//Object Response = new Object();
	String requestJson="";
	String responseString=null;
	try {
		System.out.println("ncmgetrouterserviceCall::::");
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getRouterRequestJson = new JSONObject();

				Enumeration<String> queryMap = request.getParameterNames();
				while (queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getRouterRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getRouterRequest", getRouterRequestJson);
				requestObject.put("data", dataJson);
				requestJson = requestObject.toString();
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmgetrouterExchange(), inboundQueueProperties.getNcmgetRouterQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

		// System.out.println("ncmgetrouterserviceCallResponse::::" +Response);
	} catch (Exception e) {
		LOGGER.error("Exception in Ncmgetrouterservicecall " + e);
	}
	return responseString;

}

@RequestMapping(value = "#{inboundProperties.getNcmgetactivitylogurl()}", produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
@ResponseBody 
public Object getactivitylogServiceCall(HttpServletRequest request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("getactivitylogServiceCall  --");

	String requestJson = "";
	//Object Response = new Object();
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getActivityLogsRequestJson = new JSONObject();

				Enumeration<String> queryMap = request.getParameterNames();
				while (queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getActivityLogsRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getActivityLogsRequest", getActivityLogsRequestJson);
				requestObject.put("data", dataJson);
				requestJson = requestObject.toString();
				//Response = rabbitTemplate.convertSendAndReceive(exchange.getName(), queue.getName(), requestJson);
				
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmgetactivitylogExchange(), inboundQueueProperties.getNcmgetactivitylogQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				
				responseString = new String(result.getBody());
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} catch (Exception e) {
		LOGGER.error("Exception in getactivitylogServiceCall  " + e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getNcmAccountCreateurl()}", produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public String ncmAccountSystemCreateCall(@RequestBody String request,@RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) { 
	LOGGER.info("ncmAccountSystemCall");
	String responseString=null;
	try {
			
			  if (token != null) { 
				  if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					  Message result = null;
					
						Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmAccountCreateExchange(), inboundQueueProperties.getNcmAccountCreateQueue(), message);
						if (responseHeader(result)) {
							res.setStatus(HttpStatus.SC_BAD_REQUEST);
							responseString = new String(result.getBody());
						}
						responseString = new String(result.getBody());
						
					} else {
						responseString = utilityClass.invalidToken(token);
						res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					}
				} else {
					responseString = utilityClass.unavailableToken();
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
					LOGGER.info("Invalid Token " + responseString);
				}

			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}
			return responseString;
		}

public boolean validateTransactionTypeAcc(String request, String httpMethod) throws Exception {
	boolean transactionTypeFlag = false;
	String transactionType = getTransactionType(request);
	if (transactionType != Constants.EMPTY) {
		switch (httpMethod) {
		case Constants.HTTP_POST: {
			transactionTypeFlag = "CA".equals(transactionType);
		}
			break;
		case Constants.HTTP_PUT: {
			transactionTypeFlag = "UA".equals(transactionType);
		}
			break;
		}
	} else {

	}
	return transactionTypeFlag;
}


public boolean validateTransactionTypeGroup(String request, String httpMethod) throws Exception {
	boolean transactionTypeFlag = false;
	String transactionType = getTransactionType(request);
	if (transactionType != Constants.EMPTY) {
		switch (httpMethod) {
		case Constants.HTTP_POST: {
			transactionTypeFlag = "CG".equals(transactionType);
		}
			break;
		case Constants.HTTP_PUT: {
			transactionTypeFlag = "UG".equals(transactionType);
		}
			break;
		}
	} else {

	}
	return transactionTypeFlag;
}

public boolean validateTransactionTypeRouter(String request, String httpMethod) throws Exception {
	boolean transactionTypeFlag = false;
	String transactionType = getTransactionType(request);
	if (transactionType != Constants.EMPTY) {
		switch (httpMethod) {
		case Constants.HTTP_POST: {
			transactionTypeFlag = "CG".equals(transactionType);
		}
			break;
		case Constants.HTTP_PUT: {
			transactionTypeFlag = "UR".equals(transactionType);
		}
			break;
		}
	} else {

	}
	return transactionTypeFlag;
}


@RequestMapping(value = "#{inboundProperties.getNcmRouterUpdateurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
@ResponseBody
public String routerUpdateServiceCall(@RequestBody String request, @PathVariable("id") String id, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("routerUpdateServiceCall starts");
	String responseString = null;
	
	try {
        if (token != null) {
            if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName()))  {
				if (request != null) {
					JsonObject jsonObject = new JsonParser().parse(request).getAsJsonObject();
					LOGGER.info(jsonObject.toString());
					if(jsonObject.has("data")) {
						JsonObject dataJsonObjet = (JsonObject) jsonObject.get("data");
						dataJsonObjet.getAsJsonObject().addProperty("routerId", id);
					}
					request = jsonObject.toString();
				}
				if (request != null) {
				Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmRouterUpdateExchange(), inboundQueueProperties.getNcmRouterUpdateQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				}		
            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
            }
            LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	}
	catch(Exception e) {
		LOGGER.error("Exception in routerUpdateServiceCall "+ e);
	}
	return responseString;
}


@RequestMapping(value = "#{inboundProperties.getDeleteDeviceAppBindingsurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
@ResponseBody
public String DeleteDeviceAppBindingsCall(@RequestHeader(value = "Authorization", required = false) String token,
		@PathVariable String id, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;
	try {
		JSONObject request = new JSONObject();
		JSONObject dataJson = new JSONObject();
		dataJson.put(Constants.id, id);
		request.put(Constants.DATA, dataJson);
		requestJson = request.toString();

		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDeleteDeviceAppBindingsExchange(), inboundQueueProperties.getDeleteDeviceAppBindingsQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage() + e);
	}
	return responseString;

}

@RequestMapping(value = "#{inboundProperties.getUpdateLocationServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
@ResponseBody
public String LocationServiceCall(@RequestHeader(value = "Authorization", required = false) String token,
		@RequestBody String req, HttpServletRequest request, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;
	try {
		String httpPath = request.getRequestURI();
		String httpMethod = request.getMethod();
		LOGGER.info("PATH INFO :" + httpPath);
		int lastIndexSlash = httpPath.lastIndexOf('/');
		int lengthUri = httpPath.length();
		String id = httpPath.substring(lastIndexSlash + 1, lengthUri);
		JSONObject jsonObject = new JSONObject(req);
		if (jsonObject.has("data")) {
			JSONObject dataJsonObject = new JSONObject(jsonObject.get("data").toString());
			if (dataJsonObject.has("updateLocationsRequest")) {
				JSONObject updateLocationsRequest = (JSONObject) dataJsonObject.get("updateLocationsRequest");
				updateLocationsRequest.put("id", id);
				dataJsonObject.put("updateLocationsRequest", updateLocationsRequest);
				jsonObject.put("data", dataJsonObject);
			}
		}
		requestJson = jsonObject.toString();
		LOGGER.info("requestJson " + requestJson);
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
			
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getUpdateLocationServiceExchange(), inboundQueueProperties.getUpdateLocationServiceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
					
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error("Exception in LocationServiceCall " + e);
	}
	return responseString;

}
public boolean validateTransactionType(String request, String httpMethod) throws Exception{
	boolean transactionTypeFlag = false;
	if(httpMethod.equalsIgnoreCase(Constants.HTTP_PUT)){
			transactionTypeFlag = "UL".equals(getTransactionType(request));
	}
	return transactionTypeFlag;
}




@RequestMapping(value = "#{inboundProperties.getNcmCreateGroupServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public Object NcmCreateGroupServiceCall(@RequestBody String request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmCreateGroupServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				  
				Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmCreateGroupServiceExchange(), inboundQueueProperties.getNcmCreateGroupServiceQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
					
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in NcmCreateGroupServiceCall "+ e);
		}
		return responseString;
	}


@RequestMapping(value = "#{inboundProperties.getNcmUpdateAccountSystemurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
@ResponseBody
public Object NcmUpdateAccountServiceCall(@PathVariable String id,@RequestBody String request, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmUpdateAccountServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject object = new JSONObject(request);
				JSONObject dataObj = object.getJSONObject("data");
				dataObj.put("accountId", id);
				object.put("data", dataObj);
				System.out.println(object.toString());
				Message message = MessageBuilder.withBody(object.toString().getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmUpdateAccountSystemExchange(), inboundQueueProperties.getNcmUpdateAccountSystemQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
					
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		
	}
		catch(Exception e) {
			LOGGER.error("Exception in NcmUpdateAccountServiceCall "+ e);
		}
		return responseString;
	}



@RequestMapping(value ="#{inboundProperties.getNcmgetdeviceappbindinglogurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public Object ncmgetdeviceAppBindingCall(HttpServletRequest request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	//Object Response = new Object();
	String requestJson = "";
	String responseString = null;
	try {
		System.out.println("inside devieappbinding");
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
            	
            	
            	JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getDeviceAppBindingsRequestJson = new JSONObject();

				Enumeration<String> queryMap = request.getParameterNames();
				while (queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getDeviceAppBindingsRequestJson.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getDeviceAppBindingsRequest", getDeviceAppBindingsRequestJson);
				requestObject.put("data", dataJson);
				requestJson = requestObject.toString();
            	
            	Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
            	Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmgetdeviceappbindinglogExchange(), inboundQueueProperties.getNcmgetdeviceappbindinglogQueue(), message);
            	if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());

            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			 }
			 LOGGER.info("Response :: " + responseString);
			} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ncmgetdeviceAppBindingCall " + e);
	}
	return responseString;

}


@RequestMapping(value = "#{inboundProperties.getNcmCreateSpeedlogurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public Object ncmCreateSpeedTestsSystemCall(@RequestBody String request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {

	//Object Response = new Object();
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				

				JSONObject requestObject = this.checkSizeParam(new JSONObject(request));
				 
				Message message = MessageBuilder.withBody(requestObject.toString().getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmCreateSpeedlogExchange(), inboundQueueProperties.getNcmCreateSpeedlogQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				System.out.println("start createSpeedTestRequestJsonResponse" + responseString);
					
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
	} catch (Exception e) {
		LOGGER.error("Exception in ncmSpeedTestsSystemCall " + e);
	}
	return responseString;

}


public boolean validateTransactionTypecreate(String request) throws Exception {
	boolean transactionTypeFlag = false;
	
	transactionTypeFlag = "CS".equals(getTransactionTypecreate(request));
	return transactionTypeFlag;
}

@SuppressWarnings("unchecked")
public String getTransactionTypecreate(String request) throws Exception {
	JSONObject requestJson = new JSONObject(request);
	Iterator<String> requestKeys = requestJson.keys();
	String transactionType = Constants.EMPTY;
	while (requestKeys.hasNext()) {
		String key = requestKeys.next();
		if (Constants.DATA.equalsIgnoreCase(key) || requestJson.get(key) instanceof JSONObject) {
			JSONObject dataJson = requestJson.getJSONObject(key);
			if (dataJson.has(Constants.Transaction_typ)) {
				transactionType = dataJson.getString(Constants.Transaction_typ);
			}
		} else {
			if (Constants.Transaction_typ.equalsIgnoreCase(key)) {
				transactionType = requestJson.getString(Constants.Transaction_typ);
			}
		}
	}
	return transactionType;
}

@SuppressWarnings("unchecked")
public String getTransactionErrorcreate(String request) throws Exception {
	JsonObject requestJson = new Gson().fromJson(request, JsonObject.class);
	JsonObject errorJson = new JsonObject();
	JsonObject errorDataJson = new JsonObject();
	Iterator<Entry<String, JsonElement>> requestKeys = requestJson.entrySet().iterator();
	while (requestKeys.hasNext()) {
		Entry<String, JsonElement> entry = requestKeys.next();
		if (Constants.MESSAGE_HEADER.equalsIgnoreCase(entry.getKey())) {
			JsonObject headerJson = requestJson.getAsJsonObject(entry.getKey());
			errorJson.add(entry.getKey(), headerJson);
			break;
		}
	}
	errorDataJson.addProperty(Constants.CODE, "403");
	errorDataJson.addProperty(Constants.STATUS, "Forbidden");
	errorDataJson.addProperty("Reason", "Invalid format(or)Invalid Length");
	errorDataJson.addProperty(Constants.MESSAGE, "transactionType Invalid ");
	errorDataJson.addProperty("reasonCode", "");
	errorDataJson.addProperty("input", "");
	errorJson.add(Constants.DATA, errorDataJson);
	return errorJson.toString();
}

@SuppressWarnings("unchecked")
private JSONObject checkSizeParam(JSONObject requestObject) throws JSONException {
	Iterator<String> objItr = requestObject.keys();
	while (objItr.hasNext()) {
		String key = objItr.next();
		if (Constants.DATA.equalsIgnoreCase(key)) {
			JSONObject dataObj = (JSONObject) requestObject.get(Constants.DATA);
			Iterator<String> dataItr = dataObj.keys();
			while (dataItr.hasNext()) {
				String dkey = dataItr.next();
				if (Constants.POST_SPEED_TEST_REQUEST.equalsIgnoreCase(dkey)) {
					JSONObject postObj = (JSONObject) dataObj.get(Constants.POST_SPEED_TEST_REQUEST);
					Iterator<String> pItr = postObj.keys();
					while (pItr.hasNext()) {
						String pkey = pItr.next();
						if (Constants.SPEED_TEST_CONFIG.equalsIgnoreCase(pkey)) {
							JSONObject configObj = postObj.getJSONObject(pkey);
							Iterator<String> configKeys = configObj.keys();
							while (configKeys.hasNext()) {
								String ckey = configKeys.next();
								if (Constants.SPEED_TEST_SIZE.equalsIgnoreCase(ckey)) {
									if (configObj.get(ckey) == JSONObject.NULL)
										configObj.put(Constants.SPEED_TEST_SIZE, Constants.STRING_NULL);
								} else if (Constants.SPEED_TEST_NET_DEVICE_IDS.equalsIgnoreCase(ckey)) {
									if (configObj.get(ckey) != JSONObject.NULL)
										configObj.put(ckey, String.valueOf(configObj.get(ckey)));
								}
							}
						}
					}
				}
			}
		}
	}
	return requestObject;
}


@RequestMapping(value = "#{inboundProperties.getNcmRouterDeleteurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
@ResponseBody
public String routerDeleteServiceCall(@PathVariable("routerId") String routerId, @RequestHeader(value="Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("routerDeleteServiceCall starts");
	String responseString = null;	
	
	try {	
        if (token != null) {
            if(authHandler.checkOAuthToken(token, inboundProperties.getApplicationName()))  {
				JSONObject requestJson = new JSONObject();
				JSONObject dataJson = new JSONObject();
				String request = "";
				dataJson.put("routerId", routerId);
				requestJson.put("data", dataJson);
				request = requestJson.toString();
				
				Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmRouterDeleteExchange(), inboundQueueProperties.getNcmRouterDeleteQueue(), message);
				if (responseHeader(result)) {
					res.setStatus(HttpStatus.SC_BAD_REQUEST);
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
	            
            }else {
            	responseString = utilityClass.invalidToken(token);
            	res.setStatus(HttpStatus.SC_UNAUTHORIZED);
            }
            LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	}
	catch(Exception e) {
		LOGGER.error("Exception in routerDeleteServiceCall "+ e);
	}
	return responseString;
}



@RequestMapping(value ="#{inboundProperties.getNslDeviceAppsIntegrationServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)

public String deviceAppsIntegrationServiceCall(@PathVariable("id") int id,@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("deviceAppsIntegrationServiceCall");
	String requestJson = "";
	try {
		JSONObject request = new JSONObject();
		JSONObject dataJson=new JSONObject();
		dataJson.put(Constants.id, id);
		request.put(Constants.DATA, dataJson);
		requestJson = request.toString();
	 LOGGER.info("JSONNNN ::"+requestJson);
	}catch(Exception e) {
		LOGGER.error("Exception in Constructing JSON "+e);
	}
	String Response = null;
	
	try {
	if (token != null) {
		if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNslDeviceAppsIntegrationServiceExchange(), inboundQueueProperties.getNslDeviceAppsIntegrationServiceQueue(), message);
			System.out.println("Message Response123::" + result);
			if (responseHeader(result)) {
				res.setStatus(HttpStatus.SC_BAD_REQUEST);		
				Response = new String(result.getBody());
			}
			Response = new String(result.getBody());
		
		} else {
			Response = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		LOGGER.info("Response123 :: " + Response);
	} else {
		Response = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
	
}
	catch(Exception e) {
		LOGGER.error("Exception in deviceappcall "+ e);
	}
	return Response;
}


@RequestMapping(value = "#{inboundProperties.getDeleteDeviceAppVersionurl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
@ResponseBody	
public String ncmDeleteDeviceAppVersionsCall( @PathVariable("id") int id,
		 @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	String responseString = null;
	String  requestJson="";
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject request = new JSONObject();
			JSONObject dataJson=new JSONObject();
			dataJson.put(Constants.id, id);
			request.put(Constants.DATA, dataJson);
			requestJson = request.toString();
			LOGGER.info("JSONNNN ::"+requestJson);
			Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getDeleteDeviceAppVersionExchange(), inboundQueueProperties.getDeleteDeviceAppVersionQueue(), message);
			if (responseHeader(result)) {
				LOGGER.info("responseHeader ::"+result);
				res.setStatus(HttpStatus.SC_BAD_REQUEST);		
				responseString = new String(result.getBody());
			}
			responseString = new String(result.getBody());
			
		} else {
			responseString = utilityClass.invalidToken(token);
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}
		LOGGER.info("Response :: " + responseString);
	} else {
		responseString = utilityClass.unavailableToken();
		res.setStatus(HttpStatus.SC_UNAUTHORIZED);
	}
	
}
	catch(Exception e) {
		LOGGER.error("Exception in ncmDeleteDeviceAppVersionsCall "+ e);
	}
	return responseString;
}


@RequestMapping(value ="#{inboundProperties.getNcmFailoversIntegrationServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public String initiateGetServiceCall(@RequestBody String  request,  
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	LOGGER.info("NcmFailoversIntegrationServiceController -- initiateGetServiceCall");
	String responseString = null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmFailoversIntegrationServiceExchange(), inboundQueueProperties.getNcmFailoversIntegrationServiceQueue(), message);
				if (responseHeader(result)) {
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(HttpStatus.SC_BAD_REQUEST);		
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			LOGGER.info("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return responseString;
}

@RequestMapping(value = "#{inboundProperties.getNcmrebooturl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
@ResponseBody
public Object ncmRebootCall(@RequestBody String request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	//Object Response = new Object();
	String responseString =null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				
				
				Message message = MessageBuilder.withBody(request.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmrebootExchange(), inboundQueueProperties.getNcmrebootQueue(), message);
				if (responseHeader(result)) {
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(HttpStatus.SC_BAD_REQUEST);		
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error("Exception in ncmRebootCall " + e);
	}
	return responseString;

}

public boolean validateTransactionTypeReboot(String request) throws Exception {
	boolean transactionTypeFlag = false;

	transactionTypeFlag = "CR".equals(getTransactionType(request));

	return transactionTypeFlag;
}



@RequestMapping(value = "#{inboundProperties.getNcmcreatedeviceappbindinglogUrl()}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
public Object ncmcreatedeviceAppBindingCall(@RequestBody String request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	
	String responseString = null;
	try {

		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				Message message = MessageBuilder.withBody(request.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(

						inboundQueueProperties.getNcmcreatedeviceappbindinglogExchange(),
						inboundQueueProperties.getNcmcreatedeviceappbindinglogQueue(), message);
				if (responseHeader(result)) {
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(HttpStatus.SC_BAD_REQUEST);		
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
				
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			System.out.println("Invalid Token " + responseString);
		}

		System.out.println("inside devieappbindingResponse" + responseString);
	} catch (Exception e) {
		LOGGER.error("Exception in ncmRebootCall " + e);
	}
	return responseString;

}

public boolean validateTransactionTypeapp(String request) throws Exception {
	boolean transactionTypeFlag = false;

	transactionTypeFlag = "CD".equals(getTransactionType(request));
	return transactionTypeFlag;
}

@RequestMapping(value = "#{inboundProperties.getNcmhistoricalloclogurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody
public Object ncmhistoricallocIntegCall(HttpServletRequest request,
		@RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	
	String requestJson = "";
	String responseString=null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
				JSONObject requestObject = new JSONObject();
				JSONObject dataJson = new JSONObject();
				JSONObject getHistoricalLocationIntegrationRequest = new JSONObject();

				Enumeration<String> queryMap = request.getParameterNames();
				while (queryMap.hasMoreElements()) {
					String paramName = queryMap.nextElement();
					getHistoricalLocationIntegrationRequest.put(paramName, request.getParameter(paramName).toString());
				}
				dataJson.put("getHistoricalLocationIntegrationRequest", getHistoricalLocationIntegrationRequest);
				requestObject.put("data", dataJson);
				requestJson = requestObject.toString();

				Message message = MessageBuilder.withBody(requestJson.getBytes())
						.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNcmhistoricalloclogExchange(), inboundQueueProperties.getNcmhistoricalloclogQueue(), message);
				if (responseHeader(result)) {
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(HttpStatus.SC_BAD_REQUEST);		
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());
			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			System.out.println("Invalid Token " + responseString);
		}

	} catch (Exception e) {
		LOGGER.error("Exception in ncmhistoricallocIntegCall " + e);
	}
	return responseString;

}

@RequestMapping(value ="#{inboundProperties.getNCMAllertIntegrationServiceurl()}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
@ResponseBody

public String ncmAlleretIntegrationServiceCall(HttpServletRequest request,  @RequestHeader(value = "Authorization", required = false) String token, HttpServletResponse res) {
	String requestJson = "";
	 String responseString=null;
	try {
		if (token != null) {
			if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {

				
				LOGGER.info("request :: >>>>> "+ request);
				JSONObject getRequestJson =new JSONObject();
				Map<String, String[]> msgParam = request.getParameterMap();
				for (Entry<String, String[]> eachMap : msgParam.entrySet()) {
					LOGGER.info("eachMap.getKey() :: >>>>> "+ eachMap.getKey());
					LOGGER.info("eachMap.getValue() :: >>>>> "+ eachMap.getValue()[0]);
					getRequestJson.put(eachMap.getKey(), eachMap.getValue()[0]);
				}
				JSONObject reqJson = new JSONObject();
				JSONObject dataMap = new JSONObject();
				dataMap.put(Constants.GET_DEVICE_APP_BINDINGS_REQUEST, getRequestJson);
				reqJson.put(Constants.DATA, dataMap);
				requestJson = reqJson.toString();
				Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNCMAllertIntegrationServiceExchange(), inboundQueueProperties.getNCMAllertIntegrationServiceQueue(), message);
				if (responseHeader(result)) {
					LOGGER.info("responseHeader ::"+result);
					res.setStatus(HttpStatus.SC_BAD_REQUEST);		
					responseString = new String(result.getBody());
				}
				responseString = new String(result.getBody());

			} else {
				responseString = utilityClass.invalidToken(token);
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);
			}
			LOGGER.info("Response :: " + responseString);
		} else {
			responseString = utilityClass.unavailableToken();
			res.setStatus(HttpStatus.SC_UNAUTHORIZED);
		}

	} catch (Exception e) {
		LOGGER.error("Exception in ncmAlleretIntegrationServiceCall " + e);
	}
	return responseString;
}


@RequestMapping(value ="#{inboundProperties.getNCMUpdateConfigMangerServiceurl()}", produces = "application/json", consumes = "application/json", method = RequestMethod.PATCH)
@ResponseBody
public String ncmupdategroupCall(@RequestHeader(value = "Authorization", required = false) String token,
		@RequestBody String req, HttpServletRequest request, HttpServletResponse res) {
	String requestJson = "";
	String responseString = null;			
		try {
			String httpPath = request.getRequestURI();
			LOGGER.info("PATH INFO :" + httpPath);
			int lastIndexSlash = httpPath.lastIndexOf('/');
			int lengthUri = httpPath.length();
			String id = httpPath.substring(lastIndexSlash + 1, lengthUri);
			JSONObject jsonObject = new JSONObject(req);				
			if (jsonObject.has("data")) {
				JSONObject dataJsonObject = new JSONObject(jsonObject.get("data").toString());
				dataJsonObject.put("id", id);
				jsonObject.put("data", dataJsonObject);
				LOGGER.info("jsonObject ::: " + jsonObject.toString());
			}
			requestJson = jsonObject.toString();
			LOGGER.info("requestJson " + requestJson);				
			if (token != null) {
				if (authHandler.checkOAuthToken(token, inboundProperties.getApplicationName())) {
					LOGGER.info("validateTransactionType(request) :: "+ validateTransactionTypeUpdate(requestJson));
					Message result = null;

						Message message = MessageBuilder.withBody(requestJson.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getNCMUpdateConfigMangerServiceExchange(), inboundQueueProperties.getNCMUpdateConfigMangerServiceQueue(), message);
						if (responseHeader(result)) {
							LOGGER.info("responseHeader ::"+result);
							res.setStatus(HttpStatus.SC_BAD_REQUEST);		
							responseString = new String(result.getBody());
						}
						 
					
					responseString = new String(result.getBody());
				} else {
					responseString = utilityClass.invalidToken(token);
					res.setStatus(HttpStatus.SC_UNAUTHORIZED);
				}
				LOGGER.info("responseString :: " + responseString);
			} else {
				responseString = utilityClass.unavailableToken();
				res.setStatus(HttpStatus.SC_UNAUTHORIZED);

			}
			System.out.println("responseString" + responseString);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;

	}


	public boolean validateTransactionTypeUpdate(String request) throws Exception {
		boolean transactionTypeFlag = false;

		transactionTypeFlag = "UC".equals(getTransactionType(request));
		return transactionTypeFlag;
	}

	public boolean validateTransactionTypeUpdate1(String request) throws Exception {
		boolean transactionTypeFlag = false;

		transactionTypeFlag = "CA12".equals(getTransactionType(request));
		return transactionTypeFlag;
	}
	
	public String getTransactionError(String request) throws Exception {
		JsonObject requestJson = new Gson().fromJson(request, JsonObject.class);
		JsonObject errorJson = new JsonObject();
		JsonObject errorDataJson = new JsonObject();

		Iterator<Entry<String, JsonElement>> requestKeys = requestJson.entrySet().iterator();
		while (requestKeys.hasNext()) {
			Entry<String, JsonElement> entry = requestKeys.next();
			if (Constants.MESSAGE_HEADER.equalsIgnoreCase(entry.getKey())) {
				JsonObject headerJson = requestJson.getAsJsonObject(entry.getKey());
				errorJson.add(entry.getKey(), headerJson);
				break;
			}
		}
			errorDataJson.addProperty(Constants.CODE, "403");
			errorDataJson.addProperty(Constants.STATUS, "Forbidden");
			errorDataJson.addProperty("Reason", "Invalid format(or)Invalid Length");
			errorDataJson.addProperty(Constants.MESSAGE, "transactionType Invalid ");
			errorDataJson.addProperty("reasonCode", "");
			errorDataJson.addProperty("input", "");
			errorJson.add(Constants.DATA, errorDataJson);
		return errorJson.toString();
	}	

	public String getLimitError(String request) throws Exception {
		JsonObject requestJson = new Gson().fromJson(request, JsonObject.class);
		JsonObject errorJson = new JsonObject();
		JsonObject errorDataJson = new JsonObject();

		Iterator<Entry<String, JsonElement>> requestKeys = requestJson.entrySet().iterator();
		while (requestKeys.hasNext()) {
			Entry<String, JsonElement> entry = requestKeys.next();
			if (Constants.MESSAGE_HEADER.equalsIgnoreCase(entry.getKey())) {
				JsonObject headerJson = requestJson.getAsJsonObject(entry.getKey());
				errorJson.add(entry.getKey(), headerJson);
				break;
			}
		}
			errorDataJson.addProperty(Constants.CODE, "400");
			errorDataJson.addProperty(Constants.STATUS, "Bad Request");
			errorDataJson.addProperty("Reason", "Invalid JSON request");
			errorDataJson.addProperty(Constants.MESSAGE, "limit Cannot be empty ");
			errorDataJson.addProperty("reasonCode", "");
			errorDataJson.addProperty("input", "");
			errorJson.add(Constants.DATA, errorDataJson);
		return errorJson.toString();
	}
	@SuppressWarnings("unchecked")
	public boolean responseHeader(Message msg) throws NslCustomException, NotAuthorizedException {
		try {
			byte[] body = msg.getBody();
			String req = new String(body);
			LOGGER.info(" inside request " + req);
			System.out.println("inside request::" + req);
			if (!req.isEmpty()) {
				String codeStr = "";
				String status = "";
				if (req.startsWith("{")) {

					JSONObject reqJson = new JSONObject(req);
					Iterator<String> reqJsonItr = reqJson.keys();
					while (reqJsonItr.hasNext()) {
						String reqKey = reqJsonItr.next();
						if (Constants.DATA.equalsIgnoreCase(reqKey)) {
							JSONObject dataJson = (JSONObject) reqJson.get(reqKey);
							Iterator<String> dataJsonItr = dataJson.keys();
							while (dataJsonItr.hasNext()) {
								String dataKey = dataJsonItr.next();
								if (Constants.CODE.equalsIgnoreCase(dataKey)) {
									codeStr = dataJson.getString(dataKey);
								} else if (Constants.STATUS.equalsIgnoreCase(dataKey)) {
									status = dataJson.getString(dataKey);
								}
							}
						}
						LOGGER.info("inside codeStr " + codeStr);
						System.out.println("inside codeStr::" + codeStr);
					}
					if (StringUtils.hasText(codeStr)) {
						int code = Integer.parseInt(codeStr);
						if (code >= 400 && code <= 600) {
							return true;
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
		return false;
	}
}



