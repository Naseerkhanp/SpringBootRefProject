/**
 * 
 */
package com.nsl.managelines.batch.consumer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;

import com.google.gson.Gson;
import com.nsl.managelines.batch.bean.AsyncType;
import com.nsl.managelines.batch.bean.InboundData;
import com.nsl.managelines.batch.bean.KeyValueObj;
import com.nsl.managelines.batch.bean.MessageHeader;
import com.nsl.managelines.batch.bean.OutboundRequest;
import com.nsl.managelines.batch.bean.Page;
import com.nsl.managelines.batch.bean.RequestBean;
import com.nsl.managelines.batch.bean.RetrieveDeviceAyncResponse;
import com.nsl.managelines.batch.bean.RetrieveDeviceBean;
import com.nsl.managelines.batch.bean.PortinInquiryResBean;
import com.nsl.managelines.batch.bean.SubOrder;
import com.nsl.managelines.batch.bean.planmigration.PlanMigrationRequest;
import com.nsl.managelines.batch.bean.planmigration.StgPlanMigration;
import com.nsl.managelines.batch.bean.Line;
import com.nsl.managelines.batch.constants.Constants;
import com.nsl.managelines.batch.constants.UtilityClass;
import com.nsl.managelines.batch.bean.FileDetails;
import com.nsl.managelines.batch.bean.FileOperationRequest;
import com.nsl.managelines.batch.service.ManageLinesService;
import com.nsl.managelines.batch.service.ResourceClientService;
import com.nsl.managelines.dao.cif.entity.TransactionDetails;
import com.nsl.managelines.dao.cif.impl.TransactionDetailsDao;
import com.nsl.managelines.logger.UtilityService;
import com.nsl.managelines.batch.properties.InboundProperties;
import java.io.ByteArrayOutputStream;
import com.nsl.managelines.batch.bean.ReportMgmtRequest;
import com.nsl.managelines.batch.adaptors.ReportManagementAdaptor;
import lombok.extern.log4j.Log4j2;

/**
 * @author vinothini.T
 *
 */

@Log4j2
@Component
public class ManageLineConsumer {

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private TransactionDetailsDao transactionDetailsDao;

	@Autowired
	private ManageLinesService manageLinesService;

	@Autowired
	private ResourceClientService resourceServiceClient;

	@Autowired
	private InboundProperties inboundProperties;

	@Autowired
	private ReportManagementAdaptor reportManagementAdaptor;

	public ResponseEntity<String> retriveDeviceCallforAS(RequestBean requestBean) {
		log.info("Started Scheduler at :" + getTimeStamp());
		log.info("Request:" + requestBean);
		String outboundRequest = "";
		String url = inboundProperties.getRouterserviceurl();
		String frameworkResponse = "";
		// String transactionName = "";
		String status = "";
		ResponseEntity<String> response = null;
		UtilityService.addTraceDetails("NA", "NA", Constants.SCHEDULER);
		try {
			// transactionName = requestBean.getTransactionName();
			status = requestBean.getStatus();
			Set<TransactionDetails> transactionDetailsList = transactionDetailsDao
					.findTransactionDetailsByTransactionNameAndStatus(status, requestBean.getTransactionName());
			if (transactionDetailsList.size() > 0) {
				log.info("transactionDetails " + transactionDetailsList);
				for (TransactionDetails transactionDetail : transactionDetailsList) {
					try {
						if (transactionDetail.getTransactionId() != null)
							UtilityService.updateTrace(String.valueOf(transactionDetail.getTransactionId()), "NA",
									Constants.SCHEDULER);
						outboundRequest = transactionDetail.getRequestMsg();
						OutboundRequest outRequestBean = null;
						Gson gson = new Gson();
						try {
							outRequestBean = gson.fromJson(outboundRequest, OutboundRequest.class);
						} catch (Exception e) {
							log.error("Invalid JSON format...", e);
						}
						if (outRequestBean != null) {
							String serviceName = "";
							String operationName = "";

							if (transactionDetail.getTransactionName().contains("Port-in")) {
								log.info("Processing Portin  transaction :::  "
										+ transactionDetail.getTransactionName());
								serviceName = "Portin-Inquiry";
								operationName = "mnoportininquiryworkflow";
								outboundRequest = "{\"mdn\":\"" + outRequestBean.getData().getMdn() + "\"}";
							} else {
								log.info("Processing transaction :::  " + transactionDetail.getTransactionName());
								serviceName = "Retrieve-Device";
								operationName = "RetrieveDeviceWorkflow";

								RetrieveDeviceBean retrieveDeviceRequest = new RetrieveDeviceBean();
								retrieveDeviceRequest.setData(new InboundData());
								retrieveDeviceRequest.getData().setSubOrder(new ArrayList<SubOrder>());

								SubOrder subOrder = new SubOrder();
								if (outRequestBean.getData().getIccid() != null) {
									log.info("Using ICCID for reteieve Device :: "
											+ outRequestBean.getData().getIccid());
									subOrder.setSimId(new ArrayList<KeyValueObj>());
									KeyValueObj simId = new KeyValueObj();
									simId.setType("ICCID");
									simId.setValue(outRequestBean.getData().getIccid());
									subOrder.getSimId().add(simId);
								} else if (outRequestBean.getData().getDeviceId() != null) {
									log.info("Using IMEI for reteieve Device :: "
											+ outRequestBean.getData().getDeviceId());
									subOrder.setDeviceId(new ArrayList<KeyValueObj>());
									KeyValueObj deviceId = new KeyValueObj();
									deviceId.setType("IMEI");
									deviceId.setValue(outRequestBean.getData().getDeviceId());
									subOrder.getDeviceId().add(deviceId);
								}
								retrieveDeviceRequest.getData().getSubOrder().add(subOrder);
								retrieveDeviceRequest.getData().setTransactionType("DI");
								retrieveDeviceRequest.getData().setTransactionTimeStamp(getTimeStamp());
								MessageHeader msgHeader = new MessageHeader();
								msgHeader.setRequestType("MNO");
								msgHeader.setServiceId(outRequestBean.getMessageHeader().getServiceId());
								msgHeader.setReferenceNumber(String.valueOf(transactionDetail.getTransactionId()));
								msgHeader.setAsyncErrorURL(outRequestBean.getMessageHeader().getAsyncErrorURL());
								msgHeader.setReturnURL(outRequestBean.getMessageHeader().getReturnURL());
								retrieveDeviceRequest.setMessageHeader(msgHeader);

								outboundRequest = gson.toJson(retrieveDeviceRequest);

							}
							String transactionUid = transactionDetail.getTransactionUid();
							Long rootTransactionId = transactionDetail.getRootTransactionId();
							String responseId = rootTransactionId.toString();

							String request = utilityClass.getRequestJson(outboundRequest, serviceName, operationName,
									transactionUid, responseId);
							frameworkResponse = utilityClass.callRestAPIForFramework(request, url, null);
						}
						log.info("frameworkResponse :" + frameworkResponse);

						if (StringUtils.hasText(frameworkResponse)) {
							frameworkResponse = frameworkResponse.substring(0, frameworkResponse.lastIndexOf("}~") + 1);
							log.info("Substring frameworkResponse :" + frameworkResponse);
							if (transactionDetail.getTransactionName().contains("Port-in")) {
								asyncCallback(frameworkResponse, "PORTIN", transactionDetail);
							}
						}
					} catch (Exception e) {
						log.info("Error processng transaction :::"
								+ (transactionDetail != null ? transactionDetail.getTransactionId() : ""));
					}

				}
			}
		} catch (Exception e) {
			log.error("Exception ::", e);
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
			return response;
		}

		response = new ResponseEntity<String>(frameworkResponse, HttpStatus.OK);
		return response;
	}

	public String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		Calendar cal = Calendar.getInstance();
		log.debug("Current Date: " + sdf.format(cal.getTime()));
		String date = sdf.format(cal.getTime());
		return date;
	}

	public ResponseEntity<String> asyncCallback(String request, String apiType, TransactionDetails transactionDetail) {
		log.info("Inside Consumer asyncCallback : request :" + request);
		ResponseEntity<String> response = null;
		try {
			Gson gson = new Gson();
			Boolean invokeAsyncError = Boolean.FALSE;
			UtilityService.addTraceDetails("NA", "NA", Constants.SCHEDULER);
			log.info("apiType :" + apiType);
			if (request != null) {
				if ("ASYNC".equals(apiType)) {
					RetrieveDeviceAyncResponse retrieveDeviceReponse = gson.fromJson(request,
							RetrieveDeviceAyncResponse.class);
					if (retrieveDeviceReponse != null) {
						if (retrieveDeviceReponse.getMessageHeader() != null
								&& StringUtils.hasText(retrieveDeviceReponse.getMessageHeader().getReferenceNumber())) {
							Long referenceNumber = Long
									.valueOf(retrieveDeviceReponse.getMessageHeader().getReferenceNumber());
							transactionDetail = transactionDetailsDao.findByTransactionId(referenceNumber);
							if (transactionDetail != null) {
								UtilityService.updateTrace(String.valueOf(transactionDetail.getTransactionId()), "NA",
										Constants.SCHEDULER);
								String outboundRequest = transactionDetail.getRequestMsg();
								log.info("outboundRequest :" + outboundRequest);
								OutboundRequest outRequestBean = gson.fromJson(outboundRequest, OutboundRequest.class);

								if (retrieveDeviceReponse.getData() == null) {
									invokeAsyncError = Boolean.TRUE;
								} else if (retrieveDeviceReponse.getData() != null) {
									if (retrieveDeviceReponse.getData().getReturnMessage() != null
											&& retrieveDeviceReponse.getData().getReturnMessage()
													.equals(Constants.NO_INFO_AVAIL_MSG)) {
										log.info("Error in Response : NO_INFO_AVAIL_MSG :"
												+ retrieveDeviceReponse.getData().getReturnMessage());
										invokeAsyncError = Boolean.TRUE;
									} else if (retrieveDeviceReponse.getData().getReturnCode() != null
											&& retrieveDeviceReponse.getData().getReturnCode().startsWith("E")) {
										log.info("Error in Response :"
												+ retrieveDeviceReponse.getData().getReturnCode());
										invokeAsyncError = Boolean.TRUE;
									} else if (outRequestBean != null && outRequestBean.getData() != null) {
										String iccid = outRequestBean.getData().getIccid();
										String deviceId = outRequestBean.getData().getDeviceId();
										if (retrieveDeviceReponse.getData() != null && iccid != null && deviceId != null
												&& retrieveDeviceReponse.getData().getIccid() != null
												&& retrieveDeviceReponse.getData().getDeviceId() != null) {
											if (iccid.equals(retrieveDeviceReponse.getData().getIccid())
													&& deviceId.equals(retrieveDeviceReponse.getData().getDeviceId())) {
												log.info("ICCID and IMEI Mactched : ");
												manageLinesService.triggerAsyncCallback(transactionDetail,
														retrieveDeviceReponse, null, outRequestBean, AsyncType.SUCCESS);
											}
										} else {
											invokeAsyncError = Boolean.TRUE;
										}
									}
								}
								if (invokeAsyncError) {
									log.info("Inside Error :" + retrieveDeviceReponse);
									manageLinesService.triggerAsyncCallback(transactionDetail, retrieveDeviceReponse,
											null, outRequestBean, AsyncType.ERROR);
								}
							}
						}
					}
				} else {
					PortinInquiryResBean portinInquiryResBean = gson.fromJson(request, PortinInquiryResBean.class);
					if (portinInquiryResBean != null) {
						if (portinInquiryResBean.getMessageHeader() != null
								&& StringUtils.hasText(portinInquiryResBean.getMessageHeader().getReferenceNumber())) {
							/*
							 * Long referenceNumber = transactionDetails.getTransactionId();
							 * TransactionDetails transactionDetail = transactionDetailsDao
							 * .findByTransactionId(referenceNumber);
							 */
							if (transactionDetail != null) {
								UtilityService.updateTrace(String.valueOf(transactionDetail.getTransactionId()), "NA",
										Constants.SCHEDULER);
								String outboundRequest = transactionDetail.getRequestMsg();
								OutboundRequest outRequestBean = gson.fromJson(outboundRequest, OutboundRequest.class);
								Boolean invokeSuccessAsync = Boolean.FALSE;
								Boolean invokeGatewayAsync = Boolean.FALSE;
								if (portinInquiryResBean.getData() == null) {
									invokeAsyncError = Boolean.TRUE;
								} else if (portinInquiryResBean.getData() != null) {
									if (portinInquiryResBean.getData().getReturnMessage() != null
											&& portinInquiryResBean.getData().getReturnMessage()
													.contains(Constants.NOT_VALID_REQ_MSG)) {
										invokeAsyncError = Boolean.TRUE;
									} else if (portinInquiryResBean.getData().getReturnCode() != null
											&& portinInquiryResBean.getData().getReturnCode().startsWith("E")) {
										invokeAsyncError = Boolean.TRUE;
									} else if (outRequestBean != null && outRequestBean.getData() != null) {
										String mdn = outRequestBean.getData().getMdn();
										if (portinInquiryResBean.getData() != null && mdn != null
												&& portinInquiryResBean.getData().getMdn() != null
												&& mdn.equals(portinInquiryResBean.getData().getMdn())
												&& portinInquiryResBean.getData().getReturnCode() != null
												&& portinInquiryResBean.getData().getReturnCode().equals("00")) {
											if (portinInquiryResBean.getData().getLnpStatusCode() != null
													&& portinInquiryResBean.getData().getLnpStatusCode()
															.equals("CLOSED")) {
												invokeAsyncError = Boolean.TRUE;
											} else if (portinInquiryResBean.getData().getLnpStatusCode() != null
													&& portinInquiryResBean.getData().getLnpStatusCode()
															.equals("REQUESTED")
													&& portinInquiryResBean.getData().getLnpResponseType() != null
													&& portinInquiryResBean.getData().getLnpResponseType()
															.equals("R")) {
												invokeGatewayAsync = Boolean.TRUE;
											} else if (portinInquiryResBean.getData().getLnpStatusCode() != null
													&& portinInquiryResBean.getData().getLnpStatusCode()
															.equals("REQUESTED")
													&& portinInquiryResBean.getData().getLnpResponseType() != null
													&& portinInquiryResBean.getData().getLnpResponseType()
															.equals("C")) {
												// invokeGatewayAsync = Boolean.TRUE;
												transactionDetailsDao.clearNotifiEntityStatus(
														transactionDetail.getRootTransactionId(), mdn);
											} else if (portinInquiryResBean.getData().getLnpStatusCode() != null
													&& portinInquiryResBean.getData().getLnpStatusCode()
															.equals("CONFIRMED")) {
												String extTransId = String
														.valueOf(transactionDetail.getTransactionId());
												String transactionType = "INBOUND";
												List<String> transactionName = new ArrayList<String>();
												transactionName.add("AsyncService");
												transactionName.add("hmnoasyncservice");

												int count = transactionDetailsDao
														.findCountByExtTransactionIdAndTransactionTypeAndTransactionName(
																extTransId, transactionType, transactionName);
												log.info("Is Async Already triggered: count: " + count);
												if (count <= 0) {
													invokeSuccessAsync = Boolean.TRUE;
												}
											} else {
												invokeSuccessAsync = Boolean.TRUE;
											}
										} else {
											invokeAsyncError = Boolean.TRUE;
										}
									}
									if (invokeSuccessAsync) {
										log.info("Triggering Succes Callback : " + invokeSuccessAsync);
										manageLinesService.triggerAsyncCallback(transactionDetail, null,
												portinInquiryResBean, outRequestBean, AsyncType.SUCCESS);
									} else if (invokeAsyncError) {
										log.info("Triggering ERROR Callback : " + invokeAsyncError);
										manageLinesService.triggerAsyncCallback(transactionDetail, null,
												portinInquiryResBean, outRequestBean, AsyncType.ERROR);
									} else if (invokeGatewayAsync) {
										log.info("Triggering Async Gateway Callback : " + invokeGatewayAsync);
										manageLinesService.triggerAsyncCallback(transactionDetail, null,
												portinInquiryResBean, outRequestBean, AsyncType.GATEWAY_RESPONSE);
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception ::", e);
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
			return response;
		}
		if (response == null) {
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.BAD_REQUEST);
		}
		response = new ResponseEntity<String>(Constants.SUCCESS_MSG, HttpStatus.OK);
		return response;
	}

	@Async(value = "managelinesAsyncTaskExecutor")
	public void planMigrationEligibility(ReportMgmtRequest reportMgmtRequest) {
		log.info("Request:" + reportMgmtRequest);
		UtilityService.addTraceDetails("NA", "NA", Constants.SCHEDULER);
		try {
			planMigrationEligibilityCheck(reportMgmtRequest);
		} catch (Exception e) {
			log.error("Exception ::", e);
		}
	}

	private void planMigrationEligibilityCheck(ReportMgmtRequest reportMgmtRequest) {
		try {
			reportMgmtRequest.getData().setMultipleFiles(Boolean.TRUE);
			String reportResponse = reportManagementAdaptor.invokeReportManagementAPI(reportMgmtRequest);
			if (reportResponse != null) {
				FileOperationRequest respone = manageLinesService.planMigrationEligibilityCheck(reportResponse);
				if (respone != null && respone.getData() != null && respone.getData().getHasMoreFiles() != null
						&& respone.getData().getHasMoreFiles()) {
					Page page = respone.getData().getPage();
					if (page == null) {
						page = new Page();
					}
					if (respone.getData().getPage() != null) {
						Integer currentPage = respone.getData().getPage().getCurrentPage();
						if (currentPage == null)
							currentPage = 1;
						if (currentPage != null)
							page.setCurrentPage(currentPage + 1);
					} else {
						Integer currentPage = 1;
						page.setCurrentPage(currentPage + 1);
					}
					reportMgmtRequest.getData().setPage(page);
					planMigrationEligibilityCheck(reportMgmtRequest);
				}
			}
		} catch (Exception e) {
			log.error("Exception ::", e);
		}
	}

	public ResponseEntity<String> planMigration(PlanMigrationRequest request) {
		log.info("planMigration:");
		ResponseEntity<String> response = null;
		UtilityService.addTraceDetails("NA", "NA", Constants.SCHEDULER);
		try {
			request = manageLinesService.planMigration(request);
		} catch (Exception e) {
			log.error("Exception ::", e);
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
			return response;
		}
		if (request != null) {
			Gson gson = new Gson();
			String asynRequest = gson.toJson(request);
			response = new ResponseEntity<String>(asynRequest, HttpStatus.OK);
		} else {
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	public String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd");
		Calendar cal = Calendar.getInstance();
		String date = sdf.format(cal.getTime());
		log.info("Current Date: " + date);
		if (date.matches("29|30|31")) {
			date = "01";
			log.info("Current Date: " + date);
		}
		return date;
	}
}
