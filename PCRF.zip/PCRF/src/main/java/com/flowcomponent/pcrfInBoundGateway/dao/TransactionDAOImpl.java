package com.flowcomponent.pcrfInBoundGateway.dao;

import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.flowcomponent.pcrfInBoundGateway.bean.InboundRequest;
import com.flowcomponent.pcrfInBoundGateway.constants.Constants;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class TransactionDAOImpl implements TransactionDAO {

    @Autowired
    private JdbcTemplate centuryCIFTemplate;

    Logger LOGGER = LoggerFactory.getLogger(TransactionDAOImpl.class);


    public String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName) {

       // KeyHolder keyHolder = new GeneratedKeyHolder();
       // Long insd_transId = 0l;
        String transacId = "";
        try {
            LOGGER.info("Inside insertTransaction method::transId:::");
            transacId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
            MapSqlParameterSource input = new MapSqlParameterSource();
            input.addValue(Constants.TRANSACTION_ID, transacId);
            input.addValue(Constants.APPLICATION_NAME, serviceName);
            input.addValue("APPLICATIONNAME", applicationName);
            input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
            input.addValue(Constants.TRANSACTION_UID, transUId);
            if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
                input.addValue(Constants.ENTITY_ID, Integer.parseInt(entityId));
            } else {
                input.addValue(Constants.ENTITY_ID, 0);
            }
            if (applicationName != null && applicationName.contains("NCM")) {
                input.addValue(Constants.TENANT_ID, Integer.parseInt("2"));
            } else {
                input.addValue(Constants.TENANT_ID, Integer.parseInt("1"));
            }
            input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
            NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
                    centuryCIFTemplate.getDataSource());
            //namedJdbcTemplate.update(Constants.INSERT_NORTH_BOUND_TRANSACTION, input, keyHolder);
            namedJdbcTemplate.update(Constants.INSERT_NORTH_BOUND_TRANSACTION, input);
			/*
			 * if (keyHolder.getKeys().size() > 1) { insd_transId = (Long)
			 * keyHolder.getKeys().get("TRANSACTION_ID"); }
			 */
			/* transacId = String.valueOf(insd_transId); */
            LOGGER.info("TransacID ::: " + transacId);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return transacId;
    }


    public void insertMNORequestDetails(String request, String responseId) {
		LOGGER.info("request inside insertMNORequestDetails::::" + request);
		JSONObject obj = new JSONObject();
		JSONObject addAttrObj = null;
		InboundRequest bean = null;
		String customer_req_id = "";
		String requests = null;
		String addAttrRequest = "";
		String addAttrName = "";
		String addAttrValue = "";
		String transactionType = "";
		try {
			boolean requestflag=isValidJson(request);
			if(requestflag)
			{
			if (request.startsWith("[")) {
				LOGGER.info("request in json::" + request);
				request = jsonFormatter(request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, InboundRequest.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("{")) {
				LOGGER.info("request in json object::" + request);
				addAttrObj = new JSONObject(request);
				if (addAttrObj.has("data")) {
					addAttrObj = addAttrObj.getJSONObject("data");
					if (addAttrObj.has("additionalData") && addAttrObj.getJSONArray("additionalData").length()!=0) {
						addAttrObj = addAttrObj.getJSONArray("additionalData").getJSONObject(0);
						LOGGER.info("addAttrObj final::" + addAttrObj.toString());
						if (addAttrObj.has("name")) {
							addAttrName = addAttrObj.getString("name");
						}
						if (addAttrObj.has("value")) {
							addAttrValue = addAttrObj.getString("value");
						}
					}
					if(addAttrObj.has("transactionType")) {
						transactionType = addAttrObj.getString("transactionType");
					}
				}
				request = jsonFormatter(request);
				LOGGER.info("request in after formatting::" + request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, InboundRequest.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("<")) {
				LOGGER.info("request in xml::" + request);
				requests = XML.toJSONObject(request).toString();
				LOGGER.info("request in xml format::" + requests);
				requests = jsonFormatter(requests);
				LOGGER.info("request after formatting::" + requests);
				JSONArray jsonArrayInner = new JSONArray(requests);
				obj = jsonArrayInner.getJSONObject(0);
				LOGGER.info("request xml in json object::" + obj.toString());
				Gson gson = new Gson();
				bean = gson.fromJson(obj.toString(), InboundRequest.class);
				LOGGER.info("Bean::::" + bean.toString());
			}
			
			}
			if(bean!=null) {
			if (bean.getCustomerRequestID() != null) {
				customer_req_id = bean.getCustomerRequestID();
			} else if (bean.getReferenceNumber() != null && !bean.getReferenceNumber().isEmpty()) {
				customer_req_id = bean.getReferenceNumber();
				String[] split = customer_req_id.split("\\.");
				if (split.length > 3) {
					customer_req_id = customer_req_id
							.subSequence(customer_req_id.indexOf(split[3], 1), customer_req_id.length()).toString();
				} else {
					customer_req_id = null;
				}
			} else {
				customer_req_id = null;
			}
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("TRANSACTION_ID", responseId);
			if (bean.getCustomerID() != null) {
				input.addValue("CUSTOMER_ID", bean.getCustomerID());
			} else if (bean.getSubscriberGroupCd() != null) {
				input.addValue("CUSTOMER_ID", bean.getSubscriberGroupCd());
			} else {
				input.addValue("CUSTOMER_ID", null);
			}
			input.addValue("CUSTOMER_REQUEST_ID", customer_req_id);
			if (bean.getMdn() != null) {
				input.addValue("MDN", bean.getMdn());
			} else {
				input.addValue("MDN", null);
			}
			if (bean.getIccid() != null) {
				input.addValue("PICCID", bean.getIccid());
			} else {
				input.addValue("PICCID", null);
			}
			if (bean.getImei() != null && !bean.getImei().isEmpty()) {
				input.addValue("IMEI", bean.getImei());
			} 
			else if(bean.getDeviceId() != null && !bean.getDeviceId().isEmpty()) {
				input.addValue("IMEI", bean.getDeviceId());
			}
			else {
				input.addValue("IMEI", null);
			}

			if (bean.getEid() != null) {
				input.addValue("EID", bean.getEid());
			} else {
				input.addValue("EID", null);
			}
			if (bean.getReferenceNumber() != null && !bean.getReferenceNumber().isEmpty()) {
				input.addValue("REFERENCENUMBER", bean.getReferenceNumber());
			} else {
				input.addValue("REFERENCENUMBER", null);
			}
			if (bean.getAsyncErrorURL() != null) {
				input.addValue("ASYNCURL", bean.getAsyncErrorURL());
			} else {
				input.addValue("ASYNCURL", null);
			}
			if (bean.getPlanCode() != null) {
				input.addValue("RETAILPLANCODE", bean.getPlanCode());
			} 
			else if (bean.getnewRatePlan() != null) {
				input.addValue("RETAILPLANCODE", bean.getnewRatePlan());
			} else {
				input.addValue("RETAILPLANCODE", null);
			}
			if (bean.getReturnURL() != null) {
				input.addValue("RETURNURL", bean.getReturnURL());
			} else {
				input.addValue("RETURNURL", null);
			}
			if (bean.getAccountNumber() != null) {
				input.addValue("ACCOUNTNUMBER", bean.getAccountNumber());
			} else {
				input.addValue("ACCOUNTNUMBER", null);
			}
			if (bean.getId() != null) {
				input.addValue("ID", bean.getId());
			} else {
				input.addValue("ID", null);
			}
			if (bean.getIccid() != null) {
				input.addValue("PICCID", bean.getIccid());
			} else {
				input.addValue("PICCID", null);
			}
			if (bean.getLineId() != null) {
				input.addValue("LINEID", bean.getLineId());
			} else {
				input.addValue("LINEID", null);
			}
			if (bean.getContextId() != null) {
				input.addValue("CONTEXTID", bean.getContextId());
			} else {
				input.addValue("CONTEXTID", null);
			}
			if (transactionType.equals("UW") && transactionType !=null) {
				input.addValue("ACCOUNTTYPE", null);
			} else if (bean.getType() != null) {
				input.addValue("ACCOUNTTYPE", bean.getType());
			} else {
				input.addValue("ACCOUNTTYPE", null);
			}
			if (bean.getBillCycleResetDay() != null) {
			   input.addValue("BILLCYCLEDAY", bean.getBillCycleResetDay());
			} else {
				input.addValue("BILLCYCLEDAY", null);
			}
			if (!"".equalsIgnoreCase(addAttrName)) {
				input.addValue("REFNAME", addAttrName);
			} else {
				input.addValue("REFNAME", null);
			}
			if (!"".equalsIgnoreCase(addAttrValue)) {
				input.addValue("REFVALUE", addAttrValue);
			} else {
				input.addValue("REFVALUE", null);
			}
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());

			namedJdbcTemplate.update(Constants.INSERT_REQUESTS, input);
			namedJdbcTemplate.update(Constants.INSERT_REF_ADD_DATA, input);
			}
			else
			{
				MapSqlParameterSource input = new MapSqlParameterSource();
				input.addValue("TRANSACTION_ID", responseId);	
				input.addValue("CUSTOMER_ID", null);
				input.addValue("MDN", null);
				input.addValue("PICCID", null);
				input.addValue("IMEI", null);
				input.addValue("EID", null);
				input.addValue("REFERENCENUMBER", null);
				input.addValue("ASYNCURL", null);
				input.addValue("RETAILPLANCODE", null);
				input.addValue("RETURNURL", null);
				input.addValue("ACCOUNTNUMBER", null);
				input.addValue("ID", null);
				input.addValue("PICCID", null);
				input.addValue("LINEID", null);
				input.addValue("REFNAME", null);
				input.addValue("REFVALUE", null);
                input.addValue("CONTEXTID", null);
				input.addValue("CUSTOMER_REQUEST_ID", null);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			
			namedJdbcTemplate.update(Constants.INSERT_REQUESTS, input);
			namedJdbcTemplate.update(Constants.INSERT_REF_ADD_DATA, input);
			}
			bean.setTransId(responseId);
			//return responseId;
		} catch (JSONException e) {
			LOGGER.error("JSONException in insertRequestDetails" + e.getMessage());
		} catch (Exception e1) {
			LOGGER.error("Exception in insertRequestDetails" + e1.getMessage());
		}
		//return null;

	}
    public String jsonFormatter(String inputJson) {
        LOGGER.info("inputJson:::::" + inputJson);
        String response = null;
        JSONObject finalObj = new JSONObject();
        try {
            if (inputJson.startsWith("[")) {
                JSONArray jsonarr = new JSONArray(inputJson);
                for (int i = 0; i < jsonarr.length(); i++) {
                    JSONObject obj = jsonarr.getJSONObject(i);
                    response = "[" + printJsonObject(obj, finalObj) + "]";
                    LOGGER.info("JsonArray Formatter Final Response:::" + response);
                }
            } else {
                JSONObject object = new JSONObject(inputJson);
                response = "[" + printJsonObject(object, finalObj) + "]";
                LOGGER.info("JsonObject Formatter Final Response:::" + response);
            }
        } catch (JSONException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return response;
    }

    public String printJsonObject(JSONObject jsonObj, JSONObject obj) {
        try {
            Iterator<String> a = jsonObj.keys();
            while (a.hasNext()) {
                String keyStr = a.next();

                Object keyvalue = jsonObj.get(keyStr);

                if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
                    obj.put(keyStr, keyvalue.toString());
                }
                if (keyvalue instanceof JSONObject) {
                    printJsonObject((JSONObject) keyvalue, obj);
                }
                if (keyvalue instanceof JSONArray) {
                    printJsonArray((JSONArray) keyvalue, obj);
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return obj.toString();
    }

    public String printJsonArray(JSONArray array, JSONObject obj) {
        try {
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonObject1 = array.getJSONObject(i);
                printJsonObject(jsonObject1, obj);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }

    public void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId, String transGroupId, String serviceName) {
        String status = "";
        String code = "";
        try {
            LOGGER.info("responseJson:::" + responseJson);
            if (responseJson.startsWith("{")) {
                JSONObject responseObj = new JSONObject(responseJson);
                if (responseObj.toString().contains("success") || responseObj.toString().contains("Success")
                        || responseObj.toString().contains("IN_PROGRESS")
                        || responseObj.toString().contains("INPROGRESS")
                        || responseObj.toString().contains("Inprogress")
                        || responseObj.toString().contains("InProgress")
                        || responseObj.toString().contains("SUCCESS") || responseObj.toString().contains("OK")) {
                    LOGGER.info("SUCCESS CASE");
                    status = "SUCCESS";
                } else if (responseObj.has("code")) {
                    code = responseObj.get("code").toString();
                    status = responseObj.get("status").toString();
                    LOGGER.info("FAILURE CASE");
                    LOGGER.info("code----" + code + " status---" + status);
                    if (code.startsWith("4") || code.startsWith("5") || status.contains("Fail")
                            || status.contains("fail") || status.contains("FAIL") || responseObj.toString().contains("Fail")
                            || responseObj.toString().contains("fail") || responseObj.toString().contains("FAIL")) {
                        LOGGER.info("ELSE IF--------FAILURE CASE");
                        status = "FAILURE";
                    }
                } else {
                    LOGGER.info("ELSE FAILURE CASE:::::::::");
                    status = "FAILURE";
                }
            } else if (responseJson.startsWith("[")) {
                LOGGER.info("responseJson.startsWith(\"[\"):::");
                JSONArray jsonArray = new JSONArray(responseJson);
                JSONObject responseObj = new JSONObject();
                responseObj = jsonArray.getJSONObject(0);
                LOGGER.info("responseObj::::" + responseObj);
                if (responseObj.toString().contains("success") || responseObj.toString().contains("Success")
                        || responseObj.toString().contains("IN_PROGRESS")
                        || responseObj.toString().contains("SUCCESS") || responseObj.toString().contains("OK")) {
                    LOGGER.info("SUCCESS CASE...........");
                    status = "SUCCESS";
                } else if (responseObj.has("code")) {
                    code = responseObj.get("code").toString();
                    status = responseObj.get("status").toString();
                    LOGGER.info("FAILURE CASE...........");
                    LOGGER.info("code----" + code + " status---" + status);
                    if (code.startsWith("4") || code.startsWith("5") || status.contains("Fail")
                            || status.contains("fail") || status.contains("FAIL") || responseObj.toString().contains("Fail")
                            || responseObj.toString().contains("fail") || responseObj.toString().contains("FAIL")) {
                        LOGGER.info("ELSE IF--------FAILURE CASE.............");
                        status = "FAILURE";
                    }
                } else {
                    LOGGER.info("ELSE FAILURE CASE:::::::::");
                    status = "FAILURE";
                }
            } else if (responseJson.equalsIgnoreCase("INVALID_TYPE")) {
                status = "FAILURE";
            } else {
                LOGGER.info("ELSE SUCCESS --------");
                status = "SUCCESS";
            }
            MapSqlParameterSource input = new MapSqlParameterSource();
            input.addValue(Constants.TRANSACTION_ID, transId);
            input.addValue(Constants.STATUS, status);
            input.addValue(Constants.TRANSGROUPID, Integer.parseInt(transGroupId));
            input.addValue(Constants.GROUPID, groupId);
            input.addValue("httpCode", "200");
            input.addValue("SERVICENAME", serviceName);
            if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
                input.addValue(Constants.ENTITY_ID, entityId);
            } else {
                input.addValue(Constants.ENTITY_ID, 0);
            }
            input.addValue("RESPONSE_MSG", new SqlLobValue(responseJson), Types.CLOB);
            NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(centuryCIFTemplate.getDataSource());
            namedJdbcTemplate.update(Constants.UPDATE_SUCCESS_TRANSACTION, input);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }
    
	public String insertMNONBTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName, String httpmethod, String source) {
		LOGGER.info("Inside insertMNONBTransaction method::requestJson:::" + requestJson);
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		String transactionTimeStamp = "";
		Timestamp transactionTs = null;

		try {
			transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
			LOGGER.info("Inside insertTransaction method::transId:::" + transId);
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
			input.addValue(Constants.APPLICATION_NAME, serviceName);
			input.addValue("APPLICATIONNAME", applicationName);
			input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
			input.addValue(Constants.TRANSACTION_UID, transUId);
			input.addValue("httpmethod", httpmethod);
			input.addValue("source", source);
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			if (applicationName != null && applicationName.contains("NCM")) {
				input.addValue(Constants.TENANT_ID, "2");
			} else {
				input.addValue(Constants.TENANT_ID, "1");
			}
			boolean isValidrequest=isValidJson(requestJson);
			if(isValidrequest)
			{
			if (requestJson.contains("transactionTimeStamp")) {
				JsonObject requestJsonObject = new JsonParser().parse(requestJson).getAsJsonObject();
				Iterator<Entry<String, JsonElement>> requestKeys = requestJsonObject.entrySet().iterator();
				while (requestKeys.hasNext()) {
					Entry<String, JsonElement> entry = requestKeys.next();
					if (Constants.DATA.equalsIgnoreCase(entry.getKey())) {
						JsonObject headerJson = requestJsonObject.getAsJsonObject(entry.getKey());
						transactionTimeStamp = headerJson.get("transactionTimeStamp").getAsString();
						break;
					}
				}
				if (transactionTimeStamp != null
						&& (transactionTimeStamp.contains("Z") || transactionTimeStamp.contains("z"))) {
					try {
						Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(transactionTimeStamp)).getTime();
						transactionTs = new Timestamp(date.getTime());
					} catch (Exception e) {
						transactionTs = null;
					}
				}
				if (transactionTs != null) {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, transactionTs);
				} else {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
				}
			} else {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
			}
			input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION, input);
			}
			else
			{
				input.addValue(Constants.TRANSACTION_TIMESTAMP,null);
				input.addValue("REQUEST_MSG",requestJson);
				NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
						centuryCIFTemplate.getDataSource());
				namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION, input);
			}
			/*
			 * if (serviceName.equals("Handle Download Progress Info") ||
			 * serviceName.equals("Unsolicited Notifications Port-Out") ||
			 * serviceName.equals("DPFO Event Notifications")) { String rel_id = ""; String
			 * Transaction_Type = Constants.INBOUND; this.insertEvent_notification(rel_id,
			 * transId, Transaction_Type, serviceName, applicationName, requestJson); }
			 */
			return transId;
		} catch (Exception e) {
			LOGGER.error("Exception in insertTransaction" + e.getMessage());
		}
		return transId;
	}
	
	public boolean isValidJson(String inputJson) {
		System.out.println("inputJson:::::"+inputJson);
		String response = "";
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
					JSONArray jsonarr = new JSONArray(inputJson);
					if(jsonarr != null && jsonarr.length() > 0) {
				return true;
			}
			}
			else if (inputJson.startsWith("{")) 
			{
			JSONObject object = new JSONObject(inputJson);
			
			if(object != null && object.length() > 0) {
				return true;
			}
			}
		}	
		catch (JSONException e) {
			LOGGER.error(e.getMessage());
			System.out.println("jsonFormatterforRequest.............."+inputJson);
			//response =false;
			return false;
		}
		return true;
	}



}