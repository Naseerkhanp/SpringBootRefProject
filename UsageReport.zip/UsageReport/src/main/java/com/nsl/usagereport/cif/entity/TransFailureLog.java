package com.nsl.usagereport.cif.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

@Entity(name = "TRANS_FAILURE_LOG")
@Table(name = "TRANS_FAILURE_LOG")
public class TransFailureLog implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Column(name = "TRANSACTION_ID",updatable = false)
	private Long transactionId;
	@ManyToOne
	@JoinColumn(name = "TRANSACTION_ID", referencedColumnName = "TRANSACTION_ID", insertable = false, updatable = false)
	private TransactionFileLog transactionFileLog;

	@Column(name = "ENTITY_ID")
	private long entityID;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRANSACTION_LOG_SEQ_gen")
	@SequenceGenerator(name = "TRANSACTION_LOG_SEQ_gen", sequenceName = "TRANSACTION_LOG_SEQ", allocationSize = 1)
	@Column(name = "ENTITY_TYPE_ID")
	private Long entityTypeID;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "ERROR_CODE")
	private String errorCode;
	@Column(name = "ERROR_MSG")
	private String errorMsg;
	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());
	@Column(name = "CREATED_BY")
	private String createdBy;
	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate = new java.sql.Date(new java.util.Date().getTime());
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "REJECT_CODE")
	private String rejectCode;
	@Column(name = "REJECT_MESSAGE")
	private String rejectMessage;
	@Column(name = "ENTITY_VALUE")
	private String entityValue;
	@Column(name = "ROOT_TRANSACTION_ID")
	private Long rootTransactionId;
	@Column(name = "ERROR_DETAILS")
	private String errorDetails;

	@ManyToOne

	public long getEntityID() {
		return entityID;
	}

	public void setEntityID(long entityID) {
		this.entityID = entityID;
	}

	public TransactionFileLog getTransactionFileLog() {
		return transactionFileLog;
	}

	public void setTransactionFileLog(TransactionFileLog transactionFileLog) {
		this.transactionFileLog = transactionFileLog;
	}

	public Long getEntityTypeID() {
		return entityTypeID;
	}

	public void setEntityTypeID(Long entityTypeID) {
		this.entityTypeID = entityTypeID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(String rejectCode) {
		this.rejectCode = rejectCode;
	}

	public String getRejectMessage() {
		return rejectMessage;
	}

	public void setRejectMessage(String rejectMessage) {
		this.rejectMessage = rejectMessage;
	}

	public String getEntityValue() {
		return entityValue;
	}

	public void setEntityValue(String entityValue) {
		this.entityValue = entityValue;
	}

	public Long getRootTransactionId() {
		return rootTransactionId;
	}

	public void setRootTransactionId(Long rootTransactionId) {
		this.rootTransactionId = rootTransactionId;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

}
