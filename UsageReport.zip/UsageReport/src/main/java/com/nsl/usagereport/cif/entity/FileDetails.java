
package com.nsl.usagereport.cif.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

@Entity(name = "FILE_DETAILS")
@Table(name = "FILE_DETAILS")
public class FileDetails implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FILE_DETAILS_ID")
	private Long fileDetailsId;

	@Column(name = "FILENAME")
	private String fileName;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "DOWNLOADED")
	private String downloaded;

	@Column(name = "PARSED")
	private String parsed;

	@CreatedDate

	@Column(name = "CREATED_DATE")
	private Date createDate = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "CREATED_BY")
	private String createdBy;

	@CreatedDate

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "MODIIFED_BY")
	private String modifiedBy;

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Long getFileDetailsId() {
		return fileDetailsId;
	}

	public void setFileDetailsId(Long fileDetailsId) {
		this.fileDetailsId = fileDetailsId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDownloaded() {
		return downloaded;
	}

	public void setDownloaded(String downloaded) {
		this.downloaded = downloaded;
	}

	public String getParsed() {
		return parsed;
	}

	public void setParsed(String parsed) {
		this.parsed = parsed;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
