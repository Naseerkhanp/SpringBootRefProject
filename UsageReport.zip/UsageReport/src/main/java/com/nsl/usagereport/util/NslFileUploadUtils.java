package com.nsl.usagereport.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.springframework.web.multipart.MultipartFile;

import com.nsl.usagereport.constants.NslFileUploadConstants;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class NslFileUploadUtils {
	public static String divideColumns(String line, String delimiter) {
		if (line.contains(delimiter + delimiter)) {
			line = line.replace(delimiter + delimiter, delimiter + NslFileUploadConstants.NULL + delimiter);
			if (line.contains(delimiter)) {
				line = divideColumns(line, delimiter);
			}
		}
		return line;
	}

	public static File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public static Date convertIntToDate(String givenDate) {
		SimpleDateFormat formater = new SimpleDateFormat("yyyyMMddHHmmss");
		java.util.Date date = null;
		Date da = null;
		if (!givenDate.equalsIgnoreCase(NslFileUploadConstants.NULL)) {
			try {
				date = formater.parse(givenDate);
				da = new Date(date.getTime());
			} catch (ParseException e) {
				log.error(" error in convertIntToDate ::", e);
			}
		}
		return da;
	}

	public static String convertLongToDate(long time) {
		DateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(time);
		return formatter.format(calendar.getTime());
	}

	public static java.util.Date convertStringToDate1(String givenDate) throws ParseException {
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = null;
		Date da = null;
		if (!givenDate.equalsIgnoreCase(NslFileUploadConstants.NULL)) {
			try {
				date = formater.parse(givenDate);
				da = new Date(date.getTime());
			} catch (ParseException e) {
				log.error(" error in convertIntToDate ::", e);
			}
		}
		givenDate = da + NslFileUploadConstants.EMPTY;
		java.util.Date transformedDate = format.parse(givenDate);
		log.info("transformed date :" + transformedDate);
		return transformedDate;
	}

	public static Long nullCheck(String value) {
		value = value.trim();
		Long result = null;
		if (value.contains(".")) {
			Float f = Float.parseFloat(value);
			return f.longValue();
		} else if (!value.equalsIgnoreCase(NslFileUploadConstants.NULL)) {
			result = Long.parseLong(value.trim());
		}
		return result;
	}

	public static String nullChecker(String value) {
		value = value.trim();
		String emptyData = NslFileUploadConstants.EMPTY;
		if (!value.equalsIgnoreCase(NslFileUploadConstants.NULL)) {
			emptyData = value;
		}
		return emptyData;
	}
}
