package com.excelacom.servicegateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NslMboInboundGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
