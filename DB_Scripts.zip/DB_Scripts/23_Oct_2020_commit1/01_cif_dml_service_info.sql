spool 01_cif_dml_service_info.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;  

Insert into service_info (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (SEQ_SERV_ID.NEXTVAL,'DownloadProgressInfo_URL','http://mobile-2-0-stub-service:9999/sendAck',null,null,null,'OUTBOUND',null,null,null,null,null,null,null,'',null,null,'NSL_UPG',null,null,null,null,null,null,null,null,null,null,null,null);

commit;
spool off;
