package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "REF_FILE_UPLOAD")
@Table(name = "REF_FILE_UPLOAD")
public class RefFileUpload implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "REF_FILE_UPLOAD_ID")
	private Long id;
	@Column(name = "FILE_NAME")
	private String fileName;
	@Column(name = "FILTER_COLUMN")
	private String filterColumn;
	@Column(name = "FILTER_COLUMN_INDEX")
	private long filterColumnIndex;
	@Column(name = "DESCRIPTION")
	private String description;
	@Column(name = "FILTER_VALUE")
	private long filterValue;
	@Column(name = "COLUMN_NAME")
	private String columnName;
	@Column(name = "COLUMN_INDEX")
	private long columnIndex;
	@Column(name = "TABLE_NAME")
	private String tableName;
	@Column(name = "TABLE_COLUMN_NAME")
	private String tableColumnName;
	@Column(name = "CREATED_DATE")
	private Date createdDate;
	@Column(name = "CREATED_BY")
	private String createdBy;
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "PARAMETER_VALIDATION")
	private String parameterValidation;
	@Column(name = "MANDATORY")
	private String mandatory;
	@Column(name = "PARAMATER_REGEX")
	private String paramareRegex;
	@Column(name = "Default_Value")
	private String defaultValue;

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getParameterValidation() {
		return parameterValidation;
	}

	public void setParameterValidation(String parameterValidation) {
		this.parameterValidation = parameterValidation;
	}

	public String getMandatory() {
		return mandatory;
	}

	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

	public String getParamareRegex() {
		return paramareRegex;
	}

	public void setParamareRegex(String paramareRegex) {
		this.paramareRegex = paramareRegex;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilterColumn() {
		return filterColumn;
	}

	public void setFilterColumn(String filterColumn) {
		this.filterColumn = filterColumn;
	}

	public long getFilterColumnIndex() {
		return filterColumnIndex;
	}

	public void setFilterColumnIndex(long filterColumnIndex) {
		this.filterColumnIndex = filterColumnIndex;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getFilterValue() {
		return filterValue;
	}

	public void setFilterValue(long filterValue) {
		this.filterValue = filterValue;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public long getColumnIndex() {
		return columnIndex;
	}

	public void setColumnIndex(long columnIndex) {
		this.columnIndex = columnIndex;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getTableColumnName() {
		return tableColumnName;
	}

	public void setTableColumnName(String tableColumnName) {
		this.tableColumnName = tableColumnName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
