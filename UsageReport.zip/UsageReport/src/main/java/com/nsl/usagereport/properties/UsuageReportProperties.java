package com.nsl.usagereport.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nsl")
@Configuration
@Getter
@Setter
public class UsuageReportProperties {

	private String generateReportsServiceUrl;
}
