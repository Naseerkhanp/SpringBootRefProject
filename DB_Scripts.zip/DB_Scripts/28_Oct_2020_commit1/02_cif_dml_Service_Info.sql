spool 02_cif_dml_Service_Info.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---===============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (seq_serv_id.nextval,'CONNECTIONMGR_URL','http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/cmEventTransaction',null,null,null,'OUTBOUND',null,null,null,null,null,null,null,null,null,null,'NSL_DEV',null,null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (seq_serv_id.nextval,'CONNECTIONMGR_URL','http://nsl-sit-stub.wtg.spectrum.net:9999/cmEventTransaction',null,null,null,'OUTBOUND',null,null,null,null,null,null,null,null,null,null,'NSL_SIT',null,null,null,null,null,null,null,null, EMPTY_BLOB(),null,null,null);

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (seq_serv_id.nextval,'Connection Manager','/nsl/provisioning/mno/cm/v1/event-transaction','active','1.0','NSL','inbound','NSL',systimestamp,null,null,null,'true','HMNO/POST','{"messageHeader":{"serviceId":"SPECTRUM_MOBILE","requestType":"MNO","referenceNumber":"11111"},"data":{"transactionType":"LA","transactionTimeStamp":"2020-07-18T18:42:37Z","account":{"accountNumber":"string","contextId":"string","type":"string","pin":"string","externalAccountNumber":"string","externalAccountStatus":"string"},"lineId":"string","mdn":[{"type":"mdn","value":"9876543213"}],"imsi":"string","deviceId":[{"type":"IMEI","value":"345678765456765"}],"simId":[{"type":"ICCID","value":"34251342566374867"}],"status":[{"type":"string","value":"string"}],"retailPlan":{"id":"string","name":"string","categoryName":"string"}},"additionalData":[{"name":"string","value":"string"}]}',null,null,null,'Connection Manager','Connection Manager',null,null,null,11,null,1, EMPTY_BLOB(),'Connection-Manager','BODY','OAUTH');

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) 
values (seq_Serv_id.nextval,'retrieveDevice_URL','https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry',null,null,null,'OUTBOUND',null,null,null,null,null,null,null, null,'3',3000,'NSL_DEV','MNO',null,'SUCCESS',to_timestamp('07-04-20 10:34:52.995373000 AM','DD-MM-RR HH12:MI:SSXFF AM'),to_timestamp('07-04-20 10:34:52.995373000 AM','DD-MM-RR HH12:MI:SSXFF AM'),null,null,null,null,'Retrieve-Device',null,null);

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) 
values (seq_Serv_id.nextval,'retrieveDevice_URL','https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry',null,null,null,'OUTBOUND',null,null,null,null,null,null,null, null,'3',3000,'NSL_SIT','MNO',null,'SUCCESS',to_timestamp('07-04-20 10:34:52.995373000 AM','DD-MM-RR HH12:MI:SSXFF AM'),to_timestamp('07-04-20 10:34:52.995373000 AM','DD-MM-RR HH12:MI:SSXFF AM'),null,null,null,null,'Retrieve-Device',null,null);

Insert into SERVICE_INFO (SERVICE_ID,SERVICE_NAME,SERVICE_URL,STATUS,VERSION,ISSUER_NAME,SERVICE_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,SERVICE_PORT,ACTION,TYPE,SERVICE_REQUEST,RETRYLIMIT,TIMEDELAY,SERVER,SERVICE_GROUP,SERVICE_DESCRIPTION,HEALTH_STATUS,RESPONSE_TIME,LAST_RESPOND_TIME,SERVICE_GROUP_ID,METHOD,TENANT_ID,GRAPH_META_JSON,PROCESSPLAN,REQUEST_PARAM_TYPE,AUTH_TYPE) values (seq_serv_id.nextval,'Retrieve Device','/nsl/provisioning/mno/v1/retrieve-device','active','1.0','NSL','inbound','NSL',systimestamp,null,null,null,'true','HMNO/POST','{"messageHeader":{"serviceId":"SPECTRUM_MOBILE","requestType":"MNO","referenceNumber":"20191277631409999999999999999991313131356712454725667787","returnURL":"https:\\mobileapi-dev2.spectrummobile.com:4443\mbosasyncresponsecallback-sit\api\provisioning\v1\async-response","asyncErrorURL":"https:\\mobileapi-dev2.spectrummobile.com:4443\mbosasyncresponsecallback-sit\api\provisioning\v1\async-response-error"},"data":{"transactionType":"DI","transactionTimeStamp":"2020-08-03T05:29:37Z","subOrder":[{"deviceId":[{"type":"IMEI","value":"355433072113131"}],"simId":[{"type":"ICCID","value":"355433072113131"}]}],"additionalData":[{"name":"string","value":"string"}]}}',null,null,null,'Retrieve Device','Retrieve Device',null,null,null,11,null,1,null,'Retrieve-Device','BODY','OAUTH');

update service_info set service_url = '/nsl/provisioning/mno/ws/v1/validate-wifi-address' where service_name = 'validate wifi address';

update service_info set service_url = '/nsl/provisioning/mno/ws/v1/update-wifi-address' where service_name = 'update wifi address';

update service_info set service_url = '/nsl/provisioning/mno/ws/v1/line/mdn/{mdn}/wifi-address-inquiry' where service_name = 'wifi address inquiry';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/add-subscriber-portin'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/activatePortInSubscriberCall'
WHERE service_name='ActivatePortInSubscriber_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/${mdn}/line-inquiry'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/lineInquiryService'
WHERE service_name='Lineinquiry_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/add-subscriber'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/activateSubscriberCall'
WHERE service_name='ActivateSubscriber_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/reconnect-subscriber'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/reconnectMDN'
WHERE service_name='ReconnectMDNMno_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/rate-plan/reset-feature'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/resetFeatureCall'
WHERE service_name='mnoresetfeature_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/suspend-subscriber'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/removeHotlineServiceMNO'
WHERE service_name='RemoveHotlineMNOService_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/${mdn}/portin-inquiry'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/mnoPortInInquiryResponse'
WHERE service_name='portininquiry_URL'
AND server        ='NSL_DEV';

update service_info set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/rate-plan/change-rateplan'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/changeRatePlan'
 where service_name='MNOChangeRatePlan_URL' and server='NSL_DEV';

update service_info set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/delete-subscriber'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/deactivateSubscriberCall'
 where service_name='DeactivateSubscriber_URL' and server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/change-mdn'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/restoreService'
 where service_name='ChangeMDN_URL' and server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/rate-plan/change-rateplan'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/mnoRatePlan'
where service_name='MNORatePlan_URL' and server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/delete-subscriber'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/deactivateSubscriber'
where service_name='DeactivateSubscriberMNO_URL' and server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/update-portin'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/updatePortInCall'
where service_name='updatePortOutCancelMNO_URL' and server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/change-bcd'
,SERVICE_URL='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/mnoUpdateBillCycle'
where service_name='MNOUpdateBillCycleDay_URL' and server='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/sim/change-sim'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/changeSimService'
WHERE service_name='ChangePSim_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/rate-plan/change-features'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/hmnoChangeFeatureServiceCall'
WHERE service_name='HMNOChangeFeatureService_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/deviceInquiryService'
WHERE service_name='MNODeviceInquiryService_URL'
AND server        ='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/validate-byod'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/validateByodDevice'
WHERE service_name='ValidateByodDevice_URL'
AND server        ='NSL_DEV';

UPDATE service_info 
SET END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/${mdn}/promotion/promotion-inquiry'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/promotionInquiryService'
WHERE service_name='Promotioninquiry_URL' 
AND server='NSL_DEV';

UPDATE service_info 
SET END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/deviceInquiryService' 
WHERE service_name='MNODeviceInquiryService_URL' 
AND server='NSL_DEV';

UPDATE service_info 
SET END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/update-portin'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/updatePortInMetaDataCall'
WHERE service_name='UpdatePortInMetaData_URL' 
AND server='NSL_DEV';

UPDATE service_info 
SET END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/sim/change-sim'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/changeSimService'
WHERE service_name='ChangeSimWithoutDevice_URL' 
AND server='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/${mdn}/portin-inquiry'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/portinInquiryService'
where service_name='PortinInquiry_URL' AND SERVER='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/deviceInquiryService'
where service_name='MNODeviceInquiry_URL' AND SERVER='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/${mdn}/line-inquiry'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/restoreService'
where service_name='MNOLineInquiry_URL' AND SERVER='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/change-mdn'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/changeMDNPortInService'
where service_name='ChangeMDNPortIn_URL' AND SERVER='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/rate-plan/change-features'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/restoreService'
where service_name='HmnoChangeFeatureService_URL' AND SERVER='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/sim/${iccid}/validate-sim'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/notificationService'
where service_name='MNOValidateSim_URL' and server='NSL_DEV';

UPDATE service_info
SET END_POINT_URL   ='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/${imei}/validate-device'
,service_url   ='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/validateDeviceDirectFlow/imei/{imei}'
WHERE service_name='MNOValidateDevice_URL'
AND server        ='NSL_DEV';

update service_info
set END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/${imei}/validate-device'
,service_url='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/validateDevice/imei/${imei}'
where service_name='ValidateDeviceInquiry_URL' and server='NSL_DEV';

UPDATE service_info
SET END_POINT_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/update-portout'
,SERVICE_URL='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/updatePortoutService'
WHERE SERVICE_NAME='UpdatePortout_URL' AND SERVER='NSL_DEV';

UPDATE SERVICE_INFO set END_POINT_URL = 'https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/mdn/promotion/manage-promotion' 
,SERVICE_URL='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/mnoPromotionService'
where SERVICE_NAME='MNOPromotion_URL' AND SERVICE_TYPE = 'OUTBOUND'  AND SERVER='NSL_DEV';

UPDATE SERVICE_INFO set END_POINT_URL = 'https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/subscriber/device/device-inquiry' 
,SERVICE_URL='http://wireless-nsl-stub.dev.wtg.spectrum.net:9999/retrieveDevice'
where SERVICE_NAME='retrieveDevice_URL' AND SERVICE_TYPE = 'OUTBOUND'  AND SERVER='NSL_DEV';

UPDATE SERVICE_INFO set END_POINT_URL = 'https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/manage-wifi-address' 
,SERVICE_URL='https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/manage-wifi-address'
where SERVICE_NAME='SWQueryAddress_URL' AND SERVICE_TYPE = 'OUTBOUND'  AND SERVER='NSL_DEV';

UPDATE SERVICE_INFO set END_POINT_URL = 'https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/manage-wifi-address' 
,SERVICE_URL=null
where SERVICE_NAME='SWUpdateAddressService_URL' AND SERVICE_TYPE = 'OUTBOUND'  AND SERVER='NSL_DEV';

UPDATE SERVICE_INFO set END_POINT_URL = 'https://aisl518f5i.execute-api.us-east-1.amazonaws.com/sit/wtg/vzw/services/v1-0/manage-wifi-address' 
,SERVICE_URL=null
where SERVICE_NAME='SWValidateAddressService_URL' AND SERVICE_TYPE = 'OUTBOUND'  AND SERVER='NSL_DEV';

Insert into REF_TEMPLATE (ID,NAME,TYPE,SEQUENCE,PARENT) values (TEMPLATE_ID_SEQ.nextval,'Suspend-Sheet','Sheet',0,0);
Insert into REF_TEMPLATE (ID,NAME,TYPE,SEQUENCE,PARENT) values (TEMPLATE_ID_SEQ.nextval,'MDN_List','Cell',0,(SELECT ID from REF_TEMPLATE where NAME = 'Suspend-Sheet'));
Insert into REF_TEMPLATE (ID,NAME,TYPE,SEQUENCE,PARENT) values (TEMPLATE_ID_SEQ.nextval,'Restore-Sheet','Sheet',0,0);
Insert into REF_TEMPLATE (ID,NAME,TYPE,SEQUENCE,PARENT) values (TEMPLATE_ID_SEQ.nextval,'MDN_List','Cell',0,(SELECT ID from REF_TEMPLATE where NAME = 'Restore-Sheet'));

commit;

SELECT * FROM REF_TEMPLATE WHERE NAME IN ('Suspend-Sheet','MDN_List','Restore-Sheet');

select * from service_info where service_name in('ActivatePortInSubscriber_URL' ,'Lineinquiry_URL' ,'ActivateSubscriber_URL' ,'ReconnectMDNMno_URL' ,'mnoresetfeature_URL' ,'RemoveHotlineMNOService_URL' ,'portininquiry_URL' ,'MNOChangeRatePlan_URL' ,'DeactivateSubscriber_URL' ,'ChangeMDN_URL' ,'MNORatePlan_URL' ,'MNOValidateDeviceAsync_URL' ,'DeactivateSubscriberMNO_URL' ,'updatePortOutCancelMNO_URL' ,'ReconnectChangeMdn_URL' ,'MNOUpdateBillCycleDay_URL' ,'ChangePSim_URL' ,'HMNOChangeFeatureService_URL' ,'MNODeviceInquiryService_URL' ,'ValidateByodDevice_URL' ,'Promotioninquiry_URL' ,'MNODeviceInquiryService_URL' ,'UpdatePortInMetaData_URL' ,'ChangeSimWithoutDevice_URL' ,'RemoveHotlineSubscriber_URL' ,'PortinInquiry_URL' ,'MNODeviceInquiry_URL' ,
'MNOLineInquiry_URL' ,'ChangeMDNPortIn_URL' ,'HmnoChangeFeatureService_URL' ,'MNODeviceInquiryPost_URL' ,'MNOValidateSim_URL' ,'MNOValidateDevice_URL' ,'ValidateDeviceInquiry_URL' ,'UpdatePortout_URL' ,'MNOPromotion_URL' ,'retrieveDevice_URL','SWQueryAddress_URL','SWUpdateAddressService_URL','SWValidateAddressService_URL');

select * from SERVICE_INFO where service_name in('wifi address inquiry','update wifi address','validate wifi address');

select * from SERVICE_INFO where service_name in('CONNECTIONMGR_URL','Connection Manager','retrieveDevice_URL','Retrieve Device');

Spool off;

