package com.nsl.usagereport.transaction.dao.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.constants.QueryConstants;
import com.nsl.usagereport.postgres.repository.NslDao;
import com.nsl.usagereport.transaction.entity.ResourceInfo;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ResourceInfoDaoImpl implements NslDao {

	@Autowired
	private ResourceInfoRepository resourceInfoRepository;
	
	@Autowired
	private JdbcTemplate centuryNbopTemplate;

	@Transactional
	public void save(List<Object> list) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<ResourceInfo> dataDetails = list.stream().map(s -> (ResourceInfo) s).collect(Collectors.toList());
			log.info("dataDetails::" + dataDetails);
			resourceInfoRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

	public void deleteResourceInfo(String resourceType) throws Exception {
		log.info(this.getClass() + " deleteResourceInfo method called to flush table.");
		try {
			int count = centuryNbopTemplate.update(QueryConstants.DELETE_RESOURCE_INFO,new Object[] {resourceType});
			log.info("Total ios device records deleted count: "+count);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e.getMessage());
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
	}

	public void insertResourceInfoList(List<ResourceInfo> resouceInfoList) {
		log.info(this.getClass() + " insertResourceInfoList method called.");
		centuryNbopTemplate.batchUpdate(QueryConstants.INSERT_RESOURCE_INFO, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pStmt, int index) throws SQLException {
				ResourceInfo resourceInfo = resouceInfoList.get(index);
				pStmt.setString(1, resourceInfo.getCreatedBy());
				pStmt.setString(2, resourceInfo.getResourceSubtype());
				pStmt.setString(3, resourceInfo.getResourceType());
				pStmt.setString(4, resourceInfo.getResourceValue());
				pStmt.setString(5, resourceInfo.getExternalValue1());
				pStmt.setString(6, resourceInfo.getExternalValue2());
			}

			@Override
			public int getBatchSize() {
				return resouceInfoList.size();
			}

		});
	}

	public Set<String> getRouterIds() {
		return resourceInfoRepository.findAll().stream().map(e->(String)e.getResourceValue()).distinct().collect(Collectors.toSet());
	}

}