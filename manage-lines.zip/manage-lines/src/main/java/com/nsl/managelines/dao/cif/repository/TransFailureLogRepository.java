package com.nsl.managelines.dao.cif.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsl.managelines.dao.cif.entity.TransFailureLog;

@Repository
public interface TransFailureLogRepository extends JpaRepository<TransFailureLog, Integer> {

}
