/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import java.time.ZonedDateTime;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.nsl.managelines.dao.cif.entity.BatchTransaction;
import com.nsl.managelines.dao.cif.repository.BatchTransactioRepository;

import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */
@Component
@Log4j2
public class BatchTransactionDaoImpl implements BatchTransactionDao {

	@Autowired
	private BatchTransactioRepository batchTransactioRepository;

	@Autowired
	private JdbcTemplate cifjdbcTemplate;

	public BatchTransaction saveBatchTransaction(BatchTransaction batchTransaction) {
		try {
			try {
				if (batchTransaction.getBatchId() == null) {
					Long batchId = cifjdbcTemplate.queryForObject(CifQuery.GET_BATCH_SEQ, Long.class);
					batchTransaction.setBatchId(batchId);
				}
			} catch (Exception e) {
				log.error("Exception:", e);
			}
			if (batchTransaction.getBatchId() == null) {
				batchTransaction.setBatchId(Calendar.getInstance().getTimeInMillis());
			}
			if(batchTransaction.getBatchType()!=null && ("SPM").equalsIgnoreCase(batchTransaction.getBatchType()) 
				&& batchTransaction.getMdn()!=null){
				batchTransaction.setReferenceNumber("PM" + batchTransaction.getMdn() + batchTransaction.getBatchId());
			}
			log.info("Batch Insert:" + batchTransaction);
			batchTransaction = batchTransactioRepository.save(batchTransaction);
		} catch (Exception e) {
			log.error("Exception:", e);
		}
		return batchTransaction;
	}
	
	public int findCountByExternalValue1(String externalValue) {
		return batchTransactioRepository.findCountByExternalValue1(externalValue);
	}

}
