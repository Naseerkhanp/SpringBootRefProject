package com.nsl.usagereport.constants;

public class QueryConstants {
	public static final String DELETE_RESOURCE_INFO = "delete from RESOURCE_INFO where RESOURCE_SUBTYPE=?";
	public static final String INSERT_RESOURCE_INFO = "INSERT INTO RESOURCE_INFO(CREATED_BY,RESOURCE_SUBTYPE,RESOURCE_TYPE,RESOURCE_VALUE,EXTERNAL_VALUE_1,EXTERNAL_VALUE2,CREATED_DATE) values(?,?,?,?,?,?,systimestamp)";
}
