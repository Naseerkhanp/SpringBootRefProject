package com.nsl.usagereport.batch;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.ReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.nbos.dao.repository.WibInfoDaoImpl;
import com.nsl.usagereport.transaction.dao.repository.RefFileUploadDaoImpl;
import com.nsl.usagereport.transaction.entity.RefFileUpload;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class NslBatchProcessor implements ItemProcessor<UsageReportDetails, UsageReportDetails>, StepExecutionListener {
	@Autowired
	NslDataHandler nslDataHandler;
	@Autowired
	private RefFileUploadDaoImpl refFileUploadDaoImpl;
	@Autowired
	private Environment env;
	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;
	@Autowired
	private JobOperator jobOperator;
	private StepExecution stepExecution;
	@Autowired
	private WibInfoDaoImpl wibInfoDaoImpl;

	private Map<Long, RefFileUpload> refFileUploadMap = null;

	public Map<Long, RefFileUpload> getRefFileUploadMap() {
		return refFileUploadMap;
	}

	public void setRefFileUploadMap(Map<Long, RefFileUpload> refFileUploadMap) {
		this.refFileUploadMap = refFileUploadMap;
	}

	@Override
	public UsageReportDetails process(UsageReportDetails usageReportDetails) throws Exception {
		processDataFrmFile(usageReportDetails);
		return usageReportDetails;
	}

	public Boolean processDataFrmFile(UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		Boolean isSuccess = Boolean.TRUE;
		BufferedReader in = null;
		// this map is built to store processed records in DB
		Map<Long, List<Object>> detailsBuiler = new HashMap<Long, List<Object>>();
		// this map is built to store failure records info in DB
		Map<String, Map<Object, Long>> recordsStatus = new HashMap<String, Map<Object, Long>>();
		intializeDefaultValues(recordsStatus);
		List<String> rowsLst = null;
		List<RefFileUpload> refFileUploadColumnsLST = null;
		List<RefFileUpload> fileUploadLst = null;
		RefFileUpload refFileUpload = null;
		Set<String> existingRouterIds = null;
		String fileName = NslFileUploadConstants.EMPTY;
		String extension = NslFileUploadConstants.EMPTY;
		try {
			for (ReportDetails reportDetails : usageReportDetails.getReportDetails()) {
				fileName = reportDetails.getFileObject().getName().getBaseName();
				extension = fileName.substring(fileName.lastIndexOf(NslFileUploadConstants.DOT));
				if (usageReportDetails.getFileType()
						.equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
					in = new BufferedReader(new InputStreamReader(
							new ByteArrayInputStream(reportDetails.getFileObject().getContent().getByteArray())));
				} else {
					// extracting gzip file use this
					in = new BufferedReader(new InputStreamReader(new GZIPInputStream
							(new ByteArrayInputStream(reportDetails.getFileObject().getContent().getByteArray()))));
				}
				rowsLst = extractedDataFrmFile(in);
				if (usageReportDetails.getFileType().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))
						&& rowsLst.size() < 2) {
					log.error(this.getClass() + " file does not contain data  ::");
					throw new Exception("ERR03 – Data is empty");
				}
				fileUploadLst = refFileUploadDaoImpl.getRefFileUploadDetails(usageReportDetails.getFileType());
				refFileUploadMap = fileUploadLst.stream().collect(Collectors.toMap(RefFileUpload::getFilterValue,
						Function.identity(), (getFilterValue, getFilterValue1) -> getFilterValue1));
				log.info(this.getClass() + " converted reffileUpload to map based on key");
				setRefFileUploadMap(refFileUploadMap);
				refFileUpload = refFileUploadDaoImpl.getRefFileUploadDetail(usageReportDetails.getFileType());
				if (usageReportDetails.getFileType()
						.equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
					refFileUploadColumnsLST = fileUploadLst.stream()
							.sorted(Comparator.comparing(RefFileUpload::getColumnIndex)).collect(Collectors.toList());
					log.info(this.getClass() + " sorted reffileUploadLST  based on filter column index");
					nslDataHandler.smbChecks(nslDataHandler.divideColumns(usageReportDetails, rowsLst.get(0)),
							refFileUploadColumnsLST);
				}
				buildData(refFileUpload, usageReportDetails, rowsLst, detailsBuiler, refFileUploadColumnsLST,
						recordsStatus, existingRouterIds, fileUploadLst, fileName, extension);
				reportDetails.setDetailsBuiler(detailsBuiler);
				reportDetails.setRecordsStatus(recordsStatus);
				reportDetails.setRefFileUploadMap(refFileUploadMap);
				reportDetails.setFileName(fileName);
				reportDetails.setExtension(extension);
			}

		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED, 0, 0, 0,
					fileName, null, e.getMessage(),usageReportDetails,null);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception(e.getMessage());
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				log.error(this.getClass() + " Exception thrown ::", e);
			}

		}
		log.info(this.getClass() + " extractDataFrmFile method end called .");
		return isSuccess;
	}

	public void buildData(RefFileUpload refFileUpload, UsageReportDetails usageReportDetails, List<String> rowsLst,
			Map<Long, List<Object>> detailsBuiler, List<RefFileUpload> refFileUploadColumnsLST,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds,
			List<RefFileUpload> fileUploadLst, String fileName, String extension) {
		try {
			int count = 1;
			Long longValue = new Long(refFileUpload.getFilterColumnIndex());
			if (usageReportDetails.getFileType().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				existingRouterIds = wibInfoDaoImpl.getRouterIds();
			}
			for (String row : rowsLst) {
				if (usageReportDetails.getFileType()
						.equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
					if (count != 1) {
						nslDataHandler.buildData(usageReportDetails, detailsBuiler, row, longValue, refFileUploadMap,
								refFileUploadColumnsLST, count, refFileUpload, recordsStatus, existingRouterIds,
								fileUploadLst);
					}
				} else {
					nslDataHandler.buildData(usageReportDetails, detailsBuiler, row, longValue, refFileUploadMap,
							refFileUploadColumnsLST, count, refFileUpload, recordsStatus, existingRouterIds,
							fileUploadLst);
				}
				count++;
			}
		} catch (Exception e) {
			log.error(this.getClass() + " error occured::", e);
			try {
				transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
						(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
								+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, null,
						e.getMessage(),usageReportDetails,null);
				jobOperator.stop(this.stepExecution.getJobExecutionId());
			} catch (Exception e1) {
			}
		}
	}

	public List<String> extractedDataFrmFile(BufferedReader in) throws Exception {
		String content = NslFileUploadConstants.EMPTY;
		long lineNumber = 0;
		List<String> rowsLST = new ArrayList<String>();
		try {
			while ((content = in.readLine()) != null) {
				if (lineNumber > NslFileUploadConstants.ROW_COUNT_CHECK) {
					throw new Exception("ERR05 – File has more than max count");
				}
				if (!content.trim().isEmpty()) {
					rowsLST.add(content);
				}
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception(e.getMessage());
		}
		log.info(this.getClass() + " buildExtractedDataFrmFile method called .");
		return rowsLST;
	}

	public Map<String, Map<Object, Long>> intializeDefaultValues(Map<String, Map<Object, Long>> recordsStatus) {
		recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, new HashMap<Object, Long>());
		recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, new HashMap<Object, Long>());
		return recordsStatus;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.stepExecution = stepExecution;

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}
}
