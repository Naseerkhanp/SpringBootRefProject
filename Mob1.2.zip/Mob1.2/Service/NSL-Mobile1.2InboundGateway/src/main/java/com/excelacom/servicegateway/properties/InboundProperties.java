package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String authserver;

	private String routerserviceurl;

	private String authchecktoken;
	
	private String credentials;
	
	private String hmnoendpoint;
	
	private String smbendpoint;
	
	private String cbrspcrfendpoint;
	
	private String mobile1endpoint;
	
	private String nslUpdateCancelurl;
	
	private String UpdateModifyUrl;
	
	private String HmnoChangepsimUrl;
	
	private String HmnoDeviceinquiryUrl;
	
	private String HmnoChangefeatureUrl;

	private String hmnoLineHistoryInquiryServiceUrl;
	
	private String MnoportinInquiryurl;

	private String HmnoValidateSimUrl;
	
	private String HmnoDeviceinquiryAsyncUrl;
	
	private String mnoLineDetailsUrl;
	
	private String activateHotlineUrl;
	
	private String suspendSubscriberUrl;
	
	private String restoreSubscriberUrl;
	
	private String activateSubscriberUrl;
	
	private String activatePortinSubscriberUrl;
	
	private String deactivateSubscriberUrl;
	
	private String changeRatePlanUrl;
	
	private String changeMdnUrl;
	
	private String lineInquiryUrl;
	
	private String removeHotlineUrl;
	
	private String updatePortoutUrl;
	
	private String updateDuedatePortinUrl;
	
	private String validateMdnUrl;
	
	private String validateDeviceUrl;
	

	private String resetfeatureurl;

	private String hmnochangepsimasyncurl;

	private String orderinquiryurl;

	private String changefeatureasyncurl;


}
