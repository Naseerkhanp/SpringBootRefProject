package com.excelacom.servicegateway.security;

import java.util.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.dao.TransactionDAO;

@Component
public class JWTHandler {

	@Autowired
	TransactionDAO transactionDAO;

	private static final Logger LOGGER = LogManager.getLogger(JWTHandler.class);

	public boolean validateToken(String token) {
		String subject = "HACKER";
		boolean tokenRresp = false;
		try {

			String tokenCheckStatus = transactionDAO.tokenCheck(token);
			if (tokenCheckStatus.contains("success")) {
				String[] parts = token.split("\\.");
				LOGGER.info("parts::1 " + parts[1] + " " + parts[2] + " " + parts[0]);
				JSONObject payload = new JSONObject(decode(parts[1]));
				System.out.println("payload" + payload.getLong("exp"));
				System.out.println("p time" + System.currentTimeMillis());
				if (payload.getString("sub") != null) {
					System.out.println("Matches:::" + payload.getString("sub"));
				}
				if (payload.getLong("exp") > (System.currentTimeMillis() / 1000)) {
					System.out.println("Not Expired");
					tokenRresp = true;
				} else {
					System.out.println("Expired");
				}
			} else {
				System.out.println("Token is not there in database");
			}
			return tokenRresp;
		} catch (Exception e) {
			
			LOGGER.error("Exception in validateToken "+e);
		}
		return tokenRresp;
	}

	private String decode(String encodedString) {
		return new String(Base64.getUrlDecoder().decode(encodedString));
	}
}
