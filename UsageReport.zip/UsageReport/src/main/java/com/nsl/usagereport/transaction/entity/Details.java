package com.nsl.usagereport.transaction.entity;

public interface Details {

}
