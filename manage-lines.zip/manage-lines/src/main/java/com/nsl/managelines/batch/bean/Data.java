package com.nsl.managelines.batch.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Data {

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobType")
	private String jobType;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("transactionTimeStamp")
	private Date transactionTimeStamp;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobName")
	private String jobName;

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("fileDetails")
	private List<FileDetails> fileDetails;

	@JsonProperty("multipleFiles")
	private Boolean multipleFiles;

	@JsonProperty("hasMoreFiles")
	private Boolean hasMoreFiles;

	@JsonProperty("fileName")
	private String fileName;

	@JsonProperty("bcd")
	private String bcd;
	
	@JsonProperty("batchId")
	private String batchId;

	@JsonProperty("page")
	private Page page;

	@JsonProperty("reportType")
	private String reportType;

}