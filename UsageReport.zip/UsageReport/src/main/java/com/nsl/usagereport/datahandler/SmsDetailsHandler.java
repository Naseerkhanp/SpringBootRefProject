package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.entity.SmsDetails;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("SmsDetailsHandler")
public class SmsDetailsHandler implements Handler {

	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst,UsageReportDetails usageReportDetails) throws Exception {
		long id = NslFileUploadUtils.nullCheck(column[0]);
		try {
			SmsDetails smsDetails = new SmsDetails();
			smsDetails.setDsource(fileUploadLst.stream().findFirst().get().getDefaultValue());
			smsDetails.setRecordId(id);
			smsDetails.setUsageSequenceId(NslFileUploadUtils.nullCheck(column[1]));
			smsDetails.setRerateInd(NslFileUploadUtils.nullChecker(column[2]));
			smsDetails.setRerateReasonCode(NslFileUploadUtils.nullCheck(column[3]));
			smsDetails.setBillingNumber(NslFileUploadUtils.nullChecker(column[4]));
			smsDetails.setImsi(NslFileUploadUtils.nullChecker(column[5]));
			smsDetails.setMinNum(NslFileUploadUtils.nullChecker(column[6]));
			smsDetails.setDeviceId(NslFileUploadUtils.nullChecker(column[7]));
			smsDetails.setServicePlan(NslFileUploadUtils.nullChecker(column[8]));
			smsDetails.setTariffPlan(NslFileUploadUtils.nullChecker(column[9]));
			smsDetails.setTierCd(NslFileUploadUtils.nullChecker(column[10]));
			smsDetails.setEventDateTime(NslFileUploadUtils.convertIntToDate(column[11]));
			smsDetails.setGmtOffset(NslFileUploadUtils.nullCheck(column[12]));
			smsDetails.setRecordType(NslFileUploadUtils.nullCheck(column[13]));
			smsDetails.setEventType(NslFileUploadUtils.nullCheck(column[14]));
			smsDetails.setCallDirectionInd(NslFileUploadUtils.nullChecker(column[15]));
			smsDetails.setOtherPartyAddress(NslFileUploadUtils.nullChecker(column[16]));
			smsDetails.setCountryCode(NslFileUploadUtils.nullChecker(column[17]));
			smsDetails.setRateType(NslFileUploadUtils.nullChecker(column[18]));
			smsDetails.setTotalUnits(NslFileUploadUtils.nullCheck(column[19]));
			smsDetails.setIncludedUnits(NslFileUploadUtils.nullCheck(column[20]));
			smsDetails.setChargedUnits(NslFileUploadUtils.nullCheck(column[21]));
			smsDetails.setChargeAmt(NslFileUploadUtils.nullCheck(column[22]));
			smsDetails.setZone(NslFileUploadUtils.nullChecker(column[23]));
			smsDetails.setVatTax(NslFileUploadUtils.nullCheck(column[24]));
			smsDetails.setEquivalentUnits(NslFileUploadUtils.nullCheck(column[25]));
			if (column.length > 26)
				smsDetails.setBillingId(NslFileUploadUtils.nullChecker(column[26]));

			if (detailsBuiler.containsKey(id)) {
				List<Object> li = detailsBuiler.get(id);
				li.add(smsDetails);
				detailsBuiler.put(id, li);
			} else {
				List<Object> li = new ArrayList<>();
				li.add(smsDetails);
				detailsBuiler.put(id, li);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}
}
