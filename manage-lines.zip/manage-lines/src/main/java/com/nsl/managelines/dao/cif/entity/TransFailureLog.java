package com.nsl.managelines.dao.cif.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TRANS_FAILURE_LOG")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransFailureLog implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "TRANSACTION_ID", updatable = false)
	private Long transactionId;

	/*
	 * @ToString.Exclude
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 * 
	 * @JoinColumn(name = "TRANSACTION_ID", referencedColumnName = "TRANSACTION_ID",
	 * insertable = false, updatable = false) private TransactionDetails
	 * transactionDetails;
	 */

	@Column(name = "ENTITY_ID")
	private long entityID;

	@Id
	// @GeneratedValue(strategy = GenerationType.SEQUENCE, generator =
	// "TRANSACTION_LOG_SEQ_gen")
	// @SequenceGenerator(name = "TRANSACTION_LOG_SEQ_gen", sequenceName =
	// "TRANSACTION_LOG_SEQ", allocationSize = 1)
	@Column(name = "ENTITY_TYPE_ID")
	private Long entityTypeID;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "ERROR_CODE")
	private String errorCode;

	@Column(name = "ERROR_MSG")
	private String errorMsg;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "CREATED_BY")
	private String createdBy;

	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate = new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "REJECT_CODE")
	private String rejectCode;

	@Column(name = "REJECT_MESSAGE")
	private String rejectMessage;

	@Column(name = "ENTITY_VALUE")
	private String entityValue;

	@Column(name = "ROOT_TRANSACTION_ID")
	private Long rootTransactionId;

	@Column(name = "ERROR_DETAILS")
	private String errorDetails;

}
