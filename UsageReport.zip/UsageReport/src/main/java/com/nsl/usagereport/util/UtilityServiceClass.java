package com.nsl.usagereport.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class UtilityServiceClass {

	Logger LOGGER = LoggerFactory.getLogger(UtilityServiceClass.class);

	/**
	 * This method is used for invoking the rest api
	 * 
	 * @param request
	 * @param url
	 * @return String response
	 */
	public String callRestAPI(String request, String url) {
		String outputString = "";
		HttpURLConnection conn = null;
		OutputStream os = null;
		BufferedReader in = null;
		try {
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			os = conn.getOutputStream();
			os.write(requestData);

			if (conn.getResponseCode() == 200) {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				LOGGER.info("Response code::" + conn.getResponseCode());
			} else {
				LOGGER.debug("Response code::" + conn.getResponseCode());
				in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}

			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			os.close();
		} catch (Exception e) {
			LOGGER.error("Exception - {}", e);
		} finally {
			try {
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
				if (os != null) {
					os.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
				LOGGER.error("Exception - {}", e);
			}
		}
		LOGGER.info("callRestAPI :: outputString :: " + outputString);
		return outputString;
	}

}
