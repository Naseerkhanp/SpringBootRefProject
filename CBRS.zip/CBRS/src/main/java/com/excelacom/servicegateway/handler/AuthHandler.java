package com.excelacom.servicegateway.handler;


import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import io.restassured.path.json.JsonPath;

public final class AuthHandler {

	
	static Logger LOGGER = LoggerFactory.getLogger(AuthHandler.class);

	public static boolean checkToken(String token) {
		boolean isValid = false;
		if (!(StringUtils.hasText(token) && token.split("\\.").length == 3)) {
			return isValid;
		}
		token = token.startsWith("Bearer ") ? token.substring(7) : token;
		String[] parts = token.split("\\.");
		String base64EncodedBody = parts[1];
		Base64 base64Url = new Base64(true);
		String body = new String(base64Url.decode(base64EncodedBody));
		LOGGER.info("body : " + body);
		if (StringUtils.hasText(body) && body.startsWith("{")) {
			JsonPath jsonBody = JsonPath.from(body);
			Long exp = Long.parseLong(jsonBody.getString("exp")) * 1000;
			isValid = System.currentTimeMillis() < exp;
		}
		return isValid;
	}

}
