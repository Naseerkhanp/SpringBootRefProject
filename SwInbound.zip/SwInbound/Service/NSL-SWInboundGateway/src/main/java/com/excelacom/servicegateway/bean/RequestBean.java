package com.excelacom.servicegateway.bean;

import org.springframework.stereotype.Component;

@Component
public class RequestBean {

	/** The Constant customerID. */
	private String CustomerID;

	private String CustomerRequestID;

	private String mdn;

	private String oldMDN;

	private String newMDN;

	private String hostMDN;

	private String imei;

	private String imsi;

	private String iccid;

	private String eid;

	private String transId;

	private String eiccid;

	private String matchingId;

	private String referenceNumber;

	private String returnURL;

	private String asyncErrorURL;

	private String accountNumber;

	private String subscriberGroupCd;

	private String id;

	private String iccId;

	private String deviceId;

	private String deviceid;
	
	private String oldDeviceId;
	
	private String oldIccid;

	private String planCode;

	private String lineId;

	private String newRatePlan;
	
	private String oldRatePlan;

	private String contextId;

	private String type;

	private String billCycleResetDay;

	private String userId;

	private String origData;

	private String newData;

	private String orderType;

	private String responsetype;

	private String requestNo;

	private String batchId;

	private String pin;

	private String min;

	private String errorDescription;

	private String make;
	
	private String model;
	
	private String mode;
	
	private String prodType;
	
	private String cdmaLess;
	
	private String deviceCategory;

	private String hotlineType;
	
	private String promotionId;
	
	private String startDate;
	
	private String endDate;
	
	private String promotionAllowance;

	private String action;
	
	public String getHotlineType() {
		return hotlineType;
	}

	public void setHotlineType(String hotlineType) {
		this.hotlineType = hotlineType;
	}
	
	public String getNewRatePlan() {
		return newRatePlan;
	}

	public void setNewRatePlan(String newRatePlan) {
		this.newRatePlan = newRatePlan;
	}

	public String getMin() {
		return min;
	}

	public void setMin(String min) {
		this.min = min;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getProdType() {
		return prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	public String getCdmaLess() {
		return cdmaLess;
	}

	public void setCdmaLess(String cdmaLess) {
		this.cdmaLess = cdmaLess;
	}

	public String getDeviceCategory() {
		return deviceCategory;
	}

	public void setDeviceCategory(String deviceCategory) {
		this.deviceCategory = deviceCategory;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getResponsetype() {
		return responsetype;
	}

	public void setResponsetype(String responsetype) {
		this.responsetype = responsetype;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrigData() {
		return origData;
	}

	public void setOrigData(String origData) {
		this.origData = origData;
	}

	public String getNewData() {
		return newData;
	}

	public void setNewData(String newData) {
		this.newData = newData;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getDeviceid() {
		return deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getnewRatePlan() {
		return newRatePlan;
	}

	public void setnewRatePlan(String newRatePlan) {
		this.newRatePlan = newRatePlan;
	}

	public String getOldMDN() {
		return oldMDN;
	}

	public void setOldMDN(String oldMDN) {
		this.oldMDN = oldMDN;
	}

	public String getNewMDN() {
		return newMDN;
	}

	public void setNewMDN(String newMDN) {
		this.newMDN = newMDN;
	}

	public String getHostMDN() {
		return hostMDN;
	}

	public void setHostMDN(String hostMDN) {
		this.hostMDN = hostMDN;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getMatchingId() {
		return matchingId;
	}

	public void setMatchingId(String matchingId) {
		this.matchingId = matchingId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getMdn() {
		return mdn;
	}

	public void setMdn(String mdn) {
		this.mdn = mdn;
	}

	public String getHostMdn() {
		return hostMDN;
	}

	public void setHostMdn(String hostMDN) {
		this.hostMDN = hostMDN;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getCustomerRequestID() {
		return CustomerRequestID;
	}

	public void setCustomerRequestID(String customerRequestID) {
		this.CustomerRequestID = customerRequestID;
	}

	public String getEiccid() {
		return eiccid;
	}

	public void setEiccid(String eiccid) {
		this.eiccid = eiccid;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getReturnURL() {
		return returnURL;
	}

	public void setReturnURL(String returnURL) {
		this.returnURL = returnURL;
	}

	public String getAsyncErrorURL() {
		return asyncErrorURL;
	}

	public void setAsyncErrorURL(String asyncErrorURL) {
		this.asyncErrorURL = asyncErrorURL;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getSubscriberGroupCd() {
		return subscriberGroupCd;
	}

	public void setSubscriberGroupCd(String subscriberGroupCd) {
		this.subscriberGroupCd = subscriberGroupCd;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIccId() {
		return iccId;
	}

	public void setIccId(String iccId) {
		this.iccId = iccId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getContextId() {
		return contextId;
	}

	public void setContextId(String contextId) {
		this.contextId = contextId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBillCycleResetDay() {
		return billCycleResetDay;
	}

	public void setBillCycleResetDay(String billCycleResetDay) {
		this.billCycleResetDay = billCycleResetDay;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getOldDeviceId() {
		return oldDeviceId;
	}

	public void setOldDeviceId(String oldDeviceId) {
		this.oldDeviceId = oldDeviceId;
	}

	public String getOldIccid() {
		return oldIccid;
	}

	public void setOldIccid(String oldIccid) {
		this.oldIccid = oldIccid;
	}
	
	public String getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPromotionAllowance() {
		return promotionAllowance;
	}

	public void setPromotionAllowance(String promotionAllowance) {
		this.promotionAllowance = promotionAllowance;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getOldRatePlan() {
		return oldRatePlan;
	}

	public void setOldRatePlan(String oldRatePlan) {
		this.oldRatePlan = oldRatePlan;
	}

	@Override
	public String toString() {
		return "RequestBean [CustomerID=" + CustomerID + ", CustomerRequestID=" + CustomerRequestID + ", mdn=" + mdn
				+ ", oldMDN=" + oldMDN + ", newMDN=" + newMDN + ", hostMDN=" + hostMDN + ", imei=" + imei + ", imsi="
				+ imsi + ", iccid=" + iccid + ", eid=" + eid + ", transId=" + transId + ", eiccid=" + eiccid
				+ ", matchingId=" + matchingId + ", referenceNumber=" + referenceNumber + ", returnURL=" + returnURL
				+ ", asyncErrorURL=" + asyncErrorURL + ", accountNumber=" + accountNumber + ", subscriberGroupCd="
				+ subscriberGroupCd + ", id=" + id + ", iccId=" + iccId + ", deviceId=" + deviceId + ", deviceid="
				+ deviceid + ", oldDeviceId=" + oldDeviceId + ", oldIccid=" + oldIccid + ", planCode=" + planCode
				+ ", lineId=" + lineId + ", newRatePlan=" + newRatePlan + ", oldRatePlan=" + oldRatePlan
				+ ", contextId=" + contextId + ", type=" + type + ", billCycleResetDay=" + billCycleResetDay
				+ ", userId=" + userId + ", origData=" + origData + ", newData=" + newData + ", orderType=" + orderType
				+ ", responsetype=" + responsetype + ", requestNo=" + requestNo + ", batchId=" + batchId + ", pin="
				+ pin + ", min=" + min + ", errorDescription=" + errorDescription + ", make=" + make + ", model="
				+ model + ", mode=" + mode + ", prodType=" + prodType + ", cdmaLess=" + cdmaLess + ", deviceCategory="
				+ deviceCategory + ", hotlineType=" + hotlineType + ", promotionId=" + promotionId + ", startDate="
				+ startDate + ", endDate=" + endDate + ", promotionAllowance=" + promotionAllowance + ", action="
				+ action + "]";
	}

	
}
