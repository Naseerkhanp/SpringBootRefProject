
package com.nsl.usagereport.cif.dao.repository;

import com.nsl.usagereport.cif.entity.FileDetails;
import com.nsl.usagereport.dto.UsageReportDetails;

public interface FileDetailsDao {

	public void insertFileDetails(UsageReportDetails usageReportDetails, String fileName) throws Exception;

	public void updateFileDetails(String downloadStatus, String parsedStatus, String fileName) throws Exception;

	public FileDetails findByFileName(String fileName) throws Exception;
}
