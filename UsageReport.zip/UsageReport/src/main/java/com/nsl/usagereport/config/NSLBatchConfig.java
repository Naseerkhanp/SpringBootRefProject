package com.nsl.usagereport.config;

import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.nsl.usagereport.batch.NslBatchReader;
import com.nsl.usagereport.dto.UsageReportDetails;

@Configuration
@EnableBatchProcessing
public class NSLBatchConfig {

	@Bean
	@StepScope
	@Primary
	ItemReader<UsageReportDetails> restStudentReader(@Value("#{jobParameters}") Map<String, Object> jobParameters) {
		return new NslBatchReader(jobParameters);
	}

	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
			ItemReader<UsageReportDetails> itemReader,
			ItemProcessor<UsageReportDetails, UsageReportDetails> itemProcessor,
			ItemWriter<UsageReportDetails> itemWriter) {

		Step step = stepBuilderFactory.get("ETL-file-load").<UsageReportDetails, UsageReportDetails>chunk(1)
				.reader(itemReader).processor(itemProcessor).writer(itemWriter).build();

		return jobBuilderFactory.get("ETL-Load").incrementer(new RunIdIncrementer()).start(step).build();
	}
}