package com.excelacom.servicegateway.dao;

public interface TransactionDAO {

	String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName);

	void insertMNORequestDetails(String request, String responseId);

	void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId,
			String transGroupId, String serviceName);

	String updateNorthBoundTransactionNcm(String transId, String entityId, String response, String groupId,
			String processPlanId, String serviceName, String status);

	void updateNorthBoundTransactionFailure(String transId, String entityId, String groupId, String processPlanId,
			String serviceName);

	String tokenCheck(String token);

	String insertMNONBTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName, String httpMethod, String source);

	public void insertRequestDetails(String requestJson,String responseId);

	public String validateBasicToken(String basicToken);

}
