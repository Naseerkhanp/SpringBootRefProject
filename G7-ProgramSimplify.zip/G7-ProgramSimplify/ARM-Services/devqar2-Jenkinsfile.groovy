pipeline {
    agent any
	
	tools { 
        maven 'Maven-3.3.9' 
        jdk 'jdk-11.0.9' 
    }	
	
    stages {
        
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-devqar2-CICD@excelacom.in',
			to: 'nsl_devops@excelacom.in',
			subject: "NSL devqar2 arm-service Service Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }

		stage('NSL devqar2 - EKS POD Deploy') {
			steps {
			echo 'arm-service Service POD Deployment has been started...'
			sh 'cat devqar2-arm-service-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f devqar2-arm-service-service.yaml'
			sh 'kubectl apply -f devqar2-arm-service-config.yaml'
			sh 'kubectl rollout restart deployment arm-service-deployment'
			
                  }
        }
		stage('NSL devqar2 - EKS POD Status') {
		    steps {
			echo 'arm-service Service POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep arm-service-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,

		  subject: "NSL devqar2 arm-service Service Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-devqar2-CICD@excelacom.in',
		  to: 'nsl_devops@excelacom.in',
		  attachLog: true,

		  subject: "NSL devqar2 arm-service Service Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }