package com.excelacom.servicegateway.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.bean.Account;
import com.excelacom.servicegateway.bean.Device;
import com.excelacom.servicegateway.bean.Feature;
import com.excelacom.servicegateway.bean.Line;
import com.excelacom.servicegateway.bean.LineHistory;
import com.excelacom.servicegateway.bean.LinePlan;
import com.excelacom.servicegateway.bean.ReferenceValue;
import com.excelacom.servicegateway.bean.RequestBean;
import com.excelacom.servicegateway.bean.ResourceUpdateRequest;
import com.excelacom.servicegateway.bean.Sim;
import com.excelacom.servicegateway.bean.TransactionHistory;
import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.google.gson.Gson;

@Component
public class ResourceServiceClient {

	@Autowired
	private JdbcTemplate centuryCIFTemplate;

	@Autowired
	private JdbcTemplate centuryNBOPTemplate;

//	@Autowired
//	private Account account;

//	@Autowired
//	private Line lineBean;

//	@Autowired
//	private Sim simBean;

//	@Autowired
//	private LinePlan linePlanBean;

	@Autowired
	private ResourceUpdateRequest resourceUpdateRequest;

/*	@Autowired
	private LineHistory lineHistoryBean;

	@Autowired
	private TransactionHistory transactionHistory;

	@Autowired
	private Feature featureBean; */

	@Autowired
	InboundProperties inboundProperties;

//	@Autowired
//	private Device device;

	@Autowired
	TransactionDAO transactionDAO;
	
//	@Autowired
//	ReferenceValue referenceValue;

	Logger LOGGER = LoggerFactory.getLogger(ResourceServiceClient.class);

	public void insertMNODomainDetails(RequestBean asyncResponseBean) {
		Account account = new Account();
		Line line = new Line();
		Sim sim = new Sim();
		LinePlan linePlan = new LinePlan();
		ResourceUpdateRequest resourceUpdateRequest = new ResourceUpdateRequest();
		LineHistory lineHistory = new LineHistory();
		TransactionHistory transactionHistory = new TransactionHistory();
		Feature feature = new Feature();
		Device device = new Device();
		LOGGER.info("inside NEW....insertMNODomainDetails smartwatch::::" + asyncResponseBean.toString());
		String transId = "";
		String transactionName = "";
		String inboundRequest = "";
		String deviceDetails = "";
		int deviceCount = 0;
		String lineId = "";
		String accountId = "";
		String verifyAccount = "";
		String verifyLine = "";
		String formattedrequest = "";
		RequestBean obRequestBean = null;
		RequestBean secondObReqBean = null;
		RequestBean ibRequestBean = null;
		RequestBean deviceDetailsBean = null;
		ReferenceValue referenceValue = new ReferenceValue();
		JSONObject requestobj = new JSONObject();
		JSONArray featureArray = new JSONArray();
		JSONObject featureObj = new JSONObject();
		Map<String, String> featMap = new HashMap<String, String>();
		List<Map<String, Object>> outboundRequest = null;
		String action = "";
		Map<String, Object> inboundReq = new HashMap<String, Object>();
		String transName = "";
		try {

			if (asyncResponseBean != null && asyncResponseBean.getReferenceNumber() != null) {

				transId = centuryCIFTemplate.queryForObject(Constants.GETNBTRANSID,
						new Object[] { asyncResponseBean.getReferenceNumber() }, String.class);
				LOGGER.info("request inside NEW..transId.......::::" + transId);
				
				outboundRequest = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GETOBREQUEST,
						new Object[] { transId });
				LOGGER.info("outboundRequest:::" + outboundRequest);
				inboundReq = centuryCIFTemplate.queryForMap(Constants.GETIBREQUEST, new Object[] { transId });
				LOGGER.info("inboundReq:::////////" + inboundReq);
				inboundRequest = inboundReq.get(Constants.REQ_MSG).toString();
				transName = inboundReq.get(Constants.TRANS_NAME).toString();
				LOGGER.info("inboundRequest:::..............." + inboundRequest);
				LOGGER.info("transName:::" + transName);
				int counter = 0;
				if (outboundRequest.size() > 0) {
					for (int i = 0; i < outboundRequest.size(); i++) {
						LOGGER.info("formattedrequest:: " + outboundRequest.get(i).toString());

						for (Map<String, Object> map : outboundRequest) {
							LOGGER.info("formattedrequest map:: " + map.get("TRANSACTION_NAME"));
							if (!(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("AsyncService"))
									&& !(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("GateWayService"))
									&& !(map.get("TRANSACTION_NAME").toString()
											.equalsIgnoreCase("ConnectionManagerLD"))
											&& !(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Deactivate Subscriber"))) {
											if(transName.equalsIgnoreCase("Transfer Wearable")){
												transactionName=transName;
											}else{
												transactionName = map.get("TRANSACTION_NAME").toString();
											}								
								if (map.get("REQUEST_MSG").toString().startsWith("[")
										|| map.get("REQUEST_MSG").toString().startsWith("{")) {
									counter++;
									formattedrequest = jsonFormatter(map.get("REQUEST_MSG").toString());
									JSONArray jsonArrayInner = new JSONArray(formattedrequest);
									LOGGER.info("map1111:: " + jsonArrayInner);
									requestobj = jsonArrayInner.getJSONObject(0);
									Gson gson = new Gson();
									if (counter == 1) {
										LOGGER.info("Inside else if :: ");
										obRequestBean = gson.fromJson(requestobj.toString(), RequestBean.class);
									} else {
										LOGGER.info("Inside if obRequestBean:: ");
										secondObReqBean = gson.fromJson(requestobj.toString(), RequestBean.class);
										LOGGER.info("Inside if secondObReqBean:: " + secondObReqBean.toString());
									}
									LOGGER.info("requestobj:: " + requestobj.toString());
									LOGGER.info("request after bean conversion in insertMNODomainDetails111::::"
											+ obRequestBean.toString() + "\n---------------"
											+ asyncResponseBean.toString());
								}
							}
							if (map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Activate Subscriber")
									|| map.get("TRANSACTION_NAME").toString()
											.equalsIgnoreCase("Activate Subscriber Port-In")
									|| map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Change Feature")
									|| map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Change Rate Plan")
									|| map.get("TRANSACTION_NAME").toString()
											.equalsIgnoreCase("Device Detection Change Rate Plan")) {
								if (map.get("REQUEST_MSG").toString() != "") {
									if (map.get("REQUEST_MSG").toString().startsWith("{")) {
										JSONObject newObj = new JSONObject(map.get("REQUEST_MSG").toString());
										newObj = newObj.getJSONObject("data");
										if (newObj.has("feature") && newObj.getJSONArray("feature").length() != 0) {
											featureArray = newObj.getJSONArray("feature");
										}
										if (newObj.has("newRatePlan")) {
											JSONObject newRatePlanObj = new JSONObject();
											newRatePlanObj = newObj.getJSONObject("newRatePlan");
											if (newRatePlanObj.has("planCode")) {
												String newWholeSaleplanCode = newRatePlanObj.getString("planCode");
												obRequestBean.setnewRatePlan(newWholeSaleplanCode);
												LOGGER.info(
														"obj new rate whole sale plan Code:::" + newWholeSaleplanCode);
											}

										}
										if (newObj.has("oldRatePlan")) {
											JSONObject oldRatePlanObj = new JSONObject();
											oldRatePlanObj = newObj.getJSONObject("oldRatePlan");
											if (oldRatePlanObj.has("planCode")) {
												String oldWholeSaleplanCode = oldRatePlanObj.getString("planCode");
												obRequestBean.setOldRatePlan(oldWholeSaleplanCode);
												LOGGER.info(
														"obj old rate whole sale plan Code:::" + oldWholeSaleplanCode);
											}
										}

									} else {
										if (map.get("REQUEST_MSG").toString().startsWith("[")) {
											JSONArray requestArray = new JSONArray(map.get("REQUEST_MSG").toString());
											JSONObject obj = new JSONObject();
											obj = requestArray.getJSONObject(0);
											if (obj.has("resellerOrder")) {
												obj = obj.getJSONObject("resellerOrder");
												obj = obj.getJSONObject("data");
												if (obj.has("feature") && obj.getJSONArray("feature").length() != 0) {
													featureArray = obj.getJSONArray("feature");
												}
											} else if (obj.has("MNOChangeRatePlan")) {
												obj = obj.getJSONObject("MNOChangeRatePlan");
												obj = obj.getJSONObject("data");
												LOGGER.info("obj:::" + obj.toString());
												if (obj.has("oldRatePlan")) {
													JSONObject oldRatePlanObj = new JSONObject();
													oldRatePlanObj = obj.getJSONObject("oldRatePlan");
													if (oldRatePlanObj.has("planCode")) {
														String oldWholeSaleplanCode = oldRatePlanObj
																.getString("planCode");
														obRequestBean.setOldRatePlan(oldWholeSaleplanCode);
														LOGGER.info("obj old rate whole sale plan Code:::"
																+ oldWholeSaleplanCode);
													}
												}
												if (obj.has("feature") && obj.getJSONArray("feature").length() != 0) {
													featureArray = obj.getJSONArray("feature");
												} else if (obj.has("newRatePlan")) {
													obj = obj.getJSONObject("newRatePlan");
													if (obj.has("feature")
															&& obj.getJSONArray("feature").length() != 0) {
														featureArray = obj.getJSONArray("feature");
														LOGGER.info("obj new rate plan:::" + featureArray.toString());
													}
													if (obj.has("planCode")) {
														String newWholeSaleplanCode = obj.getString("planCode");
														obRequestBean.setnewRatePlan(newWholeSaleplanCode);
														LOGGER.info("obj new rate whole sale plan Code:::"
																+ newWholeSaleplanCode);
													}

												}
											}
										}
									}
								}
							}
							if (featureArray.length() > 0) {
								for (int j = 0; j < featureArray.length(); j++) {
									String featureCode = "";
									String subscribe = "";
									featureObj = featureArray.getJSONObject(j);
									Iterator a = featureObj.keys();
									while (a.hasNext()) {
										String keyStr = a.next().toString();
										if (keyStr.equalsIgnoreCase("subscribe")) {
											subscribe = featureObj.getString(keyStr);
											if (subscribe.equalsIgnoreCase("A")) {
												subscribe = "Y";
											} else {
												subscribe = "N";
											}
										}
										if (keyStr.equalsIgnoreCase("featureCode")) {
											featureCode = featureObj.getString(keyStr);
										}
										if (subscribe != "" && featureCode != "") {
											featMap.put(featureCode, subscribe);
										}
									}

								}
							}
						}
					}
				}
				

				if (!"".equalsIgnoreCase(inboundRequest)) {
					formattedrequest = jsonFormatter(inboundRequest);
					JSONArray jsonArrayInner = new JSONArray(formattedrequest);
					LOGGER.info("map1111:: " + jsonArrayInner);
					requestobj = jsonArrayInner.getJSONObject(0);
					Gson gson = new Gson();
					ibRequestBean = gson.fromJson(requestobj.toString(), RequestBean.class);
				}
				if (!("Deactivate Subscriber".equalsIgnoreCase(transactionName)
						|| "Suspend Subscriber".equalsIgnoreCase(transactionName)
						|| "Restore Service".equalsIgnoreCase(transactionName)
						|| "Reconnect Service".equalsIgnoreCase(transactionName))) {
					deviceCount = centuryCIFTemplate.queryForObject(Constants.GETDEVICEREQ_COUNT,
							new Object[] { transId, transId }, Integer.class);
					if (deviceCount != 0) {
						List<Map<String, Object>> deviceDetailsMap = new ArrayList<Map<String, Object>>();
						deviceDetailsMap = (List<Map<String, Object>>) centuryCIFTemplate
								.queryForList(Constants.GETDEVICEREQUEST, new Object[] { transId, transId });
						for (int i = 0; i < deviceDetailsMap.size(); i++) {
							if (deviceDetailsMap.get(i).get(Constants.TRANSACTION_NAME)
									.equals(Constants.VALIDATE_DEVICE)) {
								deviceDetails = deviceDetailsMap.get(i).get(Constants.RESPONSE_MSG).toString();
								break;
							} else if (deviceDetailsMap.get(i).get(Constants.TRANSACTION_NAME)
									.equals(Constants.ACTIVATE_SUB)) {
								deviceDetails = getDeviceDetails(
										deviceDetailsMap.get(i).get(Constants.REQUEST_MSG).toString());
								break;
							}
						}
						LOGGER.info("deviceDetails:::" + deviceDetails);
					}
					if (!"".equalsIgnoreCase(deviceDetails)) {
						formattedrequest = jsonFormatter(deviceDetails);
						JSONArray jsonArrayInner = new JSONArray(formattedrequest);
						LOGGER.info("map1111:: " + jsonArrayInner);
						requestobj = jsonArrayInner.getJSONObject(0);
						Gson gson = new Gson();
						deviceDetailsBean = gson.fromJson(requestobj.toString(), RequestBean.class);
					}
				}
			}
			MapSqlParameterSource input = new MapSqlParameterSource();
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryNBOPTemplate.getDataSource());
			LOGGER.info("Inside insertMNORequestDetails Input :: IF " + transName);
			LOGGER.info("Inside insertMNORequestDetails Input :: obRequestBean " + obRequestBean + " asyncResponseBean"
					+ asyncResponseBean);
			if (transName.equalsIgnoreCase("Device Detection") || transName.equalsIgnoreCase("Unsolicited Port-out")
					|| transName.equalsIgnoreCase("Unsolicited Port-out Cancel")
					|| transName.equalsIgnoreCase("DPFO Notification")) {
				if (obRequestBean == null && asyncResponseBean != null) {
					/*
					 * transactionName = centuryCIFTemplate.queryForObject(Constants.GETNBTRANSNAME,
					 * new Object[] { transId }, String.class);
					 */
					resourceUpdateRequest.setTransactionName(transName);
					resourceUpdateRequest.setTransationId(transId);
					resourceUpdateRequest = insertIntoTransactionHistory(inboundRequest,
							resourceUpdateRequest.getTransationId(), resourceUpdateRequest.getTransactionName());
					LOGGER.info("Calling callResourceService after transactionHistory......"
							+ resourceUpdateRequest.toString());
					callResourceService(resourceUpdateRequest);
				}
			}
			if (obRequestBean != null && asyncResponseBean != null) {
				if (obRequestBean.getSubscriberGroupCd() != null) {
					input.addValue("SUBGROUPCD", obRequestBean.getSubscriberGroupCd());
					account.setSubgroupcd(obRequestBean.getSubscriberGroupCd());
				} else if (asyncResponseBean.getSubscriberGroupCd() != null) {
					input.addValue("SUBGROUPCD", asyncResponseBean.getSubscriberGroupCd());
					account.setSubgroupcd(asyncResponseBean.getSubscriberGroupCd());
				} else {
					input.addValue("SUBGROUPCD", null);
				}
				if (ibRequestBean.getAccountNumber() != null) {
					input.addValue("ACCOUNT_NUMBER", ibRequestBean.getAccountNumber());
					line.setAccountNumber(ibRequestBean.getAccountNumber());
					account.setAccountNumber(ibRequestBean.getAccountNumber());
					lineHistory.setAccountNumber(ibRequestBean.getAccountNumber());
					accountId = ibRequestBean.getAccountNumber();
					// verifyAccount = verifyAccount(accountId);
				} else {
					input.addValue("ACCOUNT_NUMBER", null);
				}
				if (ibRequestBean.getAction() != null) {
					action = ibRequestBean.getAction();
				}
				if (obRequestBean.getContextId() != null) {
					input.addValue("CONTEXT_ID", obRequestBean.getContextId());
					account.setContextId(obRequestBean.getContextId());
				} else if (ibRequestBean.getContextId() != null) {
					input.addValue("CONTEXT_ID", ibRequestBean.getContextId());
					account.setContextId(ibRequestBean.getContextId());
				} else {
					input.addValue("CONTEXT_ID", null);
				}
				if (obRequestBean.getType() != null) {
					input.addValue("ACCT_TYPE", obRequestBean.getType());
					account.setAccountType(obRequestBean.getType());
				} else if (ibRequestBean.getType() != null) {
					input.addValue("ACCT_TYPE", ibRequestBean.getType());
					account.setAccountType(ibRequestBean.getType());
				} else {
					input.addValue("ACCT_TYPE", null);
				}
				if (obRequestBean.getPin() != null) {
					input.addValue("PIN", obRequestBean.getPin());
					LOGGER.info("obRequestBean.getPin()::" + obRequestBean.getPin());
					account.setPin(obRequestBean.getPin());
				} else if (ibRequestBean.getPin() != null) {
					input.addValue("PIN", ibRequestBean.getPin());
					LOGGER.info("ibRequestBean.getPin()::" + ibRequestBean.getPin());
					account.setPin(ibRequestBean.getPin());
				} else {
					input.addValue("PIN", null);
				}
				if (obRequestBean.getImsi() != null) {
					input.addValue("IMSI", obRequestBean.getImsi());
					sim.setImsi(obRequestBean.getImsi());
				} else if (asyncResponseBean.getImsi() != null) {
					input.addValue("IMSI", asyncResponseBean.getImsi());
					sim.setImsi(asyncResponseBean.getImsi());
				} else {
					input.addValue("IMSI", null);
				}
				if (ibRequestBean.getReferenceNumber() != null) {
					input.addValue("REFERENCENUMBER", obRequestBean.getReferenceNumber());
					line.setReferenceNumber(obRequestBean.getReferenceNumber());
				} else if (asyncResponseBean.getReferenceNumber() != null) {
					input.addValue("REFERENCENUMBER", asyncResponseBean.getReferenceNumber());
					line.setReferenceNumber(asyncResponseBean.getReferenceNumber());
				} else {
					input.addValue("REFERENCENUMBER", null);
				}
				
				LOGGER.info("Inside insertMNORequestDetails obRequestBean.getMdn() :: IF " + obRequestBean.getMdn());
				LOGGER.info("Inside insertMNORequestDetails asyncResponseBean.getMdn() :: IF " + asyncResponseBean.getMdn());
				
				if (obRequestBean.getMdn() != null) {
					input.addValue("MDN", obRequestBean.getMdn());
					line.setMdn(obRequestBean.getMdn());
					lineHistory.setMdn(obRequestBean.getMdn());
				} else if (asyncResponseBean.getMdn() != null) {
					input.addValue("MDN", asyncResponseBean.getMdn());
					line.setMdn(asyncResponseBean.getMdn());
					lineHistory.setMdn(asyncResponseBean.getMdn());
				} else {
					input.addValue("MDN", null);
					input.addValue("HOSTMDN", null);
				}
				if (obRequestBean.getHostMdn() != null) {
					input.addValue("HOSTMDN", obRequestBean.getHostMdn());
					line.setHostMdn(obRequestBean.getHostMdn());
				} else if (asyncResponseBean.getHostMdn() != null) {
					input.addValue("HOSTMDN", asyncResponseBean.getHostMdn());
					line.setHostMdn(asyncResponseBean.getHostMdn());
				} else {
					input.addValue("HOSTMDN", null);
				}
				if (asyncResponseBean.getMin() != null) {
					input.addValue("MIN", asyncResponseBean.getMin());
					line.setMin(asyncResponseBean.getMin());
				} else {
					input.addValue("MIN", null);
				}
				if (ibRequestBean.getLineId() != null) {
					input.addValue("LINEID", ibRequestBean.getLineId());
					lineId = ibRequestBean.getLineId();
					// verifyLine = verifyLine(lineId);
					device.seteLineId(ibRequestBean.getLineId());
					line.seteLineId(ibRequestBean.getLineId());
					sim.seteLineId(ibRequestBean.getLineId());
					linePlan.seteLineId(ibRequestBean.getLineId());
					lineHistory.seteLineId(ibRequestBean.getLineId());
					feature.seteLineId(ibRequestBean.getLineId());
				} else {
					input.addValue("LINEID", null);
				}
				if (obRequestBean.getBillCycleResetDay() != null) {
					input.addValue("BILLCYCLEDAY", obRequestBean.getBillCycleResetDay());
					line.setBcd(obRequestBean.getBillCycleResetDay());
					LOGGER.info("Change ESIM asyncResponseBean.getImei()::" + asyncResponseBean.getImei());
				} else if (ibRequestBean.getBillCycleResetDay() != null) {
					input.addValue("BILLCYCLEDAY", ibRequestBean.getBillCycleResetDay());
					line.setBcd(ibRequestBean.getBillCycleResetDay());
					LOGGER.info("Change ESIM asyncResponseBean.getImei()::" + asyncResponseBean.getImei());
				} else {
					input.addValue("BILLCYCLEDAY", null);
				}
				LOGGER.info("Change ESIM  asyncResponseBean.getIMEI()::" + asyncResponseBean.getImei());
				if (ibRequestBean.getImei() != null) {
					input.addValue("IMEI", ibRequestBean.getImei());
					device.setImei(ibRequestBean.getImei());
				}else if (asyncResponseBean.getImei() != null) {
					input.addValue("IMEI", asyncResponseBean.getImei());
					device.setImei(asyncResponseBean.getImei());
				}else if (obRequestBean.getImei() != null) {
						input.addValue("IMEI", obRequestBean.getImei());
						device.setImei(obRequestBean.getImei());
				} /*
					 * else if (asyncResponseBean.getDeviceId() != null) { input.addValue("IMEI",
					 * deviceDetailsBean.getDeviceId()); }
					 */ else {
					input.addValue("IMEI", null);
				}
				LOGGER.info("Change ESIM  asyncResponseBean.getIccId()::" + asyncResponseBean.getIccId());
				LOGGER.info("Change ESIM asyncResponseBean.getIccid()::" + asyncResponseBean.getIccid());
				if (asyncResponseBean.getIccid() != null) {
					input.addValue("ICCID", asyncResponseBean.getIccid());
					sim.setIccid(asyncResponseBean.getIccid());
					LOGGER.info("Change ESIM asyncResponseBean.getIccid()::" + asyncResponseBean.getIccid());
				}else if (obRequestBean.getIccid() != null) {
					input.addValue("ICCID", obRequestBean.getIccid());
					sim.setIccid(obRequestBean.getIccid());
					LOGGER.info("Change ESIM obRequestBean.getIccid()::" + obRequestBean.getIccid());
				} else {
					input.addValue("ICCID", null);
				}
				if (ibRequestBean.getPlanCode() != null) {
					input.addValue("RETAIL_PLANCODE", ibRequestBean.getPlanCode());
					linePlan.setRetailPlan(ibRequestBean.getPlanCode());
				} else {
					input.addValue("RETAIL_PLANCODE", null);
				}
				if (obRequestBean.getPlanCode() != null) {
					input.addValue("WHOLESALE_PLAN", obRequestBean.getPlanCode());
					linePlan.setWhsPlan(obRequestBean.getPlanCode());
				} else {
					input.addValue("WHOLESALE_PLAN", null);
				}
				// Device details update
				if (deviceDetailsBean != null) {
					if (deviceDetailsBean.getMake() != null) {
						input.addValue("MAKE", deviceDetailsBean.getMake());
						device.setMake(deviceDetailsBean.getMake());
						if (deviceDetailsBean.getMake().equalsIgnoreCase(Constants.OS_APL)) {
							device.setOs("IOS");
						} else {
							device.setOs("Android");
						}
					} else {
						input.addValue("MAKE", null);
					}
					if (deviceDetailsBean.getDeviceId() != null) {
						input.addValue("IMEI", deviceDetailsBean.getDeviceId());
						device.setImei(deviceDetailsBean.getDeviceId());
					} else {
						input.addValue("IMEI", null);
					}
					if (deviceDetailsBean.getModel() != null) {
						input.addValue("MODEL", deviceDetailsBean.getModel());
						device.setModel(deviceDetailsBean.getModel());
					} else {
						input.addValue("MODEL", null);
					}
					if (deviceDetailsBean.getMode() != null) {
						input.addValue("MODE", deviceDetailsBean.getMode());
						device.setModeValue(deviceDetailsBean.getMode());
						// DEVICE_TYPE
						String deviceType = deviceDetailsBean.getMode().toString();
						input.addValue("DEVICE_TYPE", deviceType.substring(0, 2));
						device.setDeviceType(deviceType.substring(0, 2));
						sim.setFirstActivatedNetwork(deviceType.substring(0, 2));
					} else {
						input.addValue("MODE", null);
					}
					if (deviceDetailsBean.getCdmaLess() != null) {
						input.addValue("CDMALESS", deviceDetailsBean.getCdmaLess());
						device.setCdmaless(deviceDetailsBean.getCdmaLess());
					} else {
						input.addValue("CDMALESS", "N");
						device.setCdmaless("N");
					}

					if (deviceDetailsBean.getDeviceCategory() != null) {
						input.addValue("DEVICE_CATEGORY", deviceDetailsBean.getDeviceCategory());
					} else {
						input.addValue("DEVICE_CATEGORY", null);
					}
					if (deviceDetailsBean.getProdType() != null) {
						input.addValue("PRODTYPE", deviceDetailsBean.getProdType());
					} else {
						input.addValue("PRODTYPE", null);
					}
				}
				if (secondObReqBean != null) {
					LOGGER.info("secondObReqBea## " + secondObReqBean.toString());
				}

				line.setIsMigrated(Constants.NO);
				lineHistory.setTransactionId(transId);
				account.setIsMigrated(Constants.NO);
				resourceUpdateRequest.setTransactionName(transactionName);
				resourceUpdateRequest.setTransationId(transId);
				resourceUpdateRequest.setFeatureMap(featMap);
				setResourceDetails(asyncResponseBean, obRequestBean, ibRequestBean, account, line, device, sim,
						linePlan, lineHistory, resourceUpdateRequest, inboundRequest, feature, secondObReqBean,
						deviceDetailsBean,referenceValue);
			}
		} catch (JSONException e) {
			LOGGER.error("Exception", e);
		}
	}

	public void setResourceDetails(RequestBean asyncResponseBean, RequestBean obRequestBean, RequestBean ibRequestBean,
			Account account, Line line, Device device, Sim sim, LinePlan linePlan, LineHistory lineHistory,
			ResourceUpdateRequest resourceUpdateRequest, String inboundRequest, Feature feature,
			RequestBean secondObReqBean, RequestBean deviceDetailsBean,ReferenceValue referenceValue) {
		LOGGER.info("setResourceDetails getTransactionName......" + resourceUpdateRequest.getTransactionName());
		switch (resourceUpdateRequest.getTransactionName()) {
		case Constants.TRANSACTION_NAME_TW:
			resourceUpdateRequest = transferWearbaleRecords(ibRequestBean, line, device, lineHistory, resourceUpdateRequest,
					obRequestBean, secondObReqBean, deviceDetailsBean,sim, asyncResponseBean, referenceValue,linePlan);
			break;
		case Constants.TRANSACTION_NAME_CW:
			resourceUpdateRequest = changeWearbaleRecords(ibRequestBean,lineHistory,resourceUpdateRequest,sim, line, referenceValue,linePlan,device,obRequestBean);
			break;
		}
		//resourceUpdateRequest = insertIntoTransactionHistory(inboundRequest, resourceUpdateRequest.getTransationId(),
				//resourceUpdateRequest.getTransactionName());
		LOGGER.info("Calling callResourceService after transactionHistory......" + resourceUpdateRequest.toString());
		// Update TransactionHistory
				LOGGER.info("update transaction History TransactionId" + resourceUpdateRequest.getTransationId());
				TransactionHistory transactionHistory = new TransactionHistory();
				transactionHistory.setTransactionEndDate(getTimeStamp());
				transactionHistory.setModifiedDate(getTimeStamp());
				transactionHistory.setTransactionId(resourceUpdateRequest.getTransationId());
				resourceUpdateRequest.setTransactionHistory(transactionHistory);
				LOGGER.info("Calling callResourceService after transactionHistory......"+resourceUpdateRequest.toString());
				callResourceService(resourceUpdateRequest);
		
	}

	private ResourceUpdateRequest transferWearbaleRecords(RequestBean ibRequestBean, Line line,Device device, LineHistory lineHistory,
			ResourceUpdateRequest resourceUpdateRequest, RequestBean obRequestBean, RequestBean secondObReqBean,
			RequestBean deviceDetailsBean,Sim sim, RequestBean asyncResponseBean, ReferenceValue referenceValue, LinePlan linePlan) {
		LOGGER.info("Inside transferWearbaleRecords:::::" + ibRequestBean.toString());
		try {
			/* Line details */
			LOGGER.info("line.getMdn():::::" + line.getMdn());
			
			LOGGER.info("asyncResponseBean.getMdn():::::" + asyncResponseBean.getMdn());
			LOGGER.info("ibRequestBean.getHostMDN():::::" + ibRequestBean.getHostMDN());
			
			line.setMdn(asyncResponseBean.getMdn());
			line.setHostMdn(ibRequestBean.getHostMDN());
			line.setActivationDate(getTimeStamp());
			line.setLineType(Constants.LINETYPE_SMARTWATCH);
			line.setModifiedDate(getTimeStamp());
			line.setModifiedBy(Constants.MODITY_BY);
			line.setLteStatus(Constants.LTE_STATUS_RS);
			
			LOGGER.info("line Bean after setting values:::::" + line.toString());
			
			/* Line History details */
			lineHistory.setOrdType(Constants.ORDER_TYPE_TW);
			lineHistory.setTransactionType(Constants.TRANSACTION_TYPE_TW);
			lineHistory.setCreatedDate(getTimeStamp());
			lineHistory.setModifiedDate(getTimeStamp());
			lineHistory.setModifiedBy(Constants.MODITY_BY);
			lineHistory.setCreatedBy(Constants.CREATED_BY);
			lineHistory.setMdn(line.getMdn());
			lineHistory.setNewValue(line.getMdn());
			lineHistory.setStartDate(getTimeStamp());
			lineHistory.setAcctStatus(Constants.ACCOUNT_STATUS);
			
			/* Device details */
			device.setCreatedDate(getTimeStamp());
			device.setStartDate(getTimeStamp());
			device.setCreatedBy(Constants.CREATED_BY);
			device.setModifiedBy(Constants.MODITY_BY);
			device.setModifiedDate(getTimeStamp());
			device.setEquipmentType(Constants.LINETYPE_SMARTWATCH);
			device.setIsByod(Constants.YES);
			
			/* Sim Details */
			sim.setModifiedBy(Constants.MODITY_BY);
			sim.setModifiedDate(getTimeStamp());
			
			//LINEPlan
			linePlan.setRetailPlan(Constants.MSWAP);
			
			//resourceUpdateRequest.setTransactionName("Add Wearable");
			resourceUpdateRequest.setLinePlan(linePlan);
			resourceUpdateRequest.setLineDetails(line);
			resourceUpdateRequest.setLineHistory(lineHistory);
			resourceUpdateRequest.setDeviceDetails(device);
			resourceUpdateRequest.setSimDetails(sim);
			resourceUpdateRequest.setReferenceValue(referenceValue);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return resourceUpdateRequest;
	}

	public String jsonFormatter(String inputJson) {
		LOGGER.info("inputJson:::::" + inputJson);
		String response = null;
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					response = "[" + printJsonObject(obj, finalObj) + "]";
					LOGGER.info("JsonArray Formatter Final Response:::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				response = "[" + printJsonObject(object, finalObj) + "]";
				LOGGER.info("JsonObject Formatter Final Response:::" + response);
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return response;
	}

	public String printJsonObject(JSONObject jsonObj, JSONObject obj) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();

				Object keyvalue = jsonObj.get(keyStr);
				JSONObject object = null;

				if ("mdn".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String key = jsonObject1.get("type").toString();

							String str = jsonObject1.toString();

							if (key.equalsIgnoreCase("hostMDN")) {
								str = str.replace("value", "hostMDN");
							} else {
								str = str.replace("value", "mdn");
							}
							object = new JSONObject(str);
						}
					}
				}
				if ("simid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "iccid");
							object = new JSONObject(str);
						}
					}
				}
				if ("deviceid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "imei");
							object = new JSONObject(str);
						}
					}
				}
				if (object != null) {
					keyvalue = object;
				}

				if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
					obj.put(keyStr, keyvalue.toString());
				}
				if (keyvalue instanceof JSONObject) {
					printJsonObject((JSONObject) keyvalue, obj);
				}
				if (keyvalue instanceof JSONArray) {
					printJsonArray((JSONArray) keyvalue, obj);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return obj.toString();
	}

	public String printJsonArray(JSONArray array, JSONObject obj) {
		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				printJsonObject(jsonObject1, obj);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

	public String getDeviceDetails(String deviceDetails) throws JSONException {
		JSONObject addtionalJsonRes = new JSONObject();
		JSONObject ipJsonObject = new JSONObject(deviceDetails);
		JSONObject data = ipJsonObject.getJSONObject(Constants.DATA);
		JSONArray subOrder = data.getJSONArray(Constants.SUBORDER);
		JSONObject deviceId = subOrder.getJSONObject(0).getJSONArray("deviceId").getJSONObject(0);
		addtionalJsonRes.put("deviceId", deviceId.getString("value"));
		JSONArray additionalData = ipJsonObject.getJSONObject(Constants.DATA).getJSONArray(Constants.ADDITIONAL_DATA);
		for (int a = 0; a < additionalData.length(); a++) {
			addtionalJsonRes.put(additionalData.getJSONObject(a).getString(Constants.NAME),
					additionalData.getJSONObject(a).getString(Constants.VALUE));
		}
		return validateDeviceDetails(addtionalJsonRes);
	}

	public String validateDeviceDetails(JSONObject addtionalJsonRes) throws JSONException {
		if (addtionalJsonRes.has("deviceType")) {
			addtionalJsonRes.put("deviceCategory", addtionalJsonRes.getString("deviceType") + " Smartphone");
			addtionalJsonRes.put("mode", addtionalJsonRes.getString("deviceType"));
			// addtionalJsonRes.put("model","SMG");
			if (!addtionalJsonRes.has("make")) {
				addtionalJsonRes.put("make", "SAM");
			}
		}

		return addtionalJsonRes.toString();

	}

	public String verifyLine(String lineId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETLINEIDCOUNT, new Object[] { lineId },
				Integer.class);
		if (count == 0) {
			return "NEW";
		} else {
			return "OLD";
		}
	}

	public String verifyAccount(String accountId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETACCIDCOUNT, new Object[] { accountId },
				Integer.class);
		if (count == 0) {
			return "NEW";
		} else {
			return "OLD";
		}
	}

	public String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		Calendar cal = Calendar.getInstance();
		LOGGER.debug("Current Date: " + sdf.format(cal.getTime()));
		String date = sdf.format(cal.getTime());
		return date;
	}

	public String callResourceService(ResourceUpdateRequest resourceUpdateRequest) {
		LOGGER.info("callResourceService in SW INBOUND:::" + resourceUpdateRequest.toString());
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		try {
			URL serviceUrl = new URL(inboundProperties.getResourceServiceURL());
			conn = (HttpURLConnection) serviceUrl.openConnection();
			System.out.println("req:::" + requestGson.toJson(resourceUpdateRequest));
			byte[] requestData = requestGson.toJson(resourceUpdateRequest).getBytes(StandardCharsets.UTF_8);
			// byte[] requestData = request.toString().getBytes(StandardCharsets.UTF_8);
			// conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = Constants.EMPTYSTRING;
			while ((responseString = in.readLine()) != null) {
				outputString = responseString;
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		//LOGGER.info("callResourceService :: outputString :: " + outputString);
		return outputString;
	}

	public ResourceUpdateRequest insertIntoTransactionHistory(String request, String transId, String serviceName) {

		LOGGER.info("request inside insertIntoTransactionHistory::::" + request);
		LOGGER.info(
				"request inside insertIntoTransactionHistory serviceName::::" + serviceName + "transId.... " + transId);
		JSONObject mdnDetailobj = new JSONObject();
		JSONObject subOrderObj = new JSONObject();
		JSONObject addAttrObj = null;
		String mdnAttrType = "";
		String mdnAttrValue = "";
		String channelId = "";
		String agentId = "";
		String accountNumber = "";
		String lineId = "";
		String mdn = "";
		String deviceId = "";
		String simId = "";
		String phoneNumber = "";
		String firstName = "";
		String lastName = "";
		String emailId = "";
		String addressLine1 = "";
		String addressLine2 = "";
		String city = "";
		String state = "";
		String zip = "";
		String referenceNumber = "";
		String deviceValue = "";
		String deviceType = "";
		String mdnValue = "";
		String mdnType = "";
		String simValue = "";
		String simType = "";
		String transactionType = "";
		String notificationStatus = "PENDING";
		String transactionStatus = "IN PROGRESS";
		String orderType = "";	
		String min = "";
		String imsi = "";
		try {
			LOGGER.info("serviceName::insertIntoTransactionHistory::" + serviceName);
			if (request.contains("referenceNumber")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.MESSAGEHEADER)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.MESSAGEHEADER);
					if (requestJsonObjectData.has("referenceNumber")) {
						referenceNumber = requestJsonObjectData.getString("referenceNumber");
						LOGGER.info("Inside insertIntoTransactionHistory method::referenceNumber:::" + referenceNumber);
					}
				}
			}
			if (request.contains("requestNo")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.UNSOLICITEDPORTOUT)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.UNSOLICITEDPORTOUT);
					if (requestJsonObjectData.has("mdnDetail")) {
						JSONObject mdnDetailObject = requestJsonObjectData.getJSONObject(Constants.MDNDETAILS);
						mdnValue = mdnDetailObject.getString("mdn");
						LOGGER.info("Inside insertIntoTransactionHistory method:: mdn" + mdnValue);
					}
				}
			}
			if (request.contains("mdn")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DEVICEDETECTION)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DEVICEDETECTION);
					if (requestJsonObjectData.has("mdn")) {
						mdnValue = requestJsonObjectData.getString("mdn");
						simValue = requestJsonObjectData.getString("iccid");
						deviceValue = requestJsonObjectData.getString("deviceId");
						LOGGER.info("Inside insertIntoTransactionHistory method::referenceNumber:::" + referenceNumber
								+ "mdn" + mdnValue + "simId::" + simValue + "deviceId::" + deviceValue);
					}
				}
			}
			if (request.contains("mdn")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DPFONOTIFICATION)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DPFONOTIFICATION);
					if (requestJsonObjectData.has("mdn")) {
						mdnValue = requestJsonObjectData.getString("mdn");
						LOGGER.info("Inside insertIntoTransactionHistory method:: mdn" + mdnValue);
					}
				}
			}
			if (request.contains("transactionType")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if (requestJsonObjectData.has("transactionType")) {
						transactionType = requestJsonObjectData.getString("transactionType");
						LOGGER.info("Inside insertIntoTransactionHistory method::transactionType::" + transactionType);
					}
				}
			}
			if (request.contains("channel")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if (requestJsonObjectData.has("channel")) {
						channelId = requestJsonObjectData.getString("channel");
						LOGGER.info("Inside insertIntoTransactionHistory method::channel:::" + channelId);
					}
				}
			}
			if (request.contains("agentDetails")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if (requestJsonObjectData.has("agentDetails")) {
						LOGGER.info(
								"Inside insertIntoTransactionHistory method::agentDetails:::" + requestJsonObjectData);
						requestJsonObjectData = requestJsonObjectData.getJSONObject("agentDetails");
						agentId = requestJsonObjectData.getString("agentId");
						phoneNumber = requestJsonObjectData.getString("phoneNumber");
						firstName = requestJsonObjectData.getString("firstName");
						lastName = requestJsonObjectData.getString("lastName");
						emailId = requestJsonObjectData.getString("emailId");
						addressLine1 = requestJsonObjectData.getString("addressLine1");
						addressLine2 = requestJsonObjectData.getString("addressLine2");
						city = requestJsonObjectData.getString("city");
						state = requestJsonObjectData.getString("state");
						zip = requestJsonObjectData.getString("zip");
					}
				}
			}
			if (request.contains("account")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if (requestJsonObjectData.has("account")) {
						requestJsonObjectData = requestJsonObjectData.getJSONObject("account");
						if (requestJsonObjectData.has("accountNumber")) {
							accountNumber = requestJsonObjectData.getString("accountNumber");
							LOGGER.info("Insert::accountNumber:::" + accountNumber);
						}
					}
				}
			}
			addAttrObj = new JSONObject(request);
			if (addAttrObj.has("data")) {
				addAttrObj = addAttrObj.getJSONObject("data");
				if (addAttrObj.has("subOrder")) {
					String subOrder = addAttrObj.getString("subOrder");
					JSONArray subArray = new JSONArray(subOrder);
					JSONObject subJson = new JSONObject();
					subJson = subArray.getJSONObject(0);
					if(subJson.has("hostMDN")) {
						String mdn1 = subJson.getString("hostMDN");
						JSONArray submdn = new JSONArray(mdn1);
						JSONObject mdnJson = new JSONObject();
						for (int i = 0; i < submdn.length(); i++) {
							mdnJson = submdn.getJSONObject(i);
							if (mdnJson.has("type")) {
								mdnType = mdnJson.getString("type");
							}
							if (mdnJson.has("value")) {
								mdnValue = mdnJson.getString("value");
							}
						}
					}
					if (subJson.has("mdn")) {
						String mdn1 = subJson.getString("mdn");
						JSONArray submdn = new JSONArray(mdn1);
						JSONObject mdnJson = new JSONObject();
						for (int i = 0; i < submdn.length(); i++) {
							mdnJson = submdn.getJSONObject(i);
							if (mdnJson.has("type")) {
								mdnType = mdnJson.getString("type");
							}
							if (transactionType.equalsIgnoreCase("CM")) {
								if (mdnType.equalsIgnoreCase("oldMDN")) {
									if (mdnJson.has("value")) {
										mdnValue = mdnJson.getString("value");
									}
								}
							} else if (transactionType.equalsIgnoreCase("CP") || transactionType.equalsIgnoreCase("RS")
									|| transactionType.equalsIgnoreCase("RM")) {
								if (mdnType.equalsIgnoreCase("newMDN")) {
									if (mdnJson.has("value")) {
										mdnValue = mdnJson.getString("value");
									}
								}
							} else {
								if (mdnType.equalsIgnoreCase("mdn")) {
									if (mdnJson.has("value")) {
										mdnValue = mdnJson.getString("value");
									}
								}
							}
						}
					} else {
						LOGGER.info("Insert::mdnDetail:::" + transactionType);
						if (subJson.has("mdnDetail")) {
							mdnDetailobj = subJson.getJSONObject("mdnDetail");
							LOGGER.info("Insert::mdnDetailobj:::" + mdnDetailobj);
							if (mdnDetailobj.has("mdn")) {
								String mdn1 = mdnDetailobj.getString("mdn");
								JSONArray submdn = new JSONArray(mdn1);
								LOGGER.info("Insert::submdn:::" + submdn);
								JSONObject mdnJson = new JSONObject();
								for (int i = 0; i < submdn.length(); i++) {
									mdnJson = submdn.getJSONObject(i);
									LOGGER.info("Insert::mdnJson:::" + mdnJson);
									if (mdnJson.has("value")) {
										mdnValue = mdnJson.getString("value");
										LOGGER.info("Insert::mdnValue:::" + mdnValue);
									}
								}
							}
						}
					}
					if (subJson.has("deviceId")) {
						String deviceId1 = subJson.getString("deviceId");
						JSONArray subdeviceId1 = new JSONArray(deviceId1);
						JSONObject deviceJson = new JSONObject();
						for (int i = 0; i < subdeviceId1.length(); i++) {
							deviceJson = subdeviceId1.getJSONObject(i);
							if (deviceJson.has("type")) {
								deviceType = deviceJson.getString("type");
							}
							if (transactionType.equalsIgnoreCase("RM")) {
								if (deviceType.equalsIgnoreCase("IMEI")) {
									if (deviceJson.has("value")) {
										deviceValue = deviceJson.getString("value");
									}
								}
							} else if (transactionType.equalsIgnoreCase("OD")
									|| transactionType.equalsIgnoreCase("DS")) {
								if (deviceType.equalsIgnoreCase("newIMEI")) {
									if (deviceJson.has("value")) {
										deviceValue = deviceJson.getString("value");
									}
								}
							} else {
								if (deviceType.equalsIgnoreCase("IMEI")) {
									if (deviceJson.has("value")) {
										deviceValue = deviceJson.getString("value");
									}
								}
							}
						}
						LOGGER.info("::deviceValue:::" + deviceValue);
					}
					if (subJson.has("simId")) {
						String simId1 = subJson.getString("simId");
						JSONArray subsimId1 = new JSONArray(simId1);
						JSONObject simJson = new JSONObject();
						for (int i = 0; i < subsimId1.length(); i++) {
							simJson = subsimId1.getJSONObject(i);
							if (simJson.has("type")) {
								simType = simJson.getString("type");
							}
							if (transactionType.equalsIgnoreCase("RM")) {
								if (simType.equalsIgnoreCase("oldICCID")) {
									if (simJson.has("value")) {
										simValue = simJson.getString("value");
									}
								}
							} else if (transactionType.equalsIgnoreCase("OS")
									|| transactionType.equalsIgnoreCase("DS")) {
								if (simType.equalsIgnoreCase("ICCID")) {
									if (simJson.has("value")) {
										simValue = simJson.getString("value");
									}
								}
							} else {
								if (simType.equalsIgnoreCase("ICCID")) {
									if (simJson.has("value")) {
										simValue = simJson.getString("value");
									}
								}
							}
						}
						LOGGER.info("::deviceValue:::" + simValue);
					}
					if (subJson.has("lineId")) {
						lineId = subJson.getString("lineId");
						LOGGER.info("::lineId:::" + lineId);
					}
				} else {
					if (transactionType.equals("GD")) {
						if (addAttrObj.has("simId")) {
							String simId1 = addAttrObj.getString("simId");
							JSONArray subsimId1 = new JSONArray(simId1);
							JSONObject simJson = new JSONObject();
							for (int i = 0; i < subsimId1.length(); i++) {
								simJson = subsimId1.getJSONObject(i);
								if (simJson.has("type")) {
									simType = simJson.getString("type");
								}
								if (simType.equalsIgnoreCase("ICCID")) {
									if (simJson.has("value")) {
										simValue = simJson.getString("value");
									}
								}
							}
							LOGGER.info("::simId Value:::" + simValue);
						}
						if (addAttrObj.has("deviceId")) {
							String deviceId1 = addAttrObj.getString("deviceId");
							JSONArray subdeviceId1 = new JSONArray(deviceId1);
							JSONObject deviceJson = new JSONObject();
							for (int i = 0; i < subdeviceId1.length(); i++) {
								deviceJson = subdeviceId1.getJSONObject(i);
								if (deviceJson.has("type")) {
									deviceType = deviceJson.getString("type");
								}
								if (deviceType.equalsIgnoreCase("IMEI")) {
									if (deviceJson.has("value")) {
										deviceValue = deviceJson.getString("value");
									}
								}
							}
							LOGGER.info("::device Value:::" + deviceValue);
						}
					}
				}
			}

			Integer typeId = 5;
			ReferenceValue referenceValue = new ReferenceValue();
			referenceValue.setTypeId(typeId);
			if(transactionType != null && !serviceName.equalsIgnoreCase("DPFO Notification") ) {
				LOGGER.info("transactionType::" + transactionType);
				JSONObject refernceValueObject = new JSONObject();
				referenceValue.setValue(transactionType);
				LOGGER.info("referenceValue::::" + referenceValue.toString());
				String referenceValue1 = callReferenceValueResourceService(referenceValue);
				LOGGER.info("referenceValue to set in TransactionHistory" +referenceValue1);
				if(referenceValue1!=null&& (!referenceValue1.isEmpty())) {
					refernceValueObject = new JSONObject(referenceValue1);
					if (refernceValueObject != null) {
						orderType = refernceValueObject.getString("valueDesc");
					}
				}
				
				LOGGER.info("orderType:::" + orderType);
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Calendar cal = Calendar.getInstance();
			LOGGER.debug("Current Date: " + sdf.format(cal.getTime()));
			String date = sdf.format(cal.getTime());
			TransactionHistory transactionHistory = new TransactionHistory();
			
			transactionHistory.setTransactionId(transId);
			transactionHistory.seteLineId(lineId);
			transactionHistory.setAccountNumber(accountNumber);
			transactionHistory.setMdn(mdnValue);
			transactionHistory.setImei(deviceValue);
			transactionHistory.setIccid(simValue);
			transactionHistory.setMin(min);
			transactionHistory.setImsi(imsi);
			transactionHistory.setAgentId(agentId);
			transactionHistory.setAgentFirstName(firstName);
			transactionHistory.setAgentLastName(lastName);
			transactionHistory.setAgentEmailId(emailId);
			transactionHistory.setAgentAddressLine1(addressLine1);
			transactionHistory.setAgentAddressLine2(addressLine2);
			transactionHistory.setAgentCity(city);
			transactionHistory.setAgentState(state);
			transactionHistory.setAgentZipCode(zip);
			transactionHistory.setChannel(channelId);
			transactionHistory.setAgentPhoneNumber(phoneNumber);
			transactionHistory.setReferenceNumber(referenceNumber);
			transactionHistory.setTransactionStartDate(getTimeStamp());
			// transactionHistory.setTransactionEndDate(date);
			transactionHistory.setTransactionStatus(transactionStatus);
			transactionHistory.setNotificationStatus(notificationStatus);
			transactionHistory.setTransactionType(transactionType);
			transactionHistory.setOrderType(orderType);
			transactionHistory.setCreatedDate(getTimeStamp());
			transactionHistory.setCreatedBy(Constants.TRANSACTION_HISTORY_CREATED_BY);
			// transactionHistory.setModifiedDate(date);
			// transactionHistory.setModifiedBy(Constants.TRANSACTION_HISTORY_MODIFIED_BY);
			resourceUpdateRequest.setTransactionHistory(transactionHistory);
			System.out.println("transactionHistory..toString()." + transactionHistory.toString());
		} catch (Exception e) {
			LOGGER.error("Exception in insertIntoTransactionHistory method" + e.getMessage());
		}
		return resourceUpdateRequest;
	}

	public String callReferenceValueResourceService(ReferenceValue referenceValue) {
		LOGGER.info("callReferenceValueResourceService in INBOUND:::" + referenceValue.getValue());
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		try {
			URL serviceUrl = new URL(inboundProperties.getReferenceValueUrl());
			conn = (HttpURLConnection) serviceUrl.openConnection();
			System.out.println("req:::"+requestGson.toJson(referenceValue));
			byte[] requestData = requestGson.toJson(referenceValue).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = responseString;
				//referenceValue = requestGson.fromJson(outputString, ReferenceValue.class);
				//LOGGER.info("Request Bean in referenceValue::::" + referenceValue.toString());
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		LOGGER.info("callReferenceValueResourceService :: referenceValue :: " + outputString);
		return outputString;
	}
	public void insertTransactionHistory(String transactionId,String serviceName,String requestJson) {
		LOGGER.info("Inside insertTransactionHistory transactionId ::: " +transactionId);
		LOGGER.info("Inside insertTransactionHistory serviceName ::: " +serviceName);
		LOGGER.info("Inside insertTransactionHistory requestJson ::: " +requestJson);
		Map<String, Object> inboundReq=new HashMap<String, Object>();
		String transName="";
		String inboundRequest ="";
		ResourceUpdateRequest resourceUpdateRequest=new ResourceUpdateRequest();
		TransactionHistory transactionHistory=new TransactionHistory();
		try {
			inboundReq = centuryCIFTemplate.queryForMap(Constants.GETIBREQUEST, new Object[] { transactionId });
			inboundRequest=inboundReq.get(Constants.REQ_MSG).toString();
			transName=inboundReq.get(Constants.TRANS_NAME).toString();
			LOGGER.info("inboundRequest:::" + inboundRequest);
			LOGGER.info("transName:::" + transName);
			
			resourceUpdateRequest.setTransactionName(transName);
			resourceUpdateRequest.setTransationId(transactionId);
			LOGGER.info("Transaction History::");
			resourceUpdateRequest = insertIntoTransactionHistory(inboundRequest, resourceUpdateRequest.getTransationId(),resourceUpdateRequest.getTransactionName());
			LOGGER.info("Calling callResourceService after transactionHistory......"+resourceUpdateRequest.toString());
			transactionHistory = resourceUpdateRequest.getTransactionHistory();
			LOGGER.info("transactionHistory :::::" + transactionHistory.toString());
			callTransactionHistoryResourceService(transactionHistory);
					
			
		}catch (Exception e) {
			LOGGER.error("Exception", e);
		}
		
	}
	
public String callTransactionHistoryResourceService(TransactionHistory transactionHistory) {
		LOGGER.info("callTransactionHistoryResourceService in INBOUND:::" + transactionHistory.toString());
			String outputString = Constants.EMPTYSTRING;
			HttpURLConnection conn = null;
			Gson requestGson = new Gson();
			try {
				URL serviceUrl = new URL(inboundProperties.getSaveTransactionHistoryUrl());
				conn = (HttpURLConnection) serviceUrl.openConnection();
				System.out.println("req:::"+requestGson.toJson(transactionHistory));
				byte[] requestData = requestGson.toJson(transactionHistory).getBytes(StandardCharsets.UTF_8);
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("charset", "utf-8");
				conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setInstanceFollowRedirects(false);
				conn.setRequestMethod("POST");
				conn.setUseCaches(false);
				OutputStream os = conn.getOutputStream();
				os.write(requestData);
				InputStreamReader isr = new InputStreamReader(conn.getInputStream());
				BufferedReader in = new BufferedReader(isr);
				String responseString = null;
				while ((responseString = in.readLine()) != null) {
					outputString = responseString;
				}
				isr.close();
				os.close();
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			} finally {
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
			}
			LOGGER.info("callResourceService :: outputString :: " + outputString);
			return outputString;
		}
public String updateTransactionHistoryForNSUrl(TransactionHistory transactionHistory) {
		
		LOGGER.info("updateTransactionHistoryForNSUrl :: "+transactionHistory);
				String outputString = Constants.EMPTYSTRING;
				HttpURLConnection conn = null;
				Gson requestGson = new Gson();
				try {
					URL serviceUrl = new URL(inboundProperties.getUpdateTransactionHistoryForNSUrl());
					conn = (HttpURLConnection) serviceUrl.openConnection();
					System.out.println("req:::"+requestGson.toJson(transactionHistory));
					byte[] requestData = requestGson.toJson(transactionHistory).getBytes(StandardCharsets.UTF_8);
					conn.setRequestProperty("Content-Type", "application/json");
					conn.setRequestProperty("charset", "utf-8");
					conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
					conn.setDoOutput(true);
					conn.setDoInput(true);
					conn.setInstanceFollowRedirects(false);
					conn.setRequestMethod("POST");
					conn.setUseCaches(false);
					OutputStream os = conn.getOutputStream();
					os.write(requestData);
					InputStreamReader isr = new InputStreamReader(conn.getInputStream());
					BufferedReader in = new BufferedReader(isr);
					String responseString = null;
					while ((responseString = in.readLine()) != null) {
						outputString = outputString + responseString;
					}
					isr.close();
					os.close();
				} catch (Exception e) {
					LOGGER.error(e.getMessage(), e);
				} finally {
					if (conn != null) {
						conn.disconnect();
						conn = null;
					}
				}
				LOGGER.info("updateTransactionHistoryUrl :: outputString :: " + outputString);
				return outputString;
			}

	public String updateTransactionHistory(TransactionHistory transactionHistory) {
	
	LOGGER.info("updateTransactionHistory :: "+transactionHistory);
			String outputString = Constants.EMPTYSTRING;
			HttpURLConnection conn = null;
			Gson requestGson = new Gson();
			try {
				URL serviceUrl = new URL(inboundProperties.getUpdateTransactionHistoryUrl());
				conn = (HttpURLConnection) serviceUrl.openConnection();
				System.out.println("req:::"+requestGson.toJson(transactionHistory));
				byte[] requestData = requestGson.toJson(transactionHistory).getBytes(StandardCharsets.UTF_8);
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("charset", "utf-8");
				conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setInstanceFollowRedirects(false);
				conn.setRequestMethod("POST");
				conn.setUseCaches(false);
				OutputStream os = conn.getOutputStream();
				os.write(requestData);
				InputStreamReader isr = new InputStreamReader(conn.getInputStream());
				BufferedReader in = new BufferedReader(isr);
				String responseString = null;
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;
				}
				isr.close();
				os.close();
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			} finally {
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
			}
			LOGGER.info("updateTransactionHistoryUrl :: outputString :: " + outputString);
			return outputString;
		}
	
	private ResourceUpdateRequest changeWearbaleRecords(RequestBean ibRequestBean,LineHistory lineHistory,
			ResourceUpdateRequest resourceUpdateRequest,Sim sim, Line line, ReferenceValue referenceValue, LinePlan linePlan, Device device,RequestBean obRequestBean) {
		LOGGER.info("Inside changeWearbaleRecords:::::");
		try {
			/* sim details */
			sim.setSimType(Constants.ESIM);
			sim.setModifiedBy(Constants.MODITY_BY);
			sim.setModifiedDate(getTimeStamp());
			
			
			/* Line History details */
			lineHistory.setOrdType(Constants.ORDER_TYPE_CW);
			lineHistory.setTransactionType(Constants.TRANSACTION_TYPE_CW);
			lineHistory.setCreatedDate(getTimeStamp());
			lineHistory.setModifiedDate(getTimeStamp());
			lineHistory.setModifiedBy(Constants.MODITY_BY);
			lineHistory.setCreatedBy(Constants.CREATED_BY);
			lineHistory.setAcctStatus(Constants.ACCOUNT_STATUS);
			lineHistory.setLineStatus(Constants.LINETYPE_SMARTWATCH);
			lineHistory.setStartDate(getTimeStamp());
			lineHistory.setNewValue(sim.getIccid());
			
			lineHistory.setFieldType(Constants.ICCID);
			
			//device
			device.setIsByod(Constants.YES);
			
			resourceUpdateRequest.setDeviceDetails(device);
			resourceUpdateRequest.setSimDetails(sim);;
			resourceUpdateRequest.setLineHistory(lineHistory);
			resourceUpdateRequest.setLineDetails(line);
			resourceUpdateRequest.setReferenceValue(referenceValue);
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return resourceUpdateRequest;
	}
	
	
	
	
public Sim getsimdetailsbyiccid(Sim sim) {
		
		LOGGER.info("getSimdetailsbyiccidurl :: "+sim);
				String outputString = Constants.EMPTYSTRING;
				HttpURLConnection conn = null;
				Gson requestGson = new Gson();
				try {
					URL serviceUrl = new URL(inboundProperties.getSimdetailsbyiccidurl()+"?iccid="+sim.getIccid());
					conn = (HttpURLConnection) serviceUrl.openConnection();
					System.out.println("req:::"+requestGson.toJson(sim));
					byte[] requestData = requestGson.toJson(sim).getBytes(StandardCharsets.UTF_8);
					conn.setRequestProperty("Content-Type", "application/json");
					conn.setRequestProperty("charset", "utf-8");
					conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
					conn.setDoOutput(true);
					conn.setDoInput(true);
					conn.setInstanceFollowRedirects(false);
					conn.setRequestMethod("POST");
					conn.setUseCaches(false);
					OutputStream os = conn.getOutputStream();
					os.write(requestData);
					InputStreamReader isr = new InputStreamReader(conn.getInputStream());
					BufferedReader in = new BufferedReader(isr);
					String responseString = null;
					while ((responseString = in.readLine()) != null) {
						outputString = outputString + responseString;
						sim = requestGson.fromJson(outputString, Sim.class);
					}
					isr.close();
					os.close();
				} catch (Exception e) {
					LOGGER.error(e.getMessage(), e);
				} finally {
					if (conn != null) {
						conn.disconnect();
						conn = null;
					}
				}
				LOGGER.info("getSimdetailsbyiccidurl :: outputString :: " + outputString);
				return sim;
			}




public Line getLineAccountNumber(Line line) {
	
	LOGGER.info("getLineAccountNumber :: "+line);
			String outputString = Constants.EMPTYSTRING;
			HttpURLConnection conn = null;
			Gson requestGson = new Gson();
			try {
				URL serviceUrl = new URL(inboundProperties.getAccounturl()+"?eLineId="+line.geteLineId());
				conn = (HttpURLConnection) serviceUrl.openConnection();
				System.out.println("req:::"+requestGson.toJson(line));
				byte[] requestData = requestGson.toJson(line).getBytes(StandardCharsets.UTF_8);
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("charset", "utf-8");
				conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setInstanceFollowRedirects(false);
				conn.setRequestMethod("POST");
				conn.setUseCaches(false);
				OutputStream os = conn.getOutputStream();
				os.write(requestData);
				InputStreamReader isr = new InputStreamReader(conn.getInputStream());
				BufferedReader in = new BufferedReader(isr);
				String responseString = null;
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;
					line = requestGson.fromJson(outputString, Line.class);
				}
				isr.close();
				os.close();
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			} finally {
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
			}
			LOGGER.info("getLineAccountNumber :: outputString :: " + outputString);
			return line;
		}











	public TransactionHistory getTransactionHistoryDetails(TransactionHistory transactionHistory){
		LOGGER.info("Inside getTransactionHistoryDetails::::" + transactionHistory);
		String outputString = null;
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url="";
		try {
			url=inboundProperties.getTransactionHistoryDetailsUrl()+"?transactionId="+transactionHistory.getTransactionId();
			LOGGER.info("getTransactionHistoryDetails URL::::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData =requestGson.toJson(transactionHistory).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = responseString;
				transactionHistory = requestGson.fromJson(outputString, TransactionHistory.class);
				LOGGER.info("Request Bean in getTransactionHistoryDetails::::" + transactionHistory.toString());
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			//LOGGER.error(e.getMessage(), e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		LOGGER.info("getTransactionHistoryDetails :: outputString :: " + outputString);
		return transactionHistory;
	
	}
	
	
	

	
	
}
