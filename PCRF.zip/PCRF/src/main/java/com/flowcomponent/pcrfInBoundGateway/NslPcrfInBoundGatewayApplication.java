package com.flowcomponent.pcrfInBoundGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableAutoConfiguration
public class NslPcrfInBoundGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(NslPcrfInBoundGatewayApplication.class, args);
	}

}
