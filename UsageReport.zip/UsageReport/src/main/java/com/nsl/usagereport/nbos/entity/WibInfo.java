package com.nsl.usagereport.nbos.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "WIB_INFO")
@Table(name = "WIB_INFO")
public class WibInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "WIB_INFO_ID")
	private Long wibInfoId;

	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;
	
	@Column(name = "MAC_ADDRESS")
	private String macAddress;
	
	@Column(name = "ROUTER_ID")
	private String routerId;
	
	@Column(name = "SIM_SLOT1_DEVICE_ID")
	private String errorMsg;
	
	@Column(name = "SIM_SLOT2_DEVICE_ID")
	private String errorCode;
	
	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "WIB_STATUS")
	private String wibStatus = "Unknown";

	@Column(name = "ETHERNET_STATUS")
	private String ethernetStatus = "Unknown";

	@Column(name = "MODEM_STATUS")
	private String modemStatus = "Unknown";

	@Column(name = "IS_INITIALISED")
	private String isInitialised = "NO";

	@Override
	public String toString() {
		return " [serialNumber=" + serialNumber + ", macAddress=" + macAddress + ", routerId=" + routerId + "]";
	}
}
