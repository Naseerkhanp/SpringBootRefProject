package com.excelacom.servicegateway.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.*;
import org.json.JSONException;
import org.json.JSONObject;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;


import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


@Component
public class ExternalServiceClient {

	@Autowired
	TransactionDAO transactionDAO;
	
	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;
	
	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	private UtilityClass utilityClass;
	
	Logger LOGGER = LoggerFactory.getLogger(ExternalServiceClient.class);

	/**
	 * Gets the response from client.
	 *
	 * @param requestJson the request json
	 * @param transId the trans id
	 * @param responseId the response id
	 * @return the response from client
	 */
	
	public String getResponseFromClient(String request, String transId, String responseId, String httpMethod,String entityId) {
		LOGGER.info("getResponseFromClient::::::::::::" + request);
		HttpURLConnection conn = null;
		String serviceName = null;
		String groupId =null;
		String processPlanId = null;

		 try
		 {
			String url = inboundProperties.getRouterserviceurl();
			LOGGER.info("Request JSON ::::" + request);
		//	LOGGER.info("Request JSON1 ::::" + request.split("&")[0]);
			/* request = requesturl1(request.split("&")[0]); */
			LOGGER.info("HTTP METHOD ::::" + httpMethod);
			  if("POST".equalsIgnoreCase(httpMethod) || "PUT".equalsIgnoreCase(httpMethod) || "PATCH".equalsIgnoreCase(httpMethod))
			  { 
				  LOGGER.info("INSIDE REQURL METHOD ::::" + httpMethod + "REQUEST" + request);
				  request = requesturl1(request,httpMethod); 
				  LOGGER.info("REQ METHOD ::::" + request);  
			  }
			 
			LOGGER.info("Reqqqqq::::"+request);
			String frameworkResponse = utilityClass.callRestAPI(request, url);
			LOGGER.info(" frameworkResponse :: " + frameworkResponse);
			String Id = frameworkResponse.substring(frameworkResponse.indexOf("~") + 1);
			 groupId = Id.substring(Id.indexOf("~") + 1);
			serviceName = groupId.substring(groupId.indexOf("~") + 1);
			groupId = groupId.substring(0, groupId.indexOf("~"));
			 processPlanId = Id.substring(0, Id.indexOf("~"));
			frameworkResponse = frameworkResponse.substring(0, frameworkResponse.indexOf("~"));
			
			
			LOGGER.info("HTTP GET and POST METHOD ::::" + httpMethod);
			if("POST".equalsIgnoreCase(httpMethod) || "PUT".equalsIgnoreCase(httpMethod) || "PATCH".equalsIgnoreCase(httpMethod)) {
				frameworkResponse=this.messageOrdering(frameworkResponse,responseId);
			}
			else if ("GET".equalsIgnoreCase(httpMethod) && (serviceName.equalsIgnoreCase("NCMSpeedTestIntegeration"))) {
				frameworkResponse=this.messageOrdering(frameworkResponse,responseId);
				JsonObject jsonRes = new JsonParser().parse(frameworkResponse).getAsJsonObject();
				if (jsonRes.has("messageHeader")) {	
					jsonRes.remove("messageHeader");
				}
				frameworkResponse = jsonRes.toString();
			}
			else if ("DELETE".equalsIgnoreCase(httpMethod)) {
				JsonObject jsonRes = new JsonParser().parse(frameworkResponse).getAsJsonObject();
				if (jsonRes.has("messageHeader")) {	
					jsonRes.remove("messageHeader");
				}
				frameworkResponse=this.messageOrdering(jsonRes.toString(),responseId);
			}
			else if ("GET".equalsIgnoreCase(httpMethod)) {
				JsonObject jsonRes = new JsonParser().parse(frameworkResponse).getAsJsonObject();
				if (jsonRes.has("messageHeader")) {	
					jsonRes.remove("messageHeader");
				}
				frameworkResponse = jsonRes.toString();
			}
			
			JSONObject jsonObjRes = new JSONObject(frameworkResponse);
			JSONObject obj = new JSONObject();
			if (jsonObjRes.has("data")) {
				obj = jsonObjRes.getJSONObject("data");
				if (obj.has("transactionId")) {
					String resTransId = obj.getString("transactionId");
			
					if (frameworkResponse.contains("\"transactionId\":\"" + resTransId + "\"")) {
						System.out.println("Inside transactionId");
						frameworkResponse = frameworkResponse.replace("\"transactionId\":\"" + resTransId + "\"",
								"\"transactionId\":\"" + responseId + "\"");
					}
				}
				else {
					frameworkResponse=addTransid(frameworkResponse,responseId);
				}
			}
			if (!frameworkResponse.contains("\"message\":\"\"") && !(frameworkResponse.contains("\"message\":[{\"responseCode\""))) {
				System.out.println("responseCode conversion to ERR");
				String array = "";
				LOGGER.info("INSIDE ARRAY" +array);
				JsonObject jsonRes = new JsonParser().parse(frameworkResponse).getAsJsonObject();
				JsonObject dataObj = jsonRes.get("data").getAsJsonObject();
				LOGGER.info("INSIDE OBJ:::" +dataObj);
				array = dataObj.get("message").toString();
				LOGGER.info("INSIDE ARRAY2:::" +array);
				frameworkResponse = frameworkResponse.replace("\"message\":"+array+"", "\"message\":[{\"responseCode\":\"ERR20\",\"description\":"+array+"}]");
			}
			if (frameworkResponse.contains("\"code\":\"204\"") || frameworkResponse.contains("\"code\":\"200\"") || frameworkResponse.contains("\"code\":\"201\"") || frameworkResponse.contains("\"code\":\"202\"")||frameworkResponse.contains("\"code\":200") || frameworkResponse.contains("\"code\":201") || frameworkResponse.contains("\"code\":202")) {
				System.out.println("responseCode conversion to SUC00");
				frameworkResponse = frameworkResponse.replace("\"message\":\"\"", "\"message\":[{\"responseCode\":\"SUC00\",\"description\":\"Success\"}]");
			}
			if("GET".equalsIgnoreCase(httpMethod)){
				frameworkResponse  = metaConversion(frameworkResponse);
				LOGGER.info(" INSIDE METARESPONSE :: " + frameworkResponse);
				}
			if ("GET".equalsIgnoreCase(httpMethod) && (serviceName.equalsIgnoreCase("NCMGetActivityLogIntegration"))) {
				LOGGER.info("INSIDE GET METHOD3 ::::" + httpMethod);
				frameworkResponse=this.messageOrderingActivityLogs(frameworkResponse);
				LOGGER.info("INSIDE GET METHOD33 ::::" + frameworkResponse);
			}
				/*if ("PATCH".equalsIgnoreCase(httpMethod) || "POST".equalsIgnoreCase(httpMethod) || "PUT".equalsIgnoreCase(httpMethod)) {
					frameworkResponse = resourceurlConversionPatch(frameworkResponse);
					 LOGGER.info("INSIDE FRAMEWORKRES PATCH:::" + frameworkResponse);
				}*/
			this.asyncUpdateNorthBoundTransactionNcm(transId, entityId, frameworkResponse, groupId, processPlanId,
					serviceName, Constants.SUCCESS.toUpperCase(),responseId);
			return frameworkResponse;
		 } catch (Exception e) {
				asyncUpdateTransactionFailure(transId, entityId, groupId, processPlanId, serviceName,responseId);
				LOGGER.error("Exception in ncmCreateSubAccountSystemCall" + e.getMessage());
			}
			return null;
		}
	
	private void asyncUpdateNorthBoundTransactionNcm(String transId, String entityId, String respJson, String grpId, String processId, String servName, String status,String responseId) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
		@Override
		public void run() {
			transactionDAO.updateNorthBoundTransactionNcm(transId, entityId, respJson, grpId, processId, servName, status,responseId);
		}
	});
	}
	
	public String asyncUpdateTransactionFailure(final String transId, final String entityId, final String groupId,
			final String processPlanId, final String serviceName,String responseId) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransactionFailure(transId, entityId, groupId, processPlanId,serviceName,responseId);
			}
		});

		executor.shutdown();
		return "success";
	}
	/*public String resourceurlConversion(String request) throws JSONException {

        Map<String, String> pathParamMap = new HashMap<>();
        LOGGER.info("Enter::::::::::");
        //request = "{'messageHeader':{'serviceId':'SMB','requestType':'DEVICE','referenceNumber':'0508'},'data':{'transactionId':'41515066','statusCode':201,'status':'Created','createSpeedTestResponse':{'account':'https://www.cradlepointecm.com/api/v2/accounts/64815/','createdAt':'2020-11-23T06:54:05.838210+00:00','id':'7152146','progress':'null','resourceUri':'https://www.cradlepointecm.com/api/v2/speed_test/7152146/','results':'null','state':'created','updatedAt':'2020-11-23T06:54:05.838230+00:00','config':{'host':'192.168.0.1','maxTestConcurrency':1,'netDeviceIds':[53966937,53966938],'port':12765,'size':'null','testTimeOut':1,'testType':'TCP Download','time':1}}}}";
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject(request);
        Iterator<String> objItr = obj.keys();
        while (objItr.hasNext()) {
               String key = objItr.next();
               if ("data".equalsIgnoreCase(key)) {
                     JSONObject dataObj = obj.getJSONObject(key);
                     Iterator<String> datakey = dataObj.keys();

                     while (datakey.hasNext()) {
                            String key1 = datakey.next();
                            if (key1.contains("Response")) {
                                   //System.out.println("Request11111" + key1);

                                   if ("resource_url".equalsIgnoreCase(key1) || "configuration_manager".equalsIgnoreCase(key1)
                                                 || "default_configuration".equalsIgnoreCase(key1)) {
                                          dataObj.put(key1, dataObj.getString("id"));
                                   } else if ("account".equalsIgnoreCase(key1) || "product".equalsIgnoreCase(key1)
                                                 || "target_firmware".equalsIgnoreCase(key1)
                                                 || "last_known_location".equalsIgnoreCase(key1) || "app_version".equalsIgnoreCase(key1)
                                                 || "actual_firmware".equalsIgnoreCase(key1) || "net_device".equalsIgnoreCase(key1)
                                                 || "group".equalsIgnoreCase(key1) || "router".equalsIgnoreCase(key1)
                                                 || "resource_uri".equalsIgnoreCase(key1) || "app".equalsIgnoreCase(key1)) {
                                          //System.out.println("Request11333333111" + key1);
                                          String val = obj.getString(key1);
                                          String[] ar = val.split("/");
                                          int arraylength = ar.length;
                                          String LastVal = ar[arraylength - 1];
                                          dataObj.put(key1, LastVal);
                                   }

                            } else if ("meta".equalsIgnoreCase(key)) {

                     String val = obj.getString(key);
                     JSONObject obj2 = obj.getJSONObject(key);
                     Iterator<String> objItr11 = obj2.keys();
                     while (objItr11.hasNext()) {
                            JSONObject json = new JSONObject();
                            String key12 = objItr11.next();
                            json.put("name", key12);
                            json.put("value", obj2.get(key12));
                            array.put(json);
                     }
                     obj.remove("meta");
                     obj.put("additionalData", array);
               }
                     }
               } 
        }
        LOGGER.info("obj::::::" + obj.toString());
        return obj.toString();
 }*/

	public String resourceurlConversionPatch(String request) throws JSONException {
		Map<String, String> pathParamMap = new HashMap<>();
		JSONArray array = new JSONArray();
		JSONObject obj = new JSONObject(request);
		JSONObject obj1 = new JSONObject(request);
		Iterator<String> objItr = obj.keys();
		while (objItr.hasNext()) {
			String key = objItr.next();
			if ("data".equalsIgnoreCase(key)) {
				JSONObject dataObj1 = obj1.getJSONObject(key);
				JSONObject dataObj = obj.getJSONObject(key);
				Iterator<String> datakey = dataObj.keys();
				while (datakey.hasNext()) {
					String key11 = datakey.next();
					if (key11.contains("Response")) {
						JSONObject dataObj11 = dataObj1.getJSONObject(key11);
						JSONObject dataObj112 = dataObj1.getJSONObject(key11);
						Iterator<String> datakey1 = dataObj11.keys();
						while (datakey1.hasNext()) {
							String key1 = datakey1.next();
							if ("configuration_manager".equalsIgnoreCase(key1)
                                    || "default_configuration".equalsIgnoreCase(key1)) {
								dataObj112.put(key1, dataObj11.getString("id"));
		                       } else if ("account".equalsIgnoreCase(key1) || "product".equalsIgnoreCase(key1)
                                    || "target_firmware".equalsIgnoreCase(key1)
                                    || "last_known_location".equalsIgnoreCase(key1) || "app_version".equalsIgnoreCase(key1)
                                    || "actual_firmware".equalsIgnoreCase(key1) || "net_device".equalsIgnoreCase(key1)
                                    || "group".equalsIgnoreCase(key1) || "router".equalsIgnoreCase(key1)
                                    || "resource_uri".equalsIgnoreCase(key1) || "app".equalsIgnoreCase(key1)|| "parentAccountId".equalsIgnoreCase(key1)) {
								// System.out.println("Request11333333111" + key1);
								String val = dataObj11.getString(key1);
								String[] ar = val.split("/");
								int arraylength = ar.length;
								String LastVal = ar[arraylength - 1];
								dataObj112.put(key1, LastVal);
							}

						}

					} else if ("product".equalsIgnoreCase(key) || "target_firmware".equalsIgnoreCase(key)){
						JSONObject dataObj11 = new JSONObject(); 
						JSONObject dataObj112 = new JSONObject(); 
						String val = dataObj11.getString(key);
						String[] ar = val.split("/");
						int arraylength = ar.length;
						String LastVal = ar[arraylength - 1];
						dataObj112.put(key, LastVal);
					}/*else if ("meta".equalsIgnoreCase(key)) {

				String val = obj.getString(key);
				JSONObject obj2 = obj.getJSONObject(key);
				Iterator<String> objItr11 = obj2.keys();
				while (objItr11.hasNext()) {
					JSONObject json = new JSONObject();
					String key12 = objItr11.next();
					json.put("name", key12);
					json.put("value", obj2.get(key12));
					array.put(json);
				}
				obj.remove("meta");
				obj.put("additionalData", array);
			}*/

				}

			} 

		}
		return obj1.toString();
	}
	
	/*public String metaConversion(String request) throws JSONException {
        Map<String, String> pathParamMap = new HashMap<>();
        LOGGER.info("Enter::::::::::");
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject(request);
        Iterator<String> objItr = obj.keys();
        while (objItr.hasNext()) {
               String key = objItr.next();
               LOGGER.info("KEYS ::::::" + key);
               if ("data".equalsIgnoreCase(key)) {
                     JSONObject dataObj = obj.getJSONObject(key);
                     Iterator<String> datakey = dataObj.keys();
                     while (datakey.hasNext()) {
                            String key1 = datakey.next();
                            LOGGER.info("KEYS11 ::::::" + key1);
                            if ("meta".equalsIgnoreCase(key1)) {
                            LOGGER.info("INSIDE META::" +key1);
                                String val = dataObj.getString(key1);
                                JSONObject obj2 = dataObj.getJSONObject(key1);
                                Iterator<String> objItr11 = obj2.keys();
                                while (objItr11.hasNext()) {
                                       JSONObject json = new JSONObject();
                                       String key12 = objItr11.next();
                                       json.put("name", key12); 
                                       json.put("value", obj2.get(key12));
                                       array.put(json);
                                       
                                }
                          }
                     }
                     dataObj.remove("meta");
                     dataObj.put("additionalData", array);
                     } 
                           * else if ("meta".equalsIgnoreCase(key)) {
                           * 
                            * String val = obj.getString(key); JSONObject obj2 = obj.getJSONObject(key);
                           * Iterator<String> objItr11 = obj2.keys(); while (objItr11.hasNext()) {
                           * JSONObject json = new JSONObject(); String key12 = objItr11.next();
                           * json.put("name", key12); json.put("value", obj2.get(key12)); array.put(json);
                           * } obj.remove("meta"); obj.put("additionalData", array); }
                           *
        }
        LOGGER.info("obj::::::" + obj.toString());
        return obj.toString();
}*/

	public String metaConversion(String request) throws JSONException {
		LOGGER.info("Enter::::::::::");
		JsonArray array = new JsonArray();
		boolean isMeta = false;
		JsonObject reqJson = new JsonParser().parse(request).getAsJsonObject();
		JsonObject dataobj1 = new JsonObject();
		JsonObject dataobj2 = new JsonObject();
		JsonElement message = null;
		boolean isMsgPresent = false;
		for (Map.Entry<String, JsonElement> entry : reqJson.entrySet()) {
			String key = entry.getKey();
			if ("data".equalsIgnoreCase(key)) {
				JsonObject dataObj = reqJson.get(key).getAsJsonObject();
				for (Map.Entry<String, JsonElement> dataentry : dataObj.entrySet()) {
					String key1 = dataentry.getKey();
					if ("meta".equalsIgnoreCase(key1)) {
						JsonObject metaObj = dataObj.get(key1).getAsJsonObject();
						for (Map.Entry<String, JsonElement> metaentry : metaObj.entrySet()) {
							isMeta = true;
							JsonObject json = new JsonObject();
							String key12 = metaentry.getKey();
							json.addProperty("name", key12);
							json.addProperty("value", metaentry.getValue().getAsString());
							array.add(json);
						}
					} else if ("message".equals(key1)) {
						message = dataentry.getValue();
						isMsgPresent = true;
					} else {
						if (!isMsgPresent) {
							dataobj2.add(key1, dataentry.getValue());
						} else {
							dataobj2.add(key1, dataentry.getValue());
							dataobj2.add("message", message);
							isMsgPresent = false;
						}
					}
				}
			}
		}
		if (isMeta) {
			LOGGER.info("KEYS11 inside meta replacement::::::");
			// dataobj2.remove("meta");
			dataobj2.add("additionalData", array);
			dataobj1.add("data", dataobj2);
			return dataobj1.toString();
			// LOGGER.info("KEYS11 inside meta");
		}
		LOGGER.info("obj::::::" + reqJson.toString());
		return reqJson.toString();

	}
	
	public String messageOrdering(String request,String transactionId) throws JSONException {
		LOGGER.info("Enter::::::::::messageOrdering");
		JsonArray array = new JsonArray();
		boolean isMeta = false;
		JsonObject reqJson = new JsonParser().parse(request).getAsJsonObject();
		JsonObject dataobj1 = new JsonObject();
		JsonObject dataobj2 = new JsonObject();
		JsonElement message = null;
		boolean isMsgPresent = false;
		for (Map.Entry<String, JsonElement> entry : reqJson.entrySet()) {
			String key = entry.getKey();
			if ("data".equalsIgnoreCase(key)) {
				dataobj2.addProperty("transactionId",transactionId);
				JsonObject dataObj = reqJson.get(key).getAsJsonObject();
				if (dataObj.has("message")) {
					message = dataObj.get("message");
					isMsgPresent = true;
				}
				for (Map.Entry<String, JsonElement> dataentry : dataObj.entrySet()) {
					String key1 = dataentry.getKey();
					if (!key1.equalsIgnoreCase("message")) {
						if(key1.equalsIgnoreCase("statusCode")) {
							dataobj2.add("code", dataentry.getValue());
						}else {
						dataobj2.add(key1, dataentry.getValue());
						if (key1.equalsIgnoreCase("reason") && isMsgPresent) {
							dataobj2.add("message", message);
						}
					}
					}
				}
			}
		}
		reqJson.remove("data");
		reqJson.add("data", dataobj2);
		LOGGER.info("obj::::::" + reqJson.toString());
		return reqJson.toString();

	}
	
	public String messageOrderingActivityLogs(String request) throws JSONException {
		LOGGER.info("Enter::::::::::messageOrdering");
		JsonArray array = new JsonArray();
		boolean isMeta = false;
		JsonObject reqJson = new JsonParser().parse(request).getAsJsonObject();
		JsonObject dataobj1 = new JsonObject();
		JsonObject dataobj2 = new JsonObject();
		JsonElement message = null;
		JsonElement activity = null;
		boolean isMsgPresent = false;
		for (Map.Entry<String, JsonElement> entry : reqJson.entrySet()) {
			String key = entry.getKey();
			if ("data".equalsIgnoreCase(key)) {
				JsonObject dataObj = reqJson.get(key).getAsJsonObject();
				if (dataObj.has("message")) {
					message = dataObj.get("message");
					isMsgPresent = true;
				}
				if (dataObj.has("getActivityLogsResponse")) {
					activity = dataObj.get("getActivityLogsResponse");
					isMsgPresent = true;
				}
				for (Map.Entry<String, JsonElement> dataentry : dataObj.entrySet()) {
					String key1 = dataentry.getKey();
					if (!key1.equalsIgnoreCase("message") && !key1.equalsIgnoreCase("getActivityLogsResponse")) {
						dataobj2.add(key1, dataentry.getValue());
						if (key1.equalsIgnoreCase("reason") && isMsgPresent) {
							dataobj2.add("message", message);
							dataobj2.add("getActivityLogsResponse", activity);
						}
					}
				}
			}
		}
		reqJson.remove("data");
		reqJson.add("data", dataobj2);
		LOGGER.info("obj::::::" + reqJson.toString());
		return reqJson.toString();

	}
	
	public String requesturl1(String request, String httpMethod) throws JSONException {
		String operationRequest = "";
		request = request.replaceAll("\\s", "");
		//LOGGER.info("INSIDE POST22222" +request);
		if("PATCH".equalsIgnoreCase(httpMethod)) {
			operationRequest = "]&"+request.split("}]&")[1];
			request = request.split("]&")[0];
			//LOGGER.info("PATCH4444"+ operationRequest + "PATCH5555"+ request);
		}else {
			 operationRequest = "&"+request.split("}&")[1];
			 request = request.split("&")[0];
			 //LOGGER.info("PATCH6666"+ operationRequest + "PATCH777"+ request);
		}
		LOGGER.info("REQU ::" + request + "  OPREQ :::: " + operationRequest);
		//LOGGER.info("inside:::::"+request.replace("[" , ""));
		Map<String, String> pathParamMap = new HashMap<>();
		JSONObject obj;
		if("PATCH".equalsIgnoreCase(httpMethod)) {
			request = request.replaceFirst("\\[" , "");
		  //LOGGER.info("inside:::::"+request.split("=")[1]);
		   obj = new JSONObject(request.split("=")[1]);
		  //LOGGER.info("insidepatch:::::"+obj);
		}else {
			 obj = new JSONObject(request.split("=")[1]);
		}
		Iterator<String> objItr = obj.keys();
		while (objItr.hasNext()) {
			String key = objItr.next();
			if ("data".equalsIgnoreCase(key)) {
				LOGGER.info("data1111111"+key);
				JSONObject dataObj = obj.getJSONObject(key);
				Iterator<String> objItr1 = dataObj.keys();
				while (objItr1.hasNext()) {
					String datakey = objItr1.next();

					if (datakey.contains("Request")) {
						LOGGER.info("Request11111"+datakey);
						JSONObject reqObj = dataObj.getJSONObject(datakey);
						Iterator<String> objItrObj = reqObj.keys();
						while (objItrObj.hasNext()) {
							String reqKey = objItrObj.next();
							switch (reqKey) {
							case "account":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String accounturl = inboundProperties.getAccounturl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, accounturl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "product":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String producturl = inboundProperties.getProducturl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, producturl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "targetfirmware":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String targetFirmwareurl = inboundProperties.getTargetFirmwareurl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								
								reqObj.put(reqKey, targetFirmwareurl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "targetFirmware":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String targetFirmwareurl = inboundProperties.getTargetFirmwareurl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, targetFirmwareurl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "router":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String routerurl = inboundProperties.getRouterurl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, routerurl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "appVersion":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String appVersionurl = inboundProperties.getAppVersionurl();
								reqObj.put(reqKey, appVersionurl + reqObj.getString(reqKey) + "/");
								}
								break;
							case "location":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String locationurl = inboundProperties.getLocationurl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, locationurl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							case "group":
								//System.out.println("key11::::;" + obj11.getString(key11));
								if(!(reqObj.getString(reqKey).contains("https://www.cradlepointecm.com/"))) {
								String groupurl = inboundProperties.getGroupurl();
								if(reqObj.getString(reqKey).equals(null)||reqObj.getString(reqKey).equals("null")||reqObj.getString(reqKey).equals(""))
								{
									reqObj.put(reqKey, "");	
								}
								else {
								reqObj.put(reqKey, groupurl + reqObj.getString(reqKey) + "/");
								}
								}
								break;
							}

						}
					}
				}
			} else if ("router".equalsIgnoreCase(key)) {
				//LOGGER.info("key11::::;" + obj.getString(key));
				if (!(obj.getString(key).contains("https://www.cradlepointecm.com/"))) {
					String routerurl = inboundProperties.getRouterurl();
					obj.put(key, routerurl + obj.getString(key) + "/");
					//LOGGER.info("key11222222222::::;" + obj.getString(key));
				}

			}

		}
		LOGGER.info("obj::::::" + obj);
		request = obj.toString();
		if("PATCH".equalsIgnoreCase(httpMethod)) {
		request = "json=[" + request + operationRequest;
		}else {
		request = "json=" + request + operationRequest;
		}
		LOGGER.info("REQUESTVAL ::" + request );
		return request;
	}
	public String addTransid(String request, String responseId) throws JSONException {
        JsonObject reqJson = new JsonParser().parse(request).getAsJsonObject();
        JsonObject  dataobj1=new JsonObject();
        for(Map.Entry<String, JsonElement> entry : reqJson.entrySet()) {
               String key = entry.getKey();
               LOGGER.info("KEYS ::::::" + key);
               if ("data".equalsIgnoreCase(key)) {
                     JsonObject dataObj = reqJson.get(key).getAsJsonObject();
                     for(Map.Entry<String, JsonElement> dataentry : dataObj.entrySet()) {
                            	String key1 = dataentry.getKey();
                            	LOGGER.info("KEYS11 ::::::" + key1);
                            	dataobj1.addProperty("transactionId", responseId);
                            	dataobj1.add( key1, dataentry.getValue());
                            }
                     }
               
        }
       if(reqJson.has("data")) {
    	   reqJson.remove("data");
    	   reqJson.add("data", dataobj1);
       }
        LOGGER.info("obj::::::" + reqJson.toString());
        return reqJson.toString();
}
	
}
