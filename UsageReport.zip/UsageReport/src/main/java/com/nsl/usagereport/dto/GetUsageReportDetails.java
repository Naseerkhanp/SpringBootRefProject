package com.nsl.usagereport.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class GetUsageReportDetails {
	@JsonProperty("mdn")
	public Long  mdn;

	@JsonProperty("imei")
	public String imei;

	@JsonProperty("iccid")
	public String iccid;

	@JsonProperty("startDate")
	public String startDate;
	
	@JsonProperty("endDate")
	public String endDate;

	@JsonProperty("deviceType")
	public String deviceType;
	
	@JsonProperty("imsi")
	public Long imsi;

}
