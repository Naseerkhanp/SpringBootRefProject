package com.nsl.usagereport.exception;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse {

	public ErrorResponse(String message, List<String> details) {
		super();
		this.message = message;
		this.details = details;
	}

	// General error message about nature of error
	@JsonProperty("message")
	private String message;

	// Specific errors in API request processing
	@JsonProperty("details")
	private List<String> details;

}
