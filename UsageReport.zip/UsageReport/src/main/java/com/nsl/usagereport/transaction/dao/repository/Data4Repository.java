package com.nsl.usagereport.transaction.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.Data4;


@Repository("data4")
public interface Data4Repository extends JpaRepository<Data4, Integer> {

}
