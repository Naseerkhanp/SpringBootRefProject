/**
 * 
 */
package com.nsl.managelines.batch.bean.async;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class MdnDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String mdn;

	public String reasonCode;

	public String reasonDetail;
}
