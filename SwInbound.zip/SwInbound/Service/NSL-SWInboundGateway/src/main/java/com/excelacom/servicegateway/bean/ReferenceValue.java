package com.excelacom.servicegateway.bean;


import java.time.ZonedDateTime;
import org.springframework.stereotype.Component;

@Component
public class ReferenceValue {

		private Integer valueId;
		
		private Integer typeId;
		
		private String value;

		private String valueDesc;

		private ZonedDateTime createdDate;

		private String createdBy;

		private ZonedDateTime modifiedDate;

		private String modifiedBy;

		public Integer getValueId() {
			return valueId;
		}

		public void setValueId(Integer valueId) {
			this.valueId = valueId;
		}

		public Integer getTypeId() {
			return typeId;
		}

		public void setTypeId(Integer typeId) {
			this.typeId = typeId;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		public String getValueDesc() {
			return valueDesc;
		}

		public void setValueDesc(String valueDesc) {
			this.valueDesc = valueDesc;
		}

		public ZonedDateTime getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(ZonedDateTime createdDate) {
			this.createdDate = createdDate;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public ZonedDateTime getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(ZonedDateTime modifiedDate) {
			this.modifiedDate = modifiedDate;
		}

		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		
	}