package com.nsl.managelines.batch.constants;

public class Constants {

	public static String TOKEN_CODE = "Basic YnNzdXNlcjE6YnNzcHN3ZDE=";

	public static String NO_INFO_AVAIL_MSG = "No information available";

	public static String NOT_VALID_REQ_MSG = "is not a valid request";

	public static String SCHEDULER = "SCHEDULER";

	public static final String SUCCESS_MSG = "{\"status\":{\"code\":\"200\",\"message\":\"Successfully processed Request.\"}"
			+ "}";

	public static final String INVALID_ERROR = "{\"status\":{\"code\":\"500\",\"reason\":\"INTERNAL_SERVER_ERROR\",\"message\":\"Unable to process the request.\"}"
			+ "}";

	public static final String EMPTYSTRING = "";

	public static final String PENDING = "PENDING";

	public static final String IN_PROGRESS = "IN PROGRESS";

	public static final String COMPLETED = "COMPLETED";

	public static final String FAILED = "FAILED";
	
	public static final String PLAN_MIG_ELIG_OUT_REP = "Plan_Migration_Eligibility_Output_Report";
	
	public static final String PLAN_MIG_OUTPUT_REP = "Plan_Migration_Job_Output_Report";
}
