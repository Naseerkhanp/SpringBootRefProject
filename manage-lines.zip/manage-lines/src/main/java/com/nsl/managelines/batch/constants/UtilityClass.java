package com.nsl.managelines.batch.constants;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.springframework.stereotype.Component;
import org.json.JSONObject;
import java.io.IOException;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class UtilityClass {

	/**
	 * This method is used for invoking the rest api
	 * 
	 * @param request
	 * @param url
	 * @return String response
	 */

	public String callRestAPIForFramework(String request, String url, String token) {
		String outputString = "";
		HttpURLConnection conn = null;
		log.info("URL::" + url);
		log.info("Request to framework::" + request);
		try {
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			if (token != null) {
				conn.setRequestProperty("Authorization", token);
			}
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			log.error("Exception - ", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callRestAPI outputString::" + outputString);
		return outputString;
	}

	/**
	 * This method is used for invoking the rest api
	 * 
	 * @param request
	 * @param url
	 * @return String response
	 */
	public String callRestAPI(String request, String url, String token) {
		String outputString = "";
		HttpURLConnection conn = null;
		log.info("URL::" + url);
		log.info("Request to async callback pod::" + request);
		try {
			String soapAction = Constants.EMPTYSTRING;
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
			conn.setRequestProperty("Accept", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
			conn.setRequestProperty("SOAPAction", soapAction);
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			if (token != null) {
				conn.setRequestProperty("Authorization", token);
			}
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			os.close();
			BufferedReader reader = null;
			if (conn.getResponseCode() == 200) {
				reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				log.info("Response code:::" + conn.getResponseCode());
			} else {
				log.info("Response code:::" + conn.getResponseCode() + "getErrorStream" + conn.getErrorStream());
				if (conn.getErrorStream() != null) {
					reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				}
			}
			String responseString1 = null;
			while (reader != null && (responseString1 = reader.readLine()) != null) {
				outputString = outputString + responseString1;
			}
		} catch (Exception e) {
			log.error("Exception - ", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callRestAPI outputString::" + outputString);
		return outputString;
	}

	public String getRequestJson(String requestJson, String serviceName, String operationName, String transId,
			String responseId) {
		String request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
				+ "&transId=" + transId + "&responseId=" + responseId;
		return request;

	}

	public String batchProcessingResponseFromClient(String requestJson, String ServerURL, String OauthUrl,
			String ServiceURL) {
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection serviceConn = null;
		String request = "grant_type=client_credentials";
		String tokenCode = "";
		String finResponse = "";
		String username = "";
		InputStreamReader isr = null;
		// CloseableHttpClient client = HttpClientBuilder.create().build();
		String soapAction = Constants.EMPTYSTRING;
		URL url;
		try {
			if (requestJson.contains("&")) {
				requestJson = requestJson.replaceAll("&", "u+00000026");
			}

			url = new URL(OauthUrl + "?" + request);
			log.info("OAUTH CONNECTION" + url);
			if (ServiceURL.contains("manage-promotion") || ServiceURL.contains("change-feature")
					|| ServiceURL.contains("change-rateplan")) {
				username = "change-and-update-service-user";
			}

			System.out.println("grant_type:::" + request + "username::" + username);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			String encoded = Base64.getEncoder().encodeToString((username + ":" + "welcome123").getBytes("UTF-8"));
			conn.setRequestProperty("Authorization", "Basic " + encoded);
			conn.setRequestProperty("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
			conn.setRequestProperty("Accept", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
			conn.setRequestProperty("SOAPAction", soapAction);
			conn.setRequestMethod("POST");
			conn.setConnectTimeout(10000);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				finResponse = finResponse + responseString;
			}
			if (!"".equalsIgnoreCase(finResponse)) {
				JSONObject obj = new JSONObject(finResponse);
				tokenCode = obj.getString("access_token");
				log.debug("tokenCode::" + tokenCode);
			}
			log.info("service url" + ServerURL + ServiceURL);
			if (!"".equalsIgnoreCase(tokenCode) && !ServiceURL.contains("validate-device")) {

				url = new URL(ServerURL + ServiceURL);
				log.info("url:::" + url);
				Thread.sleep(1000);
				serviceConn = (HttpURLConnection) url.openConnection();
				serviceConn.setRequestProperty("Content-Length", String.valueOf(requestJson.getBytes().length));
				serviceConn.setRequestProperty("Content-Type",
						org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
				serviceConn.setRequestProperty("SOAPAction", soapAction);
				serviceConn.setRequestProperty("Authorization", tokenCode);
				serviceConn.setRequestMethod("POST");
				serviceConn.setConnectTimeout(10000);
				serviceConn.setDoOutput(true);
				serviceConn.setDoInput(true);
				OutputStream out = serviceConn.getOutputStream();
				out.write(requestJson.getBytes());
				out.close();
				BufferedReader reader = null;
				if (serviceConn.getResponseCode() == 200) {
					reader = new BufferedReader(new InputStreamReader(serviceConn.getInputStream()));
					log.info("Response code::" + serviceConn.getResponseCode());
				} else {
					log.info("Response code::" + serviceConn.getResponseCode());
					reader = new BufferedReader(new InputStreamReader(serviceConn.getErrorStream()));
				}
				String responseString1 = null;
				while ((responseString1 = reader.readLine()) != null)
					outputString = outputString + responseString1;
				log.info("Response outputString::" + outputString);
			}
		}

		catch (Exception e) {
			// e.printStackTrace();
			log.error("Exception in getResponseFromClient method::", e);
		} finally {
			if (serviceConn != null) {
				serviceConn.disconnect();
			}
			if (isr != null) {
				try {
					isr.close();
				} catch (IOException e2) {
					log.info(e2.getMessage(), e2);
				}
			}
		}
		return outputString;

	}

}
