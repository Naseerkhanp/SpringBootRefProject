package com.excelacom.servicegateway.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.consumer.InboundMobile1MessageConsumer;
import com.excelacom.servicegateway.handler.AuthHandler;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.consumer.InboundMobile1MessageConsumer;
import com.google.gson.Gson;

@RestController
public class InboundServiceController {

	@Autowired
	private RabbitTemplate customRabbitTemplate;

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Autowired
	private InboundProperties inboundProperties;

	@Autowired
	private TransactionDAO transactionDAO;

	@Autowired
	private InboundMobile1MessageConsumer inboundMobile1MessageConsumer;

	Logger LOGGER = LoggerFactory.getLogger(InboundServiceController.class);

	@RequestMapping(value = "#{inboundProperties.getNslUpdateCancelurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public Object updateportCancelCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("UpdateCancelController");
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getNslUpdateCancelExchange(),
								inboundQueueProperties.getNslUpdateCancelQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
				} else {
					responseString = utilityClass.invalidToken(token);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				LOGGER.info("Invalid Token " + responseString);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getUpdateModifyUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String updateModifyCancelCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("UpdateModifyController");
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getUpdateModifyExchange(),
								inboundQueueProperties.getUpdateModifyQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
				} else {
					responseString = utilityClass.invalidToken(token);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				LOGGER.info("Invalid Token " + responseString);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getHmnoChangepsimUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String HmnoChangepSIMCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnochangepsimExchange(),
								inboundQueueProperties.getHmnochangepsimQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;

	}

	@RequestMapping(value = "#{inboundProperties.getHmnoLineHistoryInquiryServiceUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	public String HMNOLineHistoryInquiryServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("HMNOLineHistoryInquiryServiceCall");
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnoLineHistoryInquiryServiceExchange(),
								inboundQueueProperties.getHmnoLineHistoryInquiryServiceQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
				} else {
					responseString = utilityClass.invalidToken(token);
				}
			} else {
				responseString = utilityClass.unavailableToken();
				LOGGER.info("Invalid Token " + responseString);
			}
			LOGGER.info("Response :: " + responseString);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getMnoportinInquiryurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String mnoPortinInquiryCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("MnoPortinInquiryController");
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getMnoportinInquiryExchange(),
								inboundQueueProperties.getMnoportinInquiryQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getHmnoDeviceinquiryUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String HmnoDeviceInquiryServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnodeviceinquiryExchange(),
								inboundQueueProperties.getHmnodeviceinquiryQueue(), message);
						responseString = new String(result.getBody());
						LOGGER.info("Response::" + responseString);
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;

	}

	@RequestMapping(value = "#{inboundProperties.getHmnoChangefeatureUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String HmnoChangeFeatureCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {

		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnoChangeFeatureExchange(),
								inboundQueueProperties.getHmnoChangeFeatureQueue(), message);
						responseString = new String(result.getBody());
						LOGGER.info("Response::" + responseString);
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;

	}

	@RequestMapping(value = "#{inboundProperties.getHmnoValidateSimUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String HMNOValidateSimServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnoValidateSimExchange(),
								inboundQueueProperties.getHmnoValidateSimQueue(), message);
						responseString = new String(result.getBody());
						LOGGER.info("Response::" + responseString);
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getHmnoDeviceinquiryAsyncUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String HmnoDeviceInquiryAsyncServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		String responseString = null;
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getHmnodeviceinquiryAsyncExchange(),
								inboundQueueProperties.getHmnodeviceinquiryAsyncQueue(), message);
						responseString = new String(result.getBody());
						LOGGER.info("Response::" + responseString);
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getMnoLineDetailsUrl()}", produces = "application/json", method = RequestMethod.GET)
	@ResponseBody
	public String mnoLineDetailsCall(HttpServletRequest request, @PathVariable String mdn,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("mnoLineDetailsCall");
		String requestJson = "";
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String referenceNumber = request.getHeader("referenceNumber");
						String accountNumber = request.getHeader("accountNumber");
						HashMap<String, String> msgheader = new HashMap<String, String>();
						msgheader.put("referenceNumber", referenceNumber);
						msgheader.put("accountNumber", accountNumber);
						HashMap<String, String> data = new HashMap<String, String>();
						data.put("mdn", mdn);
						HashMap<String, HashMap<String, String>> req = new HashMap<String, HashMap<String, String>>();
						req.put("messageHeader", msgheader);
						req.put("data", data);
						requestJson = new Gson().toJson(req);
						LOGGER.info("requestJson :: " + requestJson);
						Message message = MessageBuilder.withBody(requestJson.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getMnoLineDetailsExchange(),
								inboundQueueProperties.getMnoLineDetailsQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getActivateHotlineUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String activateHotLineServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("activateHotLineServiceCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(
								inboundQueueProperties.getActivateHotlineExchange(),
								inboundQueueProperties.getActivateHotlineQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getSuspendSubscriberUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String suspendSubscriberCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("suspendSubscriberCall");
		String responseString = "";
		try {
			// String requests = XML.toJSONObject(request).toString();
			LOGGER.info(request);
			Message message = MessageBuilder.withBody(request.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getSuspendSubscriberExchange(),
					inboundQueueProperties.getSuspendSubscriberQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getRestoreSubscriberUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String getRestoreSubscriber(@RequestBody String request) {
		LOGGER.info("getRestoreSubscriber");
		String responseString = "";
		try {
			// String requests = XML.toJSONObject(request).toString();
			LOGGER.info(request);
			Message message = MessageBuilder.withBody(request.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			// Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getRestoreSubscriberExchange(),
			// 		inboundQueueProperties.getRestoreSubscriberQueue(), message);
			Message result = inboundMobile1MessageConsumer.restoreSubscriberCall(message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getActivateSubscriberUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String activateSubscriberServiceCall(@RequestBody String request) {
		LOGGER.info(" activateSubscriberServiceCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getActivateSubscriberExchange(),
					inboundQueueProperties.getActivateSubscriberQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getActivatePortinSubscriberUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String activatePortServiceCall(@RequestBody String request) {
		LOGGER.info("activatePortServiceCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getActivatePortinSubscriberExchange(),
					inboundQueueProperties.getActivatePortinSubscriberQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	//String sde=inboundProperties.getDeactivateSubscriberUrl()
	@RequestMapping(value = "#{inboundProperties.getDeactivateSubscriberUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String deactivateSubscriberCall(@RequestBody String request) {
		LOGGER.info("activatePortServiceCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(
					inboundQueueProperties.getDeactivateSubscriberExchhange(),
					inboundQueueProperties.getDeactivateSubscriberQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getResetfeatureurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String hmnoResetFeatureServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("hmnoResetFeatureServiceCall");
		String responseString = "";
		try {
			// String requests = XML.toJSONObject(request).toString();
			LOGGER.info(request);
			Message message = MessageBuilder.withBody(request.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getResetfeatureExchange(),
					inboundQueueProperties.getResetfeatureQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getOrderinquiryurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String hmnoOrderInquiryServiceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("hmnoOrderInquiryServiceCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getOrderinquiryExchange(),
					inboundQueueProperties.getOrderinquiryQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getChangefeatureasyncurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String hmnochangefeatureasyncCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("hmnochangefeatureasyncCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getChangefeatureasyncExchange(),
					inboundQueueProperties.getChangefeatureasyncQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getHmnochangepsimasyncurl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String hmnochangepsimasyncCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("hmnochangepsimasyncCall");
		String responseString = "";
		try {
			String requests = XML.toJSONObject(request).toString();
			LOGGER.info(requests);
			Message message = MessageBuilder.withBody(requests.getBytes())
					.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
			Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getHmnochangepsimasyncExchange(),
					inboundQueueProperties.getHmnochangepsimasyncQueue(), message);
			responseString = new String(result.getBody());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}

	@RequestMapping(value = "#{inboundProperties.getChangeRatePlanUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String changeRatePlanCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("changeRatePlanCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						String requests = XML.toJSONObject(request).toString();
						LOGGER.info(requests);
						Message message = MessageBuilder.withBody(requests.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
					Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getChangeRatePlanExchange(),
								inboundQueueProperties.getChangeRatePlanQueue(), message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getChangeMdnUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String changeMdnCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("changeMdnCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getChangeMdnExchange(),
								inboundQueueProperties.getChangeMdnQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getLineInquiryUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String lineInquiryCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("lineInquiryCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getLineInquiryExchange(),
								inboundQueueProperties.getLineInquiryQueue() , message);
						//Message result = inboundMobile1MessageConsumer.lineInquiryCallResponse(message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getRemoveHotlineUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String removeHotlineCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("removeHotlineCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						//String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getRemoveHotlineExchange(),
								inboundQueueProperties.getRemoveHotlineQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getUpdatePortoutUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String updatePortoutCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("updatePortoutCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getUpdatePortoutExchange(),
								inboundQueueProperties.getUpdatePortoutQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getUpdateDuedatePortinUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String updateDuedatePortinCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("updateDuedatePortinCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						// String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getUpdateDuedatePortinExchange(),
								inboundQueueProperties.getUpdateDuedatePortinQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getValidateMdnUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String validateMdnCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("validateMdnCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						//String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getValidateMdnExchange(),
								inboundQueueProperties.getValidateMdnQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
	
	@RequestMapping(value = "#{inboundProperties.getValidateDeviceUrl()}", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_XML_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public String validateDeviceCall(@RequestBody String request,
			@RequestHeader(value = "Authorization", required = false) String token) {
		LOGGER.info("validateDeviceCall");
		String responseString = "";
		try {
			if (token != null) {
				if (token.toLowerCase().startsWith("basic")) {
					String tokenResponse = transactionDAO.validateBasicToken(token);
					if (tokenResponse.equalsIgnoreCase("success")) {
						//String requests = XML.toJSONObject(request).toString();
						LOGGER.info(request);
						Message message = MessageBuilder.withBody(request.getBytes())
								.setContentType(MediaType.APPLICATION_JSON_VALUE).build();
						Message result = customRabbitTemplate.sendAndReceive(inboundQueueProperties.getValidateDeviceExchange(),
								inboundQueueProperties.getValidateDeviceQueue() , message);
						responseString = new String(result.getBody());
					} else {
						responseString = utilityClass.invalidToken(token);
					}
					LOGGER.info("Response :: " + responseString);
				} else {
					responseString = utilityClass.unavailableToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return responseString;
	}
}
