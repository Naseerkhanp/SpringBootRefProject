package com.nsl.usagereport.cif.entity;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

@Entity(name = "TRANSACTION_FILE_LOG")
@Table(name = "TRANSACTION_FILE_LOG")
public class TransactionFileLog implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRANSACTION_LOG_SEQ_gen")
	@SequenceGenerator(name = "TRANSACTION_LOG_SEQ_gen", sequenceName = "TRANSACTION_LOG_SEQ", allocationSize = 1)
	@Column(name = "TRANSACTION_ID")
	private Long transactionId;
	@Column(name = "FILE_NAME")
	private String fileName;
	@Column(name = "FILE_EXTENSION")
	private String fileExtension;
	@Column(name = "FILE_TYPE")
	private String fileType;
	@Column(name = "FILE_CONTENT")
	private Blob fileContent;
	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());
	@Column(name = "CREATED_BY")
	private String createdBy;
	@CreatedDate
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate = new java.sql.Date(new java.util.Date().getTime());
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	@Column(name = "ENTITY_ID")
	private Long entityId;
	@Column(name = "ENTITY_TYPE_ID")
	private Long entityTypeId;
	@Column(name = "REASON")
	private String reason;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "TOTAL_RECORDS")
	private Long totalRecords;
	@Column(name = "TOTAL_RECORDS_PROCESSED")
	private Long totalRecordsProcessed;
	@Column(name = "TOTAL_RECORDS_FAILED")
	private Long totalRecordsfailed;
	@CreatedDate
	@Column(name = "START_DATE")
	private Date startDate = new java.sql.Date(new java.util.Date().getTime());
	@CreatedDate
	@Column(name = "END_DATE")
	private Date endDate = new java.sql.Date(new java.util.Date().getTime());
	@Column(name = "RESPONSE_MSG")
	@Lob
	private String responseMsg;

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	@OneToMany(mappedBy = "transactionFileLog")
	private Set<TransFailureLog> transFailureLogLst;

	public Set<TransFailureLog> getTransFailureLogLst() {
		return transFailureLogLst;
	}

	public void setTransFailureLogLst(Set<TransFailureLog> transFailureLogLst) {
		this.transFailureLogLst = transFailureLogLst;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Long getTotalRecordsProcessed() {
		return totalRecordsProcessed;
	}

	public void setTotalRecordsProcessed(Long totalRecordsProcessed) {
		this.totalRecordsProcessed = totalRecordsProcessed;
	}

	public Long getTotalRecordsfailed() {
		return totalRecordsfailed;
	}

	public void setTotalRecordsfailed(Long totalRecordsfailed) {
		this.totalRecordsfailed = totalRecordsfailed;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Blob getFileContent() {
		return fileContent;
	}

	public void setFileContent(Blob fileContent) {
		this.fileContent = fileContent;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public Long getEntityTypeId() {
		return entityTypeId;
	}

	public void setEntityTypeId(Long entityTypeId) {
		this.entityTypeId = entityTypeId;
	}
}
