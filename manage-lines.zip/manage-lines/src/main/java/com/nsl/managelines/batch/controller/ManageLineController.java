/**
 * 
 */
package com.nsl.managelines.batch.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsl.managelines.dao.cif.entity.TransactionDetails;
import com.nsl.managelines.dao.cif.impl.TransactionDetailsDao;
import com.nsl.managelines.batch.consumer.ManageLineConsumer;
import com.nsl.managelines.batch.bean.RequestBean;
import com.nsl.managelines.batch.bean.planmigration.PlanMigrationRequest;
import com.nsl.managelines.batch.constants.Constants;
import com.nsl.managelines.batch.bean.ReportMgmtRequest;

import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */

@RestController
@Log4j2
@CrossOrigin
public class ManageLineController {

	@Autowired
	private TransactionDetailsDao transactionDetailsDao;

	@Autowired
	private ManageLineConsumer manageLineConsumer;

	@GetMapping(value = "/getTransactionDetailsByErrorCode/errorCode/{errorCode}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Set<TransactionDetails> getTransactionDetailsByErrorCode(
			@PathVariable(value = "errorCode") String errorCode) {
		log.info("errorCode:" + errorCode);
		return transactionDetailsDao.findTransactionDetailsByErrorCode(errorCode);
	}

	@PostMapping(value = "/retrigger-ne-callback", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<String> retriggerNeCallbackApi(@RequestBody RequestBean requestBean) {
		ResponseEntity<String> entityResponse = manageLineConsumer.retriveDeviceCallforAS(requestBean);
		return entityResponse;
	}

	@PostMapping(value = "/async-callback", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<String> asyncCallback(@RequestBody String request) {
		ResponseEntity<String> entityResponse = manageLineConsumer.asyncCallback(request, "ASYNC", null);
		return entityResponse;
	}

	@PostMapping(value = "/plan-migration-eligibility", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<String> planMigrationEligibility(@RequestBody ReportMgmtRequest reportMgmtRequest) {
		ResponseEntity<String> response = null;
		try {
			manageLineConsumer.planMigrationEligibility(reportMgmtRequest);
		} catch (Exception e) {
			log.error("Exception ::", e);
			response = new ResponseEntity<String>(Constants.INVALID_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
			return response;
		}
		response = new ResponseEntity<String>(Constants.SUCCESS_MSG, HttpStatus.OK);
		return response;

	}
	
	@PostMapping(value = "/plan-migration", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<String> planMigration(@RequestBody PlanMigrationRequest request) {
		ResponseEntity<String> entityResponse = manageLineConsumer.planMigration(request);
		return entityResponse;
	}
}
