package com.nsl.usagereport.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.vfs2.FileFilterSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSelector;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.filter.RegexFileFilter;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.hibernate.result.Output;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.cif.entity.TransFailureLog;
import com.nsl.usagereport.cif.entity.TransactionFileLog;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.repository.DataDetailsDaoImpl;
import com.nsl.usagereport.postgres.repository.SmsDetailsDaoImpl;
import com.nsl.usagereport.postgres.repository.VoiceDetailsDaoImpl;
import com.nsl.usagereport.properties.UsuageReportProperties;
import com.nsl.usagereport.transaction.dao.repository.ResourceInfoDaoImpl;
import com.nsl.usagereport.transaction.entity.ResourceInfo;
import com.nsl.usagereport.uio.DataDetailsUIO;
import com.nsl.usagereport.uio.SmsDetailsUIO;
import com.nsl.usagereport.uio.VoiceDetailsUIO;
import com.nsl.usagereport.util.UtilityServiceClass;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class FileUploadService extends FileUploadSFTPMgrService {
	@Autowired
	private VoiceDetailsDaoImpl voiceDetailsDaoImpl;
	@Autowired
	private DataDetailsDaoImpl dataDetailsDaoImpl;
	@Autowired
	private SmsDetailsDaoImpl smsDetailsDaoImpl;
	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;

	@Autowired
	NslDataHandler nslDataHandler;
	@Autowired
	private Environment env;
	@Autowired
	JobLauncher jobLauncher;
	@Autowired
	Job job;
	@Autowired
	private Gson gson;
	
	@Autowired
	private JobOperator jobOperator;
	private StepExecution stepExecution;
	
	@Autowired
	private ProcessIOSDevices processIOSDevices;

	@Override
	public ResponseEntity<String> extractDataFrmFile(UsageReportDetails fileDetails) {
		log.info(this.getClass() + " extractDataFrmFile method called .");
		String msg = NslFileUploadConstants.SUCCESS;
		HttpStatus status = HttpStatus.OK;
		try {
			Map<String, JobParameter> maps = new HashMap<>();
			maps.put("time", new JobParameter(System.currentTimeMillis()));
			maps.put("usageReport", new JobParameter(new Gson().toJson(fileDetails)));
			JobParameters parameters = new JobParameters(maps);
			jobLauncher.run(job, parameters);
			// downloadFromSFTP(fileDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			msg = " Exception thrown :-" + e.getMessage();
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		log.info(this.getClass() + " extractDataFrmFile method called .");
		return new ResponseEntity<>(msg, status);
	}

	@Override
	public List<DataDetailsUIO> getDataDetails(GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " getDataDetails method called .");
		return dataDetailsDaoImpl.getDataDetails(getUsageReportDetails);
	}

	@Override
	public List<SmsDetailsUIO> getSmsDetails(GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " getSmsDetails method called .");
		return smsDetailsDaoImpl.getSmsDetails(getUsageReportDetails);
	}

	@Override
	public List<VoiceDetailsUIO> getVoiceDetails(GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " getVoiceDetails method called .");
		return voiceDetailsDaoImpl.getVoiceDetails(getUsageReportDetails);
	}

	@Override
	public ResponseEntity<String> deleteData(GetUsageReportDetails getUsageReportDetails) throws Exception {
		log.info(this.getClass() + " deleteData method called .");
		HttpStatus status = HttpStatus.OK;
		String msg = NslFileUploadConstants.PARSED_STATUS_SUCCESS;
		try {
			dataDetailsDaoImpl.deleteData(getUsageReportDetails);
			voiceDetailsDaoImpl.deleteData(getUsageReportDetails);
			smsDetailsDaoImpl.deleteData(getUsageReportDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			msg = e.getMessage();
			status = HttpStatus.BAD_REQUEST;
		}
		log.info(this.getClass() + " extractDataFrmSmbFile method called .");
		return new ResponseEntity<String>(msg, status);
	}

	@Override
	public ResponseEntity<String> extractDataFrmSmbFile(UsageReportDetails usageReportDetails, MultipartFile file)
			throws Exception {
		log.info(this.getClass() + " extractDataFrmSmbFile method called .");
		String msg = NslFileUploadConstants.PARSED_STATUS_INPROGRESS;
		HttpStatus status = HttpStatus.OK;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		TransactionFileLog transactionFileLog = null;
		try {
			if (!extension.equalsIgnoreCase(env.getProperty(NslFileUploadConstants.CSV))) {
				String error = "ERR05 – File format is invalid";
				return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
			}
			transactionFileLog = transactionFileLogDaoImpl.findByFileName(file.getOriginalFilename());
			if (transactionFileLog != null) {
				if (transactionFileLog.getStatus().equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_INPROGRESS)) {
					msg = "ERR05 – File upload already in-progress";
					status = HttpStatus.BAD_REQUEST;
				} else if (transactionFileLog.getStatus()
						.equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_SUCCESS)) {
					msg = "ERR05 – Data already exists";
					status = HttpStatus.BAD_REQUEST;
				} else if (transactionFileLog.getStatus()
						.equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_FAILED)) {
					saveTransactionDetails(usageReportDetails, file.getOriginalFilename(), extension,
							NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
					processDataFrmFile(file.getBytes(), usageReportDetails, file.getOriginalFilename(), extension);
				}
			} else {
				saveTransactionDetails(usageReportDetails, file.getOriginalFilename(), extension,
						NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
				processDataFrmFile(file.getBytes(), usageReportDetails, file.getOriginalFilename(), extension);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			msg = e.getMessage();
			status = HttpStatus.BAD_REQUEST;
		}
		log.info(this.getClass() + " extractDataFrmSmbFile method called .");
		return new ResponseEntity<String>(msg, status);
	}

	public Message initiateCallResponse(Message msg) throws Exception {
		log.debug("Inside initiateCallResponse - UsageReport");
		String operationName = null;
		String requestJson = null;
		String destName = null;
		String entityId = null;
		String destination = null;
		String transactionResp = null;
		String endpointURL = null;
		String endpointOperation = null;
		String response = null;
		String gpName = "";
		String groupId = null;
		String processPlanId = null;
		String requestParams = null;
		String responseId = null;
		String funcReqIdentifier = "";
		String groupJson = "";
		String serviceName = "";
		String str = "";
		String newJsonData = "";
		JSONObject obj = new JSONObject();
		JSONArray jsonArray;
		Map<String, String> dataMap = new HashMap<String, String>();
		byte[] body = msg.getBody();
		String request = new String(body);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String[] nameValuePairs = request.split(NslFileUploadConstants.AMP);
			String[] arrayOfString1 = nameValuePairs;
			int i = arrayOfString1.length;
			for (int j = 0; j < i; ++j) {
				String nameValuePair = arrayOfString1[j];
				if (nameValuePair.startsWith(NslFileUploadConstants.SOAPACTION)) {
					operationName = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.JSON)) {
					requestJson = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.DESTNAME)) {
					destName = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.ENTITYID)) {
					entityId = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
					if (entityId != null) {
						groupId = entityId.substring(entityId.indexOf(NslFileUploadConstants.DELTA) + 1,
								entityId.length());
						processPlanId = entityId.substring(0, entityId.indexOf(NslFileUploadConstants.DELTA));
					}
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.DESTINATION)) {
					destination = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.ENDPOINTURLEQ)) {
					endpointURL = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.ENDPOINTOPERATION)) {
					endpointOperation = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.REQUESTJSON)) {
					requestParams = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
				if (nameValuePair.startsWith(NslFileUploadConstants.RESPONSEID)) {
					responseId = nameValuePair.split(NslFileUploadConstants.EQUALTO)[1];
				}
			}
			// logger changes
			String referenceNumberr = "NA";
			// UtilityService.addTraceDetails(responseId, referenceNumberr);
			if (endpointURL != null && !NslFileUploadConstants.EMPTYSTRING.equalsIgnoreCase(endpointURL)
					&& !NslFileUploadConstants.NULL.equalsIgnoreCase(endpointURL)) {
				destName = endpointURL;
				operationName = endpointOperation;
			}
			log.debug("Operation name : " + operationName + "Dest name : " + destName + "Entity ID : " + entityId
					+ "destination : " + destination + "EndpointURL : " + endpointURL + "EndpointOperation : "
					+ endpointOperation + "requestParams::::" + requestParams);
			requestParams = jsonFormatter(requestParams);
			log.info("Entering Voice Details" + requestParams);			
			GetUsageReportDetails usageReportDetails = gson.fromJson(requestParams, GetUsageReportDetails.class);
			log.info("usageReportDetails Voice Details" + usageReportDetails.toString());
			if ("Voice Details".equalsIgnoreCase(operationName)) {
				log.info("Entering Voice Details");
				List<VoiceDetailsUIO> voicedetails = getVoiceDetails(usageReportDetails);
				newJsonData = mapper.writeValueAsString(voicedetails);
				log.info("newJsonData Voice Details" + newJsonData);
				if (newJsonData.isEmpty() || newJsonData.equalsIgnoreCase(NslFileUploadConstants.NULL)
						|| newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYSTRING) || newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYDATA) || newJsonData.length()==0) {
					response = errorJson(newJsonData, responseId);
				} else {
					response = constructJson(newJsonData, responseId);
				}
				log.info("Final Voice Details" + response);
			}
			if ("Data Details".equalsIgnoreCase(operationName)) {
				log.info("Entering Data Details");
				List<DataDetailsUIO> datadetails = getDataDetails(usageReportDetails);
				newJsonData = mapper.writeValueAsString(datadetails);
				log.info("newJsonData Data Details" + newJsonData);
				if (newJsonData.isEmpty() || newJsonData.equalsIgnoreCase(NslFileUploadConstants.NULL)
						|| newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYSTRING) || newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYDATA) || newJsonData.length()==0) {
					response = errorJson(newJsonData, responseId);
				} else {
					response = constructJson(newJsonData, responseId);
				}
				log.info("Final Data Details" + response);

			}
			if ("Sms Details".equalsIgnoreCase(operationName)) {
				log.info("Entering Sms Details");
				List<SmsDetailsUIO> smsdetails = getSmsDetails(usageReportDetails);
				newJsonData = mapper.writeValueAsString(smsdetails);
				log.info("newJsonData Voice Details" + newJsonData);
				if (newJsonData.isEmpty() || newJsonData.equalsIgnoreCase(NslFileUploadConstants.NULL)
						|| newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYSTRING) || newJsonData.equalsIgnoreCase(NslFileUploadConstants.EMPTYDATA) || newJsonData.length()==0) {
					response = errorJson(newJsonData, responseId);
				} else {
					response = constructJson(newJsonData, responseId);
				}
				log.info("Final Sms Details" + response);
			}
		} catch (Exception e) {
			log.error("Exception in initiateCallResponse e{}", e);
		}
		if (response == null) {
			response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	public String jsonFormatter(String inputJson) {
		log.debug("inputJson:::::" + inputJson);
		String response = null;
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					response = printJsonObject(obj, finalObj);
					log.debug("JsonArray Formatter Final Response::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				response = printJsonObject(object, finalObj);
				log.debug("JsonObject Formatter Final Response::" + response);
			}
		} catch (JSONException e) {
			log.error("jsonFormatter Exception{}", e);
		}
		return response;
	}

	public String printJsonObject(JSONObject jsonObj, JSONObject obj) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();
				Object keyvalue = jsonObj.get(keyStr);
				JSONObject object = null;

				if ("mdn".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "mdn");
							object = new JSONObject(str);
						}
					}
				}
				if ("simid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "iccid");
							object = new JSONObject(str);
						}
					}
				}
				if ("deviceid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "imei");
							object = new JSONObject(str);
						}
					} else {
						obj.put("imei", keyvalue.toString());
					}
				}
				if ("feature".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						// JSONObject jsonObject1 = array.getJSONObject(0);
						// String str = jsonObject1.toString();
						keyvalue = array;
					}
				}
				if (object != null) {
					keyvalue = object;
				}

				if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
					obj.put(keyStr, keyvalue.toString());
				}
				if (keyvalue instanceof JSONObject) {
					printJsonObject((JSONObject) keyvalue, obj);
				}
				if (keyvalue instanceof JSONArray) {
					if (!(keyStr.equalsIgnoreCase("feature"))) {
						printJsonArray((JSONArray) keyvalue, obj);
					} else {
						obj.put(keyStr, keyvalue);
					}
				}
			}
		} catch (Exception e) {
			log.error("printJsonObject Exception{}", e);
		}
		return obj.toString();
	}

	public String printJsonArray(JSONArray array, JSONObject obj) {
		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				printJsonObject(jsonObject1, obj);
			}
		} catch (Exception e) {
			log.error("printJsonArray exception {}", e);
		}
		return null;
	}

	public String constructJson(String newJsonData, String responseId) {
		log.info("Usage report constructJson::" + responseId);
		String responseJson = "";
		StringBuilder parameterJson = new StringBuilder();
		try {
			parameterJson.append("{\r\n");
			parameterJson.append(" \"data\": {\r\n");
			parameterJson.append("\"transactionId\": " + responseId + ",\r\n");
			parameterJson.append("\"code\": \"200\",\r\n");
			parameterJson.append("\"reason\": \"OK\",\r\n");
			parameterJson.append(" \"usage\": " + newJsonData + "\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append("}");
			responseJson = parameterJson.toString();
		} catch (Exception e) {
			log.info("Exception::" + e.getMessage());
		}
		return responseJson;

	}
	
	public String errorJson(String newJsonData, String responseId) {
		log.info("Usage report errorJson::" + newJsonData);
		String responseJson = "";
		StringBuilder parameterJson = new StringBuilder();
		try {
			parameterJson.append("{\r\n");
			parameterJson.append(" \"data\": {\r\n");			
			parameterJson.append("\"code\": \"400\",\r\n");
			parameterJson.append("\"reason\": \"Bad Request\",\r\n");
			parameterJson.append(" \"message\": [\r\n");
			parameterJson.append(" {\r\n");
			parameterJson.append(" \"responseCode\": \"ERR07\",\r\n");
			parameterJson.append("\"description\": \"Data not found\",\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append(" ]\r\n");
			parameterJson.append(" }\r\n");
			parameterJson.append("}");
			responseJson = parameterJson.toString();
		} catch (Exception e) {
			log.info("Exception::" + e.getMessage());
		}
		return responseJson;

	}
	@Retryable(value = { FileSystemException.class }, maxAttempts = 3)
	public void downloadFromSFTP(UsageReportDetails usageReportDetails) throws Exception, FileSystemException {
		log.info(this.getClass() + " Connecting to SFTP.... ");
		String destinationUrl = null;
		FileObject folderPath = null;
		FileObject destinationPath = null;
		StandardFileSystemManager manager = new StandardFileSystemManager();
		try {
			try {
				manager.init();
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze VFS ::", e);
				throw new FileSystemException(" Internal Error: Unable to iniatilze VFS ::", e.getCause());
			}
			FileSystemOptions opts = new FileSystemOptions();
			FileSystemOptions destopts = new FileSystemOptions();
			try {
				SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze StrictHostKeyChecking ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException(" Internal Error: Unable to iniatilze StrictHostKeyChecking ::",
						e.getCause());
			}
			SftpFileSystemConfigBuilder.getInstance().setConnectTimeoutMillis(opts, 100000);
			String host = usageReportDetails.getHost();
			String user = usageReportDetails.getUserName();
			String password = usageReportDetails.getPassword();
			String port = usageReportDetails.getPort();
			String url = usageReportDetails.getSftpFolderPath();
			StaticUserAuthenticator auth = new StaticUserAuthenticator(host, user, password);
			try {
				DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(opts, auth);
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException("  Internal Error: Invalid SFTP Details ::", e.getCause());
			}
			try {
				String getfilesurl = "sftp://" + host + ":" + port + "/" + url;
				folderPath = manager.resolveFile(getfilesurl, opts);
				if (usageReportDetails.getReportType().equalsIgnoreCase(NslFileUploadConstants.GET_IOS_DEVICE)) {
					if (folderPath.exists()) {
						processIOSDevices.processIOSDeviceDetails(folderPath, usageReportDetails);
					} else {
						log.info("IOS Device Fetch file not exist for a name : "+url);
					}
				} else {
					if (usageReportDetails.getSftpTargetPath().contains("~")) {
						String[] destEle = usageReportDetails.getSftpTargetPath().split("~");
						List<String> destEleList = Arrays.asList(destEle);
						ArrayList<String> destination = new ArrayList<String>(destEleList);
						for (int i = 0; i < destEleList.size(); i++) {
							System.out.println("list of paths : " + destination.get(i));
							destinationUrl = "sftp://" + host + ":" + port + "/" + destination.get(i);
							System.out.println("destinationUrl successful:::" + destinationUrl);
							try {
								DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(destopts, auth);
							} catch (Exception e) {
								log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
								if (manager != null) {
									manager.close();
								}
								throw new FileSystemException("  Internal Error: Invalid SFTP Details ::",
										e.getCause());
							}
							destinationPath = manager.resolveFile(destinationUrl, destopts);
							destinationPath.copyFrom(folderPath, Selectors.SELECT_FILES);
							System.out.println("File upload successfully");
						}
					} else {
						try {
							DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(destopts, auth);
						} catch (Exception e) {
							log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
							if (manager != null) {
								manager.close();
							}
							throw new FileSystemException("  Internal Error: Invalid SFTP Details ::", e.getCause());
						}
						destinationUrl = "sftp://" + host + ":" + port + "/" + usageReportDetails.getSftpTargetPath();
						destinationPath = manager.resolveFile(destinationUrl, destopts);
						destinationPath.copyFrom(folderPath, Selectors.SELECT_FILES);
						System.out.println("Else File upload successful");
					}
				}
			} catch (Exception e) {
				log.error(this.getClass() + " Error RemotefileDeatils ::", e);
				jobOperator.stop(this.stepExecution.getJobExecutionId());
				throw new FileSystemException("  Internal Error: Error RemotefileDeatils ::", e.getCause());
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::", e);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}

	}

}
