package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.nbos.entity.WibInfo;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("WibInfoHandler")
public class WibInfoHandler implements Handler {
	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst, UsageReportDetails usageReportDetails) throws Exception {
		if (column.length == 2 && ((column[0].isEmpty() || column[0].equalsIgnoreCase("null"))
				&& ((column[1].isEmpty() || column[1].equalsIgnoreCase("null"))))) {
			return detailsBuiler;
		}
		String routerId = NslFileUploadUtils.nullChecker(column[1]);
		try {
			WibInfo wibInfo = new WibInfo();
			wibInfo.setCreatedBy(usageReportDetails.getUserID());
			if (!validateFields(wibInfo, routerId, column, fileUploadLst, recordsStatus, lineNumber)) {
				return detailsBuiler;
			}

			if (!existingRouterIds.contains(routerId)) {
				if (detailsBuiler.containsKey(NslFileUploadConstants.DEFAULT_LONG)) {
					List<Object> li = detailsBuiler.get(NslFileUploadConstants.DEFAULT_LONG);
					li.add(wibInfo);
					detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
				} else {
					List<Object> li = new ArrayList<>();
					li.add(wibInfo);
					detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
				}
				if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSPRCESSD)) {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSPRCESSD, lineNumber, wibInfo, recordsStatus));
				} else {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSPRCESSD, lineNumber, wibInfo, recordsStatus));
				}
				existingRouterIds.add(routerId);
			} else {
				wibInfo.setErrorCode(NslFileUploadConstants.DUPLICATE_ERROR_CODE);
				wibInfo.setErrorMsg(NslFileUploadConstants.TOTALRECORDSFAILED);
				if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSFAILED)) {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, wibInfo, recordsStatus));
				} else {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, wibInfo, recordsStatus));
				}

			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

	private Boolean validateFields(WibInfo wibInfo, String routerId, String[] column, List<RefFileUpload> fileUploadLst,
			Map<String, Map<Object, Long>> recordsStatus, long lineNumber) throws Exception {
		Boolean flag = true;
		String errorCd = NslFileUploadConstants.EMPTY;
		String errorMsg = NslFileUploadConstants.EMPTY;
		if (routerId.isEmpty()) {
			wibInfo.setRouterId(null);
			flag = false;
			errorMsg = "routerid is missing";
			errorCd = "ERR06";
		} else if (routerId.length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			wibInfo.setRouterId(null);
			flag = false;
			errorMsg = "routerid is greater than maximum length 255";
			errorCd = "ERR13";
		} else {
			wibInfo.setRouterId(routerId);
		}

		if (NslFileUploadUtils.nullChecker(column[0]).isEmpty()) {
			wibInfo.setSerialNumber(null);
			flag = false;
			errorMsg = "serialnumber is missing";
			errorCd = "ERR06";
		} else if (NslFileUploadUtils.nullChecker(column[0]).length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			wibInfo.setSerialNumber(null);
			flag = false;
			errorMsg = "serialnumber is greater than maximum length 255";
			errorCd = "ERR13";
		} else {
			wibInfo.setSerialNumber(NslFileUploadUtils.nullChecker(column[0]));
		}
		if (column.length == 2 || NslFileUploadUtils.nullChecker(column[2]).isEmpty()) {
			wibInfo.setMacAddress(null);
			flag = false;
			errorMsg = "macaddress is missing";
			errorCd = "ERR06";
		} else if (!regexCheck(NslFileUploadUtils.nullChecker(column[2]), fileUploadLst, column)) {
			wibInfo.setMacAddress(null);
			flag = false;
			errorMsg = "macaddress is invalid";
			errorCd = "ERR07";
		} else if (NslFileUploadUtils.nullChecker(column[2]).length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			wibInfo.setMacAddress(null);
			flag = false;
			errorMsg = "macaddress is greater than maximum length 255";
			errorCd = "ERR13";
		} else {
			wibInfo.setMacAddress(NslFileUploadUtils.nullChecker(column[2]));
		}
		if (!flag) {
			if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSFAILED)) {
				recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
						NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, wibInfo, recordsStatus));
			} else {
				recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
						NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, wibInfo, recordsStatus));
			}
			wibInfo.setErrorCode(errorCd);
			wibInfo.setErrorMsg(errorMsg);
		}
		return flag;
	}

	private boolean regexCheck(String nullChecker, List<RefFileUpload> fileUploadLst, String[] column) {
		return Pattern
				.matches(fileUploadLst.stream().filter(e -> e.getColumnIndex() == NslFileUploadConstants.MACCOLUMN)
						.findFirst().get().getParamareRegex(), column[2]);
	}

	private Map<Object, Long> getRouterInfoMap(String key, Long lineNumber, WibInfo wibInfo,
			Map<String, Map<Object, Long>> recordsStatus) {
		Map<Object, Long> routerIdLineNumber = recordsStatus.get(key);
		routerIdLineNumber.put(wibInfo, lineNumber);
		return routerIdLineNumber;
	}
}
