package com.nsl.managelines.batch.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.nsl.managelines.batch.bean.Line;
import com.nsl.managelines.batch.bean.LinePlan;
import com.nsl.managelines.batch.bean.planmigration.StgPlanMigration;
import com.nsl.managelines.batch.bean.planmigration.StgPlanMigrationDto;
import com.nsl.managelines.batch.constants.ResourceConstants;
import com.nsl.managelines.batch.properties.InboundProperties;
import com.nsl.managelines.batch.bean.planmigration.RefPlanMigration;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class ResourceClientService {

	@Autowired
	private InboundProperties inboundProperties;

	public Line callLineResourceServiceFromMdn(Line lineBean) {
		log.info("Inside callLineResourceService::" + lineBean.toString());
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		Line line = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.valueOf("GETLINEDETAILSUSINGMDN").getServiceUrl()
					+ "?mdn=" + lineBean.getMdn();
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(lineBean).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
				line = requestGson.fromJson(outputString, Line.class);
				log.info("Request Bean in callLineResourceService::::" + line.toString());
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);
		return line;
	}

	public LinePlan callLinePlanResourceService(LinePlan linePlanBean) {
		String outputString = "";
		HttpURLConnection conn = null;
		String url = "";
		Gson requestGson = new Gson();
		LinePlan linePlan = null;
		log.info("linePlanforCF linePlanBean ::" + linePlanBean.getELineId());
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.valueOf("GETLINEPLANBYLINEID").getServiceUrl()
					+ "?eLineId=" + linePlanBean.getELineId();
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = linePlanBean.toString().getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
				linePlan = requestGson.fromJson(outputString, LinePlan.class);
			}
			isr.close();
			os.close();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callRestAPI :: outputString :: " + outputString);
		return linePlan;
	}

	public ArrayList<Line> updateMigrationEligibility(ArrayList<Line> lineBean) {
		log.info("Inside callLineResourceService::" + lineBean.toString());
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<Line> lineres = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.UPDATEMIGRATIONELIGIBILITY.getServiceUrl();
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(lineBean).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<Line>>() {
				}.getType();
				lineres = requestGson.fromJson(outputString, userListType);
				log.info(lineres);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);
		if (lineres == null) {
			lineres = lineBean;
		}
		return lineres;
	}

	public ArrayList<Line> getlinedetailsbyPlanMigrationEligibile(String billCycleResetDay) {
		log.info("Inside callLineResourceService::" + billCycleResetDay);
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<Line> lineres = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL() + ResourceConstants.resourceUpdateServiceUrl
					.valueOf("GETLINEDETAILSBYPLANMIGRATIONELIGIBILE").getServiceUrl() + "?billCycleResetDay="
					+ billCycleResetDay;
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(billCycleResetDay).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<Line>>() {
				}.getType();
				lineres = requestGson.fromJson(outputString, userListType);
				log.info(lineres);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);

		return lineres;
	}

	public Integer getStgPlanMigrationCount(StgPlanMigration stgPlanMig) {
		log.info("Inside getStgPlanMigrationCount::" + stgPlanMig);
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		Integer count = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL() + ResourceConstants.resourceUpdateServiceUrl.GETLSTGPLANMIGCOUNT.getServiceUrl();
			log.info("getStgPlanMigrationCount URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(stgPlanMig).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
			log.info("getStgPlanMigrationCount :: outputString :: " + outputString);
			if (StringUtils.hasText(outputString)) {
				count = Integer.valueOf(outputString);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("getStgPlanMigrationCount :: count :: " + count);
		return count;
	}
	
	public ArrayList<StgPlanMigration> updateStgPlanMigration(ArrayList<StgPlanMigration> stgPlanMigrationList) {
		log.info("Inside callLineResourceService::" + stgPlanMigrationList);
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<StgPlanMigration> stgPlanMigrationres = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.UPDATESTGPLANMIGRATION.getServiceUrl();
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(stgPlanMigrationList).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<Line>>() {
				}.getType();
				stgPlanMigrationres = requestGson.fromJson(outputString, userListType);
				log.info("stgPlanMigrationres::" + stgPlanMigrationres);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);
		if (stgPlanMigrationres == null) {
			stgPlanMigrationres = stgPlanMigrationList;
		}
		return stgPlanMigrationres;
	}

	public ArrayList<StgPlanMigrationDto> getStgPlanMigrationList(String billCycleResetDay) {
		log.info("Inside callLineResourceService::" + billCycleResetDay);
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<StgPlanMigrationDto> stgPlanMigrationDtoList = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.valueOf("GETSTGPLANMIGRATIONLIST").getServiceUrl()
					+ "?billCycleResetDay=" + billCycleResetDay;
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(billCycleResetDay).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<StgPlanMigrationDto>>() {
				}.getType();
				stgPlanMigrationDtoList = requestGson.fromJson(outputString, userListType);
				log.info(stgPlanMigrationDtoList);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);

		return stgPlanMigrationDtoList;
	}
	
	public ArrayList<RefPlanMigration> getRefPlanMigrationList() {
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<RefPlanMigration> refPlanMigrationList = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.valueOf("GETREFPLANMIGRATIONLIST").getServiceUrl();
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(outputString).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<RefPlanMigration>>() {
				}.getType();
				refPlanMigrationList = requestGson.fromJson(outputString, userListType);
				log.info(refPlanMigrationList);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + refPlanMigrationList);

		return refPlanMigrationList;
	}
	
	public ArrayList<LinePlan> updatePlanCategoryByLineId(ArrayList<LinePlan> linePlan) {
		log.info("Inside callLineResourceService::" + linePlan.toString());
		String outputString = "";
		HttpURLConnection conn = null;
		Gson requestGson = new Gson();
		String url = "";
		ArrayList<LinePlan> lineres = null;
		try {
			url = inboundProperties.getResourceBaseServiceURL()
					+ ResourceConstants.resourceUpdateServiceUrl.UPDATELINEPLANCATEGORY.getServiceUrl();
			log.info("callLineResourceService URL::" + url);
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = requestGson.toJson(linePlan).getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = "";
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();

			if (StringUtils.hasText(outputString)) {
				Type userListType = new com.google.gson.reflect.TypeToken<ArrayList<LinePlan>>() {
				}.getType();
				lineres = requestGson.fromJson(outputString, userListType);
				log.info(lineres);
			}
		} catch (Exception e) {
			log.error("Exception - {}", e);
		} finally {
			if (conn != null) {
				conn.disconnect();
				conn = null;
			}
		}
		log.info("callLineResourceService :: outputString :: " + outputString);
		if (lineres == null) {
			lineres = linePlan;
		}
		return lineres;
	}
}
