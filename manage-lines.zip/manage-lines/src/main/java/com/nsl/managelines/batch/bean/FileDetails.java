package com.nsl.managelines.batch.bean;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FileDetails {

	

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("transationId")
	private String transationId;

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobType")
	private String jobType;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("transactionTimeStamp")
	private Date transactionTimeStamp;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobName")
	private String jobName;

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("reportType")
	private String reportType;

	@JsonProperty("templateQuery")
	private String templateQuery;

	@JsonProperty("reportsFile")
	private byte[] reportsFile;

	@JsonProperty("reportsFileName")
	private String reportsFileName;
	
	@JsonProperty("fileOperation")
	private String fileOperation;
	
	@JsonProperty("operationStatus")
	private String operationStatus;
	
	@JsonProperty("serviceId")
	private String serviceId;
	
	@JsonProperty("fileOperationStatus")
	private String fileOperationStatus;
	
	@JsonProperty("bcd")
	private String bcd;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
}
