package com.nsl.usagereport.postgres.repository;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

public interface NslDao {
	@Transactional
	public void save(List<Object> list) throws Exception;

}
