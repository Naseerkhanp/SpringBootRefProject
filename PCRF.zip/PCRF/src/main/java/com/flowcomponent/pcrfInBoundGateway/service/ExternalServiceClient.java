package com.flowcomponent.pcrfInBoundGateway.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.flowcomponent.pcrfInBoundGateway.constants.UtilityClass;
import com.flowcomponent.pcrfInBoundGateway.dao.TransactionDAO;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundProperties;
import com.flowcomponent.pcrfInBoundGateway.properties.InboundQueueProperties;

@Component
public class ExternalServiceClient {

	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;

	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	private UtilityClass utilityClass;

	Logger LOGGER = LoggerFactory.getLogger(ExternalServiceClient.class);

	/**
	 * Gets the response from client.
	 *
	 * @param requestJson the request json
	 * @param transId     the trans id
	 * @param responseId  the response id
	 * @return the response from client
	 */
	public String getResponseFromClient(String requestJson, String transId, String responseId, String serviceName,
			String operationName) {
		String request = null;
		String entityId = "0";
		String url = inboundProperties.getRouterserviceurl();
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.insertMNORequestDetails(requestJson, responseId);
			}
		});
		LOGGER.info(" responseId :: " + responseId);
		LOGGER.info(" serviceName :: " + serviceName + "***operationName ***" + operationName);
		request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
				+ "&transId=" + transId + "&responseId=" + responseId;
		LOGGER.info(" request :: " + request);
		String frameworkResponse = utilityClass.callRestAPI(request, url);
		LOGGER.info(" frameworkResponse :: " + frameworkResponse);
		String Id = frameworkResponse.substring(frameworkResponse.indexOf("~") + 1);
		String groupId = Id.substring(Id.indexOf("~") + 1);
		serviceName = groupId.substring(groupId.indexOf("~") + 1);
		groupId = groupId.substring(0, groupId.indexOf("~"));
		String processPlanId = Id.substring(0, Id.indexOf("~"));
		frameworkResponse = frameworkResponse.substring(0, frameworkResponse.indexOf("~"));
		asyncUpdateNorthBoundTransaction(transId, entityId, frameworkResponse, groupId, processPlanId, serviceName);
		return frameworkResponse;
	}

	/**
	 * Async update north bound transaction.
	 *
	 * @param responseId the response id
	 * @param entityId   the entity id
	 * @param respJson   the resp json
	 * @param grpId      the grp id
	 * @param processId  the process id
	 * @param servName   the serv name
	 */
	private void asyncUpdateNorthBoundTransaction(String responseId, String entityId, String respJson, String grpId,
			String processId, String servName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransaction(responseId + "", entityId, respJson, grpId, processId,
						servName);
			}
		});

	}

	
}
