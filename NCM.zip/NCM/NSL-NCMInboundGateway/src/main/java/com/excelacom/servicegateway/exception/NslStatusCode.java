package com.excelacom.servicegateway.exception;

import javax.ws.rs.core.Response.Status.Family;
import javax.ws.rs.core.Response.StatusType;

public class NslStatusCode implements StatusType {

	private int statusCode;
	
	private String reasonPhrase;
	
	@Override
	public int getStatusCode() {
		return statusCode;
	}

	@Override
	public Family getFamily() {
		switch (statusCode / 100) {
        case 1:
            return Family.INFORMATIONAL;
        case 2:
            return Family.SUCCESSFUL;
        case 3:
            return Family.REDIRECTION;
        case 4:
            return Family.CLIENT_ERROR;
        case 5:
            return Family.SERVER_ERROR;
        default:
            return Family.OTHER;
    }
	}

	@Override
	public String getReasonPhrase() {
		return reasonPhrase;
	}

	/**
	 * @param statusCode
	 * @param reasonPhrase
	 */
	public NslStatusCode(int statusCode, String reasonPhrase) {
		super();
		this.statusCode = statusCode;
		this.reasonPhrase = reasonPhrase;
	}	
}
