package com.nsl.usagereport.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.vfs2.FileObject;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.nsl.usagereport.transaction.entity.RefFileUpload;

public class UsageReportDetails {
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("transationId")
	public String transationId;

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobType")
	public String jobType;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("transactionTimeStamp")
	public Date transactionTimeStamp;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("jobName")
	public String jobName;

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("reportType")
	public String reportType;

	@JsonProperty("templateQuery")
	public String templateQuery;

	@JsonProperty("reportsFile")
	public byte[] reportsFile;

	@JsonProperty("reportsFileName")
	public String reportsFileName;

	@JsonProperty("fileOperation")
	public String fileOperation;

	@JsonProperty("operationStatus")
	public String operationStatus;

	@JsonProperty("serviceId")
	public String serviceId;

	@JsonProperty("fileOperationStatus")
	public String fileOperationStatus;

	@JsonProperty("csvDelimiter")
	public String csvDelimiter;

	@JsonProperty("userName")
	public String userName;

	@JsonProperty("password")
	public String password;

	@JsonProperty("sftpFolderPath")
	public String sftpFolderPath;

	@JsonProperty("host")
	public String host;

	@JsonProperty("port")
	public String port;

	@JsonProperty("fileType")
	public String fileType;
	
	@JsonProperty("fileFormat")
	public String fileFormat;

	@JsonProperty("sftpTargetPath")
	public String sftpTargetPath;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("userID")
	public String userID;

	List<ReportDetails> reportDetails = new ArrayList<ReportDetails>();

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public List<ReportDetails> getReportDetails() {
		return reportDetails;
	}

	public void setReportDetails(List<ReportDetails> reportDetails) {
		this.reportDetails = reportDetails;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	public String getTransationId() {
		return transationId;
	}

	public void setTransationId(String transationId) {
		this.transationId = transationId;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public Date getTransactionTimeStamp() {
		return transactionTimeStamp;
	}

	public void setTransactionTimeStamp(Date transactionTimeStamp) {
		this.transactionTimeStamp = transactionTimeStamp;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getTemplateQuery() {
		return templateQuery;
	}

	public void setTemplateQuery(String templateQuery) {
		this.templateQuery = templateQuery;
	}

	public byte[] getReportsFile() {
		return reportsFile;
	}

	public void setReportsFile(byte[] reportsFile) {
		this.reportsFile = reportsFile;
	}

	public String getReportsFileName() {
		return reportsFileName;
	}

	public void setReportsFileName(String reportsFileName) {
		this.reportsFileName = reportsFileName;
	}

	public String getFileOperation() {
		return fileOperation;
	}

	public void setFileOperation(String fileOperation) {
		this.fileOperation = fileOperation;
	}

	public String getOperationStatus() {
		return operationStatus;
	}

	public void setOperationStatus(String operationStatus) {
		this.operationStatus = operationStatus;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getFileOperationStatus() {
		return fileOperationStatus;
	}

	public void setFileOperationStatus(String fileOperationStatus) {
		this.fileOperationStatus = fileOperationStatus;
	}

	public String getCsvDelimiter() {
		return csvDelimiter;
	}

	public void setCsvDelimiter(String csvDelimiter) {
		this.csvDelimiter = csvDelimiter;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSftpFolderPath() {
		return sftpFolderPath;
	}

	public void setSftpFolderPath(String sftpFolderPath) {
		this.sftpFolderPath = sftpFolderPath;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}
	
	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	
	public String getSftpTargetPath() {
		return sftpTargetPath;
	}

	public void setSftpTargetPath(String sftpTargetPath) {
		this.sftpTargetPath = sftpTargetPath;
	}

}
