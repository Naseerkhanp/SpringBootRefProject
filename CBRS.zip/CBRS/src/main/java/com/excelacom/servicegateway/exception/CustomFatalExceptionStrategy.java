package com.excelacom.servicegateway.exception;

import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;

public class CustomFatalExceptionStrategy extends ConditionalRejectingErrorHandler.DefaultExceptionStrategy {
	
	
	
	public CustomFatalExceptionStrategy() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isFatal(Throwable t) {
		return !(t.getCause() instanceof NslCustomException);
	}
}
