package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.annotation.CreatedDate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity(name = "ResourceInfoEntity")
@Table(name = "RESOURCE_INFO")
@ToString
public class ResourceInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESOURCE_ID")
	private Long resourceId;

	@Column(name = "RESOURCE_TYPE")
	private String resourceType;

	@Column(name = "RESOURCE_VALUE")
	private String resourceValue;

	@Column(name = "AVAILABILITY")
	private String availability;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "ALLOCATED_DATE")
	private Date allocatedDate;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createdDate = new java.sql.Date(new java.util.Date().getTime());;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "RELEASED_DATE")
	private Date releasedDate;

	@Column(name = "EXTERNAL_VALUE_1")
	private String externalValue1;

	@Column(name = "EXTERNAL_VALUE2")
	private String externalValue2;

	@Column(name = "RESOURCE_SUBTYPE")
	private String resourceSubtype;

	@Column(name = "IS_BLACKLIST")
	private String isBlacklist;

	@Column(name = "BLACKLIST_TYPE")
	private String blacklistType;

	@Transient
	private String errorCode;

	@Transient
	private String errorMsg;

}
