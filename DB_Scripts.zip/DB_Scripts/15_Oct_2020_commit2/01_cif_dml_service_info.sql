spool 01_cif_dml_service_info.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;  

UPDATE SERVICE_INFO SET SERVICE_URL = 'http://mobile-1-2-stub-service:8084/api/activate/subscriber' where SERVICE_NAME='DeviceInquiry_URL' AND SERVER = 'NSL_UPG';
UPDATE SERVICE_INFO SET SERVICE_URL = 'http://mobile-1-2-stub-service:8084/api/activate/subscriber' where SERVICE_NAME='DeviceInquiryAync_URL' AND SERVER = 'NSL_UPG';
UPDATE SERVICE_INFO SET SERVICE_URL = 'http://mobile-1-2-stub-service:8084/api/hotline/subscriber' where SERVICE_NAME='MNOPortInInquiry_URL' AND SERVER = 'NSL_UPG';

DELETE FROM service_info WHERE SERVICE_NAME='MNOPortInInquiry_URL' AND SERVICE_URL = 'http://mobile-2-0-stub-service:9999/api/hotline/subscriber';

commit;
spool off;
