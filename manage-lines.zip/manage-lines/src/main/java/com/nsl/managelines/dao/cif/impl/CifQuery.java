/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

/**
 * @author Dhayanand.B
 *
 */
public class CifQuery {

	public static final String GET_BATCH_SEQ = "SELECT SEQ_BATCH_ID.nextval from dual";

}
