package com.nsl.managelines.dao.cif.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.managelines.dao.cif.entity.BatchTransaction;

@Repository
public interface BatchTransactioRepository extends CrudRepository<BatchTransaction, Long> {

	@Query("Select count(1) from BatchTransaction b where b.externalValue1=:externalValue1")
	int findCountByExternalValue1(@Param("externalValue1") String externalValue1);

}
