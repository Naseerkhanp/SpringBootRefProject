package com.nsl.usagereport.batch;

import java.io.FileNotFoundException;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.vfs2.FileFilterSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSelector;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.filter.RegexFileFilter;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.cif.entity.TransactionFileLog;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.ReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class NslBatchReader implements ItemReader<UsageReportDetails>, StepExecutionListener {
	Map<String, Object> jobParameters;
	@Autowired
	NslDataHandler nslDataHandler;
	@Autowired
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl;
	@Autowired
	private JobOperator jobOperator;
	private StepExecution stepExecution;
	private Map<String, Map<Object, Long>> statusMap = null;

	public NslBatchReader(Map<String, Object> jobParameters) {
		this.jobParameters = jobParameters;
	}

	@Override
	public UsageReportDetails read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		log.info(this.getClass() + "read start ");
		Gson gson = new Gson();
		String json = (jobParameters.get("usageReport").toString());
		log.info(json + "read json ");
		/*
		 * json=json.replace("[", "<"); json=json.replace("]", ">");
		 * json=json.replace(",", "+");
		 */
		JsonReader reader = new JsonReader(new StringReader(json.trim()));
		reader.setLenient(true);
		UsageReportDetails usageReportDetails = gson.fromJson(reader, UsageReportDetails.class);
		/*
		 * if (usageReportDetails.getSftpFolderPath() != null) {
		 * usageReportDetails.setSftpFolderPath(usageReportDetails.getSftpFolderPath().
		 * replace("|", "/")); } if (usageReportDetails.getSftpTargetPath() != null) {
		 * usageReportDetails.setSftpTargetPath(usageReportDetails.getSftpTargetPath().
		 * replace("|", "/")); } if (usageReportDetails.getFileFormat() != null) {
		 * usageReportDetails.setFileFormat(usageReportDetails.getFileFormat().replace(
		 * "<", "["));
		 * usageReportDetails.setFileFormat(usageReportDetails.getFileFormat().replace(
		 * ">", "]")); }
		 */
		downloadFromSFTP(usageReportDetails);
		log.info(this.getClass() + " read end");
		if (usageReportDetails.getReportDetails() != null && usageReportDetails.getReportDetails().size() > 0) {
			return usageReportDetails;
		}
		return null;
	}

	@Retryable(value = { FileSystemException.class }, maxAttempts = 3)
	public void downloadFromSFTP(UsageReportDetails usageReportDetails) throws Exception, FileSystemException {
		log.info(this.getClass() + " Connecting to SFTP.... ");
		String getfilesurl = null;
		StandardFileSystemManager manager = new StandardFileSystemManager();

		try {

			try {
				manager.init();
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze VFS ::", e);
				throw new FileSystemException(" Internal Error: Unable to iniatilze VFS ::", e.getCause());
			}
			FileSystemOptions opts = new FileSystemOptions();

			try {
				SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			} catch (FileSystemException e) {
				log.error(this.getClass() + " Internal Error: Unable to iniatilze StrictHostKeyChecking ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException(" Internal Error: Unable to iniatilze StrictHostKeyChecking ::",
						e.getCause());
			}
			SftpFileSystemConfigBuilder.getInstance().setConnectTimeoutMillis(opts, 100000);
			String host = usageReportDetails.getHost();
			String user = usageReportDetails.getUserName();
			String password = usageReportDetails.getPassword();
			String port = usageReportDetails.getPort();
			String url = usageReportDetails.getSftpFolderPath();

			StaticUserAuthenticator auth = new StaticUserAuthenticator(host, user, password);
			try {
				DefaultFileSystemConfigBuilder.getInstance().setUserAuthenticator(opts, auth);
			} catch (Exception e) {
				log.error(this.getClass() + " Internal Error: Invalid SFTP Details ::", e);
				if (manager != null) {
					manager.close();
				}
				throw new FileSystemException("  Internal Error: Invalid SFTP Details ::", e.getCause());
			}
			// TODO need to Remove
			String sftpurl = "sftp://" + user + ":" + password + "@" + host + "/" + url + "/"
					+ usageReportDetails.getReportsFileName();

			try {
				getfilesurl = "sftp://" + host + ":" + port + "/" + url + "/";
				manageUsageReportDetails(manager, getfilesurl, opts, usageReportDetails);

			} catch (Exception e) {
				log.error(this.getClass() + " Error RemotefileDeatils ::", e);
				jobOperator.stop(this.stepExecution.getJobExecutionId());
				throw new FileSystemException("  Internal Error: Error RemotefileDeatils ::", e.getCause());
			}

		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::", e);
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}

	}

	/*
	 * below method used for download data from the file from sftp
	 */
	public void manageUsageReportDetails(StandardFileSystemManager manager, String getfilesurl, FileSystemOptions opts,
			UsageReportDetails usageReportDetails) throws Exception {
		log.info(this.getClass() + " manageUsageReportDetails method called .");
		FileObject remoteFile = null;
		FileObject folderPath = null;
		FileObject[] fileObjectArray = null;
		String fileName = NslFileUploadConstants.EMPTY;
		TransactionFileLog transactionFileLog = null;
		String reportFormat =NslFileUploadConstants.EMPTY;
		String featureCodeArr[];	
		try {
			folderPath = manager.resolveFile(getfilesurl, opts);			
			DateFormat format = new SimpleDateFormat("yyyyddMM");
			format.setLenient(false);
			Date date = new Date();
			String sysDate = format.format(date);
			if (usageReportDetails.getFileFormat() != null) {
			reportFormat=usageReportDetails.getFileFormat();
			}					
			for(int i=0;i<=4;i++) {
				if (reportFormat.contains("_")) {
					featureCodeArr = reportFormat.split("_");
					String bill_period = featureCodeArr[1];
					if(reportFormat.contains(bill_period)) {
						reportFormat=reportFormat.replace(bill_period, sysDate);	
					}
				}
				if (NslFileUploadConstants.CBRS.equalsIgnoreCase(usageReportDetails.getFileType())
						|| NslFileUploadConstants.PRR_FILE.equalsIgnoreCase(usageReportDetails.getFileType())) {
					fileObjectArray = folderPath
							.findFiles((FileSelector) new FileFilterSelector(new RegexFileFilter(reportFormat)));
				} else {
					fileObjectArray = folderPath.getChildren();
				}			
			for (FileObject fileObj : fileObjectArray) {
				fileName = fileObj.getName().getBaseName();
				log.info("File Name ::" + fileName);					
						
				String extension = fileName.substring(fileName.lastIndexOf(NslFileUploadConstants.DOT));
				//if (NslFileUploadConstants.EXTENSION.equalsIgnoreCase(extension)) {
					transactionFileLog = transactionFileLogDaoImpl.findByFileName(fileName);
					log.info(fileName + " file not found in DB.....Stareded ahead on Download part....");
					/*
					 * if ((NslFileUploadConstants.CBRS).equalsIgnoreCase(usageReportDetails.
					 * getFileType()) ||
					 * (NslFileUploadConstants.PRR_FILE).equalsIgnoreCase(usageReportDetails.
					 * getFileType())) { log.info(fileName + " Inside filetype...."); if
					 * (fileName.matches(NslFileUploadConstants.FILE_FORMAT)) {
					 * log.info(" TRUE FILEFORMAT::::::");
					 * log.info("FILEFORMAT::::::"+inboundprop.getAcctype()); // File format
					 * validations// //String featureCodeArr[]; if (fileName.contains("_")) {
					 * featureCodeArr = fileName.split("_"); // for (int j = 1; j <
					 * featureCodeArr.length; j++) { String account_number = featureCodeArr[2]; if
					 * (inboundprop.getAcctype().equalsIgnoreCase(account_number)) {
					 * log.info(account_number + " CBRS_ACC....");
					 * usageReportDetails.setFileType(NslFileUploadConstants.CBRS); } else {
					 * log.info(account_number + " PRR_ACC....");
					 * usageReportDetails.setFileType(NslFileUploadConstants.PRR_FILE); } // } } } }
					 */				
					if (transactionFileLog != null) {
						if (transactionFileLog.getStatus()
								.equalsIgnoreCase(NslFileUploadConstants.PARSED_STATUS_FAILED)) {
							remoteFile = manager.resolveFile(getfilesurl + fileObj.getName().getBaseName(), opts);
							if (remoteFile == null) {
								transactionFileLogDaoImpl.updateTransactionDetails(
										NslFileUploadConstants.PARSED_STATUS_FAILED, NslFileUploadConstants.FAILURECODE,
										NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE,
										fileName, statusMap, "FileNotFoundException",usageReportDetails,null);
								throw new FileNotFoundException();
							}
							log.info(this.getClass() + " file downloaded from sftp server .");
							saveTransactionDetails(usageReportDetails, fileName, extension,
									NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
							List<ReportDetails> reportDetailsLST = usageReportDetails.getReportDetails();
							ReportDetails reportDetails = new ReportDetails();
							reportDetails.setFileObject(fileObj);
							reportDetailsLST.add(reportDetails);
							usageReportDetails.setReportDetails(reportDetailsLST);
						}
					} else if (transactionFileLog == null) {
						remoteFile = manager.resolveFile(getfilesurl + fileObj.getName().getBaseName(), opts);
						if (remoteFile == null) {
							transactionFileLogDaoImpl.updateTransactionDetails(
									NslFileUploadConstants.PARSED_STATUS_FAILED, NslFileUploadConstants.FAILURECODE,
									NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE, fileName,
									statusMap, "FileNotFoundException",usageReportDetails,null);
							throw new FileNotFoundException();
						}
						log.info(this.getClass() + " file downloaded from sftp server .");
						saveTransactionDetails(usageReportDetails, fileName, extension,
								NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
						List<ReportDetails> reportDetailsLST = usageReportDetails.getReportDetails();
						ReportDetails reportDetails = new ReportDetails();
						reportDetails.setFileObject(fileObj);
						reportDetailsLST.add(reportDetails);
						usageReportDetails.setReportDetails(reportDetailsLST);
					}
				}
			Date date6 = format.parse(sysDate);
			Date oneDayBefore = new Date(date6.getTime()-1);
	        sysDate = format.format(oneDayBefore);
	        System.out.println("sysDate in promotion::::::::" + sysDate);
		}/*
					 * else { log.info(fileName+"Invalid format .");
					 * transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.
					 * PARSED_STATUS_FAILED, NslFileUploadConstants.FAILURECODE,
					 * NslFileUploadConstants.FAILURECODE, NslFileUploadConstants.FAILURECODE,
					 * fileName, statusMap, "ERR05 – Fileformat is invalid");
					 * log.error(this.getClass() + " Unsupported file Format::");
					 * jobOperator.stop(this.stepExecution.getJobExecutionId()); }
					 */
			//}
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to download to SFTP ::" + e);
			if (manager != null) {
				manager.close();
			}
			jobOperator.stop(this.stepExecution.getJobExecutionId());
			throw new Exception("  Internal Error: Unable to download to SFTP ::", e.getCause());
		} finally {
			if (manager != null)
				manager.close();
		}
	}

	public void saveTransactionDetails(UsageReportDetails usageReportDetails, String fileName, String extension,
			String status) {
		transactionFileLogDaoImpl.saveTransactionDetails(usageReportDetails, fileName, extension, status);
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.stepExecution = stepExecution;

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}

}
