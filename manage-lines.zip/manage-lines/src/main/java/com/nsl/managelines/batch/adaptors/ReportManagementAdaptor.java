/**
 * 
 */
package com.nsl.managelines.batch.adaptors;

import java.util.ArrayList;
import java.util.Map;
import com.nsl.managelines.batch.bean.RequestBean;
import com.nsl.managelines.batch.bean.ReportMgmtRequest;
import com.nsl.managelines.batch.bean.FileDetails;
import com.nsl.managelines.batch.bean.FileOperationRequest;
import com.nsl.managelines.batch.properties.InboundProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import com.nsl.managelines.batch.constants.UtilityClass;
import com.google.gson.Gson;
import lombok.extern.log4j.Log4j2;

/**
 * @author Vinothini.T
 *
 */
@Log4j2
@Component
public class ReportManagementAdaptor {

	@Autowired
	private UtilityClass utilityClass;

	@Autowired
	private InboundProperties inboundProperties;

	public String invokeReportManagementAPI(final ReportMgmtRequest reportMgmtRequest) {
		log.info("Inside invokeFileOperationAPI");
		String response = null;
		try {
			String reportMgmtRequestJson = new Gson().toJson(reportMgmtRequest, ReportMgmtRequest.class);
			response = utilityClass.callRestAPI(reportMgmtRequestJson,
					inboundProperties.getGenerateReportManagement(), null);
		} catch (Exception e) {
			log.error("Exception invokeReportManagementAPI::", e);
		}
		return response;
	}

}
