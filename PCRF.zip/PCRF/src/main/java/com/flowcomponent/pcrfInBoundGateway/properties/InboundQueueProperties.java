package com.flowcomponent.pcrfInBoundGateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("inboundservice")
@Configuration
@Getter
@Setter
public class InboundQueueProperties {

	private String rabbitListenerContainer;

	private String getPcrfQueue;

	private String getPcrfExchange;

	private String deletePcrfQueue;
	
	private String deletePcrfExchange;
	
	private String createPcrfQueue;
	
	private String createPcrfExchange;
	
	private String updatePcrfQueue;
	
	private String updatePcrfExchange;

}
