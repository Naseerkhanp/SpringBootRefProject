package com.excelacom.servicegateway.consumer;

import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;
import com.excelacom.servicegateway.service.ExternalServiceClient;

/**
 * The Class In-bound Mobile2.0 Message Consumer.
 */
@Component
public class InboundNcmMessageConsumer {

	/** The transaction service. */
	@Autowired
	private ExternalServiceClient externalServiceClient;

	/** The transaction dao. */
	@Autowired
	TransactionDAO transactionDAO;

	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;
	
	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	/** The logger. */
	Logger LOGGER = LoggerFactory.getLogger(InboundNcmMessageConsumer.class);
	
	//String containerFactoryurl =inboundQueueProperties.getCustomSimpleRabbitListenerContainer();
	
	/**
	 * Line inquiry method.
	 *
	 * @param msg the msg
	 * @return the message
	 */
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getSpeedTestQueue()}", containerFactory = "getSpeedTestrabbitListenerContainerFactory")
	public Message ncmSpeedTestsSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.NCM_SERVICE_NAME;
		String transId = null;
		String request =null;
	    String operationName = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMSpeedTestsIntegrationService",Constants.NCM);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GET Speed Tests");
				operationName = Constants.NCM_GET_OPERATION_NAME;
			} 
			request = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"nslParamSMB");
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	
	@RabbitListener(queues = "#{inboundQueueProperties.getDeleteSpeedTestQueue()}", containerFactory = "deleteSpeedTestrabbitListenerContainerFactory")
	public Message ncmDeleteSpeedTestsSystemCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String serviceName = Constants.NCM_SERVICE_NAME;;
		UUID uuid = null;
		String responseId = null;
		String operationName = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod = "DELETE";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,"NCMSpeedTestsIntegrationService",Constants.NCM);	
			if (Constants.HTTP_DELETE.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside Delete Speed Tests");
				operationName = Constants.NCM_DELETE_OPERATION_NAME;
			}
			
			exchange = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, httpmethod, entityId);
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getGetConfigManagerQueue()}",containerFactory = "configManagerrabbitListenerContainerFactory")
	public Message ncmConfigManagerSystemCall(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.CONFIG_SERVICE_PROCESS_PLAN;
		UUID uuid = null;
		String responseId = null;
		String operationName = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			String httpmethod = "GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMConfigMangerService",Constants.NCM);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside Get config");
				operationName = Constants.CONFIG_GET_WORK_FLOW;
			}
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
			} catch (Exception e) {
			
			LOGGER.error("Exception in ncmConfigManagerSystemCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmDeviceAppIntegrationQueue()}" ,containerFactory = "deviceAppsIntegrationrabbitListenerContainerFactory")
	public Message ncmDeviceAppsSystemCallResponse(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		String groupId = null;
		String serviceName = Constants.PRODUCT_SERVICE_PROCESS_PLAN;
		UUID uuid = null;
		String responseId = null;
		String operationName = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
			String httpmethod="GET";
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMDeviceAppsIntegrationService",Constants.NCM);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpmethod)) {
				LOGGER.info("Inside GEt Product");
				operationName = Constants.PRODUCT_GET_WORK_FLOW;
			}
			exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, httpmethod,entityId);
			LOGGER.info("response::" + response + "groupId::" + groupId);
			} catch (Exception e) {
			LOGGER.error("Exception in ncmDeviceAppsSystemCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getNcmNetDeviceHealthIntegrationQueue()}",containerFactory = "netDeviceHealthrabbitListenerContainerFactory")
	public Message ncmGetNetDeviceHealthIntegrationCallResponse(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = Constants.NETDEVICE_HEALTH_PROCESS_PLAN;
		UUID uuid = null;
		String responseId = null;
		String operationName = null;
		try {
			String httpMethod = "GET";
			byte[] body = msg.getBody();
			String exchange = new String(body);
			LOGGER.info(exchange);
		
			System.out.println("Transaction Type::" + httpMethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId,"NcmNetDeviceHealthIntegration",Constants.NCM);
			if (Constants.HTTP_GET.equalsIgnoreCase(httpMethod)) {
				LOGGER.info("Inside Get Net device Health Integration");
				operationName = Constants.NETDEVICE_HEALTH_WORK_FLOW;
			} else {
				LOGGER.info("Didnt get Transcation Type");
			}
			exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId, httpMethod,entityId);
			
		} catch (Exception e) {
			LOGGER.error("Exception in ncmGetNetDeviceHealthIntegrationCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmproductIntegrationQueue()}", containerFactory = "productsIntegrationrabbitListenerContainerFactory")
	public Message productIntegrationServiceCall(Message msg) {
		LOGGER.info("Inside productIntegrationServiceCall method::::");
		String response = null;		
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		String serviceName ="NCMProductIntegration";
		String operationName = "NcmGetProductWorkflow";
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			UUID uuid = UUID.randomUUID();
			transId = uuid.toString();	
			LOGGER.info("Request  ::::" + exchange); 
									
			String responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMProductIntegrationService", Constants.NCM);
			exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId,httpMethod,entityId);
					
		} catch (Exception e) {
			LOGGER.error("Exception in ncmProductSystemCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNetDeviceIntegrationQueue()}", containerFactory = "netDeviceIntegrationrabbitListenerContainerFactory")
	public Message netDeviceIntegrationServiceCall(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String httpMethod=Constants.HTTP_GET;
		String serviceName = Constants.NETDEVICE_SERVICE_PROCESS_PLAN;	
		String operationName = Constants.NETDEVICE_GET_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMNetDeviceIntegrationService", Constants.NCM);
			exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId,httpMethod,entityId);
			
		} catch (Exception e) {
			LOGGER.error("Exception in netDeviceIntegrationServiceCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNetDeviceMetricsQueue()}", containerFactory = "netdevicemetricsrabbitListenerContainerFactory")
	public Message netDeviceMetricsServiceCall(Message msg) {
		LOGGER.info("Inside netDeviceMetricsServiceCall method::::");
		String response = null;
		
		String entityId = "0";
		String transId = null;
		String httpMethod = "GET";
		String serviceName = "NCMNetDeviceMetrics";
		String operationName = null;
		operationName = "NCMNetDeviceMetricsGetWF";
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			UUID uuid = UUID.randomUUID();
			transId = uuid.toString();
			String responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMNetDeviceMetrics",Constants.NCM);
			exchange = constructRequestJson(exchange, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId,httpMethod,entityId);			
		} catch (Exception e) {
			LOGGER.error("Exception in ncmProductSystemCall" + e.getMessage());
		}	
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmNetDeviceSampleQueue()}", containerFactory = "netDeviceUsageSamplesrabbitListenerContainerFactory")
	  public Message ncmNetDeviceUsageSampleCallResponse(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = Constants.NET_DEVICE_USAGE_SAMPLE_SERVICE_PROCESS_PLAN;
		String operationName = null;
		String httpMethod = "GET";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Final Request  ::::" + request);
			String httpmethod = Constants.HTTP_GET;
			System.out.println("Transaction Type::" + httpmethod);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			String applicationName = Constants.NCM;
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMNetDeviceUsageSampleService",
					 applicationName);
			this.asyncinsertMNORequestDetails(request, responseId);
			 if (Constants.HTTP_GET.equalsIgnoreCase(httpMethod)) {
					LOGGER.info("Inside Get");
					operationName = Constants.NET_DEVICE_USAGE_SAMPLE_GET_WORK_FLOW;
				}  else {
					LOGGER.info("Didnt get Tarnscation Type");
				}
			 request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod, entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmNetDeviceUsageSampleCall" + e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getNcmGroupDeleteQueue()}", containerFactory = "ncmGroupDeleterabbitListenerContainerFactory")
	  public Message ncmGroupSystemCallResponse(Message msg) {
			String response = null;
			String entityId = "0";
			String transId = null;
			String serviceName = Constants.GROUP_SERVICE_PROCESS_PLAN;
			String operationName = null;
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);
				LOGGER.info("Final Request  ::::" + request);
				String httpmethod = Constants.HTTP_DELETE;
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				String applicationName = Constants.NCM;
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMGroupIntegrationService",
						 applicationName);
				this.asyncinsertMNORequestDetails(request, responseId);
				if (Constants.HTTP_DELETE.equalsIgnoreCase(httpmethod)) {
					LOGGER.info("Inside Delete Account");
					operationName = Constants.GROUP_DELETE_WORK_FLOW;
				}
				request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
				response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpmethod, entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmGroupSystemCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
					.build();
		}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmAccountGetQueue()}", containerFactory = "ncmAccountGetrabbitListenerContainerFactory")
	  public Message ncmAccountSystemCallResponse(Message msg) {
		LOGGER.info("ncmAccountSystemCallResponse");
			String response = null;
			String entityId = "0";
			String transId = null;
			UUID uuid = null;
			String responseId = null;
			String serviceName = Constants.ACCOUNT_SERVICE_PROCESS_PLAN;
			String operationName = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);
				String httpMethod = Constants.HTTP_GET;
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMAccountIntegrationService",
						 "NCM");
				this.asyncinsertMNORequestDetails(request, responseId);
				 if (Constants.HTTP_GET.equalsIgnoreCase(httpMethod)) {
					LOGGER.info("Inside GEt ACcount");
					operationName = Constants.ACCOUNT_GET_WORK_FLOW;
				}
				 request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
							+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
				response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod,entityId);
				LOGGER.info(response);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmAccountSystemCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
					.build();
		}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmAccountDeleteQueue()}", containerFactory = "ncmAccountDeleterabbitListenerContainerFactory")
	  public Message ncmAccountDeleteSystemCallResponse(Message msg) {
			String response = null;
			String entityId = "0";
			String transId = null;
			String serviceName = Constants.ACCOUNT_SERVICE_PROCESS_PLAN;
			String operationName = null;
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);
				LOGGER.info("Final Request  ::::" + request);
				String httpMethod = "DELETE";
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				String applicationName = Constants.NCM;
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMAccountIntegrationService",
						 applicationName);
				this.asyncinsertMNORequestDetails(request, responseId);
				if (Constants.HTTP_DELETE.equalsIgnoreCase(httpMethod)) {
					LOGGER.info("Inside Delete Account");
					operationName = Constants.ACCOUNT_DELETE_WORK_FLOW;
				} 
				request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
				response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod,entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmAccountSystemCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
					.build();
		}

	@RabbitListener(queues = "#{inboundQueueProperties.getNcmDeviceAppsStateServiceQueue()}", containerFactory = "ncmDeviceAppsStaterabbitListenerContainerFactory")
	public Message ncmDeviceAppsStateServiceCall(Message msg) {
		LOGGER.info("Inside ncmDeviceAppsStateServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String serviceName = "NCMDeviceAppStateIntegeration";
		String operationName = "NCMDeviceAppStateGetWF";
		UUID uuid = null;
		String responseId = null;
		String transaction_name="NCMDeviceAppStatesIntegrationService";
		String application_Name=Constants.NCM;
		String httpMethod=Constants.HTTP_GET;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, transaction_name,application_Name);		
			responseId = transactionDAO.insertMNORequestDetails(request, responseId);
			//request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			LOGGER.info(" responseId :: " + responseId);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmDeviceAppsIntegrationServiceCall" +
			 e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmGetRouterStateServiceQueue()}", containerFactory = "ncmGetRouterStaterabbitListenerContainerFactory")
	public Message ncmGetRouterStateServiceCall(Message msg) {
		LOGGER.info("Inside ncmGetRouterStateServiceCall");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		String serviceName = Constants.SERVICENAME;
		String operationName = Constants.OPERATIONNAME;
		UUID uuid = null;
		String responseId = null;
		String transaction_name="NCMGetRouterStateService";
		String application_Name=Constants.NCM;

		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, transaction_name,application_Name);
			this.asyncinsertMNORequestDetails(request, responseId);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod,entityId);
		} catch (Exception e) {
				LOGGER.error("Exception in NCMGetRouterStateService" +e.getMessage());
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getDeleteLocationServiceQueue()}", containerFactory = "ncmDeleteLocationrabbitListenerContainerFactory")
	public Message DeleteLocationResponse(Message msg) {
	String response = null;
	String entityId = Constants.STRING_ZERO;
	String serviceName = "NCMLocationsIntegeration";
	String operationName = "NCMDeleteLocationWF";
	String applicationName = Constants.NCM;
	String transId = null;
	UUID uuid = null;
	String responseId = null;
	try {
		byte[] body = msg.getBody();
		String request = new String(body);
		String httpmethod = Constants.HTTP_DELETE;
		uuid = UUID.randomUUID();
		transId = uuid.toString();
		responseId = transactionDAO.insertNorthBoundTransaction(request,entityId,transId,"NCMLocationIntegrationService",applicationName);
		request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
		response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod, entityId);
		
	} catch (Exception e) {
		LOGGER.error("Exception in ncmCreateSubAccountSystemCall" + e.getMessage());
	}
	if(response==null) {
		 response = "";
	}
	return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();

}

	@RabbitListener(queues = "#{inboundQueueProperties.getRouterLogsQueue()}", containerFactory = "ncmRouterLogsrabbitListenerContainerFactory")
	public Message RouterLogsServiceResponse(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String serviceName = Constants.ROUTER_LOGS_PROCESS_PLAN;
		String operationName = Constants.ROUTER_LOGS_WORK_FLOW;;
		String applicationName = Constants.NCM;
		String transId = null;
		String responseId = "";
		UUID uuid = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String httpmethod = Constants.HTTP_GET;
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request,entityId,transId,"NcmRouterLogsIntegration",applicationName);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		} catch (Exception e) {
			LOGGER.error( e.getMessage(),e);
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
			
	@RabbitListener(queues = "#{inboundQueueProperties.getLocationServiceQueue()}", containerFactory = "ncmLocationServicerabbitListenerContainerFactory")
	public Message GetLocationResponse(Message msg) {
	
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String applicationName = Constants.NCM;
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "NCMLocationsIntegeration";
		String operationName = "NCMLocationsGetWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String httpmethod = "GET";
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request,entityId,transId,"NCMLocationIntegrationService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(),e);
		}
		if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	
	}
	
		@RabbitListener(queues = "#{inboundQueueProperties.getNcmFirmwareQueue()}", containerFactory = "ncmFirmwarerabbitListenerContainerFactory")
		public Message ncmFirmwareServiceCall(Message msg) {
			LOGGER.info("Inside ncmFirmwareServiceCall::::");	
			String response = null;
			String transId = null;
			String applicationName = "NCM";
			String serviceName = "NcmFirmwareService";
			String operationName = "NcmFirmwareGetWF";	
			String entityId = "0";
			String httpMethod=Constants.HTTP_GET;
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);				
				LOGGER.info("Final Request  ::::" + request);
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "GetNcmFirmware",applicationName);
				request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
				response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod, entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmSignalSampleSystemCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();			
		}
		
		@RabbitListener(queues = "#{inboundQueueProperties.getNcmnetdeviceusagesampleserviceQueue()}", containerFactory = "ncmDeviceusagesamplerabbitListenerContainerFactory")
		public Message ncmNetDeviceUsageSampleServiceCall(Message msg) {
			String response = null;
			String entityId = "0";
			String httpMethod = Constants.HTTP_GET;
			String transId = null;
			String serviceName = Constants.NET_DEVICE_USAGE_SAMPLE_SERVICE_PROCESS_PLAN;
			String operationName = Constants.NET_DEVICE_USAGE_SAMPLE_GET_WORK_FLOW;
			String applicationName = null;
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);			
				LOGGER.info("Final Request  ::::" + request);
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				applicationName = Constants.NCM;
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMNetDeviceUsageSampleService",applicationName);
				request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
				response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmNetDeviceUsageSampleCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		}

		@RabbitListener(queues = "#{inboundQueueProperties.getNcmLocationServiceCreateQueue()}", containerFactory = "ncmLocationServiceCreaterabbitListenerContainerFactory")
		public Message ncmLocationServiceCreateCall(Message msg) {

			String response = null;
			String entityId = Constants.STRING_ZERO;
			String transId = null;
			String httpMethod=Constants.HTTP_POST;
			String applicationName = Constants.NCM;
			String serviceName = "NCMLocationsIntegeration";
			String operationName = "NCMLocationsPostWF";
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);					
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMLocationIntegrationService",applicationName);
				request = constructRequestJson(request, serviceName, operationName, transId, responseId,"smbCreateLocationRule");
				response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
				} catch (Exception e) {
				LOGGER.error("Exception in ncmCreateSubAccountSystemCall" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		}
	
		@RabbitListener(queues = "#{inboundQueueProperties.getNcmPushNotificationQueue()}", containerFactory = "pushnotificationrabbitListenerContainerFactory")
		public Message ncmPushNotification(Message msg) {
			LOGGER.info("Inside ncmPushNotification Consumer");
			String response = null;
			String httpMethod=Constants.HTTP_POST;
			String applicationName = Constants.NCM;
			String responseId = null;
			try {
			
				byte[] body = msg.getBody();
				String request = new String(body);	
				responseId = transactionDAO.insertEventNotificationTransaction(request);
				LOGGER.error("ncmPushNotification responseId :"+responseId);
				response = Constants.Response;
				/*JSONObject jsb = new JSONObject(response);
				JSONObject jsb1 = new JSONObject();
				jsb1 = jsb.getJSONObject("data");
				if(jsb1.has("transactionId"))
				{
					jsb1.put("transactionId", responseId);
				}*/
				response = response.replaceAll("EventId", responseId);
				LOGGER.info("out ncmPushNotification Consumer with response :");
				} catch (Exception e) {
				LOGGER.error("Exception in ncmPushNotification" + e.getMessage());
			}
			if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		}
		
	@RabbitListener(queues = "#{inboundQueueProperties.getRouterStreamUsageSamplesIntegrationQueue()}", containerFactory = "ncmRouterStreamUsageSamplesrabbitListenerContainerFactory")
	public Message ncmRouterStreamUsuageSampleServiceCall(Message msg) {
		LOGGER.info("Inside ncmFirmwareServiceCall::::");	
		String response = null;
		String transId = null;
		String serviceName = "NCMRouterStreamUsageSample";
		String operationName = "NCMRouterStreamUsageGetWF";
		String applicationName = Constants.NCM;
		String entityId = "0";
		String httpMethod=Constants.HTTP_GET;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Final Request  ::::" + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMRouterStreamUsageSamplesIntegrationService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmSignalSampleSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getNcmRoutersallertsIntegrationQueue()}", containerFactory = "routersAllertsrabbitListenerContainerFactory")
	public Message ncmRoutersAllertsIntegrationCall(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info("Final Request  ::::" + request);
			String httpMethod = "GET";
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,"NcmRoutersAllertsIntegration",Constants.NCM);
			
			String serviceName = Constants.ROUTERS_ALLERT_PROCESS_PLAN;
			String operationName = null;

			if (Constants.HTTP_GET.equalsIgnoreCase(httpMethod)) {
				LOGGER.info("Inside Get Routers Alert Integration");
				operationName = Constants.ROUTERS_ALLERT_WORK_FLOW;
			} else {
				LOGGER.info("Didnt get Transcation Type");
			}
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmRoutersAllertsIntegrationCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmGetGroupServiceQueue()}", containerFactory = "GetGroupServicerabbitListenerContainerFactory")
	public Message ncmGetGroupServiceCall(Message msg){ 
		LOGGER.info("Inside ncmGetGroupServiceCall method::::");
		String response = null;
	    String entityId = "0";
		String transId = null;
		String httpMethod=Constants.HTTP_GET;
		String operationName = "NCMGetGroupWF";
		String serviceName = "NCMGroupIntegration";	
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			LOGGER.info("serviceName:::"+serviceName+"operationName::"+operationName);

			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId,transId,"NCMGroupGetService","NCM");	
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId + "&responseId=" + responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId,responseId,httpMethod, entityId);
		 } catch (Exception e) {
			LOGGER.error("Exception in GetGroupServiceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getNCMGroupUpdateServiceQueue()}", containerFactory = "NCMGroupUpdateServicerabbitListenerContainerFactory")
	public Message ncmUpdateGroupServiceCall(Message msg){ 
		LOGGER.info("Inside ncmUpdateGroupServiceCall method::::");
		String response = null;
	    String entityId = "0";
		String transId = null;
		String httpMethod=Constants.HTTP_PUT;
		UUID uuid = null;
		String responseId = null;
		String operationName = "NcmUpdateGroupWF";
		String serviceName = "NCMGroupIntegration";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId,transId,"NCMGroupUpdateService","NCM");
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId + "&responseId=" + responseId +"&ruleParam=smbUpdateGroupRule" ;
			response = externalServiceClient.getResponseFromClient(request, transId,responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in GetGroupServiceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

	@RabbitListener(queues = "#{inboundQueueProperties.getNcmGetDeviceAppVersionQueue()}", containerFactory = "ncmGetDeviceAppVersionrabbitListenerContainerFactory")
	public Message ncmGetDeviceAppVersionsCall(Message msg) {
		LOGGER.info("Inside ncmDeviceAppVersionsCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		UUID uuid = null;
		String responseId = null;
		String transaction_name="NCMDeviceAppVersions";
		String serviceName = "NCMDeviceAppVersionsIntegration";
		String operationName = "NCMGetDeviceAppVersionsWF";
		String application_Name=Constants.NCM;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,transaction_name,application_Name);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmDeviceAppVersionsCall" +
			 e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmgetRouterQueue()}", containerFactory = "ncmgetRouterrabbitListenerContainerFactory")
	public Message ncmGetRouterServiceCall(Message msg) {
		LOGGER.info("Inside ncmGetRouterServiceCall method::::");
		String response=null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		UUID uuid = null;
		String responseId = null;
		String operationName ="NCMRouterGetWF";
		String serviceName = "NCMRouterIntegration";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMRouterIntegrationService","NCM");
			LOGGER.info("Response Id " + responseId);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmgetdeviceAppBindingCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmgetactivitylogQueue()}", containerFactory = "ncmgetactivitylograbbitListenerContainerFactory")
	public Message ncmGetActivityLogServiceCallResponse(Message msg)	
	{
		LOGGER.info("Inside ncmGetActivityLogServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		String operationName = "NCMGetActivityLogWF";
		String serviceName = "NCMGetActivityLogIntegration";
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMActivityLogIntegration","NCM");
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	 @RabbitListener(queues = "#{inboundQueueProperties.getNcmAccountCreateQueue()}", containerFactory = "ncmAccountCreaterabbitListenerContainerFactory")
	  public Message ncmAccountCreateSystemCallResponse(Message msg) {
			String response = null;
			String entityId = "0";
			String transId = null;
			String serviceName = Constants.ACCOUNT_SERVICE_PROCESS_PLAN;
			String operationName = null;
			UUID uuid = null;
			String responseId = null;
			try {
				byte[] body = msg.getBody();
				String request = new String(body);
				String httpmethod = "POST";
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				String applicationName = Constants.NCM;

				responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMAccountIntegrationService",
						 applicationName);
				if (Constants.HTTP_POST.equalsIgnoreCase(httpmethod)) {
					LOGGER.info("Inside Create ACcount");
					operationName = Constants.ACCOUNT_CREATE_WORK_FLOW;
				}
				this.asyncinsertMNORequestDetails(request, responseId);
				request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" + responseId + "&ruleParam=smbCreateAccount";
				response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmAccountSystemCall" + e.getMessage());
			}if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		
			  }
	 
	 @RabbitListener(queues = "#{inboundQueueProperties.getNcmRouterUpdateQueue()}", containerFactory = "ncmRouterUpdaterabbitListenerContainerFactory")
		public Message routerUpdateServiceCall(Message msg) {
			String response = null;
			String entityId = "0";
			String transId = null;
			String httpMethod = "PUT";
			UUID uuid = null;
			String responseId = null;
			String serviceName = Constants.ROUTER_SERVICE_PROCESS_PLAN;
			String operationName  = Constants.ROUTER_UPDATE_WORK_FLOW;
			try {
				byte[] body = msg.getBody();
				String exchange = new String(body);
				uuid = UUID.randomUUID();
				transId = uuid.toString();
				responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMRouterIntegrationService", Constants.NCM);
				exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
						+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=smbUpdateRouterRule";
				response = externalServiceClient.getResponseFromClient(exchange, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
				LOGGER.error("Exception in ncmRouterSystemCall" + e.getMessage());
			}if(response==null) {
				 response = "";
			}
			return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
		}
	 
	 @RabbitListener(queues = "#{inboundQueueProperties.getDeleteDeviceAppBindingsQueue()}", containerFactory = "DeleteDeviceAppBindingsrabbitListenerContainerFactory")
		public Message deviceAppBindingResponse(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String applicationName = Constants.NCM;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "NCMDeviceAppBindingsIntegeration";
		String operationName = "NCMDeviceAppBindingsDeleteWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			String httpmethod = Constants.HTTP_DELETE;
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request,entityId,transId,"NCMDeviceAppBindingsIntegrationService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(),e);
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	 @RabbitListener(queues = "#{inboundQueueProperties.getUpdateLocationServiceQueue()}", containerFactory = "UpdateLocationServicerabbitListenerContainerFactory")
     public Message InsertLocationResponse(Message msg) {
		String response = null;
		String entityId = Constants.STRING_ZERO;
		String applicationName = Constants.NCM;
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "NCMLocationsIntegeration";
		String operationName = Constants.NCM_PUT_OPERATION_NAME;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			String httpmethod = Constants.HTTP_PUT;
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request,entityId,transId,"NCMLocationIntegrationService",applicationName);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"smbUpdateLocationRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId, httpmethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmCreateSubAccountSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}

 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmCreateGroupServiceQueue()}", containerFactory = "ncmCreateGroupServicerabbitListenerContainerFactory")
	public Message ncmCreateGroupServiceCall(Message msg){ 
		LOGGER.info("Inside ncmCreateGroupServiceCall method::::"+msg);
		String response = null;
	    String entityId = "0";
		String transId = null;
		String httpMethod=Constants.HTTP_POST;
		UUID uuid = null;
		String responseId = null;
		String operationName = "NcmCreateGroupWF";
		String serviceName = "NCMGroupIntegration";	
		//NcmCreateGroup
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			LOGGER.info("transId::::::"+transId);
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId,transId,"NCMGroupCreateService","NCM");
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId + "&responseId=" + responseId+"&ruleParam=smbCreateGroupRule" ;
			response = externalServiceClient.getResponseFromClient(request, transId,responseId,httpMethod,entityId);
		 } catch (Exception e) {
			LOGGER.error("Exception in GetGroupServiceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmUpdateAccountSystemQueue()}", containerFactory = "customSimpleRabbitListenerContainer")
	public Message ncmUpdateAccountSystemCall(Message msg){ 
		LOGGER.info("Inside ncmUpdateAccountSystemCall method::::");
		String response = null;
	    String entityId = "0";
		String transId = null;
		String httpMethod=Constants.HTTP_PUT;
		UUID uuid = null;
		String responseId = null;
		String operationName = "NCMAccountUpdateWF";
		String serviceName = "NCMAccountIntegrationSystem";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			System.out.println("transc ID::"+transId);
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId,transId,"NCMAccountsUpdateService","NCM");
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +transId + "&responseId=" + responseId+"&ruleParam=smbUpdateAccountRule" ;
			response = externalServiceClient.getResponseFromClient(request, transId,responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmUpdateAccountSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmgetdeviceappbindinglogQueue()}", containerFactory = "DeleteDeviceAppBindingsrabbitListenerContainerFactory")
	public Message ncmgetdeviceAppBindingCallResponse(Message msg) {
		LOGGER.info("Inside ncmgetdeviceAppBindingCallResponse method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		UUID uuid = null;
		String responseId = null;
		String operationName = "NCMDeviceAppBindingsGetWF";
		String serviceName = "NCMDeviceAppBindingsIntegeration";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMDeviceAppBindingsIntegrationService","NCM");
			LOGGER.info("Response Id " + responseId);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod, entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmgetdeviceAppBindingCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmCreateSpeedlogQueue()}", containerFactory = "customSimpleRabbitListenerContainer")
	public Message ncmCreateSpeedTestsSystemCall(Message msg) {
		LOGGER.info("Inside ncmCreateSpeedTestsSystemCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_POST;
		UUID uuid = null;
		String responseId = null;
		String operationName = "NCMSpeedTestsPostWF";
		String serviceName = "NCMSpeedTestIntegeration";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMSpeedTestsIntegrationService","NCM");
			LOGGER.info("Response Id " + responseId);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"smbCreateSpeedLogRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmgetdeviceAppBindingCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmRouterDeleteQueue()}", containerFactory = "customSimpleRabbitListenerContainer")
	public Message routerDeleteServiceCall(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = null;
		String serviceName = Constants.ROUTER_SERVICE_PROCESS_PLAN;
		String operationName  = Constants.ROUTER_DELETE_WORK_FLOW;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String exchange = new String(body);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(exchange, entityId, transId, "NCMRouterIntegrationService", Constants.NCM);
			exchange = "json=" + exchange + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(exchange, transId, responseId,httpMethod,entityId);
			} catch (Exception e) {
			LOGGER.error("Exception in ncmRouterSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNslDeviceAppsIntegrationServiceQueue()}", containerFactory = "nslDeviceAppsIntegrationrabbitListenerContainerFactory")
	public Message ncmDeviceAppsIntegrationServiceCall(Message msg) {
		LOGGER.info("Inside ncmDeviceAppsIntegrationServiceCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = null;
		UUID uuid = null;
		String responseId = null;
		String transaction_name="NCMDeviceAppsIntegrationService";
		String application_Name=Constants.NCM;
		String serviceName = "NCMDeviceAppsIntegration";
		String operationName = "NCMDeleteDeviceAppWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId,transaction_name ,application_Name);	
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response =externalServiceClient. getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmDeviceAppsIntegrationServiceCall" +
			 e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getDeleteDeviceAppVersionQueue()}", containerFactory = "deleteDeviceAppVersionrabbitListenerContainerFactory")	
	public Message ncmDeleteDeviceAppVersionsCallResponse(Message msg) {
		String response = null;
		String entityId = "0";
		String transId = null;
		UUID uuid = null;
		String responseId = null;
		String httpMethod=null;
		String serviceName = Constants.DEVICE_APP_VERSIONS_PROCESS_PLAN;
		String operationName = Constants.DELETE_DEVICE_APP_VERSIONS_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();	 
		   responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMDeviceAppVersions",Constants.NCM);
		   request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
		   response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmDeleteDeviceAppVersionsCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmFailoversIntegrationServiceQueue()}", containerFactory = "ncmFailoversIntegrationrabbitListenerContainerFactory")
	public Message ncmFailoversIntegrationServiceCall(Message msg) {
		LOGGER.info("Inside ncmFirmwareServiceCall::::");
		String response = null;
		String transId = null;
		String httpMethod=Constants.HTTP_GET;
		String applicationName = "NCM";
		String entityId = "0";
		UUID uuid = null;
		String responseId = null;
		String serviceName = Constants.GET_FAILOVER_PROCESS_PLAN;
		String operationName = Constants.GET_FAILOVER_WORK_FLOW;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);			
			LOGGER.info("Final Request  ::::" + request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "GetNcmFirmware",applicationName);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=nslParamSMB";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmSignalSampleSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	 
 	
 	
 	@RabbitListener(queues = "#{inboundQueueProperties.getNcmrebootQueue()}", containerFactory = "ncmrebootrabbitListenerContainerFactory")
	public Message ncmrebootCallResponse(Message msg) {
		LOGGER.info("Inside ncmrebootCallResponse method::::");

		String response = null;

		LOGGER.info("Inside ncmrebootCallResponse method::::");

		String entityId = "0";
		String transId = null;
		String operationName = Constants.NCMReboot_OPERATIONNAME;
		String serviceName = Constants.NCMReboot_SERVICENAME;
		String httpMethod=Constants.HTTP_POST;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMRebootActivity",
					Constants.NCM);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=smbCreateRebootRule";
 	
			   response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
					} catch (Exception e) {
						LOGGER.error("Exception in ncmrebootCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
					return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
				}
 
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmcreatedeviceappbindinglogQueue()}", containerFactory = "ncmcreatedeviceappbindingrabbitListenerContainerFactory")
	public Message ncmcreatedeviceAppBindingCallResponse(Message msg) {
		LOGGER.info("Inside ncmcreatedeviceAppBindingCallResponse method::::");

		String response = null;

		LOGGER.info("Inside ncmcreatedeviceAppBindingCallResponse method::::");

		String entityId = "0";
		String transId = null;
		String operationName = Constants.NCMDEVICEAPP_OPERATIONNAME;
		String serviceName = Constants.NCMDEVICEAPP_SERVICENAME;
		String httpMethod=Constants.HTTP_POST;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMDeviceAppBindingsIntegrationService",Constants.NCM);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"smbCreateDeviceAppBindingRule");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmgetdeviceAppBindingCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
	@RabbitListener(queues = "#{inboundQueueProperties.getNcmhistoricalloclogQueue()}", containerFactory = "NcmhistoricalloclograbbitListenerContainerFactory")
	public Message ncmhistoricallocIntegCallResponse(Message msg) {
		LOGGER.info("Inside ncmhistoricallocIntegCallResponse method::::");


		String response = null;

		LOGGER.info("Inside ncmhistoricallocIntegCallResponse method::::");

		String entityId = "0";
		String transId = null;
		String operationName = Constants.NCMHistorical_OPERATIONNAME;
		String serviceName = Constants.NCMHistorical_SERVICENAME;
		String httpMethod=Constants.HTTP_GET;
		UUID uuid = null;
		String responseId = null;
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NcmHistoricalLocationIntegrationService",Constants.NCM);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in NcmHistoricalLocationIntegrationCallResponse" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 	
	@RabbitListener(queues = "#{inboundQueueProperties.getNCMAllertIntegrationServiceQueue()}", containerFactory = "NCMAllertIntegrationServicerabbitListenerContainerFactory")
	public Message ncmAllertIntegrationServiceCall(Message msg) {

		String response = null;
		String entityId = Constants.STRING_ZERO;
		String transId = null;
		String httpMethod = Constants.HTTP_GET;
		String responseId = null;
		UUID uuid = null;
		String serviceName = "NCMAllertIntegrationServiceIntegration";
		String operationName = "NCMAllertIntegrationServiceGetWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMAllertIntegrationService", Constants.NCM);
			request = constructRequestJson(request, serviceName, operationName, transId, responseId,"nslParamSMB");	
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);
		} catch (Exception e) {
			LOGGER.error("Exception in ncmAllertIntegrationServiceCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
 
	@RabbitListener(queues = "#{inboundQueueProperties.getNCMUpdateConfigMangerServiceQueue()}", containerFactory = "NCMUpdateConfigMangerServicerabbitListenerContainerFactory")
	public Message ncmUpdateConfigManagerSystemCall(Message msg) {
		LOGGER.info("Inside ncmUpdateConfigManagerSystemCall method::::");
		String response = null;
		String entityId = "0";
		String transId = null;
		String httpMethod = Constants.HTTP_PATCH;
		UUID uuid = null;
		String responseId = null;
		String serviceName = "NCMConfigManager";
		String operationName = "ConfigManagerPatchWF";
		try {
			byte[] body = msg.getBody();
			String request = new String(body);
			LOGGER.info(request);
			uuid = UUID.randomUUID();
			transId = uuid.toString();
			
			responseId = transactionDAO.insertNorthBoundTransaction(request, entityId, transId, "NCMConfigMangerService","NCM");		
			request = formatRequestForMerge(request);
			request = "json=" + request + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" +responseId + "&ruleParam=smbPatchConfigManager";
			response = externalServiceClient.getResponseFromClient(request, transId, responseId,httpMethod,entityId);	
		} catch (Exception e) {
			LOGGER.error("Exception in ncmupdategroupSystemCall" + e.getMessage());
		}if(response==null) {
			 response = "";
		}
		return MessageBuilder.withBody(response.getBytes()).setContentType(MediaType.APPLICATION_JSON_VALUE).build();
	}
	
	private String  constructRequestJson(String requestJson,String serviceName, String operationName, String transId, String responseId,String ruleParam){
		StringBuilder requestBuilder = new StringBuilder();
		requestBuilder.append(Constants.REQUEST_JSON);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(requestJson);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_SERVICE_NAME);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(serviceName);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_OPERATION_NAME);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(operationName);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_TRANS_ID);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(transId);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.REQUEST_RESPONSE_ID);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(responseId);
		requestBuilder.append(Constants.AMP);
		requestBuilder.append(Constants.RULE_PARAM);
		requestBuilder.append(Constants.EQUAL);
		requestBuilder.append(ruleParam);
		
		return requestBuilder.toString();
	}
	
	@SuppressWarnings("unchecked")
	private String formatRequestForMerge(String response) {		
		JSONArray jsonArr = new JSONArray();
		try {
			JSONObject obj = new JSONObject(response);
			JSONObject finalObj = new JSONObject();
			Iterator<String> objItr = obj.keys();
			while (objItr.hasNext()) {
				String key = objItr.next();
				JSONObject reqObj = obj.getJSONObject(key);
				Iterator<String> reqObjItr = reqObj.keys();
				while (reqObjItr.hasNext()) {
					String groupKey = reqObjItr.next();
					Object data = reqObj.get(groupKey);
					if (data instanceof JSONObject) {
						JSONObject lastObj = (JSONObject) data;
						Iterator<String> lastItr = lastObj.keys();
						while (lastItr.hasNext()) {
							String lastKey = lastItr.next();
							Object val = lastObj.get(lastKey);
							finalObj.put(lastKey, val);
						}
					} else if (data instanceof String) {
						finalObj.put(groupKey, data);
					}
				}
			}
			jsonArr.put(finalObj);	
		} catch (Exception e) {
			LOGGER.error("Error in formatRequestForMerge" + e);
		}
		LOGGER.info("jsonArr.toString()::"+jsonArr.toString());
		return jsonArr.toString();	
	}
	
	private void asyncinsertMNORequestDetails(String requestJson, String responseId) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.insertMNORequestDetails(requestJson, responseId);
			}
		});
	}
	
	
	
	
}
