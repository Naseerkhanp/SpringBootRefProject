package com.excelacom.servicegateway.constants;

final public class Constants {

	
	
	public static final String ID = "ID";
	
	public static final String COLON_SPACE = " : ";
	
	public static final String METHOD_HANDLE = "handle";
	
	public static final String METHOD_NCM_SPEED_TEST_CALL = "ncmSpeedTestsSystemCall";
	
	public static final String EMPTY = "";
	
	public static final String GET_DEVICE_APP_BINDINGS_REQUEST = "getAllertIntegrationServiceRequest";
	
	public static final String AMP = "&";
	
	public static final int SC_FORBIDDEN = 403;
	
	public static final String NCMReboot_OPERATIONNAME = "NCMRebootActivityCreateWF";
	
	public static final String NCMReboot_SERVICENAME = "NCMRebootActivity";
	
	public static final String NCMDEVICEAPP_OPERATIONNAME = "NCMDeviceAppBindingsPostWF";
	
	public static final String NCMDEVICEAPP_SERVICENAME = "NCMDeviceAppBindingsIntegeration";
	
	public static final String NCMHistorical_OPERATIONNAME = "NCMHistoricalLocationIntegerationGetWF";
	
	public static final String NCMHistorical_SERVICENAME = "NCMHistoricalLocationIntegeration";
	
	public static final String Transaction_typ = "transactionType";
	
	public static final String Limit = "limit";
	
	public static final String HTTP_PUT = "PUT";
	
	public static final String GET_ROUTER_STREAM_USAGE_SAMPLES = "getRouterStreamUsageSamplesRequest";
	
	public static final String QUESTION = "?";
	
	public static final String GET_FIRMWARE_REQUEST = "getFirmwareRequest";
	
    public static final String GET_NETDEVICEUSAGESAMPLE_REQUEST = "getNetDeviceUsageSample";
	
	public static final String EQUAL = "=";
	
	public static final String REQUEST_PARAM = "requestParam";
	
	public static final String DATA = "data";
	
	public static final String ENDPOINT_HTTP_METHOD = "EndPointHttpMethod";
	
	public static final String DOUBLE_OPEN_BRACE = "{{";
	
	public static final String DOUBLE_CLOSE_BRACE = "}}";
	
	public static final String COMMA = ",";
	
	public static final String id = "id";
	
	public static final String PATH_PARAM = "Path";
	
	public static final String ECMAPIID = "X-ECM-API-ID";
	
	public static final String ECMAPIKEY = "X-ECM-API-KEY";
	
	public static final String CPAPIID = "X-CP-API-ID";
	
	public static final String CPAPIKEY = "X-CP-API-KEY";
	
	public static final String STRING_ZERO = "0";
	
	public static final String CONTENTTYPE = "Content-Type";
	
	public static final String APPLICATION_JSON = "application/json";
	
	public static final String STATUS = "status";
	
	public static final String HTTP_NO_CONTENT = "NO_CONTENT";
	
	public static final String CODE = "code";
	
	public static final String MESSAGE = "message";
	
	public static final String HTTP_CODE_202 = "HTTP 202";
	
	public static final String ACCEPTED = "Accepted";
	
	public static final String MESSAGE_INPROGRESS = "Processing is still INPROGRESS";
	
	public static final String HEADER_AUTHORIZATION = "Authorization";
	
	public static final String HTTP_GET = "GET";
	
	public static final String HTTP_POST = "POST";
	
	public static final String HTTP_DELETE = "DELETE";
	
	public static final String HTTP_PATCH = "PATCH";
	
	public static final String SERVICE_ID = "serviceId";
	
	public static final String REQUEST_TYPE = "requestType";
	
	public static final String REFERENCE_NUMBER = "referenceNumber";
	
	public static final String MESSAGE_HEADER = "messageHeader";
	
	public static final String HTTP_METHOD = "HTTP_METHOD";
	
	public static final String TRANSACTION_TIME_STAMP = "transactionTimeStamp";
	
	public static final String NCM_TRANSACTION_NAME = "NCMSpeedTestsIntegrationService";
	
	public static final String NCM = "NCM";
	
	public static final String NCM_SERVICE_NAME = "NCMSpeedTestIntegeration";
	
	public static final String NCM_GET_OPERATION_NAME = "NCMSpeedTestsGetWF";
	
	public static final String NCM_POST_OPERATION_NAME = "NCMSpeedTestsPostWF";
	
	public static final String NCM_DELETE_OPERATION_NAME = "NCMSpeedTestsDeleteWF";
	
	public static final String NETDEVICE_HEALTH_PROCESS_PLAN="NCMGetNetDeviceHealth";
	
	public static final String NETDEVICE_HEALTH_WORK_FLOW="GetNetDeviceHealthWorkflow";
	
	public static final String NETDEVICE_SERVICE_PROCESS_PLAN="NCMNetDeviceIntegration";
	
	public static final String NCM_PUT_OPERATION_NAME = "NCMLocationsPutWF";
	
	public static final String NETDEVICE_GET_WORK_FLOW="NCMNetDeviceGetWF";
	
	public static final String NET_DEVICE_USAGE_SAMPLE_SERVICE_PROCESS_PLAN="NCMNetDeviceUsageSample";
	
	public static final String NET_DEVICE_USAGE_SAMPLE_GET_WORK_FLOW="NetDeviceUsageSampleWF";
	
	public static final String GROUP_SERVICE_PROCESS_PLAN="NCMGroupIntegration";
	
	public static final String GROUP_DELETE_WORK_FLOW="NCMDeleteGroupWF";
	
	public static final String ACCOUNT_SERVICE_PROCESS_PLAN="NCMAccountIntegrationSystem";
	
	public static final String ACCOUNT_CREATE_WORK_FLOW="NCMAccountCreateWF";
	
	public static final String ACCOUNT_GET_WORK_FLOW="NCMAccountGetWF";
	
	public static final String ACCOUNT_DELETE_WORK_FLOW="NCMAccountDeleteWF";
	
	public static final String ROUTER_LOGS_PROCESS_PLAN = "NcmRouterLogsIntegration";

	public static final String ROUTER_LOGS_WORK_FLOW = "GetRouterLogsWF";
	
	/** The Constant OPERATIONNAME. */ 
	public static final String OPERATIONNAME = "ncmGetRouterStateWorkFlow";
	
	/** The Constant SERVICENAME. */ 
	public static final String  SERVICENAME = "ncmGetRouterState";
	
	public static final String ROUTERS_ALLERT_PROCESS_PLAN="NCMRouterAllertsIntegration";
	
	public static final String ROUTERS_ALLERT_WORK_FLOW="GetRouterAllertsWF";
	
	public static final String UNAUTHORIZED = "unauthorized";
	
	public static final String ROUTERSERVICEURL = "RouterServiceURL";
	
	public static final String CONFIG_GET_WORK_FLOW="ConfigManagerWF";
	
	public static final String CONFIG_SERVICE_PROCESS_PLAN="NCMConfigManager";
	
	public static final String PRODUCT_SERVICE_PROCESS_PLAN="NCMDeviceAppsIntegration";
	
	public static final String PRODUCT_GET_WORK_FLOW="NcmGetDeviceAppsworkflow";
	
	public static final String ROUTER_SERVICE_PROCESS_PLAN="NCMRouterIntegration";
	
	public static final String ROUTER_UPDATE_WORK_FLOW="NCMRouterUpdateWF";
	
	public static final String ROUTER_DELETE_WORK_FLOW="NCMRouterDeleteWF";
	
	public static final String DEVICE_APP_VERSIONS_PROCESS_PLAN="NCMDeviceAppVersionsIntegration";
	
	public static final String DELETE_DEVICE_APP_VERSIONS_WORK_FLOW="NCMDeleteDeviceAppVersionWF";
	
	public static final String GET_FAILOVER_PROCESS_PLAN="ncmFailOverService";
	
	public static final String GET_FAILOVER_WORK_FLOW="ncmFailOverServiceWorkFlow";
	
	public static final String TRANSGROUPID = "TRANSGROUPID";
	
	public static final String GROUPID = "GROUPID";
	
	public static final String REQUEST_JSON = "json";
	
	public static final String REQUEST_SERVICE_NAME = "serviceName";
	
	public static final String REQUEST_OPERATION_NAME = "operationName";
	
	public static final String REQUEST_TRANS_ID = "transId";
	
	public static final String REQUEST_RESPONSE_ID = "responseId";
	
	public static final String RULE_PARAM = "ruleParam";

	public static final String SUCCESS = "success";
	
	public static final String PROPERTIES = "properties";
	
	public static final String CONFIGURATION_PROPS = "file:${karaf.home}/etc/configuration.properties";
	
	public static final String GET_SPEED_TEST_REQUEST = "getSpeedTestsRequest";
	
	public static final String GET_PATH_PARAM_ID = "id";
	
	public static final String SPEED_TEST_CONFIG = "config";
	
	public static final String SPEED_TEST_SIZE = "size";
	
	public static final String STRING_NULL = "null";
	
	public static final String POST_SPEED_TEST_REQUEST= "postSpeedTestsRequest";
	
	public static final String SPEED_TEST_NET_DEVICE_IDS = "netDeviceIds";
	
	public static final String INVALID_TOKEN_1="{\"status\":{\"code\":\"401\",\"reason\":\"Unauthorized\",\"message\":\"User account access privileges issue or Token is missing or invalid/expired\"},"
			+ "\"userProfile\":{\"userName\":\"hmnouser\",\"userRole\":\"API_USER\"},\"token\":\"";
	
	public static final String INVALID_TOKEN_2="\"}";
	
	public static final String TOKEN_UNAVAILABLE = "Not Available";
	
	public static final String INVALID_Sec="{\"status\":{\"code\":\"403\",\"reason\":\"Unauthorized\",\"message\":\"Bad Password\"}}";

	public static final String ENDURL = "/nsl/provisioning/ncm/v1/speedtests/{id}";
	
	public static final String RESPONSE_PARAM_ACTIVE = "active";
	
	public static final String FAILURE="FAILURE";
	
	public static final String STATUSCODE = "code";
	
	public static final String FAILED_SOUTH_BOUND = "Failed in Southbound System";
	
	public static final String SQUARE_BRACKET ="[";
	
	public static final String CURLY_BRACKET ="{";
	

    /** The Constant TRANSACTION_ID. */
    public static final String TRANSACTION_ID ="TRANSACTION_ID";
    
    
    public static final String EXT_TRANSACTION_ID ="EXT_TRANSACTION_ID";
    /** The Constant TRANSACTION_UID. */
    public static final String TRANSACTION_UID ="TRANSACTION_UID";
    
    /** The Constant ENTITY_ID. */
    public static final String ENTITY_ID ="ENTITY_ID";
    
    /** The Constant APPLICATION_NAME. */
    public static final String APPLICATION_NAME = "APPLICATION_NAME";
    
    /** The Constant TRANSACTION_TYPE. */
    public static final String TRANSACTION_TYPE = "TRANSACTION_TYPE";
    
    /** The Constant EVENT_NAME*/
    public static final String EVENT_NAME = "EVENT_NAME";
    /** The Constant SENT_DATE*/
    public static final String SENT_DATE = "SENT_DATE";
    /** The Constant SENT_STATUS*/
    public static final String SENT_STATUS = "SENT_STATUS";
    /** The Constant EVENT_TIME*/
    public static final String EVENT_TIME = "EVENT_TIME";
    /** The Constant EVENT_DES*/
    public static final String EVENT_DESC = "EVENT_DESC";
    /** The Constant VALUE*/
    public static final String VALUE = "VALUE";
    /** The Constant EVENT_SOURCE*/
    public static final String EVENT_SOURCE = "EVENT_SOURCE";
    /** The Constant EVENT_TYPE*/
    public static final String EVENT_TYPE = "EVENT_TYPE";
    /** The Constant EVENT_STATUS*/
    public static final String EVENT_STATUS = "EVENT_STATUS";
    
    public static final String INBOUND = "INBOUND";
    
    public static final String GETTRANSACTIONID = "SELECT SEQ_TRANSACTION_ID.nextval from dual";
    
    public static final String TENANT_ID = "TENANT_ID";
    
    public static final String DELTA ="~";
    
    public static final String INSERT_NORTH_BOUND_TRANSACTION = "INSERT " 
	        +"INTO TRANSACTION_DETAILS " 
	        +"  ( " 
	        +"    TRANSACTION_ID , " 
	        +"    REL_TRANSACTION_ID , " 
	        +"    TRANSACTION_NAME , " 
	        +"	  APPLICATION_NAME,"
	        +"    EXT_TRANSACTION_ID , " 
	        +"    TRANSACTION_TYPE , " 
	        +"    STATUS , " 
	        +"    REQ_SENT_DATE , " 
	        +"    RESP_RECEIVED_DATE , " 
	        +"    CREATED_DATE , " 
	        +"    CREATED_BY , " 
	        +"    MODIFIED_DATE , " 
	        +"    MODIFIED_BY , " 
	        +"      ICC_VAL,"
	        +"    REQUEST_MSG ," 
	        +"    ENTITY_ID ,"
	        +"    TRANSACTION_UID,"
	        +"    TENANT_ID"
	        +"  ) " 
	        +"  VALUES " 
	        +"  ( " 
	        +"    (SEQ_TRANSACTION_ID.nextval) , " 
	        +"    NULL , " 
	        +"    :APPLICATION_NAME , " 
	        +"	  :APPLICATIONNAME,"
	        +"    :EXT_TRANSACTION_ID, " 
	        +"    :TRANSACTION_TYPE , " 
	        +"    'INITIATED', " 
	        +"    systimestamp , " 
	        +"    NULL , " 
	        +"    systimestamp , " 
	        +"    'NSL' , " 
	        +"    NULL , " 
	        +"    NULL , " 
	        +"      NULL,"
	        +"    :REQUEST_MSG ,"
	        +"    :ENTITY_ID ,"
	        +"    :TRANSACTION_UID,"
	        +"    :TENANT_ID"
	        +"  )";
    
    public static final String INSERT_EVENT_NOTIFICATION_TRANSACTION = "INSERT " 
	        +"INTO EVENT_NOTIFICATION " 
	        +"  ( " 
	        +"    EVENT_ID , " 
	        +"    EVENT_NAME , " 
	        +"    SENT_DATE , " 
	        +"	  SENT_STATUS,"
	        +"	  NOTIFICATION_TYPE,"
	        +"    EVENT_TIME , " 
	        +"    EVENT_DESC , " 
	        +"    VALUE , " 
	        +"    EVENT_SOURCE , " 
	        +"    APPLIACTION_NAME , " 
	        +"    EVENT_DESTINATION , " 
	        +"    EVENT_STATUS , " 
	        +"    EVENT_TYPE"
	        +"  ) " 
	        +"  VALUES " 
	        +"  ( " 
	        +"    (EVENT_ID_SEQ.nextval) , " 
	        +"    :EVENT_NAME , " 
	        +"	  TO_TIMESTAMP(:SENT_DATE, 'YYYY-MM-DD HH24:MI:SS.FF'),"
	        +"    :SENT_STATUS, " 
	        +"    1, " 
	        +"	  TO_TIMESTAMP(:EVENT_TIME, 'YYYY-MM-DD HH24:MI:SS.FF'),"
	        +"    :EVENT_DESC , " 
	        +"    :VALUE , " 
	        +"    :EVENT_SOURCE ,"
	        +"    'NCM' ,"
	        +"    'NSL' ,"
	        +"    :EVENT_STATUS , " 
	        +"    :EVENT_TYPE"
	        +"  )";
    

	public static final String INSERT_REQUESTS ="INSERT " 
		    +"INTO rh_csr_request" 
		    +"  ( " 
		    +"    TRANSACTION_ID , " 
		    +"    CUSTOMER_ID , " 
		    +"    CUSTOMER_REQUEST_ID , " 
		    +"    MDN , " 
		    +"    IMEI , " 
		    +"    PICCID ,"
			+"    EID,"	
		    +"    CREATED_DATE , " 
		    +"    CREATED_BY , " 
		    +"    MODIFIED_DATE ,"
			+"    MODIFIED_BY, "
			+"    REFERENCE_NUMBER , " 
		    +"    ASYNC_URL , " 
		    +"    RETURN_URL ,"
			+"    ACCOUNT_NUMBER, "
			+"    SUBORDERID, "
			+"    RETAILPLANCODE, "
			+"    LINEID, "
			+"    CONTEXTID, "
			+"    ACCOUNTTYPE, "
			+"    BILLCYCLEDAY "
		    +"  ) " 
		    +"  VALUES " 
		    +"  ( " 
		    +"    :TRANSACTION_ID , " 
		    +"    :CUSTOMER_ID , " 
		    +"    :CUSTOMER_REQUEST_ID , " 
		    +"    :MDN, " 
		    +"    :IMEI , " 
		    +"    :PICCID, " 
			+"    :EID , " 
			+"    systimestamp, " 
		    +"    'NSL' , " 
		    +"    NULL, " 
			+"    NULL,  " 
			+"    :REFERENCENUMBER,  " 
			+"    :ASYNCURL,  " 
			+"    :RETURNURL,  " 
			+"    :ACCOUNTNUMBER , " 
			+"    :ID,  " 
			+"    :RETAILPLANCODE,  "
			+"    :LINEID,  "
			+"    :CONTEXTID,  "
			+"    :ACCOUNTTYPE,  "
			+"    :BILLCYCLEDAY  "
		    +"  )";
			
		public static final String INBOUND_TRANSACTION_ID = "INBOUND_TRANSACTION_ID";

		public static final String UPDATE_SUCCESS_TRANSACTION = "update TRANSACTION_DETAILS set status = :status , RESPONSE_MSG = :RESPONSE_MSG, HTTP_RESPONSE=:httpCode, NOTES = '' ,RESP_RECEIVED_DATE=systimestamp ,ENTITY_ID = :ENTITY_ID ,TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID, SERVICENAME = :SERVICENAME,ROOT_TRANSACTION_ID=:INBOUND_TRANSACTION_ID where transaction_uid = :TRANSACTION_ID";
	
		public static final String GET_LOCATIONS_REQUEST = "getLocationsRequest";
		
		/** The Constant UPDATE_FAIL_TRANSACTION. */
		public static final String UPDATE_FAIL_TRANSACTION = "update TRANSACTION_DETAILS set status = :status,RESP_RECEIVED_DATE=systimestamp,ENTITY_ID = :ENTITY_ID , TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID,SERVICENAME = :SERVICENAME,ROOT_TRANSACTION_ID=:INBOUND_TRANSACTION_ID where transaction_uid = :TRANSACTION_ID";
		
		public static final String GET_TOKEN = "select count(*) from ACCESSTOKEN_INFO where TOKEN=:TOKEN";

		public static final String EMPTYSTRING = "";
		public static final String GET_NET_DEVICE_METRICS_REQUEST = "getNetDeviceMetricsRequest";
		
		public static final String INSERT_REF_ADD_DATA = "INSERT " 
	            +"INTO ref_additional_data " 
	            +"  ( " 
	            +"    TRANSACTIONID , " 
	            +"    REFNAME , " 
	            +"    REFVALUE ,"
				+"    CREATED_DATE , " 
	            +"    CREATED_BY , " 
	            +"    MODIFIED_DATE , " 
	            +"    MODIFIED_BY  " 			
	            +"  ) " 
	            +"  VALUES " 
	            +"  ( " 
	            +"    :TRANSACTION_ID , " 
	            +"    :REFNAME, " 
	            +"    :REFVALUE ,"
				+"    systimestamp , " 
	            +"    'NSL' , " 
				+"    systimestamp , " 
	            +"    'NSL'  " 			
	            +"  )";

		public static final String APPLICATION_SMB = "SMB";

		public static final String APPLICATION_HMNO = "HMNO";
		
		public static final String SecurityCode = "22d9583df2e942df950fbd661d14a7a3404c3bbdaa69834b139bc2e097e62f2b";

		public static final String TOKEN = "token";
		
		public static final String Response = "{\r\n    \"messageHeader\": {\r\n        \"serviceId\": \"MANAGED_WIRELESS\", \r\n        \"requestType\": \"DEVICE\", \r\n        \"referenceNumber\": \"EventId\"\r\n    }, \r\n    \"data\": {\r\n        \"transactionId\": \"EventId\", \r\n        \"code\": \"200\", \r\n        \"reason\": \"ok\", \r\n        \"message\": [\r\n            {\r\n                \"responseCode\": \" SUC00\", \r\n                \"description\": \" Success\"\r\n            }\r\n        ]\r\n    }\r\n}\r\n";

		
}
