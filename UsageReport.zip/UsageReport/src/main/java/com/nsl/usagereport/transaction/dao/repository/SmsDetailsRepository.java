package com.nsl.usagereport.transaction.dao.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nsl.usagereport.transaction.entity.SmsDetails;

@Repository("smsdao")
public interface SmsDetailsRepository extends JpaRepository<SmsDetails, Integer> {
	@Query("select d from SMS_DETAILS d where d.minNum = :minNum and d.eventDateTime BETWEEN :startDate AND :endDate AND  d.imsi = :imsi")
	List<SmsDetails> findDataByDate(@Param("minNum") String minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("imsi") String imsi);

	@Query("select d from SMS_DETAILS d where d.minNum = :minNum and d.eventDateTime BETWEEN :startDate AND :endDate")
	List<SmsDetails> findDataByDateWithOutOptional(@Param("minNum") String minNum, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);
	
	@Query("select d from SMS_DETAILS d where d.minNum = :minNum")
	List<SmsDetails> findDataByWithOutStartEnddateAndImsi(@Param("minNum") String minNum);

	@Query("select d from SMS_DETAILS d where d.minNum = :minNum AND  d.imsi = :imsi")
	List<SmsDetails> findDataByMdnAndImsi(@Param("minNum") String minNum, @Param("imsi") String imsi);
}
