/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import java.util.List;
import java.util.Set;

import com.nsl.managelines.dao.cif.entity.TransactionLog;

/**
 * @author Dhayanand.B
 *
 */
public interface TransactionLogDao {
	
	int findCountByFileName(String fileName,String status);
}
