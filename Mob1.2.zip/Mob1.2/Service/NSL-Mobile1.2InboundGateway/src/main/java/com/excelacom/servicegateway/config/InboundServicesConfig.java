package com.excelacom.servicegateway.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;

import com.excelacom.servicegateway.properties.InboundQueueProperties;

import org.springframework.util.ErrorHandler;
import com.excelacom.servicegateway.exception.CustomFatalExceptionStrategy;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;

@Configuration
@EnableRabbit
@Import(value = InboundQueueProperties.class)
public class InboundServicesConfig {

	@Value("${spring.application.dlqExchange}")
	private String dlqExchange;

	@Value("${spring.application.dlqueue}")
	private String dlqueue;

	@Value("${spring.rabbitmq.host}")
	private String host;

	@Value("${spring.rabbitmq.port}")
	private String port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${spring.rabbitmq.listener.simple.concurrency}")
	private String concurrentConsumers;
	
	@Value("${spring.rabbitmq.listener.simple.max-concurrency}")
	private String maxConcurrentConsumers;

	@Autowired
	private InboundQueueProperties inboundQueueProperties;

	@Bean
	public DirectExchange deadLetterExchange() {
		return new DirectExchange(dlqExchange);
	}

	@Bean
	public Queue dlq() {
		return QueueBuilder.durable(dlqueue).build();
	}

	@Bean
	Binding DLQbinding() {
		return BindingBuilder.bind(dlq()).to(deadLetterExchange()).with(dlqueue);
	}

	@Bean
	public Queue nslUpdateCancelQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getNslUpdateCancelQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange nslUpdateCancelExchange() {
		return new DirectExchange(inboundQueueProperties.getNslUpdateCancelExchange());
	}

	@Bean
	Binding nslUpdateCancelBinding() {
		return BindingBuilder.bind(nslUpdateCancelQueue()).to(nslUpdateCancelExchange())
				.with(inboundQueueProperties.getNslUpdateCancelQueue());
	}

	@Bean
	public Queue updateModifyQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getUpdateModifyQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange updateModifyExchange() {
		return new DirectExchange(inboundQueueProperties.getUpdateModifyExchange());
	}

	@Bean
	Binding UpdateModifyBinding() {
		return BindingBuilder.bind(updateModifyQueue()).to(updateModifyExchange())
				.with(inboundQueueProperties.getUpdateModifyQueue());
	}
	
	@Bean
	public Queue hmnoLineHistoryInquiryServiceQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getHmnoLineHistoryInquiryServiceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoLineHistoryInquiryServiceExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnoLineHistoryInquiryServiceExchange());
	}

	@Bean
	Binding hmnoLineHistoryInquiryServiceBinding() {
		return BindingBuilder.bind(hmnoLineHistoryInquiryServiceQueue()).to(hmnoLineHistoryInquiryServiceExchange())
				.with(inboundQueueProperties.getHmnoLineHistoryInquiryServiceQueue());
	}

	@Bean
	public Queue hmnoChangepsimQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getHmnochangepsimQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoChangepsimExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnochangepsimExchange());
	}

	@Bean
	Binding hmnoChangepsimBinding() {
		return BindingBuilder.bind(hmnoChangepsimQueue()).to(hmnoChangepsimExchange())
				.with(inboundQueueProperties.getHmnochangepsimQueue());
	}

	@Bean
	public Queue hmnoDeviceinquiryQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getHmnodeviceinquiryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoDeviceinquiryExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnodeviceinquiryExchange());
	}

	@Bean
	Binding hmnoDeviceinquiryBinding() {
		return BindingBuilder.bind(hmnoDeviceinquiryQueue()).to(hmnoDeviceinquiryExchange())
				.with(inboundQueueProperties.getHmnodeviceinquiryQueue());
	}
	
	@Bean
	public Queue hmnoChangeFeatureQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getHmnoChangeFeatureQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoChangeFeatureExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnoChangeFeatureExchange());
	}

	@Bean
	Binding hmnoChangeFeatureBinding() {
		return BindingBuilder.bind(hmnoChangeFeatureQueue()).to(hmnoChangeFeatureExchange())
				.with(inboundQueueProperties.getHmnoChangeFeatureQueue());
	}

	@Bean
	public Queue hmnoValidateSimQueue() {
		
	    return QueueBuilder.durable(inboundQueueProperties.getHmnoValidateSimQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoValidateSimExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnoValidateSimExchange());
	}

	@Bean
	Binding hmnoValidateSimBinding() {
		return BindingBuilder.bind(hmnoValidateSimQueue()).to(hmnoValidateSimExchange())
				.with(inboundQueueProperties.getHmnoValidateSimQueue());
	}
	
	@Bean
	public Queue mnoportinInquiryQueue() {
		return QueueBuilder.durable(inboundQueueProperties.getMnoportinInquiryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange mnoportinInquiryExchange() {
		return new DirectExchange(inboundQueueProperties.getMnoportinInquiryExchange());
	}

	@Bean
	Binding getMnoportinInquiryBinding() {
		return BindingBuilder.bind(mnoportinInquiryQueue()).to(mnoportinInquiryExchange())
				.with(inboundQueueProperties.getMnoportinInquiryQueue());
	}
	
	@Bean
	public Queue hmnoDeviceinquiryAsyncQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getHmnodeviceinquiryAsyncQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange hmnoDeviceinquiryAsyncExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnodeviceinquiryAsyncExchange());
	}

	@Bean
	Binding hmnoDeviceinquiryAsyncBinding() {
		return BindingBuilder.bind(hmnoDeviceinquiryAsyncQueue()).to(hmnoDeviceinquiryAsyncExchange())
				.with(inboundQueueProperties.getHmnodeviceinquiryAsyncQueue());
	}
	
	@Bean
	public Queue mnoLineDetailsQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getMnoLineDetailsQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange mnoLineDetailsExchange() {
		return new DirectExchange(inboundQueueProperties.getMnoLineDetailsExchange());
	}

	@Bean
	Binding mnoLineDetailsBinding() {
		return BindingBuilder.bind(mnoLineDetailsQueue()).to(mnoLineDetailsExchange())
				.with(inboundQueueProperties.getMnoLineDetailsQueue());
	}
	
	@Bean
	public Queue activateHotlineQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getActivateHotlineQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange activateHotlineExchange() {
		return new DirectExchange(inboundQueueProperties.getActivateHotlineExchange());
	}

	@Bean
	Binding activateHotlineBinding() {
		return BindingBuilder.bind(activateHotlineQueue()).to(activateHotlineExchange())
				.with(inboundQueueProperties.getActivateHotlineQueue());
	}
	
	@Bean
	public Queue suspendSubscriberQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getSuspendSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange suspendSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getSuspendSubscriberExchange());
	}

	@Bean
	Binding suspendSubscriberBinding() {
		return BindingBuilder.bind(suspendSubscriberQueue()).to(suspendSubscriberExchange())
				.with(inboundQueueProperties.getSuspendSubscriberQueue());
	}
	
	@Bean
	public Queue restoreSubscriberQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getRestoreSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange restoreSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getRestoreSubscriberExchange());
	}

	@Bean
	Binding restoreSubscriberBinding() {
		return BindingBuilder.bind(restoreSubscriberQueue()).to(restoreSubscriberExchange())
				.with(inboundQueueProperties.getRestoreSubscriberQueue());
	}
	
	@Bean
	public Queue activateSubscriberQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getActivateSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange activateSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getActivateSubscriberExchange());
	}

	@Bean
	Binding activateSubscriberBinding() {
		return BindingBuilder.bind(activateSubscriberQueue()).to(activateSubscriberExchange())
				.with(inboundQueueProperties.getActivateSubscriberQueue());
	}

	@Bean
	public Queue activatePortinSubscriberQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getActivatePortinSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange activatePortinSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getActivatePortinSubscriberExchange());
	}

	@Bean
	Binding activatePortinSubscriberBinding() {
		return BindingBuilder.bind(activatePortinSubscriberQueue()).to(activatePortinSubscriberExchange())
				.with(inboundQueueProperties.getActivatePortinSubscriberQueue());
	}
	
	@Bean
	public Queue deactivateSubscriberQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getDeactivateSubscriberQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange deactivateSubscriberExchange() {
		return new DirectExchange(inboundQueueProperties.getDeactivateSubscriberExchhange());
	}

	@Bean
	Binding deactivateSubscriberBinding() {
		return BindingBuilder.bind(deactivateSubscriberQueue()).to(deactivateSubscriberExchange())
				.with(inboundQueueProperties.getDeactivateSubscriberQueue());
	}
	
	@Bean
	public Queue changeRatePlanQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getChangeRatePlanQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange changeRatePlanExchange() {
		return new DirectExchange(inboundQueueProperties.getChangeRatePlanExchange());
	}

	@Bean
	Binding changeRatePlanBinding() {
		return BindingBuilder.bind(changeRatePlanQueue()).to(changeRatePlanExchange())
				.with(inboundQueueProperties.getChangeRatePlanQueue());
	}
	
	@Bean
	public Queue changeMdnQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getChangeMdnQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange changeMdnExchange() {
		return new DirectExchange(inboundQueueProperties.getChangeMdnExchange());
	}

	@Bean
	Binding changeMdnBinding() {
		return BindingBuilder.bind(changeMdnQueue()).to(changeMdnExchange())
				.with(inboundQueueProperties.getChangeMdnQueue());
	}
	
	@Bean
	public Queue lineInquiryQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getLineInquiryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange lineInquiryExchange() {
		return new DirectExchange(inboundQueueProperties.getLineInquiryExchange());
	}

	@Bean
	Binding lineInquiryBinding() {
		return BindingBuilder.bind(lineInquiryQueue()).to(lineInquiryExchange())
				.with(inboundQueueProperties.getLineInquiryQueue());
	}
	
	@Bean
	public Queue removeHotlineQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getRemoveHotlineQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange removeHotlineExchange() {
		return new DirectExchange(inboundQueueProperties.getRemoveHotlineExchange());
	}

	@Bean
	Binding removeHotlineBinding() {
		return BindingBuilder.bind(removeHotlineQueue()).to(removeHotlineExchange())
				.with(inboundQueueProperties.getRemoveHotlineQueue());
	}
	
	@Bean
	public Queue updatePortoutQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getUpdatePortoutQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange updatePortoutExchange() {
		return new DirectExchange(inboundQueueProperties.getUpdatePortoutExchange());
	}

	@Bean
	Binding updatePortoutBinding() {
		return BindingBuilder.bind(updatePortoutQueue()).to(updatePortoutExchange())
				.with(inboundQueueProperties.getUpdatePortoutQueue());
	}
	
	@Bean
	public Queue updateDuedatePortinQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getUpdateDuedatePortinQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange updateDuedatePortinExchange() {
		return new DirectExchange(inboundQueueProperties.getUpdateDuedatePortinExchange());
	}

	@Bean
	Binding updateDuedatePortinBinding() {
		return BindingBuilder.bind(updateDuedatePortinQueue()).to(updateDuedatePortinExchange())
				.with(inboundQueueProperties.getUpdateDuedatePortinQueue());
	}
	
	@Bean
	public Queue validateMdnQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getValidateMdnQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange validateMdnExchange() {
		return new DirectExchange(inboundQueueProperties.getValidateMdnExchange());
	}

	@Bean
	Binding validateMdnBinding() {
		return BindingBuilder.bind(validateMdnQueue()).to(validateMdnExchange())
				.with(inboundQueueProperties.getValidateMdnQueue());
	}
	
	@Bean
	public Queue validateDeviceQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getValidateDeviceQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange validateDeviceExchange() {
		return new DirectExchange(inboundQueueProperties.getValidateDeviceExchange());
	}

	@Bean
	Binding validateDeviceBinding() {
		return BindingBuilder.bind(validateDeviceQueue()).to(validateDeviceExchange())
				.with(inboundQueueProperties.getValidateDeviceQueue());
	}
	
	
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	@Bean(name = "ConnectionFactory")
	@Primary
	public ConnectionFactory rabbitMQConnectionFactory() {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(host);
		connectionFactory.setPort(Integer.parseInt(port));
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setConnectionTimeout(30000);
		return connectionFactory;
	}
	
	@Bean()
    RabbitAdmin rabbitAdmin(){
        return new RabbitAdmin(rabbitMQConnectionFactory());
    }
	
	@Bean(name = "getNslUpdateCancelConnectionFactory")
	public ConnectionFactory getNslUpdateCancelRabbitMQConnectionFactory() {
			CachingConnectionFactory getNslUpdateCancelConnectionFactory = new CachingConnectionFactory(host);
			getNslUpdateCancelConnectionFactory.setPort(Integer.parseInt(port));
			getNslUpdateCancelConnectionFactory.setUsername(username);
			getNslUpdateCancelConnectionFactory.setPassword(password);
			getNslUpdateCancelConnectionFactory.setConnectionTimeout(30000);
			return getNslUpdateCancelConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getNslUpdateCancelRabbitAdmin(){
        return new RabbitAdmin(getNslUpdateCancelRabbitMQConnectionFactory());
    } 
	
	@Bean(name = "getUpdateModifyConnectionFactory")
	public ConnectionFactory getUpdateModifyRabbitMQConnectionFactory() {
			CachingConnectionFactory getUpdateModifyConnectionFactory = new CachingConnectionFactory(host);
			getUpdateModifyConnectionFactory.setPort(Integer.parseInt(port));
			getUpdateModifyConnectionFactory.setUsername(username);
			getUpdateModifyConnectionFactory.setPassword(password);
			getUpdateModifyConnectionFactory.setConnectionTimeout(30000);
			return getUpdateModifyConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getUpdateModifyRabbitAdmin(){
        return new RabbitAdmin(getUpdateModifyRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoChangepsimConnectionFactory")
	public ConnectionFactory getHmnoChangepsimRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoChangepsimConnectionFactory = new CachingConnectionFactory(host);
			getHmnoChangepsimConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoChangepsimConnectionFactory.setUsername(username);
			getHmnoChangepsimConnectionFactory.setPassword(password);
			getHmnoChangepsimConnectionFactory.setConnectionTimeout(30000);
			return getHmnoChangepsimConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoChangepsimRabbitAdmin(){
        return new RabbitAdmin(getHmnoChangepsimRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoDeviceinquiryConnectionFactory")
	public ConnectionFactory getHmnoDeviceinquiryRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoDeviceinquiryConnectionFactory = new CachingConnectionFactory(host);
			getHmnoDeviceinquiryConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoDeviceinquiryConnectionFactory.setUsername(username);
			getHmnoDeviceinquiryConnectionFactory.setPassword(password);
			getHmnoDeviceinquiryConnectionFactory.setConnectionTimeout(30000);
			return getHmnoDeviceinquiryConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoDeviceinquiryRabbitAdmin(){
        return new RabbitAdmin(getHmnoDeviceinquiryRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoChangeFeatureConnectionFactory")
	public ConnectionFactory getHmnoChangeFeatureRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoChangeFeatureConnectionFactory = new CachingConnectionFactory(host);
			getHmnoChangeFeatureConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoChangeFeatureConnectionFactory.setUsername(username);
			getHmnoChangeFeatureConnectionFactory.setPassword(password);
			getHmnoChangeFeatureConnectionFactory.setConnectionTimeout(30000);
			return getHmnoChangeFeatureConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoChangeFeatureRabbitAdmin(){
        return new RabbitAdmin(getHmnoChangeFeatureRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoValidateSimConnectionFactory")
	public ConnectionFactory getHmnoValidateSimRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoValidateSimConnectionFactory = new CachingConnectionFactory(host);
			getHmnoValidateSimConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoValidateSimConnectionFactory.setUsername(username);
			getHmnoValidateSimConnectionFactory.setPassword(password);
			getHmnoValidateSimConnectionFactory.setConnectionTimeout(30000);
			return getHmnoValidateSimConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoValidateSimRabbitAdmin(){
        return new RabbitAdmin(getHmnoValidateSimRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoDeviceinquiryAsyncConnectionFactory")
	public ConnectionFactory getHmnoDeviceinquiryAsyncRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoDeviceinquiryAsyncConnectionFactory = new CachingConnectionFactory(host);
			getHmnoDeviceinquiryAsyncConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoDeviceinquiryAsyncConnectionFactory.setUsername(username);
			getHmnoDeviceinquiryAsyncConnectionFactory.setPassword(password);
			getHmnoDeviceinquiryAsyncConnectionFactory.setConnectionTimeout(30000);
			return getHmnoDeviceinquiryAsyncConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoDeviceinquiryAsyncRabbitAdmin(){
        return new RabbitAdmin(getHmnoDeviceinquiryAsyncRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getHmnoLineHistoryInquiryServiceConnectionFactory")
	public ConnectionFactory getHmnoLineHistoryInquiryServiceRabbitMQConnectionFactory() {
			CachingConnectionFactory getHmnoLineHistoryInquiryServiceConnectionFactory = new CachingConnectionFactory(host);
			getHmnoLineHistoryInquiryServiceConnectionFactory.setPort(Integer.parseInt(port));
			getHmnoLineHistoryInquiryServiceConnectionFactory.setUsername(username);
			getHmnoLineHistoryInquiryServiceConnectionFactory.setPassword(password);
			getHmnoLineHistoryInquiryServiceConnectionFactory.setConnectionTimeout(30000);
			return getHmnoLineHistoryInquiryServiceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getHmnoLineHistoryInquiryServiceRabbitAdmin(){
        return new RabbitAdmin(getHmnoLineHistoryInquiryServiceRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getMnoportinInquiryConnectionFactory")
	public ConnectionFactory getMnoportinInquiryRabbitMQConnectionFactory() {
			CachingConnectionFactory getMnoportinInquiryConnectionFactory = new CachingConnectionFactory(host);
			getMnoportinInquiryConnectionFactory.setPort(Integer.parseInt(port));
			getMnoportinInquiryConnectionFactory.setUsername(username);
			getMnoportinInquiryConnectionFactory.setPassword(password);
			getMnoportinInquiryConnectionFactory.setConnectionTimeout(30000);
			return getMnoportinInquiryConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getMnoportinInquiryRabbitAdmin(){
        return new RabbitAdmin(getMnoportinInquiryRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getMnoLineDetailsConnectionFactory")
	public ConnectionFactory getMnoLineDetailsRabbitMQConnectionFactory() {
			CachingConnectionFactory getMnoLineDetailsConnectionFactory = new CachingConnectionFactory(host);
			getMnoLineDetailsConnectionFactory.setPort(Integer.parseInt(port));
			getMnoLineDetailsConnectionFactory.setUsername(username);
			getMnoLineDetailsConnectionFactory.setPassword(password);
			getMnoLineDetailsConnectionFactory.setConnectionTimeout(30000);
			return getMnoLineDetailsConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getMnoLineDetailsRabbitAdmin(){
        return new RabbitAdmin(getMnoLineDetailsRabbitMQConnectionFactory());
    }
	
	@Bean(name = "getActivateHotlineConnectionFactory")
	public ConnectionFactory getActivateHotlineRabbitMQConnectionFactory() {
			CachingConnectionFactory getActivateHotlineConnectionFactory = new CachingConnectionFactory(host);
			getActivateHotlineConnectionFactory.setPort(Integer.parseInt(port));
			getActivateHotlineConnectionFactory.setUsername(username);
			getActivateHotlineConnectionFactory.setPassword(password);
			getActivateHotlineConnectionFactory.setConnectionTimeout(30000);
			return getActivateHotlineConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin getActivateHotlineRabbitAdmin(){
        return new RabbitAdmin(getActivateHotlineRabbitMQConnectionFactory());
    }

	@Bean("customSimpleRabbitListenerContainer")
	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory() {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(rabbitMQConnectionFactory());
		/*factory.setConcurrentConsumers(200);
		factory.setMaxConcurrentConsumers(250);*/
		factory.setReceiveTimeout((long) 30000);
		return factory;
	}

	@Bean("getNslUpdateCancelRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getNslUpdateCancelRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getNslUpdateCancelFactory = new SimpleRabbitListenerContainerFactory();
			getNslUpdateCancelFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getNslUpdateCancelFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getNslUpdateCancelFactory.setPrefetchCount(1);
			getNslUpdateCancelFactory.setReceiveTimeout((long) 50000);
			getNslUpdateCancelFactory.setConnectionFactory(getNslUpdateCancelRabbitMQConnectionFactory());
			getNslUpdateCancelFactory.setErrorHandler(errorHandler());
			return getNslUpdateCancelFactory;
	}
	
	@Bean
	public ErrorHandler errorHandler() {
	    return new ConditionalRejectingErrorHandler(customExceptionStrategy());
	}
	
	@Bean
	FatalExceptionStrategy customExceptionStrategy() {
	    return new CustomFatalExceptionStrategy();
	}

	@Bean("getUpdateModifyRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getUpdateModifyRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getUpdateModifyFactory = new SimpleRabbitListenerContainerFactory();
			getUpdateModifyFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getUpdateModifyFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getUpdateModifyFactory.setPrefetchCount(1);
			getUpdateModifyFactory.setReceiveTimeout((long) 50000);
			getUpdateModifyFactory.setConnectionFactory(getUpdateModifyRabbitMQConnectionFactory());
			getUpdateModifyFactory.setErrorHandler(errorHandler());
			return getUpdateModifyFactory;
	}
	@Bean("getHmnoChangepsimRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoChangepsimRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoChangepsimFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoChangepsimFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoChangepsimFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoChangepsimFactory.setPrefetchCount(1);
			getHmnoChangepsimFactory.setReceiveTimeout((long) 50000);
			getHmnoChangepsimFactory.setConnectionFactory(getHmnoChangepsimRabbitMQConnectionFactory());
			getHmnoChangepsimFactory.setErrorHandler(errorHandler());
			return getHmnoChangepsimFactory;
	}
	@Bean("getHmnoDeviceinquiryRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoDeviceinquiryRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoDeviceinquiryFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoDeviceinquiryFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoDeviceinquiryFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoDeviceinquiryFactory.setPrefetchCount(1);
			getHmnoDeviceinquiryFactory.setReceiveTimeout((long) 50000);
			getHmnoDeviceinquiryFactory.setConnectionFactory(getHmnoDeviceinquiryRabbitMQConnectionFactory());
			getHmnoDeviceinquiryFactory.setErrorHandler(errorHandler());
			return getHmnoDeviceinquiryFactory;
	}
	@Bean("getHmnoChangeFeatureRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoChangeFeatureRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoChangeFeatureFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoChangeFeatureFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoChangeFeatureFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoChangeFeatureFactory.setPrefetchCount(1);
			getHmnoChangeFeatureFactory.setReceiveTimeout((long) 50000);
			getHmnoChangeFeatureFactory.setConnectionFactory(getHmnoChangeFeatureRabbitMQConnectionFactory());
			getHmnoChangeFeatureFactory.setErrorHandler(errorHandler());
			return getHmnoChangeFeatureFactory;
	}
	@Bean("getHmnoValidateSimRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoValidateSimRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoValidateSimFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoValidateSimFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoValidateSimFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoValidateSimFactory.setPrefetchCount(1);
			getHmnoValidateSimFactory.setReceiveTimeout((long) 50000);
			getHmnoValidateSimFactory.setConnectionFactory(getHmnoValidateSimRabbitMQConnectionFactory());
			getHmnoValidateSimFactory.setErrorHandler(errorHandler());
			return getHmnoValidateSimFactory;
	}
	@Bean("getHmnoDeviceinquiryAsyncRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoDeviceinquiryAsyncRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoDeviceinquiryAsyncFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoDeviceinquiryAsyncFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoDeviceinquiryAsyncFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoDeviceinquiryAsyncFactory.setPrefetchCount(1);
			getHmnoDeviceinquiryAsyncFactory.setReceiveTimeout((long) 50000);
			getHmnoDeviceinquiryAsyncFactory.setConnectionFactory(getHmnoDeviceinquiryAsyncRabbitMQConnectionFactory());
			getHmnoDeviceinquiryAsyncFactory.setErrorHandler(errorHandler());
			return getHmnoDeviceinquiryAsyncFactory;
	}
	@Bean("getHmnoLineHistoryInquiryServiceRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getHmnoLineHistoryInquiryServiceRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getHmnoLineHistoryInquiryServiceFactory = new SimpleRabbitListenerContainerFactory();
			getHmnoLineHistoryInquiryServiceFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getHmnoLineHistoryInquiryServiceFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getHmnoLineHistoryInquiryServiceFactory.setPrefetchCount(1);
			getHmnoLineHistoryInquiryServiceFactory.setReceiveTimeout((long) 50000);
			getHmnoLineHistoryInquiryServiceFactory.setConnectionFactory(getHmnoLineHistoryInquiryServiceRabbitMQConnectionFactory());
			getHmnoLineHistoryInquiryServiceFactory.setErrorHandler(errorHandler());
			return getHmnoLineHistoryInquiryServiceFactory;
	}
	@Bean("getMnoportinInquiryRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getMnoportinInquiryRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getMnoportinInquiryFactory = new SimpleRabbitListenerContainerFactory();
			getMnoportinInquiryFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getMnoportinInquiryFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getMnoportinInquiryFactory.setPrefetchCount(1);
			getMnoportinInquiryFactory.setReceiveTimeout((long) 50000);
			getMnoportinInquiryFactory.setConnectionFactory(getMnoportinInquiryRabbitMQConnectionFactory());
			getMnoportinInquiryFactory.setErrorHandler(errorHandler());
			return getMnoportinInquiryFactory;
	}
	@Bean("getMnoLineDetailsRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getMnoLineDetailsRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getMnoLineDetailsFactory = new SimpleRabbitListenerContainerFactory();
			getMnoLineDetailsFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getMnoLineDetailsFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getMnoLineDetailsFactory.setPrefetchCount(1);
			getMnoLineDetailsFactory.setReceiveTimeout((long) 50000);
			getMnoLineDetailsFactory.setConnectionFactory(getMnoLineDetailsRabbitMQConnectionFactory());
			getMnoLineDetailsFactory.setErrorHandler(errorHandler());
			return getMnoLineDetailsFactory;
	}
	@Bean("getActivateHotlineRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory getActivateHotlineRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory getActivateHotlineFactory = new SimpleRabbitListenerContainerFactory();
			getActivateHotlineFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			getActivateHotlineFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			getActivateHotlineFactory.setPrefetchCount(1);
			getActivateHotlineFactory.setReceiveTimeout((long) 50000);
			getActivateHotlineFactory.setConnectionFactory(getActivateHotlineRabbitMQConnectionFactory());
			getActivateHotlineFactory.setErrorHandler(errorHandler());
			return getActivateHotlineFactory;
	}	

	@Bean("customRabbitTemplate")
	public RabbitTemplate customRabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setReplyTimeout(30000L);
		rabbitTemplate.setConnectionFactory(rabbitMQConnectionFactory());
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}

	@Bean()
	public RabbitTemplate getNslUpdateCancelCustomRabbitTemplate() {
		RabbitTemplate getNslUpdateCancelRabbitTemplate = new RabbitTemplate();
		getNslUpdateCancelRabbitTemplate.setReplyTimeout(30000L);
		getNslUpdateCancelRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getNslUpdateCancelRabbitTemplate.setConnectionFactory(getNslUpdateCancelRabbitMQConnectionFactory());
		return getNslUpdateCancelRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getUpdateModifyCustomRabbitTemplate() {
		RabbitTemplate getUpdateModifyRabbitTemplate = new RabbitTemplate();
		getUpdateModifyRabbitTemplate.setReplyTimeout(30000L);
		getUpdateModifyRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getUpdateModifyRabbitTemplate.setConnectionFactory(getUpdateModifyRabbitMQConnectionFactory());
		return getUpdateModifyRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoChangepsimCustomRabbitTemplate() {
		RabbitTemplate getHmnoChangepsimRabbitTemplate = new RabbitTemplate();
		getHmnoChangepsimRabbitTemplate.setReplyTimeout(30000L);
		getHmnoChangepsimRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoChangepsimRabbitTemplate.setConnectionFactory(getHmnoChangepsimRabbitMQConnectionFactory());
		return getHmnoChangepsimRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoDeviceinquiryCustomRabbitTemplate() {
		RabbitTemplate getHmnoDeviceinquiryRabbitTemplate = new RabbitTemplate();
		getHmnoDeviceinquiryRabbitTemplate.setReplyTimeout(30000L);
		getHmnoDeviceinquiryRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoDeviceinquiryRabbitTemplate.setConnectionFactory(getHmnoDeviceinquiryRabbitMQConnectionFactory());
		return getHmnoDeviceinquiryRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoChangeFeatureCustomRabbitTemplate() {
		RabbitTemplate getHmnoChangeFeatureRabbitTemplate = new RabbitTemplate();
		getHmnoChangeFeatureRabbitTemplate.setReplyTimeout(30000L);
		getHmnoChangeFeatureRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoChangeFeatureRabbitTemplate.setConnectionFactory(getHmnoChangeFeatureRabbitMQConnectionFactory());
		return getHmnoChangeFeatureRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoValidateSimCustomRabbitTemplate() {
		RabbitTemplate getHmnoValidateSimRabbitTemplate = new RabbitTemplate();
		getHmnoValidateSimRabbitTemplate.setReplyTimeout(30000L);
		getHmnoValidateSimRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoValidateSimRabbitTemplate.setConnectionFactory(getHmnoValidateSimRabbitMQConnectionFactory());
		return getHmnoValidateSimRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoDeviceinquiryAsyncCustomRabbitTemplate() {
		RabbitTemplate getHmnoDeviceinquiryAsyncRabbitTemplate = new RabbitTemplate();
		getHmnoDeviceinquiryAsyncRabbitTemplate.setReplyTimeout(30000L);
		getHmnoDeviceinquiryAsyncRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoDeviceinquiryAsyncRabbitTemplate.setConnectionFactory(getHmnoDeviceinquiryAsyncRabbitMQConnectionFactory());
		return getHmnoDeviceinquiryAsyncRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getHmnoLineHistoryInquiryServiceCustomRabbitTemplate() {
		RabbitTemplate getHmnoLineHistoryInquiryServiceRabbitTemplate = new RabbitTemplate();
		getHmnoLineHistoryInquiryServiceRabbitTemplate.setReplyTimeout(30000L);
		getHmnoLineHistoryInquiryServiceRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getHmnoLineHistoryInquiryServiceRabbitTemplate.setConnectionFactory(getHmnoLineHistoryInquiryServiceRabbitMQConnectionFactory());
		return getHmnoLineHistoryInquiryServiceRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getMnoportinInquiryCustomRabbitTemplate() {
		RabbitTemplate getMnoportinInquiryRabbitTemplate = new RabbitTemplate();
		getMnoportinInquiryRabbitTemplate.setReplyTimeout(30000L);
		getMnoportinInquiryRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getMnoportinInquiryRabbitTemplate.setConnectionFactory(getMnoportinInquiryRabbitMQConnectionFactory());
		return getMnoportinInquiryRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getMnoLineDetailsCustomRabbitTemplate() {
		RabbitTemplate getMnoLineDetailsRabbitTemplate = new RabbitTemplate();
		getMnoLineDetailsRabbitTemplate.setReplyTimeout(30000L);
		getMnoLineDetailsRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getMnoLineDetailsRabbitTemplate.setConnectionFactory(getMnoLineDetailsRabbitMQConnectionFactory());
		return getMnoLineDetailsRabbitTemplate;
	}
	@Bean()
	public RabbitTemplate getActivateHotlineCustomRabbitTemplate() {
		RabbitTemplate getActivateHotlineRabbitTemplate = new RabbitTemplate();
		getActivateHotlineRabbitTemplate.setReplyTimeout(30000L);
		getActivateHotlineRabbitTemplate.setMessageConverter(jsonMessageConverter());
		getActivateHotlineRabbitTemplate.setConnectionFactory(getActivateHotlineRabbitMQConnectionFactory());
		return getActivateHotlineRabbitTemplate;
	}
	
	@Bean(name = "suspendSubscriberConnectionFactory")
	public ConnectionFactory suspendSubscriberRabbitMQConnectionFactory() {
			CachingConnectionFactory suspendSubscriberConnectionFactory = new CachingConnectionFactory(host);
			suspendSubscriberConnectionFactory.setPort(Integer.parseInt(port));
			suspendSubscriberConnectionFactory.setUsername(username);
			suspendSubscriberConnectionFactory.setPassword(password);
			suspendSubscriberConnectionFactory.setConnectionTimeout(30000);
			return suspendSubscriberConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin suspendSubscriberRabbitAdmin(){
        return new RabbitAdmin(suspendSubscriberRabbitMQConnectionFactory());
    }
	
	@Bean("suspendSubscriberRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory suspendSubscriberRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory suspendSubscriberServiceFactory = new SimpleRabbitListenerContainerFactory();
			suspendSubscriberServiceFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			suspendSubscriberServiceFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			suspendSubscriberServiceFactory.setPrefetchCount(1);
			suspendSubscriberServiceFactory.setReceiveTimeout((long) 50000);
			suspendSubscriberServiceFactory.setConnectionFactory(suspendSubscriberRabbitMQConnectionFactory());
			suspendSubscriberServiceFactory.setErrorHandler(errorHandler());
			return suspendSubscriberServiceFactory;
	}

	@Bean()
	public RabbitTemplate suspendSubscriberCustomRabbitTemplate() {
		RabbitTemplate suspendSubscriberRabbitTemplate = new RabbitTemplate();
		suspendSubscriberRabbitTemplate.setReplyTimeout(30000L);
		suspendSubscriberRabbitTemplate.setMessageConverter(jsonMessageConverter());
		suspendSubscriberRabbitTemplate.setConnectionFactory(suspendSubscriberRabbitMQConnectionFactory());
		return suspendSubscriberRabbitTemplate;
	}
	
	
	@Bean(name = "restoreSubscriberConnectionFactory")
	public ConnectionFactory restoreSubscriberRabbitMQConnectionFactory() {
			CachingConnectionFactory restoreSubscriberConnectionFactory = new CachingConnectionFactory(host);
			restoreSubscriberConnectionFactory.setPort(Integer.parseInt(port));
			restoreSubscriberConnectionFactory.setUsername(username);
			restoreSubscriberConnectionFactory.setPassword(password);
			restoreSubscriberConnectionFactory.setConnectionTimeout(30000);
			return restoreSubscriberConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin restoreSubscriberRabbitAdmin(){
        return new RabbitAdmin((restoreSubscriberRabbitMQConnectionFactory()));
    }
	
	@Bean("restoreSubscriberRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory restoreSubscriberRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory restoreSubscriberFactory = new SimpleRabbitListenerContainerFactory();
			restoreSubscriberFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			restoreSubscriberFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			restoreSubscriberFactory.setPrefetchCount(1);
			restoreSubscriberFactory.setReceiveTimeout((long) 50000);
			restoreSubscriberFactory.setConnectionFactory(restoreSubscriberRabbitMQConnectionFactory());
			restoreSubscriberFactory.setErrorHandler(errorHandler());
			return restoreSubscriberFactory;
	}

	@Bean()
	public RabbitTemplate restoreSubscriberCustomRabbitTemplate() {
		RabbitTemplate restoreSubscriberRabbitTemplate = new RabbitTemplate();
		restoreSubscriberRabbitTemplate.setReplyTimeout(30000L);
		restoreSubscriberRabbitTemplate.setMessageConverter(jsonMessageConverter());
		restoreSubscriberRabbitTemplate.setConnectionFactory(restoreSubscriberRabbitMQConnectionFactory());
		return restoreSubscriberRabbitTemplate;
	}
	
	@Bean(name = "activateSubscriberConnectionFactory")
	public ConnectionFactory activateSubscriberRabbitMQConnectionFactory() {
			CachingConnectionFactory activateSubscriberConnectionFactory = new CachingConnectionFactory(host);
			activateSubscriberConnectionFactory.setPort(Integer.parseInt(port));
			activateSubscriberConnectionFactory.setUsername(username);
			activateSubscriberConnectionFactory.setPassword(password);
			activateSubscriberConnectionFactory.setConnectionTimeout(30000);
			return activateSubscriberConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin activateSubscriberRabbitAdmin(){
        return new RabbitAdmin(activateSubscriberRabbitMQConnectionFactory());
    }
	
	@Bean("activateSubscriberabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory activateSubscriberRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory activateSubscriberFactory = new SimpleRabbitListenerContainerFactory();
			activateSubscriberFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			activateSubscriberFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			activateSubscriberFactory.setPrefetchCount(1);
			activateSubscriberFactory.setReceiveTimeout((long) 50000);
			activateSubscriberFactory.setConnectionFactory(activateSubscriberRabbitMQConnectionFactory());
			activateSubscriberFactory.setErrorHandler(errorHandler());
			return activateSubscriberFactory;
	}

	@Bean()
	public RabbitTemplate activateSubscriberCustomRabbitTemplate() {
		RabbitTemplate activateSubscriberRabbitTemplate = new RabbitTemplate();
		activateSubscriberRabbitTemplate.setReplyTimeout(30000L);
		activateSubscriberRabbitTemplate.setMessageConverter(jsonMessageConverter());
		activateSubscriberRabbitTemplate.setConnectionFactory(activateSubscriberRabbitMQConnectionFactory());
		return activateSubscriberRabbitTemplate;
	}
	
	@Bean(name = "activatePortinSubscriberConnectionFactory")
	public ConnectionFactory activatePortinSubscriberRabbitMQConnectionFactory() {
			CachingConnectionFactory activateSubscriberPortinConnectionFactory = new CachingConnectionFactory(host);
			activateSubscriberPortinConnectionFactory.setPort(Integer.parseInt(port));
			activateSubscriberPortinConnectionFactory.setUsername(username);
			activateSubscriberPortinConnectionFactory.setPassword(password);
			activateSubscriberPortinConnectionFactory.setConnectionTimeout(30000);
			return activateSubscriberPortinConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin activateSubscriberPortinRabbitAdmin(){
        return new RabbitAdmin(activatePortinSubscriberRabbitMQConnectionFactory());
    }
	
	@Bean("activatePortinSubscriberabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory activatePortinSubscriberRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory activatePortinSubscriberFactory = new SimpleRabbitListenerContainerFactory();
			activatePortinSubscriberFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			activatePortinSubscriberFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			activatePortinSubscriberFactory.setPrefetchCount(1);
			activatePortinSubscriberFactory.setReceiveTimeout((long) 50000);
			activatePortinSubscriberFactory.setConnectionFactory(activatePortinSubscriberRabbitMQConnectionFactory());
			activatePortinSubscriberFactory.setErrorHandler(errorHandler());
			return activatePortinSubscriberFactory;
	}

	@Bean()
	public RabbitTemplate activatePortinSubscriberCustomRabbitTemplate() {
		RabbitTemplate activatePortinSubscriberRabbitTemplate = new RabbitTemplate();
		activatePortinSubscriberRabbitTemplate.setReplyTimeout(30000L);
		activatePortinSubscriberRabbitTemplate.setMessageConverter(jsonMessageConverter());
		activatePortinSubscriberRabbitTemplate.setConnectionFactory(activatePortinSubscriberRabbitMQConnectionFactory());
		return activatePortinSubscriberRabbitTemplate;
	}
	
	@Bean(name = "deactivateSubscriberConnectionFactory")
	public ConnectionFactory deactivateSubscriberRabbitMQConnectionFactory() {
			CachingConnectionFactory deactivateSubscriberConnectionFactory = new CachingConnectionFactory(host);
			deactivateSubscriberConnectionFactory.setPort(Integer.parseInt(port));
			deactivateSubscriberConnectionFactory.setUsername(username);
			deactivateSubscriberConnectionFactory.setPassword(password);
			deactivateSubscriberConnectionFactory.setConnectionTimeout(30000);
			return deactivateSubscriberConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin deactivateSubscriberPortinRabbitAdmin(){
        return new RabbitAdmin(deactivateSubscriberRabbitMQConnectionFactory());
    }
	
	@Bean("deactivateSubscriberabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory deactivateSubscriberRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory deactivateSubscriberFactory = new SimpleRabbitListenerContainerFactory();
			deactivateSubscriberFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			deactivateSubscriberFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			deactivateSubscriberFactory.setPrefetchCount(1);
			deactivateSubscriberFactory.setReceiveTimeout((long) 50000);
			deactivateSubscriberFactory.setConnectionFactory(deactivateSubscriberRabbitMQConnectionFactory());
			deactivateSubscriberFactory.setErrorHandler(errorHandler());
			return deactivateSubscriberFactory;
	}

	@Bean()
	public RabbitTemplate deactivateSubscriberCustomRabbitTemplate() {
		RabbitTemplate deactivateSubscriberRabbitTemplate = new RabbitTemplate();
		deactivateSubscriberRabbitTemplate.setReplyTimeout(30000L);
		deactivateSubscriberRabbitTemplate.setMessageConverter(jsonMessageConverter());
		deactivateSubscriberRabbitTemplate.setConnectionFactory(deactivateSubscriberRabbitMQConnectionFactory());
		return deactivateSubscriberRabbitTemplate;
	}
	
	@Bean
	public Queue resetFeatureQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getResetfeatureQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange resetFeatureExchange() {
		return new DirectExchange(inboundQueueProperties.getResetfeatureExchange());
	}

	@Bean
	Binding resetFeatureBinding() {
		return BindingBuilder.bind(resetFeatureQueue()).to(resetFeatureExchange())
				.with(inboundQueueProperties.getResetfeatureQueue());
	}
	
	@Bean(name = "resetFeatureConnectionFactory")
	public ConnectionFactory resetFeatureRabbitMQConnectionFactory() {
			CachingConnectionFactory resetFeatureConnectionFactory = new CachingConnectionFactory(host);
			resetFeatureConnectionFactory.setPort(Integer.parseInt(port));
			resetFeatureConnectionFactory.setUsername(username);
			resetFeatureConnectionFactory.setPassword(password);
			resetFeatureConnectionFactory.setConnectionTimeout(30000);
			return resetFeatureConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin resetFeatureRabbitAdmin(){
        return new RabbitAdmin(resetFeatureRabbitMQConnectionFactory());
    }
	
	@Bean("resetFeatureRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory resetFeatureRabbitListenerContainerFactory(){
			SimpleRabbitListenerContainerFactory resetFeatureFactory = new SimpleRabbitListenerContainerFactory();
			resetFeatureFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			resetFeatureFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			resetFeatureFactory.setPrefetchCount(1);
			resetFeatureFactory.setReceiveTimeout((long) 50000);
			resetFeatureFactory.setConnectionFactory(resetFeatureRabbitMQConnectionFactory());
			resetFeatureFactory.setErrorHandler(errorHandler());
			return resetFeatureFactory;
	}

	@Bean()
	public RabbitTemplate resetFeatureCustomRabbitTemplate() {
		RabbitTemplate resetFeatureRabbitTemplate = new RabbitTemplate();
		resetFeatureRabbitTemplate.setReplyTimeout(30000L);
		resetFeatureRabbitTemplate.setMessageConverter(jsonMessageConverter());
		resetFeatureRabbitTemplate.setConnectionFactory(resetFeatureRabbitMQConnectionFactory());
		return resetFeatureRabbitTemplate;
	}
	
	@Bean
	public Queue orderInquiryQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getOrderinquiryQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange orderInquiryExchange() {
		return new DirectExchange(inboundQueueProperties.getOrderinquiryExchange());
	}

	@Bean
	Binding orderInquiryBinding() {
		return BindingBuilder.bind(orderInquiryQueue()).to(orderInquiryExchange())
				.with(inboundQueueProperties.getOrderinquiryQueue());
	}
	
	@Bean(name = "orderInquiryConnectionFactory")
	public ConnectionFactory orderInquiryRabbitMQConnectionFactory() {
			CachingConnectionFactory orderInquiryConnectionFactory = new CachingConnectionFactory(host);
			orderInquiryConnectionFactory.setPort(Integer.parseInt(port));
			orderInquiryConnectionFactory.setUsername(username);
			orderInquiryConnectionFactory.setPassword(password);
			orderInquiryConnectionFactory.setConnectionTimeout(30000);
			return orderInquiryConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin orderInquiryRabbitAdmin(){
        return new RabbitAdmin(orderInquiryRabbitMQConnectionFactory());
    }
	
	@Bean("orderInquiryRabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory orderInquiryRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory orderInquiryFactory = new SimpleRabbitListenerContainerFactory();
			orderInquiryFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			orderInquiryFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			orderInquiryFactory.setPrefetchCount(1);
			orderInquiryFactory.setReceiveTimeout((long) 50000);
			orderInquiryFactory.setConnectionFactory(orderInquiryRabbitMQConnectionFactory());
			orderInquiryFactory.setErrorHandler(errorHandler());
			return orderInquiryFactory;
	}

	@Bean()
	public RabbitTemplate orderInquiryCustomRabbitTemplate() {
		RabbitTemplate orderInquiryRabbitTemplate = new RabbitTemplate();
		orderInquiryRabbitTemplate.setReplyTimeout(30000L);
		orderInquiryRabbitTemplate.setMessageConverter(jsonMessageConverter());
		orderInquiryRabbitTemplate.setConnectionFactory(orderInquiryRabbitMQConnectionFactory());
		return orderInquiryRabbitTemplate;
	}
	
	@Bean
	public Queue changeFeatureAsyncQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getChangefeatureasyncQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange changeFeatureAsyncExchange() {
		return new DirectExchange(inboundQueueProperties.getChangefeatureasyncExchange());
	}

	@Bean
	Binding changeFeatureAsyncBinding() {
		return BindingBuilder.bind(changeFeatureAsyncQueue()).to(changeFeatureAsyncExchange())
				.with(inboundQueueProperties.getChangefeatureasyncQueue());
	}
	
	@Bean(name = "changeFeatureAsyncConnectionFactory")
	public ConnectionFactory changeFeatureAsyncRabbitMQConnectionFactory() {
			CachingConnectionFactory changeFeatureAsyncConnectionFactory = new CachingConnectionFactory(host);
			changeFeatureAsyncConnectionFactory.setPort(Integer.parseInt(port));
			changeFeatureAsyncConnectionFactory.setUsername(username);
			changeFeatureAsyncConnectionFactory.setPassword(password);
			changeFeatureAsyncConnectionFactory.setConnectionTimeout(30000);
			return changeFeatureAsyncConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin changeFeatureAsyncRabbitAdmin(){
        return new RabbitAdmin(changeFeatureAsyncRabbitMQConnectionFactory());
    }
	
	@Bean("changeFeatureAsyncrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory changeFeatureAsyncRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory changeFeatureAsyncFactory = new SimpleRabbitListenerContainerFactory();
			changeFeatureAsyncFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			changeFeatureAsyncFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			changeFeatureAsyncFactory.setPrefetchCount(1);
			changeFeatureAsyncFactory.setReceiveTimeout((long) 50000);
			changeFeatureAsyncFactory.setConnectionFactory(changeFeatureAsyncRabbitMQConnectionFactory());
			changeFeatureAsyncFactory.setErrorHandler(errorHandler());
			return changeFeatureAsyncFactory;
	}

	@Bean()
	public RabbitTemplate changeFeatureAsyncCustomRabbitTemplate() {
		RabbitTemplate changeFeatureAsyncRabbitTemplate = new RabbitTemplate();
		changeFeatureAsyncRabbitTemplate.setReplyTimeout(30000L);
		changeFeatureAsyncRabbitTemplate.setMessageConverter(jsonMessageConverter());
		changeFeatureAsyncRabbitTemplate.setConnectionFactory(changeFeatureAsyncRabbitMQConnectionFactory());
		return changeFeatureAsyncRabbitTemplate;
	}
	
	@Bean
	public Queue changePSimAsyncQueue() {
	    return QueueBuilder.durable(inboundQueueProperties.getHmnochangepsimasyncQueue())
				.withArgument("x-dead-letter-exchange", dlqExchange).withArgument("x-dead-letter-routing-key", dlqueue)
				.build();
	}

	@Bean
	public DirectExchange changePSimAsyncExchange() {
		return new DirectExchange(inboundQueueProperties.getHmnochangepsimasyncExchange());
	}

	@Bean
	Binding changePSimAsyncBinding() {
		return BindingBuilder.bind(changeFeatureAsyncQueue()).to(changePSimAsyncExchange())
				.with(inboundQueueProperties.getHmnochangepsimasyncQueue());
	}
	
	@Bean(name = "changePSimAsyncConnectionFactory")
	public ConnectionFactory changePSimAsyncRabbitMQConnectionFactory() {
			CachingConnectionFactory changePSimAsyncConnectionFactory = new CachingConnectionFactory(host);
			changePSimAsyncConnectionFactory.setPort(Integer.parseInt(port));
			changePSimAsyncConnectionFactory.setUsername(username);
			changePSimAsyncConnectionFactory.setPassword(password);
			changePSimAsyncConnectionFactory.setConnectionTimeout(30000);
			return changePSimAsyncConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin changePSimAsyncRabbitAdmin(){
        return new RabbitAdmin(changePSimAsyncRabbitMQConnectionFactory());
    }
	
	@Bean("changePSimAsyncrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory changePSimAsyncRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory changePSimAsyncFactory = new SimpleRabbitListenerContainerFactory();
			changePSimAsyncFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			changePSimAsyncFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			changePSimAsyncFactory.setPrefetchCount(1);
			changePSimAsyncFactory.setReceiveTimeout((long) 50000);
			changePSimAsyncFactory.setConnectionFactory(changePSimAsyncRabbitMQConnectionFactory());
			changePSimAsyncFactory.setErrorHandler(errorHandler());
			return changePSimAsyncFactory;
	}

	@Bean()
	public RabbitTemplate changePSimAsyncCustomRabbitTemplate() {
		RabbitTemplate changePSimAsyncRabbitTemplate = new RabbitTemplate();
		changePSimAsyncRabbitTemplate.setReplyTimeout(30000L);
		changePSimAsyncRabbitTemplate.setMessageConverter(jsonMessageConverter());
		changePSimAsyncRabbitTemplate.setConnectionFactory(changePSimAsyncRabbitMQConnectionFactory());
		return changePSimAsyncRabbitTemplate;
	}
	
	@Bean(name = "changeRatePlanConnectionFactory")
	public ConnectionFactory changeRatePlanRabbitMQConnectionFactory() {
			CachingConnectionFactory changeRatePlanConnectionFactory = new CachingConnectionFactory(host);
			changeRatePlanConnectionFactory.setPort(Integer.parseInt(port));
			changeRatePlanConnectionFactory.setUsername(username);
			changeRatePlanConnectionFactory.setPassword(password);
			changeRatePlanConnectionFactory.setConnectionTimeout(30000);
			return changeRatePlanConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin changeRatePlanPortinRabbitAdmin(){
        return new RabbitAdmin(changeRatePlanRabbitMQConnectionFactory());
    }
	
	@Bean("changeRatePlanrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory changeRatePlanRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory changeRatePlanFactory = new SimpleRabbitListenerContainerFactory();
			changeRatePlanFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			changeRatePlanFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			changeRatePlanFactory.setPrefetchCount(1);
			changeRatePlanFactory.setReceiveTimeout((long) 50000);
			changeRatePlanFactory.setConnectionFactory(changeRatePlanRabbitMQConnectionFactory());
			changeRatePlanFactory.setErrorHandler(errorHandler());
			return changeRatePlanFactory;
	}

	@Bean()
	public RabbitTemplate changeRatePlanCustomRabbitTemplate() {
		RabbitTemplate changeRatePlanRabbitTemplate = new RabbitTemplate();
		changeRatePlanRabbitTemplate.setReplyTimeout(30000L);
		changeRatePlanRabbitTemplate.setMessageConverter(jsonMessageConverter());
		changeRatePlanRabbitTemplate.setConnectionFactory(changeRatePlanRabbitMQConnectionFactory());
		return changeRatePlanRabbitTemplate;
	}
	@Bean(name = "changeMdnConnectionFactory")
	public ConnectionFactory changeMdnRabbitMQConnectionFactory() {
			CachingConnectionFactory changeMdnConnectionFactory = new CachingConnectionFactory(host);
			changeMdnConnectionFactory.setPort(Integer.parseInt(port));
			changeMdnConnectionFactory.setUsername(username);
			changeMdnConnectionFactory.setPassword(password);
			changeMdnConnectionFactory.setConnectionTimeout(30000);
			return changeMdnConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin changeMdnRabbitAdmin(){
        return new RabbitAdmin(changeMdnRabbitMQConnectionFactory());
    }
	
	@Bean("changeMdnrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory changeMdnRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory changeMdnFactory = new SimpleRabbitListenerContainerFactory();
			changeMdnFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			changeMdnFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			changeMdnFactory.setPrefetchCount(1);
			changeMdnFactory.setReceiveTimeout((long) 50000);
			changeMdnFactory.setConnectionFactory(changeMdnRabbitMQConnectionFactory());
			changeMdnFactory.setErrorHandler(errorHandler());
			return changeMdnFactory;
	}

	@Bean()
	public RabbitTemplate changeMdnCustomRabbitTemplate() {
		RabbitTemplate changeMdnRabbitTemplate = new RabbitTemplate();
		changeMdnRabbitTemplate.setReplyTimeout(30000L);
		changeMdnRabbitTemplate.setMessageConverter(jsonMessageConverter());
		changeMdnRabbitTemplate.setConnectionFactory(changeMdnRabbitMQConnectionFactory());
		return changeMdnRabbitTemplate;
	}
	
	@Bean(name = "lineInquiryConnectionFactory")
	public ConnectionFactory lineInquiryRabbitMQConnectionFactory() {
			CachingConnectionFactory lineInquiryConnectionFactory = new CachingConnectionFactory(host);
			lineInquiryConnectionFactory.setPort(Integer.parseInt(port));
			lineInquiryConnectionFactory.setUsername(username);
			lineInquiryConnectionFactory.setPassword(password);
			lineInquiryConnectionFactory.setConnectionTimeout(30000);
			return lineInquiryConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin lineInquiryRabbitAdmin(){
        return new RabbitAdmin(lineInquiryRabbitMQConnectionFactory());
    }
	
	@Bean("lineInquiryrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory lineInquiryRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory lineInquiryFactory = new SimpleRabbitListenerContainerFactory();
			lineInquiryFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			lineInquiryFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			lineInquiryFactory.setPrefetchCount(1);
			lineInquiryFactory.setReceiveTimeout((long) 50000);
			lineInquiryFactory.setConnectionFactory(lineInquiryRabbitMQConnectionFactory());
			lineInquiryFactory.setErrorHandler(errorHandler());
			return lineInquiryFactory;
	}

	@Bean()
	public RabbitTemplate lineInquiryCustomRabbitTemplate() {
		RabbitTemplate lineInquiryRabbitTemplate = new RabbitTemplate();
		lineInquiryRabbitTemplate.setReplyTimeout(30000L);
		lineInquiryRabbitTemplate.setMessageConverter(jsonMessageConverter());
		lineInquiryRabbitTemplate.setConnectionFactory(lineInquiryRabbitMQConnectionFactory());
		return lineInquiryRabbitTemplate;
	}
	
	@Bean(name = "removeHotlineConnectionFactory")
	public ConnectionFactory removeHotlineRabbitMQConnectionFactory() {
			CachingConnectionFactory removeHotlineConnectionFactory = new CachingConnectionFactory(host);
			removeHotlineConnectionFactory.setPort(Integer.parseInt(port));
			removeHotlineConnectionFactory.setUsername(username);
			removeHotlineConnectionFactory.setPassword(password);
			removeHotlineConnectionFactory.setConnectionTimeout(30000);
			return removeHotlineConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin removeHotlineRabbitAdmin(){
        return new RabbitAdmin(removeHotlineRabbitMQConnectionFactory());
    }
	
	@Bean("removeHotlinerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory removeHotlineRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory removeHotlineFactory = new SimpleRabbitListenerContainerFactory();
			removeHotlineFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			removeHotlineFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			removeHotlineFactory.setPrefetchCount(1);
			removeHotlineFactory.setReceiveTimeout((long) 50000);
			removeHotlineFactory.setConnectionFactory(removeHotlineRabbitMQConnectionFactory());
			removeHotlineFactory.setErrorHandler(errorHandler());
			return removeHotlineFactory;
	}

	@Bean()
	public RabbitTemplate removeHotlineCustomRabbitTemplate() {
		RabbitTemplate removeHotlineRabbitTemplate = new RabbitTemplate();
		removeHotlineRabbitTemplate.setReplyTimeout(30000L);
		removeHotlineRabbitTemplate.setMessageConverter(jsonMessageConverter());
		removeHotlineRabbitTemplate.setConnectionFactory(removeHotlineRabbitMQConnectionFactory());
		return removeHotlineRabbitTemplate;
	}
	
	@Bean(name = "updatePortoutConnectionFactory")
	public ConnectionFactory updatePortoutRabbitMQConnectionFactory() {
			CachingConnectionFactory updatePortoutConnectionFactory = new CachingConnectionFactory(host);
			updatePortoutConnectionFactory.setPort(Integer.parseInt(port));
			updatePortoutConnectionFactory.setUsername(username);
			updatePortoutConnectionFactory.setPassword(password);
			updatePortoutConnectionFactory.setConnectionTimeout(30000);
			return updatePortoutConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin updatePortoutRabbitAdmin(){
        return new RabbitAdmin(updatePortoutRabbitMQConnectionFactory());
    }
	
	@Bean("updatePortoutrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory updatePortoutRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory updatePortoutFactory = new SimpleRabbitListenerContainerFactory();
			updatePortoutFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			updatePortoutFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			updatePortoutFactory.setPrefetchCount(1);
			updatePortoutFactory.setReceiveTimeout((long) 50000);
			updatePortoutFactory.setConnectionFactory(updatePortoutRabbitMQConnectionFactory());
			updatePortoutFactory.setErrorHandler(errorHandler());
			return updatePortoutFactory;
	}

	@Bean()
	public RabbitTemplate updatePortoutCustomRabbitTemplate() {
		RabbitTemplate updatePortoutRabbitTemplate = new RabbitTemplate();
		updatePortoutRabbitTemplate.setReplyTimeout(30000L);
		updatePortoutRabbitTemplate.setMessageConverter(jsonMessageConverter());
		updatePortoutRabbitTemplate.setConnectionFactory(updatePortoutRabbitMQConnectionFactory());
		return updatePortoutRabbitTemplate;
	}
	
	@Bean(name = "updateDuedatePortinConnectionFactory")
	public ConnectionFactory updateDuedatePortinRabbitMQConnectionFactory() {
			CachingConnectionFactory updateDuedatePortinConnectionFactory = new CachingConnectionFactory(host);
			updateDuedatePortinConnectionFactory.setPort(Integer.parseInt(port));
			updateDuedatePortinConnectionFactory.setUsername(username);
			updateDuedatePortinConnectionFactory.setPassword(password);
			updateDuedatePortinConnectionFactory.setConnectionTimeout(30000);
			return updateDuedatePortinConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin updateDuedatePortinRabbitAdmin(){
        return new RabbitAdmin(updateDuedatePortinRabbitMQConnectionFactory());
    }
	
	@Bean("updateDuedatePortinrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory updateDuedatePortinRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory updateDuedatePortinFactory = new SimpleRabbitListenerContainerFactory();
			updateDuedatePortinFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			updateDuedatePortinFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			updateDuedatePortinFactory.setPrefetchCount(1);
			updateDuedatePortinFactory.setReceiveTimeout((long) 50000);
			updateDuedatePortinFactory.setConnectionFactory(updateDuedatePortinRabbitMQConnectionFactory());
			updateDuedatePortinFactory.setErrorHandler(errorHandler());
			return updateDuedatePortinFactory;
	}

	@Bean()
	public RabbitTemplate updateDuedatePortinCustomRabbitTemplate() {
		RabbitTemplate updateDuedatePortinRabbitTemplate = new RabbitTemplate();
		updateDuedatePortinRabbitTemplate.setReplyTimeout(30000L);
		updateDuedatePortinRabbitTemplate.setMessageConverter(jsonMessageConverter());
		updateDuedatePortinRabbitTemplate.setConnectionFactory(updateDuedatePortinRabbitMQConnectionFactory());
		return updateDuedatePortinRabbitTemplate;
	}
	
	@Bean(name = "validateMdnConnectionFactory")
	public ConnectionFactory validateMdnRabbitMQConnectionFactory() {
			CachingConnectionFactory validateMdnConnectionFactory = new CachingConnectionFactory(host);
			validateMdnConnectionFactory.setPort(Integer.parseInt(port));
			validateMdnConnectionFactory.setUsername(username);
			validateMdnConnectionFactory.setPassword(password);
			validateMdnConnectionFactory.setConnectionTimeout(30000);
			return validateMdnConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin validateMdnRabbitAdmin(){
        return new RabbitAdmin(validateMdnRabbitMQConnectionFactory());
    }
	
	@Bean("validateMdnrabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory validateMdnRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory validateMdnFactory = new SimpleRabbitListenerContainerFactory();
			validateMdnFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			validateMdnFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			validateMdnFactory.setPrefetchCount(1);
			validateMdnFactory.setReceiveTimeout((long) 50000);
			validateMdnFactory.setConnectionFactory(validateMdnRabbitMQConnectionFactory());
			validateMdnFactory.setErrorHandler(errorHandler());
			return validateMdnFactory;
	}

	@Bean()
	public RabbitTemplate validateMdnCustomRabbitTemplate() {
		RabbitTemplate validateMdnRabbitTemplate = new RabbitTemplate();
		validateMdnRabbitTemplate.setReplyTimeout(30000L);
		validateMdnRabbitTemplate.setMessageConverter(jsonMessageConverter());
		validateMdnRabbitTemplate.setConnectionFactory(validateMdnRabbitMQConnectionFactory());
		return validateMdnRabbitTemplate;
	}
	
	@Bean(name = "validateDeviceConnectionFactory")
	public ConnectionFactory validateDeviceRabbitMQConnectionFactory() {
			CachingConnectionFactory validateDeviceConnectionFactory = new CachingConnectionFactory(host);
			validateDeviceConnectionFactory.setPort(Integer.parseInt(port));
			validateDeviceConnectionFactory.setUsername(username);
			validateDeviceConnectionFactory.setPassword(password);
			validateDeviceConnectionFactory.setConnectionTimeout(30000);
			return validateDeviceConnectionFactory;
	}
	
	@Bean()
    RabbitAdmin validateDeviceRabbitAdmin(){
        return new RabbitAdmin(validateDeviceRabbitMQConnectionFactory());
    }
	
	@Bean("validateDevicerabbitListenerContainerFactory")
	public SimpleRabbitListenerContainerFactory validateDeviceRabbitListenerContainerFactory (){
			SimpleRabbitListenerContainerFactory validateDeviceFactory = new SimpleRabbitListenerContainerFactory();
			validateDeviceFactory.setConcurrentConsumers(Integer.parseInt(concurrentConsumers));
			validateDeviceFactory.setMaxConcurrentConsumers(Integer.parseInt(maxConcurrentConsumers));
			validateDeviceFactory.setPrefetchCount(1);
			validateDeviceFactory.setReceiveTimeout((long) 50000);
			validateDeviceFactory.setConnectionFactory(validateDeviceRabbitMQConnectionFactory());
			validateDeviceFactory.setErrorHandler(errorHandler());
			return validateDeviceFactory;
	}

	@Bean()
	public RabbitTemplate validateDeviceCustomRabbitTemplate() {
		RabbitTemplate validateDeviceRabbitTemplate = new RabbitTemplate();
		validateDeviceRabbitTemplate.setReplyTimeout(30000L);
		validateDeviceRabbitTemplate.setMessageConverter(jsonMessageConverter());
		validateDeviceRabbitTemplate.setConnectionFactory(validateDeviceRabbitMQConnectionFactory());
		return validateDeviceRabbitTemplate;
	}
	
	
}