package com.nsl.usagereport.nbos.dao.repository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.nbos.entity.WibInfo;
import com.nsl.usagereport.postgres.repository.NslDao;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("WibInfoDaoImpl")
public class WibInfoDaoImpl implements NslDao {

	@Autowired
	private WibInfoRepository wibInfoRepository;

	@Override
	public void save(List<Object> list) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<WibInfo> dataDetails = list.stream().map(s -> (WibInfo) s).collect(Collectors.toList());
			wibInfoRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

	public Set<String> getRouterIds() {
		return wibInfoRepository.findAll().stream().map(e->(String)e.getRouterId()).distinct().collect(Collectors.toSet());
	}

}
