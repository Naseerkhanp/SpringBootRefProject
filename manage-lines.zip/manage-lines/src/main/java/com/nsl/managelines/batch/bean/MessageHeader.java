/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class MessageHeader  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String serviceId;

	private String requestType;

	private String referenceNumber;

	private String returnURL;

	private String asyncErrorURL;
}