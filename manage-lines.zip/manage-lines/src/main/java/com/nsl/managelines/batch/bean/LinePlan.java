package com.nsl.managelines.batch.bean;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class LinePlan {

	private String linePlanId;
	
	private String eLineId;

	private Integer lId;

	private String whsPlan;

	private String retailPlan;

	private Timestamp startDate;

	private Timestamp endDate;

	private Integer dataLimit;

	private String isGfPlan;

	private Timestamp createdDate;

	private String modifiedDate;

	private String createdBy;

	private String modifiedBy;
	
	private String planCategory;
	
	private String planGroup;

	}
