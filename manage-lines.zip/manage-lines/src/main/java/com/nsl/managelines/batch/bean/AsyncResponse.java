/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class AsyncResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String mdn;

	public String min;

	public String iccid;

	public String imsi;

	public String statusCode;

	public String errorCode;

	public String errorDescription;
}
