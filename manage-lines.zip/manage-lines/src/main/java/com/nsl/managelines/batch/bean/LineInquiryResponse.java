/**
 * 
 */
package com.nsl.managelines.batch.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Setter
@Getter
@ToString
public class LineInquiryResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageHeader messageHeader;

	public Data data;

	@Setter
	@Getter
	@ToString
	public class Data {

		public String errorCode;

		public String errorMessage;

		public String min;

		public String iccid;

		public String imsi;

		public String euimid;

		public String statusCode;

		public String lteStatusCode;

		@JsonProperty("FUSFExemptFlag")
		public String fUSFExemptFlag;

		public String planCode;

		@JsonProperty("DPFOResetDay")
		public String dPFOResetDay;

		public String transactionId;
		public String code;
		public String reason;
		public String lineId;
		public String lineType;
		public String euimId;
		public String mobileIPAddress;
		public String initialServiceDate;
		public String billCycleResetDay;
		public String activationType;

		public ArrayList<Message> message;

		public ArrayList<Mdn> mdn;

		public ArrayList<DeviceId> deviceId;

		public ArrayList<SimId> simId;

		public ArrayList<Status> status;

		public ArrayList<Feature> feature;

		public ArrayList<EquipmentInfo> equipmentInfo;

	}

	@Setter
	@Getter
	@ToString
	public class Message {
		public String responseCode;
		public String description;
	}

	@Setter
	@Getter
	@ToString
	public class Mdn {
		public String type;
		public String value;
	}

	@Setter
	@Getter
	@ToString
	public class DeviceId {
		public String type;
		public String value;
	}

	@Setter
	@Getter
	@ToString
	public class SimId {
		public String type;
		public String value;
	}

	@Setter
	@Getter
	@ToString
	public class Status {
		public String statusCode;
		public String lteStatusCode;
	}

	@Setter
	@Getter
	@ToString
	public class Feature {
		public String featureCode;
		public String includedWithPlan;
		public String subscribe;
	}

	@Setter
	@Getter
	@ToString
	public class EquipmentInfo {
		public String make;
		public String mode;
		public String model;
	}

}
