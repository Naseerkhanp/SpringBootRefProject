
package com.nsl.usagereport.cif.dao.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.cif.entity.FileDetails;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;

import lombok.extern.log4j.Log4j2;

@Log4j2

@Component
public class FileDetailsDaoImpl implements FileDetailsDao {

	@Autowired
	public FileDetailsRepository fileDetailsRepository;

	@Transactional
	@Override
	public void insertFileDetails(UsageReportDetails usageReportDetails, String fileName) throws Exception {
		log.info(this.getClass() + " insertFileDetails method called .");
		try {
			FileDetails fileDetails = new FileDetails();
			fileDetails.setDownloaded(NslFileUploadConstants.DOWNLOAD_STATUS_SUCCESS);
			fileDetails.setFileName(fileName);
			fileDetails.setParsed(NslFileUploadConstants.PARSED_STATUS_INPROGRESS);
			fileDetails.setCreatedBy(NslFileUploadConstants.NSL);
			fileDetails.setFileType(usageReportDetails.getFileType());
			fileDetails.setModifiedBy(NslFileUploadConstants.NSL);
			fileDetailsRepository.save(fileDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to save data to DB :: ", e);
			throw new Exception(" Internal Error: Unable to  save data to DB ::", e);
		}
		log.info(this.getClass() + " insertFileDetails method called .");
	}

	@Transactional
	@Override
	public void updateFileDetails(String downloadStatus, String parsedStatus, String fileName) throws Exception {
		log.info(this.getClass() + " updateFileDetails method called .");
		try {
			fileDetailsRepository.updateFileDataByName(downloadStatus, parsedStatus, fileName);
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to update data to DB :: ", e);
			throw new Exception(" Internal Error: Unable to update data to DB ::", e);
		}
		log.info(this.getClass() + " updateFileDetails method called .");
	}

	@Transactional
	@Override
	public FileDetails findByFileName(String fileName) throws Exception {
		FileDetails fileDetails = null;
		log.info(this.getClass() + " findByFileName method called .");
		try {
			fileDetails = fileDetailsRepository.findByFileName(fileName);
		} catch (Exception e) {
			log.info(this.getClass() + "Unable to find search data by fileName ::", e);
		}
		log.info(this.getClass() + " findByFileName method called .");
		return fileDetails;
	}

}
