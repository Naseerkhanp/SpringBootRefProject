spool 01_cif_ddl_rh_batch_transaction.log
---=============================================================================
SET SERVEROUTPUT ON
SET DEFINE OFF
SET SCAN OFF
SET pages 20000;
SET lines 1000;
SELECT USER
  || ' @ '
  || global_name
  || '    '
  || TO_CHAR (SYSDATE, 'dd-MON-yy hh24:MI:ss') AS environment
FROM global_name;
---==============================================================================
CREATE TABLE RH_Batch_Transaction
(ID number Not NULL,
Ext_Batch_ID VARCHAR2(100),
Batch_ID VARCHAR2(100),
MDN	number,
Transaction_ID	number,
Exc_TimeStamp timestamp(6),
Batch_Type VARCHAR2(100),
status	VARCHAR2(100),
Reference_Number VARCHAR2(100),
Sync char(1),
Channel_ID VARCHAR2(100),
Service_Type VARCHAR2(100),
Created_Date timestamp(6),
Created_By VARCHAR2(100),
Modified_Date timestamp(6),
Modified_By VARCHAR2(100)
);

CREATE TABLE RH_Batch_Scheduler_Transaction
(ID number Not NULL,
Batch_ID VARCHAR2(100),
MDN	number,
Exc_TimeStamp timestamp(6),
Scheduled_Status	VARCHAR2(100),
service_type VARCHAR2(100),
Created_Date timestamp(6),
Created_By VARCHAR2(100),
Modified_Date timestamp(6),
Modified_By VARCHAR2(100),
Sync char(1)
);
Alter table rh_Csr_Request add (featurecodes CLOB);

CREATE TABLE BATCH_DETAILS
  ( ID	NUMBER not null,
TYPE	VARCHAR2(50),
CREATED_DATE	TIMESTAMP(6),
CREATED_BY	VARCHAR2(50),
STATUS	VARCHAR2(50),
CHANNEL	VARCHAR2(50),
ACCOUNT_ID	VARCHAR2(50),
MODIFIED_DATE	TIMESTAMP(6),
MODIFIED_BY	VARCHAR2(50),
MDN_COUNT	NUMBER);

CREATE TABLE REF_TEMPLATE
(ID	NUMBER not null,
NAME	VARCHAR2(50),
TYPE	VARCHAR2(50),
SEQUENCE	NUMBER,
PARENT	NUMBER);

CREATE SEQUENCE BATCH_ID_SEQ  MINVALUE 1 MAXVALUE 999999999999999999999999999 
INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE SEQUENCE TEMPLATE_ID_SEQ  MINVALUE 1 MAXVALUE 999999999999999999999999999 
INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE SEQUENCE RH_ID_SEQ  MINVALUE 1 MAXVALUE 999999999999999999999999999 
INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
Alter table service_info  add (end_point_url varchar2(300));
Alter table rh_batch_transaction add (batch_update_status  varchar2(100));
Create table  Bulk_track(
PROCEDURE_NAME VARCHAR2(100),
EXECUTED_TIME   TIMESTAMP(6), 
COMMENTS VARCHAR2(800));
  CREATE OR REPLACE PROCEDURE BULK_PROCESSING_STATUS_UPDATE
AS
  seq_id       NUMBER;
  l_mdn        NUMBER;
  l_ref_num    VARCHAR2(100);
  l_trans_id   NUMBER;
  l_mno_status VARCHAR2(100);
BEGIN
  Insert into Bulk_track (procedure_name, executed_time, comments) values ('BULK_PROCESSING_STATUS_UPDATE', systimestamp, 'Procedure start');
  FOR main_loop IN
  (SELECT rht.ID         AS seq_id ,
    rht.MDN              AS l_mdn ,
    rht.reference_number AS l_ref_num,
    req.transaction_id   AS l_trans_id,
    res.mno_status       AS l_mno_status
  FROM rh_batch_transaction rht,
    rh_csr_request req,
    rh_csr_response res
  WHERE rht. batch_update_status = 'INITIATED'
  AND rht.reference_number       = req.reference_number
  AND req.transaction_id         = res.transaction_id
  AND req.mdn                    =res.mdn
  )
  LOOP
   UPDATE rh_batch_transaction
    SET status            = main_loop.l_mno_status,
      transaction_id      = main_loop.l_trans_id,
      batch_update_status ='COMPLETED'
    WHERE ID              = main_loop.seq_id
    AND reference_number  = main_loop.l_ref_num
    AND mdn               = main_loop.l_mdn;
    COMMIT;
  END LOOP MAIN_LOOP;
           Insert into Bulk_track (procedure_name, executed_time, comments) values ('BULK_PROCESSING_STATUS_UPDATE', systimestamp, 'Procedure end');
END;
/

BEGIN
    DBMS_SCHEDULER.CREATE_SCHEDULE (
        repeat_interval  => 'FREQ=HOURLY',
        start_date => TO_TIMESTAMP_TZ('2020-10-27 11:53:45.000000000 ASIA/CALCUTTA','YYYY-MM-DD HH24:MI:SS.FF TZR'),
        schedule_name  => '"BULK_PROCESSING_SCHEDULDER"');
END;
/

BEGIN
    DBMS_SCHEDULER.CREATE_JOB (
            job_name => '"BULK_PROCESSING_JOB"',
            schedule_name => '"BULK_PROCESSING_SCHEDULDER"',
            job_type => 'STORED_PROCEDURE',
            job_action => 'BULK_PROCESSING_STATUS_UPDATE',
            number_of_arguments => 0,
            enabled => FALSE,
            auto_drop => FALSE,
               comments => '');
    DBMS_SCHEDULER.SET_ATTRIBUTE( 
             name => '"BULK_PROCESSING_JOB"', 
             attribute => 'logging_level', value => DBMS_SCHEDULER.LOGGING_OFF);
    DBMS_SCHEDULER.enable(
             name => '"BULK_PROCESSING_JOB"');
END;
/
drop SEQUENCE BATCH_ID_SEQ;

CREATE SEQUENCE BATCH_ID_SEQ  MINVALUE 10001 MAXVALUE 999999999999999999999999999 
INCREMENT BY 1 START WITH 10001 CACHE 20 NOORDER  NOCYCLE ;

Desc Bulk_track ;
SELECT  sequence_name  FROM sys.user_sequences WHERE sequence_name in ('RH_ID_SEQ');
SELECT  sequence_name  FROM sys.user_sequences WHERE sequence_name in ('BATCH_ID_SEQ','TEMPLATE_ID_SEQ');
Desc rh_Csr_Request;
desc BATCH_DETAILS;
desc REF_TEMPLATE;
Desc RH_Batch_Transaction;
Desc RH_Batch_Scheduler_Transaction;
spool off;