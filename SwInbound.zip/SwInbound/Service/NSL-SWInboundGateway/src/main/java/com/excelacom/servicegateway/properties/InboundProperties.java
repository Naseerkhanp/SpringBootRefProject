package com.excelacom.servicegateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String authserver;
	
	private String schedulerserviceurl;

	private String routerserviceurl;

	private String authchecktoken;

	private String credentials;

	private String splitterurl;

	private String ruleurl;

	private String IntrernalServerURL;
	
	private String hmnoendpoint;

	private String smbendpoint;

	private String cbrspcrfendpoint;

	private String mobile1endpoint;

	private String mobile2endpoint;

	private String mnobillcycle;

	private String mnomobile2endpoint;

	private String transactionurl;

	private String changeesnurl;

	private String mnorestoreurl;
	
	private String asyncErrorurl;

	private String validateOauthServiceUrl;

	private String server;

	private String applicationName;

	private String wifiurl;

	private String updateWifiurl;

	private String validateWifiurl;
	
	private String swWearableurl;
	
	private String changeesimurl;
	
	private String swRetrieveDeviceurl;
	
	private String transferWearableurl;
	
	private String transferWearableAsyncurl;
	
	private String resourceServiceURL;
	
	private String updateTransactionHistoryForNSUrl;
	
	private String updateTransactionHistoryUrl;
	
	private String saveTransactionHistoryUrl;
	
	private String referenceValueUrl;
	
		private String loginauthwsurl;

		
		private String  simdetailsbyiccidurl;


		
		private String transactionHistoryDetailsUrl;
	
		private String accounturl;
	
	private String searchEnvironmenturl;

}