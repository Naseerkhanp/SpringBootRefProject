/**
 * 
 */
package com.nsl.managelines.batch.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Dhayanand.B
 *
 */
@Getter
@Setter
@ToString
public class Page {


	@JsonProperty("currentPage")
	public Integer currentPage;

	@JsonProperty("totalItems")
	public Integer totalItems;

	@JsonProperty("pageSize")
	public Integer pageSize;

}
