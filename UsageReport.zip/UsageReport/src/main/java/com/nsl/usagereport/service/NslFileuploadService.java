package com.nsl.usagereport.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.nsl.usagereport.dto.GetUsageReportDetails;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.uio.DataDetailsUIO;
import com.nsl.usagereport.uio.SmsDetailsUIO;
import com.nsl.usagereport.uio.VoiceDetailsUIO;

public interface NslFileuploadService {
	public ResponseEntity<String> extractDataFrmFile(UsageReportDetails fileDetails);

	public List<DataDetailsUIO> getDataDetails(GetUsageReportDetails getUsageReportDetails) throws Exception;

	public List<SmsDetailsUIO> getSmsDetails(GetUsageReportDetails getUsageReportDetails) throws Exception;

	public List<VoiceDetailsUIO> getVoiceDetails(GetUsageReportDetails getUsageReportDetails) throws Exception;

	public ResponseEntity<String> extractDataFrmSmbFile(UsageReportDetails usageReportDetails, MultipartFile file)
			throws Exception;

	public ResponseEntity<String> deleteData(GetUsageReportDetails getUsageReportDetails) throws Exception;
}
