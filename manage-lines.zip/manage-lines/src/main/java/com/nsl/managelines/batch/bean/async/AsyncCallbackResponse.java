package com.nsl.managelines.batch.bean.async;

import com.nsl.managelines.batch.bean.AsyncResponse;
import com.nsl.managelines.batch.bean.MessageHeader;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class AsyncCallbackResponse {

	public MessageHeader messageHeader;

	public AsyncResponse asyncResponse;

	public GatewayResponse gatewayResponse;

}
