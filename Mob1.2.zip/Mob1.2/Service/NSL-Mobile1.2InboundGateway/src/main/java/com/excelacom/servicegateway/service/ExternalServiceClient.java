
package com.excelacom.servicegateway.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;
import com.excelacom.servicegateway.dao.TransactionDAO;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.excelacom.servicegateway.properties.InboundQueueProperties;

@Component
public class ExternalServiceClient {

	@Autowired
	TransactionDAO transactionDAO;
	
	/** The inbound properties. */
	@Autowired
	InboundProperties inboundProperties;
	
	@Autowired
	InboundQueueProperties inboundQueueProperties;

	@Autowired
	private UtilityClass utilityClass;
	
	Logger LOGGER = LoggerFactory.getLogger(ExternalServiceClient.class);

	/**
	 * Gets the response from client.
	 *
	 * @param requestJson the request json
	 * @param transId the trans id
	 * @param responseId the response id
	 * @return the response from client
	 */
	public String getResponseFromClient(String requestJson, String transId, String responseId,
			String serviceName, String operationName) {
		String groupId = null;
		String Id = null;
		String entityId = "0";
		String processPlanId = null;
		try {
			String request = null;

			String url = inboundProperties.getRouterserviceurl();
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(new Runnable() {
				@Override
				public void run() {
					transactionDAO.insertMNORequestDetails(requestJson, responseId);
				}
			});
			request = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName
					+ "&transId=" + transId + "&responseId=" + responseId;
			LOGGER.info(" request :: " + request);
			String frameworkResponse = utilityClass.callRestAPI(request, url);
			LOGGER.info(" frameworkResponse :: " + frameworkResponse);
			Id = frameworkResponse.substring(frameworkResponse.indexOf("~") + 1);
			groupId = Id.substring(Id.indexOf("~") + 1);
			serviceName = groupId.substring(groupId.indexOf("~") + 1);
			groupId = groupId.substring(0, groupId.indexOf("~"));
			processPlanId = Id.substring(0, Id.indexOf("~"));
			frameworkResponse = frameworkResponse.substring(0, frameworkResponse.indexOf("~"));
			asyncUpdateNorthBoundTransaction(transId, entityId, frameworkResponse, groupId, processPlanId, serviceName);
			return frameworkResponse;
		} catch (Exception e) {
			this.asyncUpdateTransactionFailure(transId, entityId, groupId, processPlanId, serviceName);
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}
	

	private void asyncUpdateNorthBoundTransaction(String responseId, String entityId, String respJson, String grpId,
			String processId, String servName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransaction(responseId, entityId, respJson, grpId, processId, servName);
			}
		});

	}
	
	public String asyncUpdateTransactionFailure(final String transId, final String entityId, final String groupId,
			final String processPlanId, final String serviceName) {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				transactionDAO.updateNorthBoundTransactionFailure(transId, entityId, groupId, processPlanId,
						serviceName);
			}
		});

		executor.shutdown();
		return "success";
	}

}
