package com.nsl.usagereport.datahandler;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.transaction.entity.RouterInfo;
import com.nsl.usagereport.util.NslFileUploadUtils;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("RouterInfoHandler")
public class RouterInfoHandler implements Handler {

	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst,UsageReportDetails usageReportDetails) throws Exception {
		// long id = NslFileUploadUtils.nullCheck(column[0]);
		if (NslFileUploadUtils.nullChecker(column[3]).length() > NslFileUploadConstants.TWO_FIFTY_FIVE
				|| NslFileUploadUtils.nullChecker(column[4]).length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			throw new Exception("SIM id is greater than 20 characters");
		}
		if (NslFileUploadUtils.nullChecker(column[0]).isEmpty()) {
			throw new Exception("Missing required field SerialNumber");
		}
		if (NslFileUploadUtils.nullChecker(column[2]).isEmpty()) {
			throw new Exception("Missing required field RouterId");
		}
		try {
			RouterInfo routerInfoDetails = new RouterInfo();
			// routerInfoDetails.setId(NslFileUploadConstants.DEFAULT_LONG);
			routerInfoDetails.setSerialNumber(NslFileUploadUtils.nullChecker(column[0]));
			routerInfoDetails.setMacAddress(NslFileUploadUtils.nullChecker(column[1]));
			routerInfoDetails.setRouterId(NslFileUploadUtils.nullChecker(column[2]));
			routerInfoDetails.setSimId1(NslFileUploadUtils.nullChecker(column[3]));
			routerInfoDetails.setSimId2(NslFileUploadUtils.nullChecker(column[4]));
			routerInfoDetails.setCreated_by(NslFileUploadConstants.NSL);

			if (detailsBuiler.containsKey(NslFileUploadConstants.DEFAULT_LONG)) {
				List<Object> li = detailsBuiler.get(NslFileUploadConstants.DEFAULT_LONG);
				li.add(routerInfoDetails);
				detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
			} else {
				List<Object> li = new ArrayList<>();
				li.add(routerInfoDetails);
				detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Long, List<Object>> buildData(Map<Long, List<Object>> detailsBuiler, BufferedReader reader)
			throws Exception {
		CsvToBean<RouterInfo> csvToBean = null;
		List<RouterInfo> routerInfoLst = null;
		List<Object> li = new ArrayList<>();
		try {
			csvToBean = new CsvToBeanBuilder(reader).withType(RouterInfo.class).withIgnoreLeadingWhiteSpace(true)
					.build();
			routerInfoLst = csvToBean.parse();
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		routerInfoLst.forEach(roterinfo -> li.add(roterinfo));
		detailsBuiler.put(null, li);
		return detailsBuiler;
	}

}
