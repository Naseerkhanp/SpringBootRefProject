package com.flowcomponent.pcrfInBoundGateway.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("nslservice")
@Configuration
@Getter
@Setter
public class InboundProperties {

	private String authserver;

	private String routerserviceurl;

	private String authchecktoken;

	private String credentials;

	private String pcrfendpoint;

	private String GetPcrfUrl;
	
	private String DeletePcrfUrl;
	
	private String CreatePcrfUrl;
	
	private String UpdatePcrfUrl;

	
}
