/**
 * 
 */
package com.nsl.managelines.batch.bean;

/**
 * @author Dhayanand.B
 *
 */
public enum AsyncType {
	SUCCESS, ERROR, GATEWAY_RESPONSE
}
