package com.excelacom.servicegateway.dao;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;

import org.apache.http.MethodNotSupportedException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.excelacom.servicegateway.bean.RequestBean;
import com.excelacom.servicegateway.constants.Constants;
import com.excelacom.servicegateway.constants.UtilityClass;

import com.excelacom.servicegateway.exception.NslCustomException;
import com.excelacom.servicegateway.properties.InboundProperties;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONObject;

@Service
public class TransactionDAOImpl implements TransactionDAO {

	@Autowired
	private JdbcTemplate centuryCIFTemplate;
	
	@Autowired
	private JdbcTemplate centuryNBOPTemplate;
	
	@Autowired
	RequestBean requestBean;
	
	@Autowired
	private UtilityClass utilityClass;
	
	@Autowired
	InboundProperties inboundProperties;

	Logger LOGGER = LoggerFactory.getLogger(TransactionDAOImpl.class);

	private RequestBean ibRequestBean;

	public String insertNorthBoundTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName) {
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		String transactionTimeStamp = null;
		Timestamp transactionTs = null;
		String requestMsg = "";
		try {
			transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
			LOGGER.info("Inside insertTransaction method::transId:::" + transId);
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
			input.addValue(Constants.APPLICATION_NAME, serviceName);
			input.addValue("APPLICATIONNAME", applicationName);
			input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
			input.addValue(Constants.TRANSACTION_UID, transUId);
			if (requestJson.contains("transactionTimeStamp")) {
				// requestJson = jsonFormatter(requestJson);
				// JSONArray jsonArray = new JSONArray(requestJson);
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
				}
				if (transactionTimeStamp != null
						&& (transactionTimeStamp.contains("Z") || transactionTimeStamp.contains("z"))) {
					try {
						Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(transactionTimeStamp)).getTime();
						transactionTs = new Timestamp(date.getTime());
					} catch (Exception e) {
						transactionTs = null;
					}
				}
				if (transactionTs != null) {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, transactionTs);
				} else {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
				}
			} else {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
			}
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			if (applicationName != null && applicationName.contains("NCM")) {
				input.addValue(Constants.TENANT_ID, "2");
			} else {
				input.addValue(Constants.TENANT_ID, "1");
			}
			
			if (requestJson.startsWith("[") || requestJson.startsWith("{")) {
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if (requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if (requestJsonObjectData.has("channel")) {
						String channelID = requestJsonObjectData.getString("channel");
						LOGGER.info("Inside insertTransaction method::channel:::" + channelID);
						if (channelID != null) {
							input.addValue("CHANNEL", channelID);
						} else {
							input.addValue("CHANNEL", null);
						}
					}else
					{
						input.addValue("CHANNEL", null);
					}
				}

			}

			input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
			LOGGER.info("REQUEST_MSG :: "+ input.toString());
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_NORTH_BOUND_TRANSACTION, input);
			return transId;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}

	public void updateNorthBoundTransactionFailure(String transId, String entityId, String groupId, String transGroupId,
			String serviceName,String frameworkResponse) {
		try {
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("TRANSACTION_ID", transId);
			input.addValue("ENTITY_ID", entityId);
			input.addValue("status", "FAILURE");
			input.addValue(Constants.TRANSGROUPID, transGroupId);
			input.addValue(Constants.GROUPID, groupId);
			input.addValue("SERVICENAME", serviceName);
			input.addValue("RESPONSE_MSG", frameworkResponse);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.UPDATE_FAIL_TRANSACTION, input);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

	public int mdnRetrieval(final String mdn) {
		int mdnCount = 0;
		try {
			mdnCount = (int) centuryCIFTemplate.queryForObject(Constants.ID_COUNT_RETRIEVE, new Object[] { mdn },
					Integer.class);
			LOGGER.info("MDN VALUE::::::" + mdnCount);
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return mdnCount;
	}
	
	public String insertTransaction(String requestJson, String entityId,String transUId,String serviceName) {
        String transId = null;
        String json=null;
        JSONObject inputJsonObj = null;
        String applicationName=null;
        try {
			if (serviceName.equalsIgnoreCase("MnoUpdatePortOutService")
					|| serviceName.equalsIgnoreCase("mdnportability")
					|| serviceName.equalsIgnoreCase("MNOActivatePortInService")
					|| serviceName.equalsIgnoreCase("MNOUpdateCancel")
					|| serviceName.equalsIgnoreCase("MNOUpdateDueDate") 
					|| serviceName.equalsIgnoreCase("mnoupdateport")
					|| serviceName.equalsIgnoreCase("mnoportininquiry") 
					|| serviceName.contains("subscriber")
					|| serviceName.contains("Subscriber")) {
                    applicationName = "MNO";
              }else if(serviceName.contains("activate") || serviceName.contains("Activate")) {
                    applicationName = "Arterra";
              }else if(serviceName.contains("PCrf") || serviceName.contains("PCRF")) {
                    applicationName = "PCRF";
              }else {
                    applicationName = "GplusD";   
              }
              transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
              LOGGER.info("Inside insertTransaction method::transId:::" + transId);
              MapSqlParameterSource input = new MapSqlParameterSource();
              input.addValue(Constants.TRANSACTION_ID, transId);
              input.addValue(Constants.APPLICATION_NAME, serviceName);
              input.addValue("APPLICATIONNAME",applicationName);
              input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
              input.addValue(Constants.TRANSACTION_UID,transUId);
              if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
                    input.addValue(Constants.ENTITY_ID, entityId);
              } else {
                    input.addValue(Constants.ENTITY_ID, 0);
              }
              input.addValue(Constants.TENANT_ID,"1");
              
              input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
              NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
                          centuryCIFTemplate.getDataSource());
              namedJdbcTemplate.update(Constants.INSERT_TRANSACTION, input);
              return transId;
        } catch (Exception e) {
        	LOGGER.error(e.getMessage(), e);
        }
        return transId;
  }

	public void insertMNORequestDetails(String request, String responseId) {
		LOGGER.info("request inside insertMNORequestDetails::::" + request);
		JSONObject obj = new JSONObject();
		JSONObject subOrderObj = new JSONObject();
		JSONObject addAttrObj = null;
		JSONObject addAttrObj1 = null;
		RequestBean bean = null;
		String customer_req_id = "";
		String requests = null;
		String addAttrRequest = "";
		String addAttrName = "";
		String mdnAttrType = "";
		String mdnAttrValue = "";
		String addAttrValue = "";
		String transactionType = "";
		try {
			boolean requestflag=isValidJson(request);
			if(requestflag)
			{
			if (request.startsWith("[")) {
				LOGGER.info("request in json::" + request);
				request = jsonFormatter(request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("{")) {
				LOGGER.info("request in json object::" + request);
				addAttrObj = new JSONObject(request);
				LOGGER.info("request in addAttrObj object::" + addAttrObj);
				if (addAttrObj.has("data")) {
					addAttrObj = addAttrObj.getJSONObject("data");
					if (addAttrObj.has("additionalData") && addAttrObj.getJSONArray("additionalData").length()!=0) {
						addAttrObj1 = addAttrObj.getJSONArray("additionalData").getJSONObject(0);
						LOGGER.info("addAttrObj final::" + addAttrObj.toString());
						if (addAttrObj1.has("name")) {
							addAttrName = addAttrObj1.getString("name");
						}
						if (addAttrObj1.has("value")) {
							addAttrValue = addAttrObj1.getString("value");
						}
					}
					if(addAttrObj.has("transactionType")) {
						transactionType = addAttrObj.getString("transactionType");
					}
						if (addAttrObj.has("subOrder")) {
							if (addAttrObj.getJSONArray("subOrder").length() != 0) {
								subOrderObj = addAttrObj.getJSONArray("subOrder").getJSONObject(0);
								System.out.println("subOrder array:::: " + mdnAttrType);
								if (subOrderObj.has("mdn")) {
									if (subOrderObj.getJSONArray("mdn").length() != 0) {
										JSONObject mdnArrObj = subOrderObj.getJSONArray("mdn").getJSONObject(0);
										if (mdnArrObj.has("type")) {
											mdnAttrType = mdnArrObj.getString("type");
											System.out.println("hostMDN type:::: " + mdnAttrType);
										}
										if (mdnArrObj.has("value")) {
											mdnAttrValue = mdnArrObj.getString("value");
											System.out.println("hostMDN value:::: " + mdnAttrValue);
										}
									}
								}

							}
						}
				}
				LOGGER.info("request in before formatting::" + request);
				request = jsonFormatter(request);
				LOGGER.info("request in after formatting::" + request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("<")) {
				LOGGER.info("request in xml::" + request);
				requests = XML.toJSONObject(request).toString();
				LOGGER.info("request in xml format::" + requests);
				requests = jsonFormatter(requests);
				LOGGER.info("request after formatting::" + requests);
				JSONArray jsonArrayInner = new JSONArray(requests);
				obj = jsonArrayInner.getJSONObject(0);
				LOGGER.info("request xml in json object::" + obj.toString());
				Gson gson = new Gson();
				bean = gson.fromJson(obj.toString(), RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			}
			
			}
			if(bean!=null) {
			if (bean.getCustomerRequestID() != null) {
				customer_req_id = bean.getCustomerRequestID();
			} else if (bean.getReferenceNumber() != null && !bean.getReferenceNumber().isEmpty()) {
				customer_req_id = bean.getReferenceNumber();
				String[] split = customer_req_id.split("\\.");
				if (split.length > 3) {
					customer_req_id = customer_req_id
							.subSequence(customer_req_id.indexOf(split[3], 1), customer_req_id.length()).toString();
				} else {
					customer_req_id = null;
				}
			} else {
				customer_req_id = null;
			}
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("TRANSACTION_ID", responseId);
			if (bean.getCustomerID() != null) {
				input.addValue("CUSTOMER_ID", bean.getCustomerID());
			} else if (bean.getCustomerID() != null) {
				input.addValue("CUSTOMER_ID", bean.getCustomerID());
			} else {
				input.addValue("CUSTOMER_ID", null);
			}
			input.addValue("CUSTOMER_REQUEST_ID", customer_req_id);
			if (bean.getMdn() != null) {
				if(mdnAttrType.equals("hostMDN")){
					input.addValue("MDN", bean.getMdn());
					input.addValue("HOSTMDN", bean.getHostMdn());
				}else{
					input.addValue("MDN", bean.getMdn());
				}
			} else {
				input.addValue("MDN", null);
				input.addValue("HOSTMDN", null);
			}
			if (bean.getHostMdn() != null) {
				input.addValue("HOSTMDN", bean.getHostMdn());
			} else {
				input.addValue("HOSTMDN", null);
			}
			if (bean.getIccid() != null) {
				input.addValue("PICCID", bean.getIccid());
			} else {
				input.addValue("PICCID", null);
			}
			if (bean.getImei() != null && !bean.getImei().isEmpty()) {
				input.addValue("IMEI", bean.getImei());
			} 
			else if(bean.getDeviceId() != null && !bean.getDeviceId().isEmpty()) {
				input.addValue("IMEI", bean.getDeviceId());
			}
			else {
				input.addValue("IMEI", null);
			}

			if (bean.getEid() != null) {
				input.addValue("EID", bean.getEid());
			} else {
				input.addValue("EID", null);
			}
			if (bean.getReferenceNumber() != null && !bean.getReferenceNumber().isEmpty()) {
				input.addValue("REFERENCENUMBER", bean.getReferenceNumber());
			} else {
				input.addValue("REFERENCENUMBER", null);
			}
			if (bean.getAsyncErrorURL() != null) {
				input.addValue("ASYNCURL", bean.getAsyncErrorURL());
			} else {
				input.addValue("ASYNCURL", null);
			}
			if(!transactionType.isEmpty() && transactionType.equalsIgnoreCase("AW")) {	
				input.addValue("RETAILPLANCODE", "MSWAP");
				LOGGER.info("#####RETAILPLANCODE:MSWAP####");
			}
			else if (bean.getPlanCode() != null) {
				input.addValue("RETAILPLANCODE", bean.getPlanCode());
			} 
			else if (bean.getnewRatePlan() != null) {
				input.addValue("RETAILPLANCODE", bean.getnewRatePlan());
			} else {
				input.addValue("RETAILPLANCODE", null);
			}
			if (bean.getReturnURL() != null) {
				input.addValue("RETURNURL", bean.getReturnURL());
			} else {
				input.addValue("RETURNURL", null);
			}
			if (bean.getAccountNumber() != null) {
				input.addValue("ACCOUNTNUMBER", bean.getAccountNumber());
			} else {
				input.addValue("ACCOUNTNUMBER", null);
			}
			if (bean.getId() != null) {
				input.addValue("ID", bean.getId());
			} else {
				input.addValue("ID", null);
			}
			if (bean.getIccid() != null) {
				input.addValue("PICCID", bean.getIccid());
			} else {
				input.addValue("PICCID", null);
			}
			if (bean.getLineId() != null) {
				input.addValue("LINEID", bean.getLineId());
			} else {
				input.addValue("LINEID", null);
			}
			if (bean.getContextId() != null) {
				input.addValue("CONTEXTID", bean.getContextId());
			} else {
				input.addValue("CONTEXTID", null);
			}
			if (transactionType !=null && (transactionType.equals("UW")||transactionType.equals("TW")||transactionType.equals("AW"))) {
				input.addValue("ACCOUNTTYPE", null);
			} else if (bean.getType() != null) {
				input.addValue("ACCOUNTTYPE", bean.getType());
			} else {
				input.addValue("ACCOUNTTYPE", null);
			}
			if (bean.getBillCycleResetDay() != null) {
				input.addValue("BILLCYCLEDAY", bean.getBillCycleResetDay());
			} else {
				input.addValue("BILLCYCLEDAY", null);
			}
			if (!"".equalsIgnoreCase(addAttrName)) {
				input.addValue("REFNAME", addAttrName);
			//	input.addValue("REFNAME", "YOGESH");
			} else {
			     input.addValue("REFNAME", null);
		//		input.addValue("REFNAME", "YOGESH NULL");
			}
			if (!"".equalsIgnoreCase(addAttrValue)) {
				input.addValue("REFVALUE", addAttrValue);
			} else {
				input.addValue("REFVALUE", null);
			}
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			LOGGER.info("Inside insertMNORequestDetails Input :: IF "+ input.toString());
			System.out.println("responseid::::::"+responseId);
			namedJdbcTemplate.update(Constants.INSERT_REQUESTS, input);
			namedJdbcTemplate.update(Constants.INSERT_REF_ADD_DATA, input);
			}
			else
			{
				MapSqlParameterSource input = new MapSqlParameterSource();
				input.addValue("TRANSACTION_ID", responseId);	
				input.addValue("CUSTOMER_ID", null);
				input.addValue("MDN", null);
				input.addValue("PICCID", null);
				input.addValue("IMEI", null);
				input.addValue("EID", null);
				input.addValue("REFERENCENUMBER", null);
				input.addValue("ASYNCURL", null);
				input.addValue("RETAILPLANCODE", null);
				input.addValue("RETURNURL", null);
				input.addValue("ACCOUNTNUMBER", null);
				input.addValue("ID", null);
				input.addValue("PICCID", null);
				input.addValue("LINEID", null);
				input.addValue("REFNAME", null);
				input.addValue("REFVALUE", null);
                input.addValue("CONTEXTID", null);
				input.addValue("CUSTOMER_REQUEST_ID", null);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			LOGGER.info("Inside insertMNORequestDetails Input :: ELSE "+ input.toString());
			namedJdbcTemplate.update(Constants.INSERT_REQUESTS, input);
			namedJdbcTemplate.update(Constants.INSERT_REF_ADD_DATA, input);
			}
			bean.setTransId(responseId);
			//return responseId;
		} catch (JSONException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e1) {
			LOGGER.error(e1.getMessage(), e1);
		}
		//return null;

	}
	
	public String insertMNOResponseDetails(RequestBean requestBean, String response, String responseId,
			String operationName) {
		String customer_req_id = null;
		String status=null;
		String httpCode=Constants.EMPTYSTRING;
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
		NamedParameterJdbcTemplate lineHistoryNamedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
		LOGGER.info("requestBean:::" + requestBean.toString() + " response::::" + response);
		if (response.contains("~")) {
			httpCode = response.substring(response.lastIndexOf("~") + 1, response.length());
			response = response.substring(0, response.lastIndexOf("~"));
		}
		LOGGER.info("httpCode:::" + httpCode + "::::" + response);
		try {
			if (response.startsWith("<")) {
				LOGGER.info("request in xml::" + response);
				response = XML.toJSONObject(response).toString();
				LOGGER.info("request in xml format::" + response);
				response = jsonFormatter(response);
				LOGGER.info("request after formatting::" + response);
			}
			if (response.startsWith("{")&&operationName.equalsIgnoreCase("Line Inquiry")) {
				if(response.contains("~")) {
					status=response.substring(0,response.lastIndexOf("~"));
					JSONObject responseJSONObj =new JSONObject(status);
					if(responseJSONObj.has("data")) {
						status=responseJSONObj.getJSONObject("data").getJSONArray("status").getJSONObject(0).getString("value");
					}
				}
			}
			if(operationName.equalsIgnoreCase("Line Inquiry")) {
				response=jsonFormatter(response);
			}
			if(response.startsWith("{")) {
				response=jsonFormatter(response);
			}
			/*if (requestBean.getCustomerRequestID() != null) {
				customer_req_id = requestBean.getCustomerRequestID();
			} else if (requestBean.getSubscriberGroupCd() != null) {
				customer_req_id = requestBean.getSubscriberGroupCd();
			} else {
				customer_req_id = null;
			}*/
			MapSqlParameterSource input = new MapSqlParameterSource();
			MapSqlParameterSource inputValue = new MapSqlParameterSource();
			input.addValue("TRANSACTION_ID", responseId);			
			if (requestBean.getCustomerRequestID() != null) {
				customer_req_id = requestBean.getCustomerRequestID();
			} else if (requestBean.getReferenceNumber() != null && !requestBean.getReferenceNumber().isEmpty()) {
				customer_req_id = requestBean.getReferenceNumber();
				String[] split = customer_req_id.split("\\.");
				if (split.length > 3) {
					customer_req_id = customer_req_id
							.subSequence(customer_req_id.indexOf(split[3], 1), customer_req_id.length()).toString();
				} else {
					customer_req_id = null;
				}
			} else if (requestBean.getSubscriberGroupCd() != null) {
				customer_req_id = requestBean.getSubscriberGroupCd();
			} else {
				customer_req_id = null;
			}
			input.addValue("CUSTOMER_REQUEST_ID", customer_req_id);
			input.addValue("CUSTOMER_ID", requestBean.getCustomerID());			
			/*if (customer_req_id != null) {
				input.addValue("CUSTOMER_REQUEST_ID", customer_req_id);
			} else {
				input.addValue("CUSTOMER_REQUEST_ID", null);
			}*/
			input.addValue("ICCID", requestBean.getIccid());			
			if (requestBean.getIccId() != null) {
				input.addValue("ICCID", requestBean.getIccId());
			} else if (requestBean.getIccid() != null) {
				input.addValue("ICCID", requestBean.getIccid());
			} else {
				input.addValue("ICCID", null);
			}
			input.addValue("EID", requestBean.getEid());
			if (requestBean.getMdn() != null) {
				
				String hostMDNSW= (String) centuryCIFTemplate.queryForObject(Constants.GET_HOST_MDN_SMARTWATCH, new Object[] { responseId }, String.class);
				if(!hostMDNSW.equalsIgnoreCase("null")){
					if(hostMDNSW.equalsIgnoreCase(requestBean.getMdn())){
						input.addValue("MDN", null);
					}
					else{
						input.addValue("MDN", requestBean.getMdn());
					}
				}
				else{
					input.addValue("MDN", requestBean.getMdn());
				}
				
			} else {
				input.addValue("MDN", null);
			}
			if (requestBean.getImei() != null) {
				input.addValue("IMEI", requestBean.getImei());
			} else if (requestBean.getDeviceId() != null) {
				input.addValue("IMEI", requestBean.getDeviceId());
			} else if (requestBean.getDeviceid() != null) {
				input.addValue("IMEI", requestBean.getDeviceid());
			} else {
				input.addValue("IMEI", null);
			}
			if (requestBean.getMatchingId() != null) {
				input.addValue("MATCHING_ID", requestBean.getMatchingId());
			} else {
				input.addValue("MATCHING_ID", null);
			}
			if (requestBean.getPlanCode() != null) {
				input.addValue("WHOLESALEPLANCODE", requestBean.getPlanCode());
			} else {
				input.addValue("WHOLESALEPLANCODE", null);
			}
			JSONArray obj1 = new JSONArray(response);
			JSONObject obj = obj1.getJSONObject(0);
			LOGGER.info("objobjobj:::" + obj.toString());
			if (obj.has("make")) {
				if (!obj.getString("make").equalsIgnoreCase("")) {
					input.addValue("MANUFACTURER", obj.getString("make"));
				} else {
					input.addValue("MODEL", null);
				}
			} else {
				input.addValue("MANUFACTURER", null);
			}
			if (obj.has("model")) {
				if (!obj.getString("model").equalsIgnoreCase("")) {
					input.addValue("MODEL", obj.getString("model"));
				} else {
					input.addValue("MODEL", null);
				}
			} else {
				input.addValue("MODEL", null);
			}

			
			if(obj.has("mode")) {
				if(!obj.getString("mode").equalsIgnoreCase("")) {
					input.addValue("DEVICE_MODE",obj.getString("mode"));
			} 
		} else {
			input.addValue("DEVICE_MODE", null);
		}
				
			if(obj.has("cdmaLess")) {
				if(!obj.getString("cdmaLess").equalsIgnoreCase("")) {
					input.addValue("CDMALESS_FLAG", obj.get("cdmaLess"));
				}
			}else {
				input.addValue("CDMALESS_FLAG", null);
			}
			 if(operationName.equalsIgnoreCase(Constants.UPDATEWIFIADDRESS)) {
				  input.addValue("MNO_STATUS", "ACTIVE");
		      }else if(httpCode.equals("200"))	{
				 input.addValue("MNO_STATUS", "INPROGRESS");
		      }else {
				  input.addValue("MNO_STATUS", "FAILURE");
			  }
			
			namedJdbcTemplate.update(Constants.INSERT_MNO_RESPONSE, input);
			return requestBean.getCustomerID();
		} catch (Exception e1) {
			LOGGER.error("Exception in insertMNOResponseDetails" + e1.getMessage());
		}
		return requestBean.getCustomerID();
	}

	/* public String insertAsyncTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName, String refNo, String source) {

		LOGGER.info("After Calling insertAsyncTransaction 1 with :: request = " + requestJson + " :: entityId = " + entityId + " :: transId = " + transUId
				 + " :: source = " + source + " :: refNo = " + refNo);	
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		int transactionIdCount = 0;
		String rel_id = "";
		int rootIdCount = 0;
		String rootId="";
		try {
			NamedParameterJdbcTemplate asyncJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			MapSqlParameterSource input = new MapSqlParameterSource();

			input.addValue("REFERENCE_NUMBER", refNo);
			transactionIdCount = asyncJdbcTemplate.queryForObject(Constants.TRANS_ID_COUNT, input, Integer.class);
			LOGGER.info("transactionIdCount:::: " + transactionIdCount);
			if (transactionIdCount != 0) {
				rel_id = (String) centuryCIFTemplate.queryForObject(Constants.TRANS_ID, new Object[] { refNo, refNo }, String.class);
				LOGGER.info("refNo in async method:::: " + rel_id);

			}
			LOGGER.info("refNo in async method outside if:::: " + rel_id);
			if(!rel_id.equalsIgnoreCase("") && rel_id!=null) {
				MapSqlParameterSource inputs = new MapSqlParameterSource();
				inputs.addValue("TRANSACTION_ID", rel_id);
			rootIdCount = asyncJdbcTemplate.queryForObject(Constants.GET_ROOT_ID_COUNT, inputs, Integer.class);
			LOGGER.info("rootIdCount:::::"+rootIdCount);
			if(rootIdCount!=0) {
				rootId = (String) centuryCIFTemplate.queryForObject(Constants.GET_ROOT_ID, new Object[] { rel_id },
						String.class);
				LOGGER.info("rootId:::::"+rootId);
				input.addValue(Constants.ROOT_TRANSACTION_ID, rootId);
			}
			}else {
				input.addValue(Constants.ROOT_TRANSACTION_ID, rel_id);
			}
			transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
			LOGGER.info("Inside insertTransaction method::transId:::" + transId);
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.APPLICATION_NAME, serviceName);
			input.addValue("APPLICATIONNAME", applicationName);
			input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
			input.addValue(Constants.TRANSACTION_UID, transUId);
			input.addValue("REL_TRANSACTION_ID", rel_id);
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			if (applicationName != null && applicationName.contains("NCM")) {
				input.addValue(Constants.TENANT_ID, "2");
			} else {
				input.addValue(Constants.TENANT_ID, "1");
			}
			input.addValue("SOURCE_SYSTEM",source);
			input.addValue("TARGET_SYSTEM","NSL");
			input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			String Transaction_Type = Constants.INBOUND;
			namedJdbcTemplate.update(Constants.INSERT_ASYNC_TRANSACTION, input);
			if (serviceName.equalsIgnoreCase("Async Programming Response")) {
				this.insertEvent_notification(rel_id, transId, Transaction_Type, serviceName, applicationName,
						requestJson);
			}
			return transId;

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}	 */

	private String insertEvent_notification(String rel_id, String transId, String transaction_Type, String serviceName,
			String applicationName, String requestJson) {
		// String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		int transactionIdCount = 0;
		// String rel_id="";
		String Event_name = "";
		String response = "";
		String event_source = "";
		try {
			NamedParameterJdbcTemplate asyncJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			MapSqlParameterSource input = new MapSqlParameterSource();
			if (rel_id.equalsIgnoreCase("")) {
				rel_id = transId;
			}
			Event_name = (String) centuryCIFTemplate.queryForObject(Constants.EVENT_NAME, new Object[] { rel_id },
					String.class);
			LOGGER.info("Event_name in async method:::: " + Event_name);
			int one = 1;
			LOGGER.info("Inside insertEvent_notification method::transId:::" + transId);
			if (applicationName.equalsIgnoreCase("GPLUSD")) {
				event_source = "SMDP (G+D)";
			} else {
				event_source = "Verizon MNO 2.0";
			}
			input.addValue("event_name", Event_name);
			input.addValue("event_type", serviceName);
			input.addValue("notification_type", one);
			input.addValue("event_status", "SUCCESS");
			input.addValue("value", requestJson);
			input.addValue("event_source", event_source);
			input.addValue("external_id", transId);
			input.addValue("appliaction_name", applicationName);
			input.addValue("transaction_type", transaction_Type);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_EVENT_NOTIFICATION, input);
			return transId;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}
	
	public String jsonFormatter(String inputJson) {
		LOGGER.info("inputJson:::::" + inputJson);
		String response = null;
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
				JSONArray jsonarr = new JSONArray(inputJson);
				for (int i = 0; i < jsonarr.length(); i++) {
					JSONObject obj = jsonarr.getJSONObject(i);
					response = "[" + printJsonObject(obj, finalObj) + "]";
					LOGGER.info("JsonArray Formatter Final Response:::" + response);
				}
			} else {
				JSONObject object = new JSONObject(inputJson);
				response = "[" + printJsonObject(object, finalObj) + "]";
				LOGGER.info("JsonObject Formatter Final Response:::" + response);
			}
		} catch (JSONException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return response;
	}

	public String printJsonObject(JSONObject jsonObj, JSONObject obj) {
		try {
			Iterator a = jsonObj.keys();
			while (a.hasNext()) {
				String keyStr = a.next().toString();
				
				Object keyvalue = jsonObj.get(keyStr);
				JSONObject object = null;

				if ("mdn".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String key=jsonObject1.get("type").toString();
							
							String str = jsonObject1.toString();
							
							if(key.equalsIgnoreCase("hostMDN"))
							{
							str = str.replace("value", "hostMDN");
							}else
							{
								str = str.replace("value", "mdn");
							}
							object = new JSONObject(str);
						}
					}
				}
				if ("simid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "iccid");
							object = new JSONObject(str);
						}
					}
				}
				if ("deviceid".equalsIgnoreCase(keyStr)) {
					if (keyvalue instanceof JSONArray) {
						JSONArray array = (JSONArray) keyvalue;
						for (int i = 0; i < array.length(); i++) {
							JSONObject jsonObject1 = array.getJSONObject(i);
							String str = jsonObject1.toString();
							str = str.replace("value", "imei");
							object = new JSONObject(str);
						}
					}
				}
				if (object != null) {
					keyvalue = object;
				}

				if (!(keyvalue instanceof JSONObject) && !(keyvalue instanceof JSONArray)) {
					obj.put(keyStr, keyvalue.toString());
				}
				if (keyvalue instanceof JSONObject) {
					printJsonObject((JSONObject) keyvalue, obj);
				}
				if (keyvalue instanceof JSONArray) {
					printJsonArray((JSONArray) keyvalue, obj);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return obj.toString();
	}

	public String printJsonArray(JSONArray array, JSONObject obj) {
		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject1 = array.getJSONObject(i);
				printJsonObject(jsonObject1, obj);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

	public void updateNorthBoundTransaction(String transId, String entityId, String responseJson, String groupId,
			String transGroupId, String serviceName) {
		String status = "";
		String code = "";
		String contextId="";
		JSONObject newObj = new JSONObject();
		try {
			LOGGER.info("updateNorthBoundTransaction transid:::" + transId);
			LOGGER.info("responseJson:::" + responseJson);
			if (responseJson.startsWith("{")) {
				JSONObject responseObj = new JSONObject(responseJson);
				
				if(responseObj.toString().contains(Constants.UPDATE_WIFI_WARNING_CASE)) {
					status = "SUCCESS";
					LOGGER.info("UPDATE_WIFI_WARNING_CASE SUCCESS CASE ");
				} /*
					 * else if(responseObj.toString().contains(Constants.UPDATE_WIFI_CASE)) { status
					 * = "FAILURE"; }
					 */
				else if (responseObj.toString().contains("success") || responseObj.toString().contains("Success")
						|| responseObj.toString().contains("IN_PROGRESS")
						|| responseObj.toString().contains("INPROGRESS")
						|| responseObj.toString().contains("Inprogress")
						|| responseObj.toString().contains("InProgress") || responseObj.toString().contains("SUCCESS")
						|| responseObj.toString().contains("OK")|| responseObj.toString().contains("ACTIVE") || responseObj.toString().contains("Active")) {
					LOGGER.info("SUCCESS CASE");
					status = "SUCCESS";
				} else if(responseObj.toString().contains("contextId")) {
					if (responseObj.has("data")) {
					newObj = responseObj.getJSONObject("data");
					if (newObj.has("contextId")) {
						contextId = newObj.getString("contextId");
						if(contextId != null && !"".equalsIgnoreCase(contextId)){
						 status = "SUCCESS";
						}}}
				}else if (responseObj.has("code")) {
					code = responseObj.get("code").toString();
					status = responseObj.get("status").toString();
					LOGGER.info("FAILURE CASE");
					LOGGER.info("code----" + code + " status---" + status);
					if (code.startsWith("4") || code.startsWith("5") || status.contains("Fail")
							|| status.contains("fail") || status.contains("FAIL")
							|| responseObj.toString().contains("Fail") || responseObj.toString().contains("fail")
							|| responseObj.toString().contains("FAIL")) {
						LOGGER.info("ELSE IF--------FAILURE CASE");
						status = "FAILURE";
					}
				} else {
					LOGGER.info("ELSE FAILURE CASE:::::::::");
					status = "FAILURE";
				}
			} else if (responseJson.startsWith("[")) {
				LOGGER.info("responseJson.startsWith(\"[\"):::");
				JSONArray jsonArray = new JSONArray(responseJson);
				JSONObject responseObj = new JSONObject();
				responseObj = jsonArray.getJSONObject(0);
				LOGGER.info("responseObj::::" + responseObj);
				if (responseObj.toString().contains("success") || responseObj.toString().contains("Success")
						|| responseObj.toString().contains("IN_PROGRESS") || responseObj.toString().contains("SUCCESS")
						|| responseObj.toString().contains("OK")) {
					LOGGER.info("SUCCESS CASE...........");
					status = "SUCCESS";
				} else if (responseObj.has("code")) {
					code = responseObj.get("code").toString();
					status = responseObj.get("status").toString();
					LOGGER.info("FAILURE CASE...........");
					LOGGER.info("code----" + code + " status---" + status);
					if (code.startsWith("4") || code.startsWith("5") || status.contains("Fail")
							|| status.contains("fail") || status.contains("FAIL")
							|| responseObj.toString().contains("Fail") || responseObj.toString().contains("fail")
							|| responseObj.toString().contains("FAIL")) {
						LOGGER.info("ELSE IF--------FAILURE CASE.............");
						status = "FAILURE";
					}
				} else {
					LOGGER.info("ELSE FAILURE CASE:::::::::");
					status = "FAILURE";
				}
			} else if (responseJson.equalsIgnoreCase("INVALID_TYPE")) {
				status = "FAILURE";
			} else {
				LOGGER.info("ELSE SUCCESS --------");
				status = "SUCCESS";
			}
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.STATUS, status);
			input.addValue(Constants.TRANSGROUPID, transGroupId);
			input.addValue(Constants.GROUPID, groupId);
			input.addValue("httpCode", "200");
			input.addValue("SERVICENAME", serviceName);
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			input.addValue("RESPONSE_MSG", new SqlLobValue(responseJson), Types.CLOB);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.UPDATE_SUCCESS_TRANSACTION, input);
			this.Update_Event_notification(transId, responseJson, status);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

	public String Update_Event_notification(String transId, String response, String status) {
		String AcknowledgeStatus = null;
		String external_id = null;
		String event_destination = null;
		String sent_status = null;
		String sent_date = null;

		try {
			LOGGER.info("Inside Update_Event_notification method::transId:::" + transId);

			NamedParameterJdbcTemplate asyncJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			MapSqlParameterSource input = new MapSqlParameterSource();
			external_id = (String) centuryCIFTemplate.queryForObject(Constants.EXTERNAL_ID, new Object[] { transId },
					String.class);
			LOGGER.info("external_id in async method:::: " + external_id);

			LOGGER.info("Inside Update_Event_notification method::transId:::" + transId);

			input.addValue("external_id", external_id);
			if (status.equalsIgnoreCase("SUCCESS")) {
				event_destination = "IT MBO";
				sent_status = "Success";
				NamedParameterJdbcTemplate namedJdbcTemplate1 = new NamedParameterJdbcTemplate(
						centuryCIFTemplate.getDataSource());
				namedJdbcTemplate1.update(Constants.UPDATE_EVENT_NOTIFICATION_FAILURE, input);
			}

			input.addValue("acknowledge_status", AcknowledgeStatus);
			// input.addValue("value", response);
			input.addValue("event_status", status);
			input.addValue("event_destination", event_destination);
			input.addValue("sent_status", sent_status);

			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.UPDATE_EVENT_NOTIFICATION, input);
			return transId;

		} catch (Exception e) {
			LOGGER.error("Exception in Update_Event_notification" + e.getMessage(), e);
		}
		return transId;
	}

	public String insertMNONBTransaction(String requestJson, String entityId, String transUId, String serviceName,
			String applicationName, String httpmethod, String source) {
		LOGGER.info("Inside insertMNONBTransaction method::requestJson:::" + requestJson);
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		String transactionTimeStamp = "";
		Timestamp transactionTs = null;
		String transactionType = "";
		String status = "";
		int count=0;
		String rootId="";
		String channelID="";
		JSONObject object1 = new JSONObject();
		String agentId="";
		try {
			if(serviceName.equalsIgnoreCase("Update Port-In")) {
				JSONArray jsonarr=new JSONArray(jsonFormatter(requestJson));
				object1=jsonarr.getJSONObject(0);
				if(object1.has("originalRefNumber")){
					String orgRefNo=jsonarr.getJSONObject(0).getString("originalRefNumber");
					LOGGER.info("orgRefNo:::"+orgRefNo);
					count=getTransIdCount(orgRefNo);
					if(count>0) {
						rootId=getTransId(orgRefNo);
					}
				}
			} 
			else if (serviceName.equalsIgnoreCase("Reconnect Subscriber")
					|| serviceName.equalsIgnoreCase("Manage Subscriber")) {
				JSONArray jsonarr = new JSONArray(jsonFormatter(requestJson));
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if (requestJson.contains("transactionType")) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					transactionType = requestJsonObjectData.getString("transactionType").toString();
				}
				if (transactionType != null && !transactionType.isEmpty()) {
					if (transactionType.equalsIgnoreCase("RS")) {
						status = "Restore Suspend";
					} else if (transactionType.equalsIgnoreCase("SS")) {
						status = "Suspend";
					} else if (transactionType.equalsIgnoreCase("SD")) {
						status = "DEACTIVE";
					} else if (transactionType.equalsIgnoreCase("RM")) {
						status = "Reconnect";
					} else if (transactionType.equalsIgnoreCase("SH")) {
						status = "Hotline";
					} else if (transactionType.equalsIgnoreCase("RH")) {
						status = "Remove Hotline";
					}
				}
				String mdn = jsonarr.getJSONObject(0).getString("mdn");
				LOGGER.info("mdn:::" + mdn);
				count = getMdnCounts(mdn);
				LOGGER.info("count:::" + count);
				if (count == 0) {
					int mdnStatusCount=getMdnStatusCount(mdn);
					if(mdnStatusCount>0){
						String hostMdn = getHostMdnValue(mdn);
						LOGGER.info("HOST_MDN:::" + hostMdn);
						if(hostMdn!=null && !hostMdn.isEmpty()) {
							rootId = getMdnTransId(hostMdn, status);
							LOGGER.info("Root_ID:::" + rootId);
						}
					}
				}
			}
			transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
			LOGGER.info("Inside insertMNONBTransaction method::transId:::" + transId);
			LOGGER.info("Inside insertTransaction method::rootId:::" + rootId);
			MapSqlParameterSource input = new MapSqlParameterSource();
			if(rootId==null || rootId.equalsIgnoreCase("")) {
				input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
				input.addValue(Constants.REL_TRANSACTION_ID, null);
			}else {
				input.addValue(Constants.ROOT_TRANSACTION_ID, rootId);
				input.addValue(Constants.REL_TRANSACTION_ID, rootId);
			}
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.APPLICATION_NAME, serviceName);
			input.addValue("APPLICATIONNAME", applicationName);
			input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
			input.addValue(Constants.TRANSACTION_UID, transUId);
			input.addValue("httpmethod", httpmethod);
			input.addValue("SOURCE_SYSTEM",source);
			input.addValue("TARGET_SYSTEM","NSL");
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			if (applicationName != null && applicationName.contains("NCM")) {
				input.addValue(Constants.TENANT_ID, "2");
			} else {
				input.addValue(Constants.TENANT_ID, "1");
			}
			boolean isValidrequest=isValidJson(requestJson);
			if(isValidrequest)
			{
			if (requestJson.contains("transactionTimeStamp")) {
				// requestJson = jsonFormatter(requestJson);
				// JSONArray jsonArray = new JSONArray(requestJson);
				// JSONObject requestJsonObject = jsonArray.getJSONObject(0);
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
				}
				if (transactionTimeStamp != null
						&& (transactionTimeStamp.contains("Z") || transactionTimeStamp.contains("z"))) {
					try {
						Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(transactionTimeStamp)).getTime();
						transactionTs = new Timestamp(date.getTime());
					} catch (Exception e) {
						transactionTs = null;
					}
				}
				if (transactionTs != null) {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, transactionTs);
				} else {
					input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
				}
			} else {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
			}
			

			if(requestJson.contains("channel")) {
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					
					if(requestJsonObjectData.has("channel")) {
						channelID=requestJsonObjectData.getString("channel");
						LOGGER.info("Inside insertTransaction method::channel:::" +channelID);
					}
				}
			}
			
			if (requestJson.contains("agentDetails")) {
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if(requestJsonObjectData.has("agentDetails")) {
						LOGGER.info("Inside insertTransaction method::agentDetails:::" +requestJsonObjectData);
						requestJsonObjectData=requestJsonObjectData.getJSONObject("agentDetails");
						if(requestJsonObjectData.has("agentId")) {
							agentId=requestJsonObjectData.getString("agentId");
							LOGGER.info("Inside insertTransaction method::agentId:::" +agentId);
						}
					}
				}
			}
		

			if (requestJson.contains("account")) {
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
					if(requestJsonObjectData.has("account")) {
						LOGGER.info("Inside insertTransaction method::account:::" +requestJsonObjectData);
						requestJsonObjectData=requestJsonObjectData.getJSONObject("account");
						if(requestJsonObjectData.has("channelId")) {
							channelID=requestJsonObjectData.getString("channelId");
							LOGGER.info("Inside insertTransaction method::channelID:::" +channelID);
						}
						
					}
				}
			
			}else if (requestJson.startsWith("[") || requestJson.startsWith("{")) {
				
				JSONObject requestJsonObject = new JSONObject(requestJson);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);		
						if(requestJsonObjectData.has("channel")) {
							channelID=requestJsonObjectData.getString("channel");
							LOGGER.info("Inside insertTransaction method::channel:::" +channelID);
						}						
				}
				
			
			}
				if (channelID != null) {
					input.addValue("CHANNEL", channelID);
				} else {
					input.addValue("CHANNEL", null);
				}
				if (agentId != null) {
					input.addValue("AGENT_ID", agentId);
				} else {
					input.addValue("AGENT_ID", null);
				}
			input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
			if(serviceName.equals("line summary")) {
				if (channelID != null) {
					input.addValue("CHANNEL", null);
				}
				if (agentId != null) {
					input.addValue("AGENT_ID", null);
				}
			}
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION, input);
			}
			else
			{
				input.addValue(Constants.TRANSACTION_TIMESTAMP,null);
				input.addValue("REQUEST_MSG",requestJson);
				NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
						centuryCIFTemplate.getDataSource());
				namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION, input);
			}
			if (serviceName.equals("Handle Download Progress Info")
					|| serviceName.equals("Unsolicited Port-Out")
					|| serviceName.equals("DPFO Event Notifications")) {
				String rel_id = "";
				String Transaction_Type = Constants.INBOUND;
				this.insertEvent_notification(rel_id, transId, Transaction_Type, serviceName, applicationName,
						requestJson);
			}
			return transId;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}
	
	public String insertFallOut(String request, String response, String processPlanId, String processPlan,
			String serviceName, String taskName, String requestJson, String transId) {
		String fallOutId = null;
		try {
			// fallOutId = (String)
			// centuryCIFTemplate.queryForObject(Constants.GETFALLOUTID, String.class);
			MapSqlParameterSource input = new MapSqlParameterSource();
			fallOutId = centuryCIFTemplate.queryForObject(Constants.GETFALLOUTID, String.class);
			input.addValue("FALLOUT_ID", fallOutId);
			input.addValue("REQUEST", request);
			input.addValue("RESPONSE", response);
			input.addValue("PROCESSPLANID", processPlanId);
			input.addValue("PROCESSPLAN", processPlan);
			input.addValue("SERVICENAME", serviceName);
			input.addValue("TASKNAME", taskName);
			input.addValue("REQJSON", requestJson);
			input.addValue("STATUS", "FALLOUT");
			input.addValue("TRANSID", transId);
			input.addValue("TENANTID", 1);

			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());

			namedJdbcTemplate.update(Constants.INSERT_FALLOUT, input);
			LOGGER.info("FALLOUT ID :: " + fallOutId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			
		}
		return null;
	}

	public String constructSubOrderJson(String request) {
		LOGGER.info("request constructSubOrderJson:::" + request);
		//JSONArray mainarray = new JSONArray();
		JSONArray jsonarr = null;
		JSONObject obj = new JSONObject();
		//JSONObject jsonObject = new JSONObject();
		List<Map<String, Object>> res = null;
		List<Map<String, Object>> res1 = null;
		List<Map<String, Object>> res2 = null;
		String rel_tran_id = null;
		//String response = Constants.EMPTYSTRING;
		String ref_no = Constants.EMPTYSTRING;
		String value = Constants.EMPTYSTRING;
		String relTranId = Constants.EMPTYSTRING;
		//int count = 0;
		int refCount = 0;
	//	String message = Constants.EMPTYSTRING;
		String mno_status = Constants.EMPTYSTRING;
		String smdp_status = Constants.EMPTYSTRING;
		String cbrs_status = Constants.EMPTYSTRING;
		String relTranIdLength = Constants.EMPTYSTRING;
		String refNoLength = Constants.EMPTYSTRING;
		int relLength = 0;
		int ref_noLength = 0;
		Object transaction_Id = null;
		//String application_Name = Constants.EMPTYSTRING;
		String status = Constants.EMPTYSTRING;
		String requestmsg = Constants.EMPTYSTRING;
		String serviceId = Constants.EMPTYSTRING;
		String referenceNumber = Constants.EMPTYSTRING;
		String requestType = Constants.EMPTYSTRING;
		String res3 = Constants.EMPTYSTRING;
		//String transaction_name = Constants.EMPTYSTRING;
		String finalResponse = Constants.EMPTYSTRING;
		//String responsemsg = Constants.EMPTYSTRING;
		try {
			// JSONArray jsonarray = new JSONArray(request);
			JSONObject jsonobject = new JSONObject(request);
			LOGGER.info("jsonobject.length():::---- " + jsonobject.length());
			if (jsonobject.length() != 0) {
				for (int i = 0; i < jsonobject.length(); i++) {
					if (jsonobject.has(Constants.TRANSACTIONID)) {
						relTranId = jsonobject.getString(Constants.TRANSACTIONID).toString();
						LOGGER.info("jsonobject request:::::::" + relTranId);
						relLength = relTranId.length();
						LOGGER.info("relLength:::---- " + relLength);
						if (relLength < 25) {
							relTranIdLength = "success";
						} else {
							relTranIdLength = "failure";
						}
					}
					if (jsonobject.has(Constants.REFERENCE_NUMBER)) {
						ref_no = jsonobject.getString(Constants.REFERENCE_NUMBER).toString();
						LOGGER.info("jsonobject ref_no:::::::::" + ref_no);
						ref_noLength = ref_no.length();
						LOGGER.info("ref_noLength:::---- " + ref_noLength);
						if (ref_noLength < 70) {
							refNoLength = "success";
						} else {
							refNoLength = "failure";
						}
					}

					if (ref_no != null && !"".equalsIgnoreCase(ref_no)
							&& relTranId.equalsIgnoreCase(Constants.EMPTYSTRING)) {
						if (!refNoLength.equalsIgnoreCase("failure") && !"".equalsIgnoreCase(refNoLength)) {
							rel_tran_id = (String) centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID,
									new Object[] { ref_no, ref_no }, String.class);
							LOGGER.info("value:::" + rel_tran_id);
						} else {
							finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid referenceNumber Length}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
							return finalResponse;
						}
					} else if (ref_no.equalsIgnoreCase(Constants.EMPTYSTRING) && relTranId != null
							&& !"".equalsIgnoreCase(relTranId)) {
						if (!relTranIdLength.equalsIgnoreCase("failure") && !"".equalsIgnoreCase(relTranIdLength)) {
							rel_tran_id = relTranId;
						} else {
							finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid transactionId Length}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
							return finalResponse;
						}
					}

					else if (ref_no != null && relTranId != null && !"".equalsIgnoreCase(ref_no)
							&& !"".equalsIgnoreCase(relTranId)) {
						int relTransacId = Integer.parseInt(relTranId);
						if (!relTranIdLength.equalsIgnoreCase("failure") && !refNoLength.equalsIgnoreCase("failure")
								&& !"".equalsIgnoreCase(relTranIdLength) && !"".equalsIgnoreCase(refNoLength)) {
							BigDecimal count1 = centuryCIFTemplate.queryForObject(Constants.GET_TRANSACTIONID_COUNT,
									new Object[] { relTransacId }, BigDecimal.class);
							LOGGER.info("count1:::::::::::" + count1);
							if ((count1 != null)) {
								int relTranId1 = Integer.parseInt(relTranId);
								res1 = (List<Map<String, Object>>) centuryCIFTemplate
										.queryForList(Constants.GET_TRANSACTIONID, new Object[] { relTranId1 });
								LOGGER.info("res1:::::::" + res1);
								if (res1 != null && res1.size() > 0) {
									for (int j = 0; j < res1.size(); j++) {
										transaction_Id = res1.get(j).get(Constants.TRANSACTION_ID);
										value = transaction_Id.toString();
										LOGGER.info("value::::::::" + value);
										ref_no = (String) res1.get(j).get(Constants.REFERENCENUMBER);
										LOGGER.info("ref_no::::::" + ref_no);
									}
									if (value != null && !value.equalsIgnoreCase(null)) {
										rel_tran_id = value;
									}
								}
							} else if (ref_no != null && !"".equalsIgnoreCase(ref_no)) {
								refCount = (int) centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID_COUNT,
										new Object[] { ref_no, ref_no }, Integer.class);
								if (refCount != 0) {
									rel_tran_id = (String) centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID,
											new Object[] { ref_no, ref_no }, String.class);
									LOGGER.info("value:::" + rel_tran_id);
								} else {
									// response="[{\"code\": \"" + "405"+"\",\"status\": \"" +
									// "METHOD_NOT_ALLOWED"+"\",\"message\": \"" + "Invalid Inputs"+"\"}]";
									finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{No Matching Transaction Details Found}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
									return finalResponse;
								}
							} else {
								// finalResponse="[{\"code\": \"" + "405"+"\",\"status\": \"" +
								// "METHOD_NOT_ALLOWED"+"\",\"message\": \"" + "Invalid Inputs"+"\"}]";
								finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{No Matching Transaction Details Found}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
								return finalResponse;
							}
						} else {
							if ((relTranIdLength.equalsIgnoreCase("failure") || "".equalsIgnoreCase(relTranIdLength))
									&& !refNoLength.equalsIgnoreCase("failure")) {
								LOGGER.info("condition 1:::---- ");
								finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid transactionId Length}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
								return finalResponse;
							} else if ((refNoLength.equalsIgnoreCase("failure") || "".equalsIgnoreCase(refNoLength))
									&& !relTranIdLength.equalsIgnoreCase("failure")) {
								LOGGER.info("condition 2:::---- ");
								finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid referenceNumber Length}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
								return finalResponse;
							} else {
								LOGGER.info("condition 3:::---- ");
								finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid transactionId Length},{Invalid referenceNumber Length}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
								return finalResponse;
							}
						}

					} else {
						// finalResponse="[{\"code\": \"" + "405"+"\",\"status\": \"" +
						// "METHOD_NOT_ALLOWED"+"\",\"message\": \"" + "Invalid Inputs"+"\"}]";
						finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid Inputs}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
						return finalResponse;
					}
				}
			} else {
				finalResponse = "{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid Request-transactionId mandatory parameter is missing}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";
				return finalResponse;
			}
			LOGGER.info("rel_tran_id::::::" + rel_tran_id);
			int relTranId1 = Integer.parseInt(rel_tran_id);
			try {
				res = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_REL_TRANSACTIONID_RES,
						new Object[] { relTranId1 });
				res2 = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_STATUS,
						new Object[] { relTranId1 });
				if (res != null && res.size() > 0) {
					for (int i = 0; i < res.size(); i++) {
						transaction_Id = res.get(i).get("TRANSACTION_ID");
						//application_Name = (String) res.get(i).get("APPLICATION_NAME");
						if (res2 != null && res2.size() > 0) {
							for (int j = 0; j < res2.size(); j++) {
								mno_status = (String) res2.get(j).get("MNO_STATUS");
								smdp_status = (String) res2.get(j).get("SMDP_STATUS");
								cbrs_status = (String) res2.get(j).get("CBRS_STATUS");
								LOGGER.info("mno_status " + mno_status + " " + "cbrs_status " + cbrs_status + " "
										+ "smdp_status " + smdp_status);
								if (mno_status != null && !mno_status.equalsIgnoreCase("null")
										&& !"".equalsIgnoreCase(mno_status)) {
									LOGGER.info("mno_status condition--:::---- " + mno_status);
									status = "MNO STATUS:" + mno_status;
								} else if (smdp_status != null && !smdp_status.equalsIgnoreCase("null")
										&& !"".equalsIgnoreCase(smdp_status)) {
									LOGGER.info("smdp_status condition--:::---- " + smdp_status);
									status = "SMDP STATUS:" + smdp_status;
								} else if (cbrs_status != null && !cbrs_status.equalsIgnoreCase("null")
										&& !"".equalsIgnoreCase(cbrs_status)) {
									LOGGER.info("cbrs_status condition---:::---- " + cbrs_status);
									status = "CBRS STATUS:" + cbrs_status;
								} else {
									status = "";
								}
							}

						}
						requestmsg = (String) res.get(i).get("REQUEST_MSG");
						if (requestmsg.startsWith("<")) {
							LOGGER.info("requestmsg in xml::" + requestmsg);
							requestmsg = XML.toJSONObject(requestmsg).toString();
						}
						res3 = jsonFormatter(requestmsg);
						jsonarr = new JSONArray(res3);
						if (jsonarr.length() != 0) {
							for (int k = 0; k < jsonarr.length(); k++) {
								obj = jsonarr.getJSONObject(k);
								if (obj.has("requestType")) {
									requestType = obj.getString("requestType");
									LOGGER.info("requestType:::" + requestType);
								}
								if (obj.has("serviceId")) {
									serviceId = obj.getString("serviceId");
									LOGGER.info("serviceId:::" + serviceId);
								}
								if (obj.has("referenceNumber")) {
									referenceNumber = obj.getString("referenceNumber");
									LOGGER.info("referenceNumber:::" + referenceNumber);
								}
							}
						}
						//responsemsg = (String) res.get(i).get("RESPONSE_MSG");
						//transaction_name = (String) res.get(i).get("TRANSACTION_NAME");
						LOGGER.info("ref_no:::" + ref_no);
						finalResponse = "{\"messageHeader\":{\"serviceId\":\"" + serviceId + "\",\"requestType\":\""
								+ requestType + "\",\"referenceNumber\":\"" + referenceNumber
								+ "\"},\"data\":{\"code\":\"200\",\"reason\":\"" + status
								+ "\",\"message\":\"[]\",\"transactionId\":\"" + transaction_Id
								+ "\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";

					}
				}
			} catch (Exception ex) {
				LOGGER.error(ex.getMessage(), ex);
				
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return finalResponse;
	}
	
	public String constructSubOrderJson(String request,String responseId) {
		System.out.println("request constructSubOrderJson:::"+request);
		JSONArray mainarray = new JSONArray();
		JSONArray jsonarr =null;
		JSONObject obj = new JSONObject();
		JSONObject jsonObject = new JSONObject();
		List<Map<String, Object>> res = null;
		List<Map<String, Object>> res1 = null;
		List<Map<String, Object>> res2 = null;
		List<Map<String, Object>> additionaldata_response = null;
		String rel_tran_id = null;
		String response=Constants.EMPTYSTRING;
		String ref_no=Constants.EMPTYSTRING;
		String value=Constants.EMPTYSTRING;
		String relTranId=Constants.EMPTYSTRING;
		int count=0;
		int refCount=0;
		String message=Constants.EMPTYSTRING;
		String mno_status=Constants.EMPTYSTRING;
		String smdp_status=Constants.EMPTYSTRING;
		String cbrs_status=Constants.EMPTYSTRING;
		String relTranIdLength=Constants.EMPTYSTRING;
		String refNoLength=Constants.EMPTYSTRING;
		int relLength = 0;
		int ref_noLength =0;
		BigDecimal transaction_Id = null;
		String application_Name = Constants.EMPTYSTRING;
		String status = Constants.EMPTYSTRING;
		String requestmsg = Constants.EMPTYSTRING;
		String serviceId=Constants.EMPTYSTRING;
		String referenceNumber=Constants.EMPTYSTRING;
		String requestType=Constants.EMPTYSTRING;
		String res3=Constants.EMPTYSTRING;
		String transaction_name = Constants.EMPTYSTRING;
		String finalResponse=Constants.EMPTYSTRING;
		String responsemsg=Constants.EMPTYSTRING;
		String refName=Constants.EMPTYSTRING;
		String refValue=Constants.EMPTYSTRING;
		String refErrorValue="";
		String transIdErrorValue="";
		String ResponseCode=Constants.EMPTYSTRING;
		String ResponseMessage=Constants.EMPTYSTRING;
		try {
			//JSONArray jsonarray = new JSONArray(request);
			JSONObject jsonobject = new JSONObject(request);
			System.out.println("jsonobject.length():::---- "+jsonobject.length());
			if(jsonobject.length()!=0) {
			for (int i = 0; i < jsonobject.length(); i++) {
				if(jsonobject.has(Constants.TRANSACTIONID)) {
					relTranId = jsonobject.getString(Constants.TRANSACTIONID).toString();
					LOGGER.info("jsonobject request:::::::" + relTranId);
					relLength=relTranId.length();
					System.out.println("relLength:::---- "+relLength);
					if(relLength<25) {
						relTranIdLength="success";
					}else {
						relTranIdLength="failure";
						ResponseCode="ERR14";
						transIdErrorValue="transactionId expected max length:24";
					}
				} 
				if(jsonobject.has(Constants.REFERENCE_NUMBER)) {
					ref_no = jsonobject.getString(Constants.REFERENCE_NUMBER).toString();
					LOGGER.info("jsonobject ref_no:::::::::" + ref_no);
					ref_noLength=ref_no.length();
					System.out.println("ref_noLength:::---- "+ref_noLength);
					if(ref_noLength>=10&&ref_noLength<=100) {
						refNoLength="success";
					}else {
						if(ref_noLength<10)
						{
							ResponseCode="ERR13";
							refErrorValue="referenceNumber expected min length:10";
						}
						else if(ref_noLength>100)
						{
							ResponseCode="ERR14";
							refErrorValue="referenceNumber expected max length:100";
						}
						refNoLength="failure";
					}
				}
				if(ref_no!=null && !"".equalsIgnoreCase(ref_no) && relTranId.equalsIgnoreCase(Constants.EMPTYSTRING)) {
					if(!refNoLength.equalsIgnoreCase("failure") && !"".equalsIgnoreCase(refNoLength)) {
					rel_tran_id=(String) centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID, 
							new Object[] { ref_no,ref_no },String.class);
					LOGGER.info("value:::" + rel_tran_id);
					}else {
						finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+refErrorValue+"\"}]}}";
						return finalResponse;
					}
				} else if(ref_no.equalsIgnoreCase(Constants.EMPTYSTRING) && relTranId!=null && !"".equalsIgnoreCase(relTranId)) {
					if(!relTranIdLength.equalsIgnoreCase("failure") && !"".equalsIgnoreCase(relTranIdLength)) {
					rel_tran_id=relTranId;
					}else {
						finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+transIdErrorValue+"\"}]}}";
					    return finalResponse;
					}
				} else if(ref_no!=null && relTranId!=null && !"".equalsIgnoreCase(ref_no) && !"".equalsIgnoreCase(relTranId)) {
					if(!relTranIdLength.equalsIgnoreCase("failure") && !refNoLength.equalsIgnoreCase("failure") 
							&& !"".equalsIgnoreCase(relTranIdLength) && !"".equalsIgnoreCase(refNoLength)) {						
						count=(int) centuryCIFTemplate.queryForObject(Constants.GET_TRANSACTIONID_COUNT,
							new Object[] { relTranId },Integer.class);
						LOGGER.info("count:::::::::::" + count);						 
						if(count!=0) {
							res1 = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_TRANSACTIONID,
											new Object[] { relTranId });
							LOGGER.info("res1:::::::" + res1);
							if (res1 != null && res1.size() > 0) {
								for (int j = 0; j < res1.size(); j++) {
									transaction_Id=(BigDecimal) res1.get(j).get(Constants.TRANSACTION_ID);
									value=transaction_Id.toString();
									LOGGER.info("value::::::::" + value);
									ref_no=(String) res1.get(j).get(Constants.REFERENCENUMBER);
									LOGGER.info("ref_no::::::" + ref_no);
								}
								if(value!=null && !value.equalsIgnoreCase(null)) {
									rel_tran_id=value;
								}
							}
						}else if(ref_no!=null && !"".equalsIgnoreCase(ref_no)){
							refCount=(int)centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID_COUNT, 
								new Object[] { ref_no,ref_no },Integer.class);
							if(refCount!=0) {
								rel_tran_id=(String) centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID, 
									new Object[] { ref_no,ref_no },String.class);
								LOGGER.info("value:::" + rel_tran_id);
							}
							else {
								finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Resource Not Found\",\"message\":[{\"responseCode\":\"ERR22\",\"description\":\"No matching transaction record found\"}]}}";
								return finalResponse;
							}
						} else {
							finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Resource Not Found\",\"message\":[{\"responseCode\":\"ERR22\",\"description\":\"No matching transaction record found\"}]}}";
							return finalResponse;
						}
					}else {
						if((relTranIdLength.equalsIgnoreCase("failure") || "".equalsIgnoreCase(relTranIdLength)) && !refNoLength.equalsIgnoreCase("failure")) {
							System.out.println("condition 1:::---- ");
							finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+transIdErrorValue+"\"}]}}";
				    		return finalResponse;
						} else if((refNoLength.equalsIgnoreCase("failure") || "".equalsIgnoreCase(refNoLength)) && !relTranIdLength.equalsIgnoreCase("failure")) {
							System.out.println("condition 2:::---- ");
							finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+refErrorValue+"\"}]}}";
							return finalResponse;
						}else {
							System.out.println("condition 3:::---- ");
							finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+transIdErrorValue+"\"},{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+refErrorValue+"\"}]}}";
							return finalResponse;
						}
					}
				
				} else {
					finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"E101\",\"description\":\"Invalid Inputs\"}]}}";	/*finalResponse="{\"messageHeader\":{\"serviceId\":\"\",\"requestType\":\"\",\"referenceNumber\":\"\"},\"data\":{\"code\":\"400\",\"reason\":\"Failure\",\"message\":\"[{Invalid Inputs}]\",\"transactionId\":\"\",\"additionalData\":[{\"name\":\"\",\"value\":\"\"}]}}";*/
					return finalResponse;
				}
			}
			}else {
				finalResponse="{\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERR10\",\"description\":\"transactionId does not exist\"}]}}";	
				return finalResponse;
			}
			
			LOGGER.info("rel_tran_id::::::" + rel_tran_id);
			try {
			res = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_REL_TRANSACTIONID_RES,
					new Object[] { rel_tran_id,"OUTBOUND" });
			res2=(List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_STATUS,
					new Object[] { rel_tran_id });
			//if(res!=null && res2!=null) {
			if (res != null && res.size() > 0) {
				for (int i = 0; i < res.size(); i++) {
					transaction_Id = (BigDecimal) res.get(i).get("TRANSACTION_ID");
					application_Name = (String) res.get(i).get("APPLICATION_NAME");
					if (res2 != null && res2.size() > 0) {
						for (int j = 0; j < res2.size(); j++) {
							mno_status = (String) res2.get(j).get("MNO_STATUS");
							smdp_status = (String) res2.get(j).get("SMDP_STATUS");
							cbrs_status = (String) res2.get(j).get("CBRS_STATUS");
							System.out.println("mno_status "+mno_status+" "+"cbrs_status "+cbrs_status+" "+"smdp_status "+smdp_status);
							if(mno_status!=null && !mno_status.equalsIgnoreCase("null") && !"".equalsIgnoreCase(mno_status)) {
								System.out.println("mno_status condition--:::---- "+mno_status);
								//status="MNO STATUS:"+mno_status;
								status=mno_status;
							}else if(smdp_status!=null && !smdp_status.equalsIgnoreCase("null") && !"".equalsIgnoreCase(smdp_status)) {
								System.out.println("smdp_status condition--:::---- "+smdp_status);
								//status="SMDP STATUS:"+smdp_status;
								status=smdp_status;
							}else if(cbrs_status!=null && !cbrs_status.equalsIgnoreCase("null") && !"".equalsIgnoreCase(cbrs_status)) {
								System.out.println("cbrs_status condition---:::---- "+cbrs_status);
								//status="CBRS STATUS:"+cbrs_status;
								status=cbrs_status;
							}else {
								status="";
							}
						}
					
					}
					requestmsg = (String) centuryCIFTemplate.queryForObject(Constants.GET_TRANSACTIONID_RES, new Object[] { rel_tran_id },
					String.class);
					if(requestmsg.startsWith("<")) {
					System.out.println("requestmsg in xml::"+requestmsg);
					requestmsg = XML.toJSONObject(requestmsg).toString();
					}
					res3 = jsonFormatter(requestmsg);
					jsonarr = new JSONArray(res3);
					if (jsonarr.length() != 0) {
						for (int k = 0; k < jsonarr.length(); k++) {
							obj = jsonarr.getJSONObject(k);
						if (obj.has("requestType")) {
							requestType = obj.getString("requestType");
							System.out.println("requestType:::" + requestType);
						}
						if (obj.has("serviceId")) {
							serviceId = obj.getString("serviceId");
							System.out.println("serviceId:::" + serviceId);
						}
						if (obj.has("referenceNumber")) {
							referenceNumber = obj.getString("referenceNumber");
							System.out.println("referenceNumber:::" + referenceNumber);
						}
					}
					}
					additionaldata_response=(List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_ADDITONAL_DATA,
							new Object[] { rel_tran_id });
					if (additionaldata_response != null && additionaldata_response.size() > 0) {
						for (int a = 0; a < additionaldata_response.size(); a++) {
							refName=(String) additionaldata_response.get(a).get("REFNAME");
							refValue=(String) additionaldata_response.get(a).get("REFVALUE");
							System.out.println("REFNAME -REFVALUE:::" + refName +"-"+refValue);
						}
					}
					responsemsg=(String) res.get(i).get("RESPONSE_MSG");
					transaction_name = (String) res.get(i).get("TRANSACTION_NAME");
					System.out.println("ref_no:::"+ref_no);
					
					if(status.equalsIgnoreCase("Active"))
					{
						ResponseCode="SUC00";
						//ResponseMessage="Success";
					}
					else{
						ResponseCode="SUC01";
						//ResponseMessage="In Progress";
					}

						finalResponse="{\"data\":{\"transactionId\":\""+ transaction_Id +"\",\"code\":\"200\",\"reason\":\"OK\",\"message\":[{\"responseCode\":\""+ResponseCode+"\",\"description\":\""+status+"\"}]}}";

				}
			}

			}catch(Exception ex) {
				LOGGER.error(ex.getMessage(), ex);
			}

		}
			catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return finalResponse;
	}

	public String validateBasicToken(String basicToken) {

		String status = "failure";

		try {
			String base64Credentials = basicToken.substring("Basic".length()).trim();

			byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
			String credentials = new String(credDecoded, StandardCharsets.UTF_8);
			// credentials = username:password
			final String[] values = credentials.split(":", 2);
			if (values.length == 2) {
				int count = (Integer) centuryCIFTemplate
						.queryForObject("select count(*) from BASIC_AUTH_DETAILS where USER_NAME= '" + values[0]
								+ "' and passcode='" + values[1] + "'", Integer.class);
				if (count > 0) {
					status = "success";
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return status;
	}	

	public boolean isValidJson(String inputJson) {
		System.out.println("inputJson:::::"+inputJson);
		String response = "";
		JSONObject finalObj = new JSONObject();
		try {
			if (inputJson.startsWith("[")) {
					JSONArray jsonarr = new JSONArray(inputJson);
					if(jsonarr != null && jsonarr.length() > 0) {
				return true;
			}
			}
			else if (inputJson.startsWith("{")) 
			{
			JSONObject object = new JSONObject(inputJson);
			
			if(object != null && object.length() > 0) {
				return true;
			}
			}
		}	
		catch (JSONException e) {
			LOGGER.error(e.getMessage(), e);
			System.out.println("jsonFormatterforRequest.............."+inputJson);
			//response =false;
			return false;
		}
		return true;
	}
	
	public String insertAsyncTransaction(String requestJson, String entityId, String transUId, String serviceName, String applicationName,String reqType,String source, String refNo) {
		LOGGER.info("After Calling insertAsyncTransaction 2 with :: request = " + requestJson + " :: entityId = " + entityId + " :: transId = " + transUId
				 + " :: source = " + source + " :: refNo = " + refNo);		
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		int transactionIdCount = 0;
		String rootId="";
		try {
			NamedParameterJdbcTemplate asyncJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			MapSqlParameterSource input = new MapSqlParameterSource();

			input.addValue("REFERENCE_NUMBER", refNo);
			try {
				rootId = asyncJdbcTemplate.queryForObject(Constants.ROOT_TRANS_ID, input, String.class);
			} catch (Exception e) {
				rootId = "";
			}
			/*
			 * transactionIdCount =
			 * asyncJdbcTemplate.queryForObject(Constants.TRANS_ID_COUNT, input,
			 * Integer.class); LOGGER.info("transactionIdCount:::: " + transactionIdCount);
			 * if (transactionIdCount != 0) { rel_id = (String)
			 * centuryCIFTemplate.queryForObject(Constants.TRANS_ID, new Object[] { refNo,
			 * refNo }, String.class); LOGGER.info("refNo in async method:::: " + rel_id);
			 * 
			 * }
			 */
			transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
			LOGGER.info("Inside insertTransaction method::transId:::" + transId);
			input.addValue(Constants.TRANSACTION_ID, transId);
			if(rootId!=null && !"".equalsIgnoreCase(rootId)){
				input.addValue(Constants.ROOT_TRANSACTION_ID, rootId);
			}else{
				input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
			}
			input.addValue(Constants.APPLICATION_NAME, serviceName);
			input.addValue("APPLICATIONNAME", applicationName);
			input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
			input.addValue(Constants.TRANSACTION_UID, transUId);
			input.addValue("REL_TRANSACTION_ID", rootId);
			if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
				input.addValue(Constants.ENTITY_ID, entityId);
			} else {
				input.addValue(Constants.ENTITY_ID, 0);
			}
			if (applicationName != null && applicationName.contains("NCM")) {
				input.addValue(Constants.TENANT_ID, "2");
			} else {
				input.addValue(Constants.TENANT_ID, "1");
			}
			input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
			input.addValue("SOURCE_SYSTEM", source);
			input.addValue("TARGET_SYSTEM","NSL");
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			String Transaction_Type = Constants.INBOUND;
			namedJdbcTemplate.update(Constants.INSERT_ASYNC_TRANSACTION, input);
			if (serviceName.equalsIgnoreCase("Async Programming")||serviceName.equalsIgnoreCase("DPFO Notification")) {
				this.insertEvent_notification(rootId, transId, Transaction_Type, serviceName, applicationName,
						requestJson);
			}
			return transId;

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}
	
	public String tokenCheck(String token) {
		String status = null;
		String count = null;
		try {
			System.out.println("inside tokenCheck:::" + token);
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("TOKEN", token);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			count = namedJdbcTemplate.queryForObject(Constants.GET_TOKEN, input, String.class);
			System.out.println("count:::" + count);
			if (!count.equalsIgnoreCase("0")) {
				status = "success";
			} else {
				status = "failure";
			}
		} catch (Exception e) {
			LOGGER.error("Error::" + e.getMessage());
		}
		return status;
	}

	public String insertAsyncStatus(RequestBean requestBean, String response)  {
		LOGGER.info("Inside insertAsyncStatus:::: ");
		LOGGER.info("insertAsyncStatus:::: requestBean "+requestBean.toString());
		LOGGER.info("insertAsyncStatus:::: response "+response);
		MapSqlParameterSource input = new MapSqlParameterSource();
		String transId = null;
		String status=null;
		String httpCode="200";
		String operationName="";
		String referenceNumberNew ="";
		try {
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			int transactionIdCount = 0;
			Map<String, Object> refNumAndTransId =new HashMap<String, Object>();
			/*
			 * if(requestBean.getReferenceNumber().endsWith("Wearable")) {
			 * referenceNumberNew = requestBean.getReferenceNumber().substring(0,
			 * (requestBean.getReferenceNumber().length()-8));
			 * LOGGER.info("referenceNumberNew:::"+referenceNumberNew);
			 * requestBean.setReferenceNumber(referenceNumberNew); }
			 */
			input.addValue("REFERENCE_NUMBER", requestBean.getReferenceNumber().toString());
			try {
				transactionIdCount = namedJdbcTemplate.queryForObject(Constants.REF_TRANS_ID_COUNT, input,
						Integer.class);
			} catch (Exception e) {
				transactionIdCount = 0;
			}
			LOGGER.info("transactionIdCount:::: " + transactionIdCount);
			if (transactionIdCount != 0) {
				refNumAndTransId = (Map<String,Object>)centuryCIFTemplate.queryForMap(Constants.GET_REF_TRANSID, new Object[] {requestBean.getReferenceNumber(),requestBean.getReferenceNumber()});
				transId=refNumAndTransId.get(Constants.ROOT_TRANSACTION_ID).toString();
				requestBean.setReferenceNumber(refNumAndTransId.get(Constants.REFERENCE_NUM).toString());
				LOGGER.info("transId:::: " + transId);
		
				
				new MapSqlParameterSource();
				input.addValue("MDN", requestBean.getMdn());
				if(requestBean.getReferenceNumber()!=null) {
					 input.addValue("REFNO", requestBean.getReferenceNumber()); 
				}else {
					input.addValue("REFNO", null);
				}
				if(requestBean.getRequestNo()!=null) {
					 input.addValue("REQUESTNO", requestBean.getRequestNo()); 
				}else {
					input.addValue("REQUESTNO", null);
				}
				if(requestBean.getResponsetype()!=null) {
					 input.addValue("RESPONSETYPE", requestBean.getResponsetype()); 
				}else {
					input.addValue("RESPONSETYPE", null);
				}
				if(requestBean.getReferenceNumber()!=null) {
					 input.addValue("REFNO", requestBean.getReferenceNumber()); 
				}else {
					input.addValue("REFNO", null);
				}
				if(requestBean.getRequestNo()!=null) {
					 input.addValue("REQUESTNO", requestBean.getRequestNo()); 
				}else {
					input.addValue("REQUESTNO", null);
				}
				if(requestBean.getResponsetype()!=null) {
					 input.addValue("RESPONSETYPE", requestBean.getResponsetype()); 
				}else {
					input.addValue("RESPONSETYPE", null);
				}
				
			
				  input.addValue("MNO_STATUS", "ACTIVE");
			
				input.addValue("TRANSACTION_ID", transId);
				namedJdbcTemplate.update(Constants.INSERT_ASYNC_STATUS, input);
				
			}
		} catch (Exception e) {
			LOGGER.error("Exception in insertAsyncStatus" + e.getMessage(), e);
		}
		return requestBean.getReferenceNumber().toString();

	}
	
	
	public boolean getStatusFromDB(String serviceName, String method) {
		LOGGER.info("getStatusFromDB:::::::::");
		String response = "";
		boolean enabled = false;

		try {
			LOGGER.info("MapSqlParameterSource::::::::::::");
		MapSqlParameterSource input = new MapSqlParameterSource();
		input.addValue("METHOD", "%" +method+ "%");
		input.addValue(Constants.SERVICETYPE, Constants.INBOUND.toLowerCase());
		input.addValue("SERVICENAME", serviceName);
		LOGGER.info("serviceName::::::::::::"+serviceName);
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(centuryCIFTemplate.getDataSource());
		response = namedJdbcTemplate.queryForObject(Constants.GET_SERVICE_STATUS, input, String.class);
		LOGGER.info("response::::::::::::"+response);
		if (StringUtils.hasText(response) && Constants.TRUE.equalsIgnoreCase(response)) {
			LOGGER.info("response::::"+response);
		enabled = true;
		} else {
			LOGGER.info("response::::"+response);
			enabled = false;
		//throw new NslCustomException(Response.status(Status.MOVED_PERMANENTLY).entity("{\"data\":{\"code\":\"301\",\"reason\":\"Moved Permanently\",\"message\": [{\"responseCode\": \"ERROR\",\"description\": \"API Retired. New API Location: /nsl/provisioning/mno/v1/sim/{iccid}/validate-sim\"}]}}").build());
		}

		} catch (Exception e) {
			LOGGER.info("exception::::"+response);
		/* if(e instanceof NslCustomException) {
		String authErrorResponse = ((NslCustomException) e).getResponse().getEntity().toString();
		StatusType info = ((NslCustomException) e).getResponse().getStatusInfo();
		throw new NslCustomException(Response.status(info).entity(authErrorResponse).build()); 
		}*/
		}

		return enabled;
		}
	
	
	public Integer getTransIdCount(String originalRefNumber) {
		Integer count = centuryCIFTemplate.queryForObject(Constants.GET_TRANS_ID_COUNTS, new Object[] { originalRefNumber }, Integer.class);
		return count;
	}
	
	public String getTransId(String originalRefNumber) {
		String rootId =centuryCIFTemplate.queryForObject(Constants.GET_TRANS_IDS,
				new Object[] { originalRefNumber },String.class);
		return rootId;
	}
	
	public void insertBatchTransaction(JSONObject data,
			RequestBean requestBean) {

		try {
			JSONObject newObj = new JSONObject();
			String transactionType = "";
			String syncTransaction = "";
			String executionTimeStamp = "";
			String agentId = "";
			String channelId = "";
			String mdn = "";
			String batchId = "";
			JSONArray suborderArr = new JSONArray();
			JSONArray mdnArr = new JSONArray();
			JSONObject mdnObj = new JSONObject();
			Timestamp transactionTs = null;

			if (data.has("transactionType")) {
				transactionType = data.getString("transactionType");
			}
			if (data.has("syncTransaction")) {
				syncTransaction = data.getString("syncTransaction");
			}
			if (data.has("executionTimeStamp")) {
				executionTimeStamp = data.getString("executionTimeStamp");
				if (executionTimeStamp != null
						&& (executionTimeStamp.contains("Z") || executionTimeStamp.contains("z"))) {
					try {
						Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(executionTimeStamp)).getTime();
						transactionTs = new Timestamp(date.getTime());
					} catch (Exception e) {
						transactionTs = null;
					}
				}
			}
			if (data.has("agentId")) {
				agentId = data.getString("agentId");
			}
			if (data.has("channelId")) {
				channelId = data.getString("channelId");
			}

			MapSqlParameterSource inputValue = new MapSqlParameterSource();
			if (transactionTs != null) {
				inputValue.addValue("Exc_TimeStamp", transactionTs);
			} else {
				inputValue.addValue("Exc_TimeStamp", null);
			}
			inputValue.addValue("TRANSACTION_ID", null);
			inputValue.addValue("Ext_Batch_ID", requestBean.getBatchId());
			inputValue.addValue("MDN", requestBean.getMdn());
			inputValue.addValue("Batch_Type", transactionType);
			inputValue.addValue("Reference_Number", requestBean.getReferenceNumber());
			inputValue.addValue("Sync", syncTransaction);
			inputValue.addValue("Channel_ID", channelId);
			inputValue.addValue("Service_Type", "JSON");
			inputValue.addValue("Created_By", agentId);
            inputValue.addValue("batch_update_status","INITIATED");
			inputValue.addValue("STATUS","INITIATED");
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());

			namedJdbcTemplate.update(Constants.RH_Batch_Transaction, inputValue);
		} catch (Exception e) {

			LOGGER.error("Exception in handle method" + e.getMessage());
		}
	}
	
	public String getServiceURL(String serviceName) {
		String serviceUrl =centuryCIFTemplate.queryForObject(Constants.SERVICE_URL, new Object[] { serviceName }, String.class);
		
		return serviceUrl;
	}
	
	public String getRetailPlanCode(String mdn) {
		String RetailplanCode= centuryCIFTemplate.queryForObject(Constants.GET_RETAIL_PLANCODE, new Object[] { mdn}, String.class);
		
		return RetailplanCode;
	}
		
	public String constructFinalResponse(String responseId) {
		//List<Map<String, Object>> res2 = null;
		String requestJson="";
		Map<String, String> dataMap=null;
		String requestMsg="";
		String responseMsg="";
		String responseMsg2="";
		String frameworkResponse="";
		JSONObject messageHeaderObject = null;
		JSONObject deviceObject = null;
		JSONObject retrieveDevicedataObj = null;
		JSONObject getRequestIMEIVal = null;
		JSONObject requestJsonObject1 = null;
		JSONObject requestJsonObject = null;
		JSONObject dataJsonObject = null;
		JSONObject lineDetailsObject1 = null;
		JSONObject requestJsonObject2 = null;
		JSONObject lineDetailsObject2 = null;
		JSONObject lineDetailsObject3 = null;
		JSONObject jsonObj1 = null;
		JSONObject lineWearableObj = null;
		JSONObject iccidLineWearableObj = null;
		JSONArray subOrderArr=null;
		JSONArray accountResSubOrderArr=null;
		JSONObject accountResSubOrderObj = null;
		JSONArray imeiMdnArr=null;
		JSONObject imeiMdnObject=null;
		JSONArray iccidMdnArr=null;
		JSONObject iccidMdnObject=null;
		JSONArray statusArr=null;
		JSONArray deviceIdArr=null;	
		JSONArray reqImeiArr=null;
		JSONObject statusObject=null;
		JSONArray accountResStatusArr=null;
		JSONObject accountResStatusObj=null;
		JSONArray prospectDeviceIdArr=null;
		JSONObject prospectDeviceIdObject=null;
		JSONObject deviceIdstatusObject=null;
		JSONArray accountResProspectDeviceIdArr=null;
		JSONObject accountResProspectDeviceIdObj=null;
		JSONArray lineWearablestatusArr=null;
		JSONObject lineWearablestatusObject=null;
		JSONArray iccidLineWearablestatusArr=null;
		JSONArray lineDetailsArray=new JSONArray();
		JSONObject iccidLineWearablestatusObject=null;
		JSONObject accountNumberResponse=null;
		String imeiMdnType="";
		String imeiMdnValue="";
		String iccidMdnValue="";
		String statusType="";
		String statusValue="";
		String accountResStatusType="";
		String accountResStatusValue="";
		String deviceIdType="";
		String deviceIdValue="";
		String accountResDeviceIdType="";
		String accountResDeviceIdValue="";
		String lineWearablestatusType="";
		String lineWearablestatusValue="";
		String iccidLineWearablestatusType="";
		String iccidLineWearablestatusValue="";
		String hostLineStatus="";
		String hostLineStatusCheck="";
		String smartWatchLineStatus="";
		String lineWearablessmartWatchLineStatus="";
		String smartWatchIMEIStatus="";
		String smartWatchLineStatusCheck="";
		String RequestIMEIVal="";
		String deviceValue="";
		int lineCount=0;
		int iccidCount=0;
		int imeiCount=0;
		String lineCountCheck="";
		boolean newActivation=false;
		boolean eacs=false;
		boolean changeDevice=false;
		boolean manageWatch=false;
		boolean transferWatch=false;
		boolean warrantyExchange=false;
		String conditionCheck="";
		String serviceId="";
		String requestType="";
		String refNo="";
		JSONObject accountObj=null;
		String accountNumber=null;
		JSONArray getsuborder=null;
		JSONArray deviceidSubOrderArr=null;
		JSONObject deviceidSubOrderObj=null;
		JSONObject getsuborderval=null;
		String url=inboundProperties.getRouterserviceurl();
		String response="";
		String devicetypSubOrder="";
		String equipmentTypeValueStatus="";
		String equipmentTypeValue="";
		String contextId="";
		String transactionType="";
		String transactionTimeStamp="";
		String imeiaccountNumber="";
		JSONObject imeiaccountObj=null;
		JSONArray iccidlinewearable=null;
		JSONObject iccidwearableObject=null;
		String iccidLineWearcletype="";
		String equipmentTypeValueforiccid="";
		String equipmentTypeValueStatusforiccid="";
		String serviceName="Retrieve-Device-Details";
		String operationName="RetrieveAccountWF";
		int dbResponsesCount=centuryCIFTemplate.queryForObject(Constants.GET_RELTRANS_ID_COUNT, new Object[] { responseId }, Integer.class);
		System.out.println("dbResponsesCount::" + dbResponsesCount);
		if(dbResponsesCount>0) {			
			/*
			 * res2 = (List<Map<String, Object>>)
			 * centuryCIFTemplate.queryForList(Constants.GET_RESPONSE_MSG, new Object[] {
			 * responseId,"OUTBOUND" });
			 */
			//inbound request
			requestMsg= centuryCIFTemplate.queryForObject(Constants.GETIBREQUEST_RETRIEVEDEVICE, new Object[] { responseId}, String.class);
			System.out.println("requestMsg INBOUND ----::" + requestMsg);
			//iccid-Response
			responseMsg= centuryCIFTemplate.queryForObject(Constants.GET_RESPONSE_MSG, new Object[] { responseId,"OUTBOUND","Get Line Details" }, String.class);
			System.out.println("responseMsg Get Line Details constructFinalResponse::" + responseMsg);
			//imei-Response
			responseMsg2= centuryCIFTemplate.queryForObject(Constants.GET_RESPONSE_MSG, new Object[] { responseId,"OUTBOUND","Get Device Details" }, String.class);
			System.out.println("responseMsg2 Get Device Details constructFinalResponse::" + responseMsg2);
			if(responseMsg!=null && responseMsg2!=null) {
				System.out.println("Inside merging Response::----------");
				try {
					//inbound request
					requestJsonObject=new JSONObject(requestMsg);
					if(requestJsonObject.has("messageHeader")) {
						messageHeaderObject=requestJsonObject.getJSONObject("messageHeader");
						if(messageHeaderObject.has("serviceId")) {
							serviceId=messageHeaderObject.getString("serviceId");
						}
						if(messageHeaderObject.has("referenceNumber")) {
							refNo=messageHeaderObject.getString("referenceNumber");
						}
					}
					
					if (requestJsonObject.has("data")) {
						retrieveDevicedataObj = requestJsonObject.getJSONObject("data");
						if(retrieveDevicedataObj.has("contextId")) {
							 contextId = retrieveDevicedataObj.getString("contextId");
							 System.out.println("contextId value for retrieve device details ::::::" + contextId);
						}
						if(retrieveDevicedataObj.has("transactionType")) {
							transactionType = retrieveDevicedataObj.getString("transactionType");
							 System.out.println("retrieve device details for transactionType::::::" + transactionType);
						}
						if(retrieveDevicedataObj.has("transactionTimeStamp")) {
							transactionTimeStamp = retrieveDevicedataObj.getString("transactionTimeStamp");
							 System.out.println("retrieve device details for transactionTimeStamp::::::" + transactionTimeStamp);
						}
						if (retrieveDevicedataObj.has("subOrder")) {
							getsuborder = retrieveDevicedataObj.getJSONArray("subOrder");
							getsuborderval = getsuborder.getJSONObject(0);
							if (getsuborderval.has("deviceId")) {
								reqImeiArr = getsuborderval.getJSONArray("deviceId");
								getRequestIMEIVal = reqImeiArr.getJSONObject(0);

								if (getRequestIMEIVal.has("type")) {
									String RequestIMEIType = getRequestIMEIVal.getString("type");
								}
								if (getRequestIMEIVal.has("value")) {
									RequestIMEIVal = getRequestIMEIVal.getString("value");
									System.out.println("RequestIMEIVal ::::::" + RequestIMEIVal);
								}
							}
						} else if (retrieveDevicedataObj.has("deviceId")) {
							reqImeiArr = retrieveDevicedataObj.getJSONArray("deviceId");
							getRequestIMEIVal = reqImeiArr.getJSONObject(0);
							if (getRequestIMEIVal.has("type")) {
								String RequestIMEIType = getRequestIMEIVal.getString("type");
							}
							if (getRequestIMEIVal.has("value")) {
								RequestIMEIVal = getRequestIMEIVal.getString("value");
								System.out.println("RequestIMEIVal ::::::" + RequestIMEIVal);
							}
						}

					}
					
					
					//iccid
					requestJsonObject1=new JSONObject(responseMsg);					
					if(requestJsonObject1.has("data")) {
						requestJsonObject1=requestJsonObject1.getJSONObject("data");
						if(requestJsonObject1.has("account")) {
							accountObj = requestJsonObject1.getJSONObject("account");
								if(accountObj.has("accountNumber")) {
									accountNumber= accountObj.getString("accountNumber");
								}
							}
						if(requestJsonObject1.has("subOrder")) {
							subOrderArr=requestJsonObject1.getJSONArray("subOrder");
							jsonObj1=subOrderArr.getJSONObject(0);
							lineDetailsObject1=jsonObj1;
							lineDetailsArray.put(lineDetailsObject1);
							if(jsonObj1.has("status")) {
								statusArr=jsonObj1.getJSONArray("status");
								statusObject=statusArr.getJSONObject(0);
								if(statusObject.has("type")) {
									statusType=statusObject.getString("type");
									if(statusType.equalsIgnoreCase("lineStatus")) {
										if(statusObject.has("value")) {
											statusValue=statusObject.getString("value");
											hostLineStatus=statusValue;
											System.out.println("hostLineStatus constructFinalResponse::"+ hostLineStatus);
										}
									}
								}
							}
							if(jsonObj1.has("mdn")) {
								iccidMdnArr=jsonObj1.getJSONArray("mdn");
								iccidMdnObject=iccidMdnArr.getJSONObject(0);
								if(iccidMdnObject.has("value")) {
									iccidMdnValue=iccidMdnObject.getString("value");
									System.out.println("iccidMdnValue >>::"+ iccidMdnValue);
								}
							}
							if (jsonObj1.has("lineWearable")) {
								JSONArray iccidLineWearableArr=null;
								iccidLineWearableArr=jsonObj1.getJSONArray("lineWearable");
								iccidLineWearableObj=iccidLineWearableArr.getJSONObject(0);
								if (iccidLineWearableObj.has("deviceId")) {
									iccidlinewearable = iccidLineWearableObj.getJSONArray("deviceId");
									//deviceidSubOrderObj = deviceidSubOrderArr.getJSONObject(0);
									for (int k = 0; k < iccidlinewearable.length(); k++) {
										iccidwearableObject = iccidlinewearable.getJSONObject(k);
										if (iccidwearableObject.has("type")) {
											iccidLineWearcletype = iccidwearableObject.getString("type");
											if (iccidLineWearcletype.equalsIgnoreCase("equipmentType")) {
												if (iccidwearableObject.has("value")) {
													equipmentTypeValueforiccid = iccidwearableObject.getString("value");
													if(equipmentTypeValueforiccid.equalsIgnoreCase("SMART_WATCH")) {
														equipmentTypeValueStatusforiccid = equipmentTypeValueforiccid;																
														System.out.println("lineCount equipmentTypeValueStatus::"
																+ equipmentTypeValueStatusforiccid);
														break;
													}
												}
											}
										}
									}
								}
								if (iccidLineWearableObj.has("status")) {
									iccidLineWearablestatusArr = iccidLineWearableObj.getJSONArray("status");
									for (int k = 0; k <iccidLineWearablestatusArr.length(); k++) {
										iccidLineWearablestatusObject = iccidLineWearablestatusArr.getJSONObject(k);
										if (iccidLineWearablestatusObject.has("type")) {
											iccidLineWearablestatusType = iccidLineWearablestatusObject.getString("type");
											if (iccidLineWearablestatusType.equalsIgnoreCase("lineStatus")) {
												if (iccidLineWearablestatusObject.has("value")) {
													iccidLineWearablestatusValue = iccidLineWearablestatusObject.getString("value");
													System.out.println("iccidLineWearablestatusValue constructFinalResponse::"+ iccidLineWearablestatusValue);
													if (!iccidLineWearablestatusValue.isEmpty()) {
														iccidCount++;
														System.out.println("lineWearablessmartWatchLineStatus constructFinalResponse::" + lineCount);
													}
													
												}
											}
										}
									}
								}
							}
						}
					}
					//imei
					requestJsonObject2=new JSONObject(responseMsg2);
					if (requestJsonObject2.has("data")) {
						requestJsonObject2 = requestJsonObject2.getJSONObject("data");
						if(requestJsonObject2.has("account")) {
							imeiaccountObj = requestJsonObject2.getJSONObject("account");
								if(imeiaccountObj.has("accountNumber")) {
									imeiaccountNumber= imeiaccountObj.getString("accountNumber");
								}
							}
						if (requestJsonObject2.has("subOrder")) {
							subOrderArr = requestJsonObject2.getJSONArray("subOrder");
							jsonObj1 = subOrderArr.getJSONObject(0);
							lineDetailsObject2=jsonObj1;
							lineDetailsArray.put(lineDetailsObject2);
							if (jsonObj1.has("deviceId")) {
								deviceIdArr = jsonObj1.getJSONArray("deviceId");
								for (int j = 0; j < deviceIdArr.length(); j++) {
									deviceObject = deviceIdArr.getJSONObject(j);
									if (deviceObject.has("type")) {
										String deviceType = deviceObject.getString("type");
										System.out.println("smartWatchLines for  deviceType:::::::" + deviceType);
										if (deviceType.equalsIgnoreCase("imei")) {
											if (deviceObject.has("value")) {
												deviceValue = deviceObject.getString("value");
												System.out.println("smartWatchLines for  deviceValue:::::" + deviceValue);
											}
										}
									}
								}

							}
							if (jsonObj1.has("status")) {
								statusArr = jsonObj1.getJSONArray("status");
								statusObject = statusArr.getJSONObject(0);
								if (statusObject.has("type")) {
									statusType = statusObject.getString("type");
									if (statusType.equalsIgnoreCase("lineStatus")) {
										if (statusObject.has("value")) {
											statusValue = statusObject.getString("value");
											smartWatchLineStatus = statusValue;
											System.out.println("smartWatchLineStatus constructFinalResponse::"+ smartWatchLineStatus);
										}
									}
								}
							}
							if (jsonObj1.has("lineWearable")) {
								JSONArray lineWearableArr=null;
								lineWearableArr=jsonObj1.getJSONArray("lineWearable");
								lineWearableObj=lineWearableArr.getJSONObject(0);
								if (lineWearableObj.has("status")) {
									lineWearablestatusArr = lineWearableObj.getJSONArray("status");
									for (int k = 0; k < lineWearablestatusArr.length(); k++) {
										lineWearablestatusObject = lineWearablestatusArr.getJSONObject(k);
										if (lineWearablestatusObject.has("type")) {
											lineWearablestatusType = lineWearablestatusObject.getString("type");
											if (lineWearablestatusType.equalsIgnoreCase("lineStatus")) {
												if (lineWearablestatusObject.has("value")) {
													lineWearablestatusValue = lineWearablestatusObject
															.getString("value");
													lineWearablessmartWatchLineStatus = lineWearablestatusValue;
													System.out.println("lineCount constructFinalResponse::"+ lineWearablessmartWatchLineStatus);
													if (lineWearablessmartWatchLineStatus.equalsIgnoreCase("Active")
															|| lineWearablessmartWatchLineStatus
																	.equalsIgnoreCase("hotline")
															|| lineWearablessmartWatchLineStatus
																	.equalsIgnoreCase("suspended")) {
														lineCount++;
														System.out.println("lineWearablessmartWatchLineStatus constructFinalResponse::" + lineCount);
													}
												}
											}
										}
									}
								}
							}
							if (jsonObj1.has("prospectDeviceId")) {
								prospectDeviceIdArr=jsonObj1.getJSONArray("prospectDeviceId");
								for(int j=0;j<prospectDeviceIdArr.length();j++) {
									prospectDeviceIdObject=prospectDeviceIdArr.getJSONObject(j);
									if(prospectDeviceIdObject.has("type")) {
										deviceIdType=prospectDeviceIdObject.getString("type");
										if(deviceIdType.equalsIgnoreCase("IMEI")) {
											imeiCount++;
											if(prospectDeviceIdObject.has("value")) {
												deviceIdValue=prospectDeviceIdObject.getString("value");										
													if(deviceIdValue.equalsIgnoreCase("IMEI Not Found")) {
														requestJson="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"accountNumber\":\""+accountNumber+"\"}}";
														requestJson = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +responseId +"&responseId=" + responseId;
														System.out.println("requestJson callRestAPI in constructFinalResponse::" + requestJson);
														System.out.println("url url url>>>::" + url);
														response=utilityClass.callRestAPI(requestJson, url);
														System.out.println("response callRestAPI in constructFinalResponse::" + response);
														accountNumberResponse=new JSONObject(response);
														if(accountNumberResponse.has("data")) {
															accountNumberResponse=accountNumberResponse.getJSONObject("data");
															if(accountNumberResponse.has("subOrder")) {
																accountResSubOrderArr=accountNumberResponse.getJSONArray("subOrder");
																accountResSubOrderObj=accountResSubOrderArr.getJSONObject(0);
																if(accountResSubOrderObj.has("status")) {
																	accountResStatusArr=accountResSubOrderObj.getJSONArray("status");
																	accountResStatusObj=accountResStatusArr.getJSONObject(0);
																	if(accountResStatusObj.has("type")) {
																			accountResStatusType=accountResStatusObj.getString("type");
																			if(accountResStatusType.equalsIgnoreCase("lineStatus")) {
																				if(accountResStatusObj.has("value")) {
																					accountResStatusValue=accountResStatusObj.getString("value");
																					System.out.println("accountResStatusValue constructFinalResponse::"+ accountResStatusValue);
																				}
																			}																
																	}
																}
																if(accountResSubOrderObj.has("prospectDeviceId")) {
																	accountResProspectDeviceIdArr=accountResSubOrderObj.getJSONArray("prospectDeviceId");
																	for(int a=0;a<accountResProspectDeviceIdArr.length();a++) {
																		accountResProspectDeviceIdObj=accountResProspectDeviceIdArr.getJSONObject(a);
																		if(accountResProspectDeviceIdObj.has("type")) {
																			accountResDeviceIdType=accountResProspectDeviceIdObj.getString("type");
																			if(accountResDeviceIdType.equalsIgnoreCase("deviceType")) {
																				if(accountResProspectDeviceIdObj.has("value")) {
																					accountResDeviceIdValue=accountResProspectDeviceIdObj.getString("value");
																					System.out.println("accountResDeviceIdValue constructFinalResponse::"+ accountResDeviceIdValue);
																				}
																			}
																		}
																	}
																}
															}
														}
														//externalServiceClient.getResponseFromClien(requestJsonObject.toString(), responseId, responseId, "Retrieve-Device-Details", "RetrieveAccountWF");													
												}												
											}											
										}										
									}
									if (imeiCount == 0) {
										smartWatchIMEIStatus = "Active";
										System.out.println("smartWatchIMEIStatus::::" + imeiCount);
									} else {
										smartWatchIMEIStatus = "Prospect";
									}					
								}								
							} 
							if (jsonObj1.has("mdn")) {
								imeiMdnArr = jsonObj1.getJSONArray("mdn");
								for(int m=0;m<imeiMdnArr.length();m++) {
									imeiMdnObject = imeiMdnArr.getJSONObject(m);
									if (imeiMdnObject.has("type")) {
										imeiMdnType = imeiMdnObject.getString("type");
										System.out.println("imeiMdnType >>::" + imeiMdnType);
										if (imeiMdnType.equalsIgnoreCase("hostMDN")) {
											if (imeiMdnObject.has("value")) {
												imeiMdnValue = imeiMdnObject.getString("value");
												System.out.println("imeiMdnValue >>::" + imeiMdnValue);
											}
										}
									}
								}								
							}
						}
						if (requestJsonObject2.has("message")) {
							String getdescription = "";
							String getresponseCode= "";
							JSONArray messageObj = requestJsonObject2.getJSONArray("message");
							JSONObject messageObject = messageObj.getJSONObject(0);
							if (messageObject.has("responseCode")) {
								getresponseCode = messageObject.getString("responseCode");
							}
							if (messageObject.has("description")) {
								getdescription = messageObject.getString("description");
							}
							if(getresponseCode != null && getresponseCode.contains("E")) {
								//requestJson="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"accountNumber\":\""+accountNumber+"\",\"contextId\":\""+contextId+"\"}}";
								requestJson="{\"data\":{\"subOrder\":[{\"cableStatusRequired\":true,\"accountNumber\":\""+accountNumber+"\"}],\"transactionTimeStamp\":\""+transactionTimeStamp+"\",\"transactionType\":\""+transactionType+"\",\"contextId\":\""+contextId+"\"},\"messageHeader\":{\"referenceNumber\":\""+refNo+"\",\"requestType\":\"MNO\",\"serviceId\":\""+serviceId+"\"}}";
								requestJson = "json=" + requestJson + "&serviceName=" + serviceName + "&operationName=" + operationName + "&transId=" +responseId +"&responseId=" + responseId;
								System.out.println("requestJson callRestAPI in constructFinalResponse::" + requestJson);
								System.out.println("url url url>>>::" + url);
								response=utilityClass.callRestAPI(requestJson, url);
								System.out.println("response callRestAPI in constructFinalResponse response::" + response);
								accountNumberResponse=new JSONObject(response);
								if(accountNumberResponse.has("data")) {
									accountNumberResponse=accountNumberResponse.getJSONObject("data");
									if(accountNumberResponse.has("subOrder")) {
										accountResSubOrderArr=accountNumberResponse.getJSONArray("subOrder");
										accountResSubOrderObj=accountResSubOrderArr.getJSONObject(0);
										if (accountResSubOrderObj.has("deviceId")) {
											deviceidSubOrderArr = accountResSubOrderObj.getJSONArray("deviceId");
											//deviceidSubOrderObj = deviceidSubOrderArr.getJSONObject(0);
											for (int k = 0; k < deviceidSubOrderArr.length(); k++) {
												deviceIdstatusObject = deviceidSubOrderArr.getJSONObject(k);
												if (deviceIdstatusObject.has("type")) {
													devicetypSubOrder = deviceIdstatusObject.getString("type");
													if (devicetypSubOrder.equalsIgnoreCase("equipmentType")) {
														if (deviceIdstatusObject.has("value")) {
															equipmentTypeValue = deviceIdstatusObject.getString("value");
															if(equipmentTypeValue.equalsIgnoreCase("SMART_WATCH")) {
																lineDetailsObject3=accountResSubOrderObj;
																lineDetailsArray.put(lineDetailsObject3);
																equipmentTypeValueStatus = equipmentTypeValue;																
																System.out.println("lineCount equipmentTypeValueStatus::"
																		+ equipmentTypeValueStatus);
																break;
															}
														}
													}
												}
											}
										}
										if(accountResSubOrderObj.has("status")) {
											accountResStatusArr=accountResSubOrderObj.getJSONArray("status");
											accountResStatusObj=accountResStatusArr.getJSONObject(0);
											if(accountResStatusObj.has("type")) {
													accountResStatusType=accountResStatusObj.getString("type");
													if(accountResStatusType.equalsIgnoreCase("lineStatus")) {
														if(accountResStatusObj.has("value")) {
															accountResStatusValue=accountResStatusObj.getString("value");
															System.out.println("accountResStatusValue constructFinalResponse::"+ accountResStatusValue);
														}
													}																
											}
										}
										if(accountResSubOrderObj.has("prospectDeviceId")) {
											accountResProspectDeviceIdArr=accountResSubOrderObj.getJSONArray("prospectDeviceId");
											for(int a=0;a<accountResProspectDeviceIdArr.length();a++) {
												accountResProspectDeviceIdObj=accountResProspectDeviceIdArr.getJSONObject(a);
												if(accountResProspectDeviceIdObj.has("type")) {
													accountResDeviceIdType=accountResProspectDeviceIdObj.getString("type");
													if(accountResDeviceIdType.equalsIgnoreCase("deviceType")) {
														if(accountResProspectDeviceIdObj.has("value")) {
															accountResDeviceIdValue=accountResProspectDeviceIdObj.getString("value");
															System.out.println("accountResDeviceIdValue constructFinalResponse::"+ accountResDeviceIdValue);
														}
													}
												}
											}
										}
									}
								}
								//externalServiceClient.getResponseFromClien(requestJsonObject.toString(), responseId, responseId, "Retrieve-Device-Details", "RetrieveAccountWF");													
						}
						}
					}
					
					//EligibilityChecks
					//a. Host line status check
					System.out.println("EligibilityChecks Host line status check::"+ hostLineStatus);
					if(hostLineStatus.equalsIgnoreCase("Active")) {
						hostLineStatusCheck="success";
					}else {
						hostLineStatusCheck="failure";					
					}
					if(!hostLineStatusCheck.equalsIgnoreCase("success")) {
						frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS001\",\"description\":\"Host device not active\"}]}}";
						return frameworkResponse;
					}
					//b AcountNumber check
					if(!accountNumber.equalsIgnoreCase("") && !imeiaccountNumber.equalsIgnoreCase("")) {
						if(!accountNumber.equalsIgnoreCase(imeiaccountNumber)) {
							frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS006\",\"description\":\"Watch and Phone account number do not match\"}]}}";
							return frameworkResponse;
						}
					}
					
					//c. Smartwatch line status check 
					System.out.println("EligibilityChecks Smartwatch line status check::"+ smartWatchLineStatus);
					if(!smartWatchLineStatus.isEmpty()) {
					if(smartWatchLineStatus.equalsIgnoreCase("Active") || smartWatchLineStatus.equalsIgnoreCase("Prospect")) {
						smartWatchLineStatusCheck="success";
					}else {
						smartWatchLineStatusCheck="failure";
					}
					if(hostLineStatusCheck.equalsIgnoreCase("success") && !smartWatchLineStatusCheck.equalsIgnoreCase("success")) {
						frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS003\",\"description\":\"Smartwatch line is not active\"}]}}";
						return frameworkResponse;
					}
					}else {
						//d.Equipment from account call
						if(!equipmentTypeValueStatus.isEmpty() || !equipmentTypeValueStatusforiccid.isEmpty()) {
							warrantyExchange=true;
						}else {
							frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS002\",\"description\":\"BYOD watch\"}]}}";
							return frameworkResponse;
						}
					}
			
					//e. Max line exceeded check  
					System.out.println("EligibilityChecks Max line exceeded check::"+ lineCount+" smartWatchLineStatus::"+smartWatchLineStatus);
					if(lineCount>=5 && smartWatchLineStatus.equalsIgnoreCase("Prospect")) {
						lineCountCheck="failure";
					}else if (lineCount>=5){
						lineCountCheck="failure";
					}else{
						lineCountCheck="success";
					}
					if(hostLineStatusCheck.equalsIgnoreCase("success") && smartWatchLineStatusCheck.equalsIgnoreCase("success") && !lineCountCheck.equalsIgnoreCase("success")) {
						frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS004\",\"description\":\"Max line exceeded\"}]}}";
						return frameworkResponse;
					}
					
					//f. New Activation 
					System.out.println("EligibilityChecks New Activation ::"+ lineCount+" smartWatchLineStatus::"+smartWatchLineStatus+" smartWatchIMEIStatus::"+smartWatchIMEIStatus);
					if(iccidCount<5 && smartWatchLineStatus.equalsIgnoreCase("Prospect") && hostLineStatus.equalsIgnoreCase("Active")) {
						newActivation=true;
					}
					
					//g. Change ESIM (EACS and Replacement Device)
					//h. Manage Smartwatch
					System.out.println("EligibilityChecks EACS ::"+ smartWatchLineStatus+" smartWatchIMEIStatus::"+smartWatchIMEIStatus+" imeiMdnValue::"+imeiMdnValue+" iccidMdnValue::"+iccidMdnValue);
					System.out.println("EligibilityChecks Manage Smartwatch ::"+ smartWatchLineStatus+" smartWatchIMEIStatus::"+smartWatchIMEIStatus+" imeiMdnValue::"+imeiMdnValue+" iccidMdnValue::"+iccidMdnValue);
					if(smartWatchLineStatus.equalsIgnoreCase("Active") && hostLineStatus.equalsIgnoreCase("Active") && imeiMdnValue.equalsIgnoreCase(iccidMdnValue) && RequestIMEIVal.equalsIgnoreCase(deviceValue)) {
						eacs=true;
						manageWatch=true;
					}
					if(smartWatchLineStatus.equalsIgnoreCase("Active") && hostLineStatus.equalsIgnoreCase("Active") && imeiMdnValue.equalsIgnoreCase(iccidMdnValue) && !RequestIMEIVal.equalsIgnoreCase(deviceValue)) {
						changeDevice=true;
					}
					System.out.println("EligibilityChecks changeDevice ::"+ smartWatchLineStatus+" smartWatchIMEIStatus::"+smartWatchIMEIStatus+" imeiMdnValue::"+imeiMdnValue+" iccidMdnValue::"+iccidMdnValue+"RequestIMEIVal::"+RequestIMEIVal+"deviceValue::"+deviceValue);
					
					//i. Transfer Host
					System.out.println("EligibilityChecks Transfer Host ::"+ smartWatchLineStatus+" smartWatchIMEIStatus::"+smartWatchIMEIStatus+" imeiMdnValue::"+imeiMdnValue+" iccidMdnValue::"+iccidMdnValue);
					if(smartWatchLineStatus.equalsIgnoreCase("Active") && hostLineStatus.equalsIgnoreCase("Active") && !imeiMdnValue.equalsIgnoreCase(iccidMdnValue)) {
						transferWatch=true;
					}
					
					
					System.out.println("EligibilityChecks iccidLineWearablestatusValue::"+ iccidLineWearablestatusValue+" accountResStatusValue::"+accountResStatusValue+" accountResDeviceIdValue::"+accountResDeviceIdValue);
					if((iccidLineWearablestatusValue.equalsIgnoreCase("Active")) || (accountResStatusValue.equalsIgnoreCase("Prospect") && accountResDeviceIdValue.equalsIgnoreCase("smartwatch"))) {
						conditionCheck="success";
					}				
					if(!hostLineStatusCheck.equalsIgnoreCase("success") && !smartWatchLineStatusCheck.equalsIgnoreCase("success") && !lineCountCheck.equalsIgnoreCase("success")){
						frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS005\",\"description\":\"Generic Eligibility Error\"}]}}";
						return frameworkResponse;
					}else if(deviceIdValue.equalsIgnoreCase("IMEI Not Found") && !conditionCheck.equalsIgnoreCase("success")){					
					frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"400\",\"reason\":\"Bad Request\",\"message\":[{\"responseCode\":\"ERWS002\",\"description\":\"BYOD watch\"}]}}";
						return frameworkResponse;
					}else {
						frameworkResponse="{\"messageHeader\":{\"serviceId\":\""+serviceId+"\",\"requestType\":\"MNO\",\"referenceNumber\":\""+refNo+"\"},\"data\":{\"transactionId\":\""+responseId+"\",\"code\":\"200\",\"reason\":\"OK\",\"message\":{\"eligibilityDetails\":{\"newActivation\":\""+newActivation+"\",\"eacs\":\""+eacs+"\",\"changeDevice\":\""+changeDevice+"\",\"transferWatch\":\""+transferWatch+"\",\"manageWatch\":\""+manageWatch+"\",\"warrantyExchange\":\""+warrantyExchange+"\"},\"account\":"+accountObj.toString()+",\"lineDetails\":"+lineDetailsArray.toString()+"}}}";
					}
				} catch (JSONException e) {
					LOGGER.error(e.getMessage(), e);
					
				}
			}
			/*if (res2 != null && res2.size() > 0) {
				for (int i = 0; i < res2.size(); i++) {
					responseMsg=(String)res2.get(i).get("RESPONSE_MSG");
					//dataMap.put("response"+i, responseMsg);
				}
			}*/
		}
		System.out.println("frameworkResponse constructFinalResponse::" + frameworkResponse);
		return frameworkResponse;
	}
	
	public String getTransactionType(String refNo) {
		String transactionId="";
		String status="";
		try{
		transactionId= centuryCIFTemplate.queryForObject(Constants.RETRIEVE_TRANSACTIONID, new Object[] { refNo }, String.class);
		
		int transactionTypeCount = centuryCIFTemplate.queryForObject(Constants.GET_TRANSACTIONTYPE_COUNT, new Object[] { transactionId }, Integer.class);
		
		if(transactionTypeCount==0){
			status="success";
		}else{
			status="failure";
		}
		return status;
		}catch(Exception e){
			
		}return status;
	}
	
	public int getRetailPlanCodeCount(String mdn) {
		int  RetailplanCodeCount= 0;
		   RetailplanCodeCount=(int)centuryCIFTemplate.queryForObject(Constants.COUNT_RETAIL_PLANCODE, new Object[] { mdn}, Integer.class);

		return RetailplanCodeCount;
	}	
	
	public List<Map<String, Object>> getLineInquiryDetailsFromMdn(String mdn) {
		List<Map<String, Object>> result = (List<Map<String, Object>>) centuryCIFTemplate
				.queryForList(Constants.GET_LINE_INQUIRY_DETAILS_MDN, new Object[] { mdn });

		return result;
	}

	public  int getHostMdnCount(String mdn) {
		Integer count = centuryCIFTemplate.queryForObject(Constants.GET_HOSTMDN_COUNT, new Object[] { mdn }, Integer.class);
		return count;
	}
	
	public String getTransactionNameFromCSR(String referenceNumber) {
		String transactionName = centuryCIFTemplate.queryForObject(Constants.GET_TRANSACTION_NAME,
				new Object[] { referenceNumber }, String.class);
		return transactionName;
	}
	
	public String getAccountNumberFromCSR(String referenceNumber) {
		String accountNumber = centuryCIFTemplate.queryForObject(Constants.GET_ACCOUNT_NUMBER,
				new Object[] { referenceNumber }, String.class);
		return accountNumber;
	}
	public String getContextIdFromCSR(String referenceNumber) {
		String contextId = centuryCIFTemplate.queryForObject(Constants.GET_CONTEXT_ID,
				new Object[] { referenceNumber }, String.class);
		return contextId;
	}
	public String getAccountTypeFromCSR(String referenceNumber) {
		String accountType = centuryCIFTemplate.queryForObject(Constants.GET_ACCOUNT_TYPE,
				new Object[] { referenceNumber }, String.class);
		return accountType;
	}
	public String getBillCycleDayFromCSR(String referenceNumber) {
		String billCycleDay = centuryCIFTemplate.queryForObject(Constants.GET_BILL_CYCLE_DAY,
				new Object[] { referenceNumber }, String.class);
		return billCycleDay;
	}
	public String subOrderIdFromCSR(String referenceNumber) {
		String subOrderId = centuryCIFTemplate.queryForObject(Constants.GET_SUBORDER_ID,
				new Object[] { referenceNumber }, String.class);
		return subOrderId;
	}
	public String lineIdFromCSR(String referenceNumber) {
		String lineId = centuryCIFTemplate.queryForObject(Constants.GET_LINE_ID,
				new Object[] { referenceNumber }, String.class);
		return lineId;
	}

	public List getMdnValues(String mdn) {
		List<Map<String, Object>> res1 = null;
		String mdnValues = null;
		ArrayList value = new ArrayList();

		res1 = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_MDN_VALUES,
				new Object[] { mdn,mdn });
		for (int i = 0; i < res1.size(); i++) {
			mdnValues = (String) res1.get(i).get("MDN");
			value.add(mdnValues);
		}
		return value;
	}
	public String updateHostMDN(String hostMDN, String mdn) {

		LOGGER.info("After Calling UpdateHostMDN " + " :: MDN = " + mdn + " :: hostMDN = " + hostMDN);	
		String transId = null;
		String json = null;
		JSONObject inputJsonObj = null;
		int transactionIdCount = 0;
		String rel_id = "";
		int rootIdCount = 0;
		String rootId="";
		try {
			MapSqlParameterSource input = new MapSqlParameterSource();
			
			input.addValue("MDN", mdn);
			input.addValue("HOSTMDN", hostMDN);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.UPDATE_HOSTMDN, input);
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return transId;
	}	
	
	public String getHOSTMDN(String refNo) {
		
		String mdn = centuryCIFTemplate.queryForObject(Constants.GET_HOST_MDN, new Object[] { refNo } ,String.class);
		
		return mdn;
	}
	
	public List<Map<String, Object>> gethostmdnTransId(String mdn) {
		
		List<Map<String, Object>> hostmdn_transid =(List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_HOSTMDN_TRANS_ID, new Object[] { mdn });
		
		return hostmdn_transid;
	}
		
	public String getmdnFromResponse(String transactionId) {
		
		String mdn = centuryCIFTemplate.queryForObject(Constants.GET_MDN_FROM_RESPONSETABLE, new Object[] { transactionId } ,String.class);
		
		return mdn;
	}
	
	public  List<Map<String, Object>> gethostmdnDetails(String hostmdn ) {
		
		 List<Map<String, Object>> hostmdnDetails= (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GET_HOSTMDN_DETAILS, new Object[] { hostmdn });
		
		return hostmdnDetails;
	}
	public String getWholesalePlancode(String transactionId) {
		
		String mdn = centuryCIFTemplate.queryForObject(Constants.GET_WHOLESALE_FROM_RESPONSETABLE, new Object[] { transactionId } ,String.class);
		
		return mdn;
	}
	public int getTransidCountFromResponse(String transactionId) {
		
		int count = (int)centuryCIFTemplate.queryForObject(Constants.COUNT_TRANSACTIONID_RESPONSETABLE, new Object[] { transactionId } ,Integer.class);
		
		return count;
	}
	
	public void  updateRootID(String transactionId,String rootTransId) {
		
		MapSqlParameterSource input = new MapSqlParameterSource();
			
				input.addValue("ROOT_TRANSACTION_ID", rootTransId);
				input.addValue("REL_TRANSACTION_ID", rootTransId);
				input.addValue("TRANSACTION_ID", transactionId);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.UPDATE_ROOT_ID, input);
	}
	
	public List<Map<String, Object>> getAdditionalValues(String referenceNumber) {

		List<Map<String, Object>> additionalvalues = (List<Map<String, Object>>) centuryCIFTemplate
		.queryForList(Constants.GET_ADDITIONAL_DETAILS, new Object[] { referenceNumber });

		return additionalvalues;
		}
	
	public Integer getMdnCounts(String mdn) {
		Integer count = centuryCIFTemplate.queryForObject(Constants.GET_MDN_COUNTS, new Object[] { mdn }, Integer.class);
		return count;
	}
	
	public String getHostMdnValue(String mdn) {
		String transId = centuryCIFTemplate.queryForObject(Constants.GET_HOST_MDN_VALUE, new Object[] { mdn },
				String.class);
		return transId;
	}
	
	public String getMdnTransId(String hostMdn, String status) {
		String transId = centuryCIFTemplate.queryForObject(Constants.GET_MDN_TRANS_IDS, new Object[] { hostMdn, status },
				String.class);
		return transId;
	}
	
	public Integer getMdnStatusCount(String mdn) {
		Integer count = centuryCIFTemplate.queryForObject(Constants.GET_MDN_STATUS_COUNTS, new Object[] { mdn }, Integer.class);
		return count;
	}
	
	public String insertAccountDetails(String request) {
		LOGGER.info("request inside insertAccountDetails::::" + request);
		JSONObject obj = new JSONObject();
		JSONObject subOrderObj = new JSONObject();
		JSONObject addAttrObj = null;
		RequestBean bean = null;
		String requests = null;
		String mdnAttrType = "";
		String mdnAttrValue = "";
		String  acct_id ="";
		try {
			boolean requestflag=isValidJson(request);
			if(requestflag)
			{
			if (request.startsWith("[")) {
				LOGGER.info("request in json::" + request);
				request = jsonFormatter(request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("{")) {
				LOGGER.info("request in json object::" + request);
				addAttrObj = new JSONObject(request);
				LOGGER.info("request in addAttrObj object::" + addAttrObj);
				if (addAttrObj.has("data")) {
					addAttrObj = addAttrObj.getJSONObject("data");
					if(addAttrObj.has("subOrder")){
						subOrderObj = addAttrObj.getJSONArray("subOrder").getJSONObject(0);
						System.out.println("subOrder array:::: "+subOrderObj);
						if (subOrderObj.has("mdn")) {
							JSONObject mdnArrObj = subOrderObj.getJSONArray("mdn").getJSONObject(0);
							if (mdnArrObj.has("type")) {
								mdnAttrType = mdnArrObj.getString("type");
								System.out.println("hostMDN type:::: "+mdnAttrType);
							}
							if (mdnArrObj.has("value")) {
								mdnAttrValue = mdnArrObj.getString("value");
								System.out.println("hostMDN value:::: "+mdnAttrValue);
							}
						}
						
					}
				}
				LOGGER.info("request in before formatting::" + request);
				request = jsonFormatter(request);
				LOGGER.info("request in after formatting::" + request);
				JSONArray jsonArray = new JSONArray(request);
				obj = jsonArray.getJSONObject(0);
				String str = obj.toString();
				Gson gson = new Gson();
				bean = gson.fromJson(str, RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			} else if (request.startsWith("<")) {
				LOGGER.info("request in xml::" + request);
				requests = XML.toJSONObject(request).toString();
				LOGGER.info("request in xml format::" + requests);
				requests = jsonFormatter(requests);
				LOGGER.info("request after formatting::" + requests);
				JSONArray jsonArrayInner = new JSONArray(requests);
				obj = jsonArrayInner.getJSONObject(0);
				LOGGER.info("request xml in json object::" + obj.toString());
				Gson gson = new Gson();
				bean = gson.fromJson(obj.toString(), RequestBean.class);
				LOGGER.info("Bean::::" + bean.toString());
			}
			
			}
		   // acct_id =centuryCIFTemplate.queryForObject(Constants.GETACCOUNTID, String.class);
			if(bean!=null) {
			MapSqlParameterSource input = new MapSqlParameterSource();
			
			if (bean.getAccountNumber() != null) {
				input.addValue("ACCOUNT_NUMBER", bean.getAccountNumber());
			} else {
				input.addValue("ACCOUNT_NUMBER", null);
			}
			if (bean.getContextId() != null) {
				input.addValue("CONTEXT_ID", bean.getContextId());
			} else {
				input.addValue("CONTEXT_ID", null);
			}if (bean.getSubscriberGroupCd() != null) {
				input.addValue("SUBGROUPCD", bean.getSubscriberGroupCd());
			} else {
				input.addValue("SUBGROUPCD", null);
			}
			if (bean.getType() != null) {
				input.addValue("ACCT_TYPE", bean.getType());
			} else {
				input.addValue("ACCT_TYPE", null);
			}
			if(bean.getPin()!=null)
			{
				input.addValue("PIN", bean.getPin());
			} else {
				input.addValue("PIN", null);
			}
			input.addValue("ACC_STATUS", "PROSPECT");
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryNBOPTemplate.getDataSource());
			LOGGER.info("Inside insertMNORequestDetails Input :: IF "+ input.toString());
			//System.out.println("AcctountId::::::"+acct_id);

			namedJdbcTemplate.update(Constants.INSERT_ACCOUNT, input);
/*			namedJdbcTemplate.update(Constants.INSERT_LINE_DETAILS, input);
			namedJdbcTemplate.update(Constants.INSERT_DEVICE_DETAILS, input);
			namedJdbcTemplate.update(Constants.INSERT_SIM_DETAILS, input);
			namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_ASSOC, input);*/
			}

		} catch (JSONException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e1) {
			LOGGER.error(e1.getMessage(), e1);
		}
		return acct_id;

	}
	
	public int getAccountNumberCount(String accountNumber) {
        int count=0;
		count=centuryNBOPTemplate.queryForObject(Constants.GET_ACCOUNT_NUMBER_COUNTS, new Object[] { accountNumber }, Integer.class);
		return count;
	}
	
	public int getLineIdCount(String lineId,String mdn,String accountNumber) {
        int count=0;
		count= centuryNBOPTemplate.queryForObject(Constants.GET_LINE_ID_COUNTS, new Object[] { lineId,mdn,accountNumber }, Integer.class);
		return count;
	}
	
	public int getLineIdDuplicateCount(String lineId) {
        int count=0;
		count= centuryNBOPTemplate.queryForObject(Constants.GET_LINE_ID_DUP_COUNTS, new Object[] { lineId}, Integer.class);
		return count;
	}
		
	public void insertBatchSchedulerTransaction(JSONObject data,
			RequestBean requestBean) {

		try {
			JSONObject newObj = new JSONObject();
			String transactionType = "";
			String syncTransaction = "";
			String executionTimeStamp = "";
			String agentId = "";
			String channelId = "";
			String mdn = "";
			String batchId = "";
			JSONArray suborderArr = new JSONArray();
			JSONArray mdnArr = new JSONArray();
			JSONObject mdnObj = new JSONObject();
			Timestamp transactionTs = null;

			if (data.has("transactionType")) {
				transactionType = data.getString("transactionType");
			}
			if (data.has("syncTransaction")) {
				syncTransaction = data.getString("syncTransaction");
			}
			if (data.has("executionTimeStamp")) {
				executionTimeStamp = data.getString("executionTimeStamp");
				if (executionTimeStamp != null
						&& (executionTimeStamp.contains("Z") || executionTimeStamp.contains("z"))) {
					try {
						Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(executionTimeStamp)).getTime();
						transactionTs = new Timestamp(date.getTime());
					} catch (Exception e) {
						transactionTs = null;
					}
				}
			}
			if (data.has("agentId")) {
				agentId = data.getString("agentId");
			}
			MapSqlParameterSource inputValue = new MapSqlParameterSource();
			if (transactionTs != null) {
				inputValue.addValue("Exc_TimeStamp", transactionTs);
			} else {
				inputValue.addValue("Exc_TimeStamp", null);
			}
			inputValue.addValue("TRANSACTION_ID", null);
			inputValue.addValue("Ext_Batch_ID", requestBean.getBatchId());
			inputValue.addValue("MDN", requestBean.getMdn());
			inputValue.addValue("Batch_Type", transactionType);
			inputValue.addValue("Reference_Number", requestBean.getReferenceNumber());
			inputValue.addValue("Sync", syncTransaction);
			inputValue.addValue("Channel_ID", channelId);
			inputValue.addValue("Service_Type", "JSON");
			inputValue.addValue("Created_By", agentId);
            inputValue.addValue("scheduled_status","PENDING");
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());

			namedJdbcTemplate.update(Constants.RH_BATCH_SCHEDULER_TRANSACTION, inputValue);
		} catch (Exception e) {

			LOGGER.error("Exception in handle method" + e.getMessage());
		}
	}
    public String getMDNStatus(String mdn) {
		String mdnschedulerstatus = centuryCIFTemplate.queryForObject(Constants.GET_MDN_SCHEDULER_STATUS, new Object[] { mdn } ,String.class);
		return mdnschedulerstatus;
	}
    
    public String getMdnTransCount(String mdn) {
		String transcount = (String) centuryCIFTemplate.queryForObject(Constants.GET_MDN_TRANS_COUNT, new Object[] { mdn }, String.class);
		return transcount;
	}
	
	public void insertMNODomainDetails(RequestBean asyncResponseBean){
		LOGGER.info("request inside insertMNODomainDetails::::"+asyncResponseBean.toString());
		String transId="";
		String transactionName="";
		String inboundRequest="";
		String deviceDetails="";
		int deviceCount = 0;
		String lineId="";
		String accountId="";
		String verifyAccount="";
		String verifyLine="";
		String formattedrequest = "";
		RequestBean obRequestBean = null;
		RequestBean secondObReqBean = null;
		RequestBean ibRequestBean = null;
		RequestBean deviceDetailsBean = null;
		JSONObject requestobj=new JSONObject();
		JSONArray featureArray = new JSONArray();
		JSONObject featureObj=new JSONObject();
		Map<String,String> featMap = new HashMap<String,String>();
 		List<Map<String, Object>> outboundRequest= null;
 		String action="";
 		
 		try {
		if(asyncResponseBean!=null && asyncResponseBean.getReferenceNumber()!=null){
			transId = centuryCIFTemplate.queryForObject(Constants.GETNBTRANSID,
				new Object[] { asyncResponseBean.getReferenceNumber()},String.class);
			outboundRequest = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.GETOBREQUEST,
				new Object[] { transId});
			LOGGER.info("outboundRequest:::"+outboundRequest);
			int counter=0;
			if(outboundRequest.size()>0){
					for (int i = 0; i < outboundRequest.size(); i++) {
						LOGGER.info("formattedrequest:: " + outboundRequest.get(i).toString());
						
						for (Map<String, Object> map : outboundRequest) {
							LOGGER.info("formattedrequest map:: " + map.get("TRANSACTION_NAME"));
							if (!(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("AsyncService")) && !(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("GateWayService"))) {
								transactionName = map.get("TRANSACTION_NAME").toString();
								if (map.get("REQUEST_MSG").toString().startsWith("[")
										|| map.get("REQUEST_MSG").toString().startsWith("{")) {
									counter++;
									formattedrequest = jsonFormatter(map.get("REQUEST_MSG").toString());
									JSONArray jsonArrayInner = new JSONArray(formattedrequest);
									LOGGER.info("map1111:: " + jsonArrayInner);
									requestobj = jsonArrayInner.getJSONObject(0);
									Gson gson = new Gson();
									if(counter==1){
										LOGGER.info("Inside else if :: ");
										obRequestBean = gson.fromJson(requestobj.toString(), RequestBean.class);	
									} else {
										LOGGER.info("Inside if obRequestBean:: ");
										secondObReqBean = gson.fromJson(requestobj.toString(), RequestBean.class);
										LOGGER.info("Inside if secondObReqBean:: " + secondObReqBean.toString());
									}
									LOGGER.info("requestobj:: " + requestobj.toString());
									LOGGER.info("request after bean conversion in insertMNODomainDetails111::::"
											+ obRequestBean.toString()+"\n---------------"+asyncResponseBean.toString());
								}
							}
							if(map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Activate Subscriber")||
									map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Activate Subscriber Port-In")||
									map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Change Feature")||
									map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Change Rate Plan")||
									map.get("TRANSACTION_NAME").toString().equalsIgnoreCase("Device Detection Change Rate Plan")) {
								if (map.get("REQUEST_MSG").toString() != "") {
									if (map.get("REQUEST_MSG").toString().startsWith("{")) {
										JSONObject newObj = new JSONObject(map.get("REQUEST_MSG").toString());
										newObj = newObj.getJSONObject("data");
										if (newObj.has("feature") && newObj.getJSONArray("feature").length() != 0) {
											featureArray = newObj.getJSONArray("feature");
										}
										if (newObj.has("newRatePlan")) {
											JSONObject newRatePlanObj=new JSONObject();
											newRatePlanObj=newObj.getJSONObject("newRatePlan");
											if(newRatePlanObj.has("planCode")) {
												String newWholeSaleplanCode=newRatePlanObj.getString("planCode");
												obRequestBean.setnewRatePlan(newWholeSaleplanCode);
												LOGGER.info("obj new rate whole sale plan Code:::" + newWholeSaleplanCode);
											}
											
										}	
										if(newObj.has("oldRatePlan")) {
											JSONObject oldRatePlanObj=new JSONObject();
											oldRatePlanObj=newObj.getJSONObject("oldRatePlan");
											if(oldRatePlanObj.has("planCode")) {
												String oldWholeSaleplanCode=oldRatePlanObj.getString("planCode");
												obRequestBean.setOldRatePlan(oldWholeSaleplanCode);
												LOGGER.info("obj old rate whole sale plan Code:::" + oldWholeSaleplanCode);
											}
										}
											
										
									} else {
										if (map.get("REQUEST_MSG").toString().startsWith("[")) {
											JSONArray requestArray = new JSONArray(map.get("REQUEST_MSG").toString());
											JSONObject obj = new JSONObject();
											obj = requestArray.getJSONObject(0);
											if (obj.has("resellerOrder")) {
												obj = obj.getJSONObject("resellerOrder");
												obj = obj.getJSONObject("data");
												if (obj.has("feature") && obj.getJSONArray("feature").length() != 0) {
													featureArray = obj.getJSONArray("feature");
												}
											} else if (obj.has("MNOChangeRatePlan")) {
												obj = obj.getJSONObject("MNOChangeRatePlan");
												obj = obj.getJSONObject("data");
												LOGGER.info("obj:::" + obj.toString());
												if(obj.has("oldRatePlan")) {
													JSONObject oldRatePlanObj=new JSONObject();
													oldRatePlanObj=obj.getJSONObject("oldRatePlan");
													if(oldRatePlanObj.has("planCode")) {
														String oldWholeSaleplanCode=oldRatePlanObj.getString("planCode");
														obRequestBean.setOldRatePlan(oldWholeSaleplanCode);
														LOGGER.info("obj old rate whole sale plan Code:::" + oldWholeSaleplanCode);
													}
												}
												if (obj.has("feature") && obj.getJSONArray("feature").length() != 0) {
													featureArray = obj.getJSONArray("feature");
												} 
												else if (obj.has("newRatePlan")) {
													obj = obj.getJSONObject("newRatePlan");
													if (obj.has("feature") && obj.getJSONArray("feature").length() != 0) {
														featureArray = obj.getJSONArray("feature");
														LOGGER.info("obj new rate plan:::" + featureArray.toString());
													}
													if(obj.has("planCode")) {
														String newWholeSaleplanCode=obj.getString("planCode");
														obRequestBean.setnewRatePlan(newWholeSaleplanCode);
														LOGGER.info("obj new rate whole sale plan Code:::" + newWholeSaleplanCode);
													}
													
												}
											}
										}
									}
								}
							}
							if(featureArray.length()>0) {
							for (int j = 0; j < featureArray.length(); j++) {
								String featureCode="";
								String subscribe="";
								featureObj = featureArray.getJSONObject(j);
								Iterator a = featureObj.keys();
								while (a.hasNext()) {
									String keyStr = a.next().toString();
									if (keyStr.equalsIgnoreCase("subscribe")) {
										subscribe = featureObj.getString(keyStr);
										if(subscribe.equalsIgnoreCase("A")) {
											subscribe="Y";
										}else {subscribe="N";}
									}
									if (keyStr.equalsIgnoreCase("featureCode")) {
										featureCode = featureObj.getString(keyStr);
									}
									if(subscribe!="" && featureCode!="") {
										featMap.put(featureCode, subscribe);
									}
								}

							}
							}
						}
					}
				}
			inboundRequest =  centuryCIFTemplate.queryForObject(Constants.GETIBREQUEST,
					new Object[] { transId},String.class);
				LOGGER.info("inboundRequest:::"+inboundRequest);
			
			if(!"".equalsIgnoreCase(inboundRequest)){
				formattedrequest = jsonFormatter(inboundRequest);
				JSONArray jsonArrayInner = new JSONArray(formattedrequest);
				LOGGER.info("map1111:: " + jsonArrayInner);
				requestobj = jsonArrayInner.getJSONObject(0);
				Gson gson = new Gson();
				ibRequestBean = gson.fromJson(requestobj.toString(), RequestBean.class);
			}
			if(!("Deactivate Subscriber".equalsIgnoreCase(transactionName) ||
					"Suspend Subscriber".equalsIgnoreCase(transactionName) ||
					"Restore Service".equalsIgnoreCase(transactionName)||
					"Reconnect Service".equalsIgnoreCase(transactionName))){
			deviceCount = centuryCIFTemplate.queryForObject(Constants.GETDEVICEREQ_COUNT,
					new Object[] { transId,transId},Integer.class);
			if(deviceCount!=0) {
				List<Map<String, Object>> deviceDetailsMap=new ArrayList<Map<String, Object>>();
			deviceDetailsMap =  (List<Map<String, Object>>)centuryCIFTemplate.queryForList(Constants.GETDEVICEREQUEST,
					new Object[] { transId,transId});
			for(int i=0;i<deviceDetailsMap.size();i++) {
			//	if(deviceDetailsMap.get(i).get(Constants.TRANSACTION_NAME).equals(Constants.VALIDATE_DEVICE)) {
			//		deviceDetails=deviceDetailsMap.get(i).get(Constants.RESPONSE_MSG).toString();
			//		break;
				//}else if(deviceDetailsMap.get(i).get(Constants.TRANSACTION_NAME).equals(Constants.ACTIVATE_SUB)) {
				//	deviceDetails=getDeviceDetails(deviceDetailsMap.get(i).get(Constants.REQUEST_MSG).toString());
				//	break;
				//}
			}
				LOGGER.info("deviceDetails:::"+deviceDetails);
			}
			if(!"".equalsIgnoreCase(deviceDetails)){
				formattedrequest = jsonFormatter(deviceDetails);
				JSONArray jsonArrayInner = new JSONArray(formattedrequest);
				LOGGER.info("map1111:: " + jsonArrayInner);
				requestobj = jsonArrayInner.getJSONObject(0);
				Gson gson = new Gson();
				deviceDetailsBean = gson.fromJson(requestobj.toString(), RequestBean.class);
			}
			}
			}
		MapSqlParameterSource input = new MapSqlParameterSource();
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryNBOPTemplate.getDataSource());
		LOGGER.info("Inside insertMNORequestDetails Input :: IF "+ transactionName);
		if(obRequestBean!=null && asyncResponseBean!=null) {
			if (obRequestBean.getSubscriberGroupCd() != null) {
				input.addValue("SUBGROUPCD", obRequestBean.getSubscriberGroupCd());
			}else if (asyncResponseBean.getSubscriberGroupCd() != null) {
				input.addValue("SUBGROUPCD", asyncResponseBean.getSubscriberGroupCd());
			} else {
				input.addValue("SUBGROUPCD", null);
			}
		 if (ibRequestBean.getAccountNumber() != null) {
				input.addValue("ACCOUNT_NUMBER", ibRequestBean.getAccountNumber());
				accountId=ibRequestBean.getAccountNumber();
				verifyAccount = verifyAccount(accountId);
			} else {
				input.addValue("ACCOUNT_NUMBER", null);
				}
				if (ibRequestBean.getAction() != null) {
					action = ibRequestBean.getAction();
				}
			if (obRequestBean.getContextId() != null) {
				input.addValue("CONTEXT_ID", obRequestBean.getContextId());
			}else if (ibRequestBean.getContextId() != null) {
				input.addValue("CONTEXT_ID", ibRequestBean.getContextId());
			} else {
				input.addValue("CONTEXT_ID", null);
			}
			if (obRequestBean.getType() != null) {
				input.addValue("ACCT_TYPE", obRequestBean.getType());
			}else if (ibRequestBean.getType() != null) {
				input.addValue("ACCT_TYPE", ibRequestBean.getType());
			} else {
				input.addValue("ACCT_TYPE", null);
			}
			if(obRequestBean.getPin()!=null)
			{
				input.addValue("PIN", obRequestBean.getPin());
			}else if (ibRequestBean.getPin() != null) {
				input.addValue("PIN", ibRequestBean.getPin());
			} else {
				input.addValue("PIN", null);
			}
			if (obRequestBean.getImsi() != null) {
				input.addValue("IMSI", obRequestBean.getImsi());
			}else if (asyncResponseBean.getImsi() != null) {
				input.addValue("IMSI", asyncResponseBean.getImsi());
			} else {
				input.addValue("IMSI", null);
			}
			if (ibRequestBean.getReferenceNumber() != null) {
				input.addValue("REFERENCENUMBER", obRequestBean.getReferenceNumber());
			}else if (asyncResponseBean.getReferenceNumber() != null) {
				input.addValue("REFERENCENUMBER", asyncResponseBean.getReferenceNumber());
			} else {
				input.addValue("REFERENCENUMBER", null);
			}
			if (obRequestBean.getMdn() != null) {
				/*if(mdnAttrType.equals("hostMDN")){
					input.addValue("MDN", bean.getMdn());
					input.addValue("HOSTMDN", bean.getHostMdn());
				}else{*/
					input.addValue("MDN", obRequestBean.getMdn());
			//	}
			} else if (asyncResponseBean.getMdn() != null) {
				input.addValue("MDN", asyncResponseBean.getMdn());
			}else {
				input.addValue("MDN", null);
				input.addValue("HOSTMDN", null);
			}
			if (obRequestBean.getHostMdn() != null) {
				input.addValue("HOSTMDN", obRequestBean.getHostMdn());
			}else if (asyncResponseBean.getHostMdn() != null) {
				input.addValue("HOSTMDN", asyncResponseBean.getHostMdn());
			} else {
				input.addValue("HOSTMDN", null);
			}
			if (asyncResponseBean.getMin() != null) {
				input.addValue("MIN", asyncResponseBean.getMin());
			} else {
				input.addValue("MIN", null);
			}
		/*	if (obRequestBean.getLineId() != null) {
				input.addValue("LINEID", obRequestBean.getLineId());
				lineId=obRequestBean.getLineId();
				verifyLine=verifyLine(lineId);
			}else */if (ibRequestBean.getLineId() != null) {
				input.addValue("LINEID", ibRequestBean.getLineId());
				lineId=ibRequestBean.getLineId();
				verifyLine=verifyLine(lineId);
			}  else {
				input.addValue("LINEID", null);
			}
			if (obRequestBean.getBillCycleResetDay() != null) {
				input.addValue("BILLCYCLEDAY", obRequestBean.getBillCycleResetDay());
			}else if (ibRequestBean.getBillCycleResetDay() != null) {
				input.addValue("BILLCYCLEDAY", ibRequestBean.getBillCycleResetDay());
			}  else {
				input.addValue("BILLCYCLEDAY", null);
			}
			if (obRequestBean.getImei() != null) {
				input.addValue("IMEI", obRequestBean.getImei());
			}else if (asyncResponseBean.getImei() != null) {
				input.addValue("IMEI", asyncResponseBean.getImei());
			} /*else if (asyncResponseBean.getDeviceId() != null) {
				input.addValue("IMEI", deviceDetailsBean.getDeviceId());
			} */ else {
				input.addValue("IMEI", null);
			}
			if (obRequestBean.getIccid() != null) {
				input.addValue("ICCID", obRequestBean.getIccid());
			}else if (asyncResponseBean.getIccid() != null) {
				input.addValue("ICCID", asyncResponseBean.getIccid());
			}   else {
				input.addValue("ICCID", null);
			}
			if (ibRequestBean.getPlanCode() != null) {
				input.addValue("RETAIL_PLANCODE", ibRequestBean.getPlanCode());
			} else {
				input.addValue("RETAIL_PLANCODE", null);
			}
			if (obRequestBean.getPlanCode() != null) {
				input.addValue("WHOLESALE_PLAN", obRequestBean.getPlanCode());
			}  else {
				input.addValue("WHOLESALE_PLAN", null);
			}
			//Device details update
			if(deviceDetailsBean!=null) {
				if (deviceDetailsBean.getMake() != null) {
						input.addValue("MAKE", deviceDetailsBean.getMake());
					} else {
						input.addValue("MAKE", null);
					}
				if (deviceDetailsBean.getDeviceId() != null) {
					input.addValue("IMEI", deviceDetailsBean.getDeviceId());
				} else {
					input.addValue("IMEI", null);
				}
					if (deviceDetailsBean.getModel() != null) {
						input.addValue("MODEL", deviceDetailsBean.getModel());
					} else {
						input.addValue("MODEL", null);
					}
					if (deviceDetailsBean.getMode() != null) {
						input.addValue("MODE", deviceDetailsBean.getMode());
						// DEVICE_TYPE
						String deviceType = deviceDetailsBean.getMode().toString();
						input.addValue("DEVICE_TYPE", deviceType.substring(0, 2));
					} else {
						input.addValue("MODE", null);
					}
					if (deviceDetailsBean.getCdmaLess() != null) {
						input.addValue("CDMALESS", deviceDetailsBean.getCdmaLess());
					} else {
						input.addValue("CDMALESS", "N");
					}

					if (deviceDetailsBean.getDeviceCategory() != null) {
						input.addValue("DEVICE_CATEGORY", deviceDetailsBean.getDeviceCategory());
					} else {
						input.addValue("DEVICE_CATEGORY", null);
					}
					if (deviceDetailsBean.getProdType() != null) {
						input.addValue("PRODTYPE", deviceDetailsBean.getProdType());
					} else {
						input.addValue("PRODTYPE", null);
					}
		}if(secondObReqBean!=null){
			LOGGER.info("secondObReqBea## "+secondObReqBean.toString());
		}
		if(transactionName.equalsIgnoreCase("Activate Subscriber") ||
							transactionName.equalsIgnoreCase("Activate Subscriber Port-in")) {
			insertActivationRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId,verifyAccount,verifyLine,featMap);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
        if(transactionName.equalsIgnoreCase("Add Wearable"))
		{
			LOGGER.info("verifyLine......## "+verifyLine);
			insertActivationRecordsforAddWearable(input,namedJdbcTemplate,asyncResponseBean,verifyLine);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
        if(transactionName.equalsIgnoreCase("Transfer Wearable"))
		{
        	LOGGER.info("Transer Wearable");
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
        if(transactionName.equalsIgnoreCase("Cancel Port-In"))
		{
        	LOGGER.info("Cancel Port-In");
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
        
        
        if(transactionName.equalsIgnoreCase("ChangeESIM"))
		{
        	LOGGER.info("Change ESIM");
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Deactivate Subscriber")) {
			LOGGER.info("Deactivate Subscriber");
			updateDeactivationRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Suspend Subscriber")) {
			LOGGER.info("Suspend Subscriber");
			updateSuspendedRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}		
}
		if(transactionName.equalsIgnoreCase("Change BCD")) {
			LOGGER.info("Change BCD");
			updateBillCycleRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,getOldBcd(lineId),accountId,lineId);
		}
		if(transactionName.equalsIgnoreCase("Change MDN")) {
			LOGGER.info("Change MDN");
			updateChangeMdnRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Change Rate Plan")) {
			LOGGER.info("Change Rate Plan");
			updateChangeRatePlanRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId,verifyAccount,verifyLine,featMap);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}if(transactionName.equalsIgnoreCase("Device Detection Change Rate Plan")) {
			LOGGER.info("Device Detection Change Rate Plan");
			updateDDChangeRatePlanRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId,verifyAccount,verifyLine,featMap);
		}
		if(transactionName.equalsIgnoreCase("Change Feature")) {
			LOGGER.info("Change Feature");
			updateChangeFeatureRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId,verifyAccount,verifyLine,featMap);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}if(transactionName.equalsIgnoreCase("Change SIM")) {
			LOGGER.info("Change SIM");
			updateChangeSimRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,secondObReqBean);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Change Device")) {
			LOGGER.info("Change Device");
			updateChangeDeviceRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,secondObReqBean);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Hotline Subscriber")) {
			LOGGER.info("Hotline Subscriber");
			updateHotlineRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,secondObReqBean);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Change of SIM and Device")) {
			LOGGER.info("Change of SIM and Device");
			updateChangeSimAndDeviceRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,secondObReqBean,featMap, deviceDetailsBean);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		
		if(transactionName.equalsIgnoreCase("Cancel Port-In") ||
				transactionName.equalsIgnoreCase("Update Customer Information") ||
				transactionName.equalsIgnoreCase("Update Due-Date")) {
			LOGGER.info("UpdatePortIn calls");
			updatePortInRecords(transactionName, input, namedJdbcTemplate, asyncResponseBean, ibRequestBean, obRequestBean, accountId, lineId, secondObReqBean);
		
		}
		
		if(transactionName.equalsIgnoreCase("Update Port-Out")){
			LOGGER.info("UpdatePortOut");
			updatePortOutRecords(transactionName, input, namedJdbcTemplate, asyncResponseBean, ibRequestBean, obRequestBean, accountId, lineId, secondObReqBean);
		}
		
		if(transactionName.equalsIgnoreCase("managepromotion")||transactionName.equalsIgnoreCase("Manage Promotions")){
			LOGGER.info("ManagePromotions method");
			managePromotionRecords(transactionName, input, namedJdbcTemplate, asyncResponseBean, ibRequestBean, obRequestBean, accountId, lineId, secondObReqBean);
		}
		
		if(transactionName.equalsIgnoreCase("Restore Service")){
			LOGGER.info("updateRestoreServiceRecords method");
			updateRestoreServiceRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,deviceDetailsBean,accountId,lineId);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Reconnect Service")){
			LOGGER.info("Reconnect Service method");
			updateReconnectMdnRecords(transactionName, input, namedJdbcTemplate, asyncResponseBean, ibRequestBean, obRequestBean, accountId, lineId);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("MnoRemoveHotlineService") || transactionName.equalsIgnoreCase("Remove Hotline")){
			LOGGER.info("MnoRemoveHotlineService method");
			updateRemoveHotlineRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,secondObReqBean);
			if(transId != null) {
				insertIntoTransLineAssoc(inboundRequest, transId, transactionName);
			}
		}
		if(transactionName.equalsIgnoreCase("Reset Feature")){
			LOGGER.info("updateResetFeatureRecords method");
			updateResetFeatureRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId);
		}if(transactionName.equalsIgnoreCase("ManageAccount")){
			LOGGER.info("ManageAccount method");
			manageAccountRecords(transactionName, input,namedJdbcTemplate, asyncResponseBean,ibRequestBean, obRequestBean,accountId,lineId,action,transId);
		}
		
		}
	}catch(JSONException e) {
		 LOGGER.error("Exception",e);
	}
	}
	
	public Timestamp getTimeStamp() {
			Date date = new Date();
			Timestamp ts=new Timestamp(date.getTime());
			return ts;
	}
	
	public int getIdfromLineId(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETLINEIDFROMID,
				new Object[] { lineId },Integer.class);
		
 }
	public int getAccountId(String accountId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETACCID,
				new Object[] { accountId },Integer.class);
		
	}
	public String getTransactionStatus(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETTRANSACTIONSTATUS,
				new Object[] { lineId },String.class);
	}
	
	public String getOldAccountValue(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.OLDACCOUNTVALUE,
				new Object[] { lineId },String.class);
	}
	
	public int getCountTransactionStatus(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETCOUNTTRANSACTIONSTATUS,
				new Object[] { lineId },Integer.class);
	}
	
	
	public String getWHSCode(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETWHSCODE,
				new Object[] { lineId },String.class);
	}
	
	public String getRetailCode(String lineId) {
		return centuryNBOPTemplate.queryForObject(Constants.GETRETAILCODE,
				new Object[] { lineId },String.class);
	}
	
	public String getActiveLinesCount(String accountId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETACTIVELINESCOUNT, new Object[] { accountId },
				Integer.class);
		if (count == 1) {
			return "DEACTIVE";
		} else {
			return "ACTIVE";
		}
	}
	
	public String getSuspendLinesCount(String accountId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETSUSPENDLINESCOUNT, new Object[] { accountId },
				Integer.class);
		if (count == 1) {
			return "SUSPEND";
		} else {
			return "ACTIVE";
		}
	}
	
	public String getHotlineLinesCount(String accountId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETSUSPENDLINESCOUNT, new Object[] { accountId },
				Integer.class);
		if (count == 1) {
			return "HOTLINE";
		} else {
			return "ACTIVE";
		}
	}
	
	public String verifyAccount(String accountId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETACCIDCOUNT, new Object[] { accountId },
				Integer.class);
		if (count == 0) {
			return "NEW";
		} else {
			return "OLD";
		}
	}
	
	public int getOldBcd(String lineId) {
	return centuryNBOPTemplate.queryForObject(Constants.GETOLDBCD, new Object[] { lineId },
				Integer.class);
			}
	
	public Double getOldMdn(String lineId) {
	return centuryNBOPTemplate.queryForObject(Constants.GETOLDMDN, new Object[] { lineId },
				Double.class);
			}
	
	public Double getOldDeviceId(String lineId) {
	return centuryNBOPTemplate.queryForObject(Constants.GETOLDEVICEID,new Object[] { lineId },
				Double.class);
			}

	public String verifyLine(String lineId) {
		int count = centuryNBOPTemplate.queryForObject(Constants.GETLINEIDCOUNT, new Object[] { lineId },
				Integer.class);
		if (count == 0) {
			return "NEW";
		} else {
			return "OLD";
		}
	}
	
public void insertActivationRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			RequestBean deviceDetailsBean, String accountId, String lineId, String verifyAccount, String verifyLine,
			Map<String, String> featMap) {
		String lineStatus = "ACTIVE";
		String simStatus = "ACTIVATED";
		String accStatus = "ACTIVE";
		String planCode=ibRequestBean.getPlanCode();
		try {
			LOGGER.info("Inside insertActivationRecords Method");
			input.addValue("ACC_STATUS", accStatus);
			input.addValue("LINE_STATUS", lineStatus);
			if(planCode.equalsIgnoreCase("TUNLP") || planCode.equalsIgnoreCase("TUNL")||planCode.equalsIgnoreCase("TBTG")){
				input.addValue("LINETYPE", "TABLET");
			} else{
			input.addValue("LINETYPE", "PHONE");
			}
			if(input.getValue("LINETYPE").equals("TABLET") || input.getValue("LINETYPE").equals("PHONE")) {
				input.addValue("SIM_TYPE","PSIM");
			}else if(input.getValue("LINETYPE").equals("SMARTWATCH")) {
				input.addValue("SIM_TYPE","ESIM");
			}
			input.addValue("SIM_STATUS", simStatus);
			input.addValue("ACTIVATION_DATE", getTimeStamp());
			input.addValue("DEACTIVATION_DATE", null);
			input.addValue("WHOLESALE_PLAN", obRequestBean.getPlanCode());
			if (transactionName.equalsIgnoreCase("Activate Subscriber")) {
				input.addValue("TRANSACTION_TYPE", "AS");
				input.addValue("ORDER_TYPE", "ACTIVATE");
			}
			if (transactionName.equalsIgnoreCase("Activate Subscriber Port-in")) {
				input.addValue("TRANSACTION_TYPE", "SP");
				input.addValue("ORDER_TYPE", "PORT_IN");
			}
			Map<String, String> fieldTypes = new HashMap<String, String>();
			fieldTypes.put("MDN", asyncResponseBean.getMdn());
			fieldTypes.put("RETAIL_PLAN", ibRequestBean.getPlanCode());
			fieldTypes.put("WHOLESALE_PLAN", obRequestBean.getPlanCode());
			if (asyncResponseBean.getMdn() != null) {
				input.addValue("MDN", asyncResponseBean.getMdn());
			} else {
				input.addValue("MDN", null);
			}
			if (obRequestBean.getIccid() != null) {
				fieldTypes.put("ICCID", obRequestBean.getIccid());
			} else if (asyncResponseBean.getIccid() != null) {
				fieldTypes.put("ICCID", asyncResponseBean.getIccid());
			} else {
				input.addValue("ICCID", null);
			}
			if (deviceDetailsBean.getDeviceId() != null) {
				fieldTypes.put("DEVICEID", deviceDetailsBean.getDeviceId());
			} else {
				fieldTypes.put("DEVICEID", null);
			}
			input.addValue("ACCT_ID", getAccountId(accountId));
	//		if ("NEW".equalsIgnoreCase(verifyAccount)) {
				namedJdbcTemplate.update(Constants.UPDATE_ACCOUNT_AS, input);
		//	}
			
			if ("NEW".equalsIgnoreCase(verifyLine)) {
				namedJdbcTemplate.update(Constants.INSERT_LINE_DATA, input);
				input.addValue("ID", getIdfromLineId(lineId));
				namedJdbcTemplate.update(Constants.INSERT_DEVICE_DATA, input);
				namedJdbcTemplate.update(Constants.INSERT_SIM_DATA, input);
				for (Entry<String, String> feat : featMap.entrySet()) {
					input.addValue("FEATURECODES", feat.getKey());
					input.addValue("ISACTIVE", feat.getValue());
					namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					if (feat.getValue().equalsIgnoreCase("Y")) {
						input.addValue("FIELD_TYPE", "FEATURECODES");
						input.addValue("NEW_VALUE", feat.getKey());
						input.addValue("OLD_VALUE",null);
						namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
					}
				}
				for (Entry<String, String> field : fieldTypes.entrySet()) {
					input.addValue("FIELD_TYPE", field.getKey());
					input.addValue("NEW_VALUE", field.getValue());
					input.addValue("OLD_VALUE",null);
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				}
				LOGGER.info("Activate  Line Status:::");
				input.addValue("OLD_VALUE", null);
				input.addValue("NEW_VALUE", "ACTIVE");
				input.addValue("FIELD_TYPE", "LINE_STATUS");
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in insertActivationRecords:::"+e.getMessage());
		}
	}
	public void insertActivationRecordsforAddWearable(MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,String verifyLine){
		String referenceNumber=asyncResponseBean.getReferenceNumber();
		String acct_id="";
		String ACCOUNT_NUMBER="";
		String LINEID="";
		String LINE_STATUS="";
		String BILLCYCLEDAY="";
		String SUBGROUPCD="";
		String LINETYPE="";
		String hostMDN="";
		String DEVICE_TYPE="";
		List<Map<String, Object>> hostmdnlineDetails= null;
		try {
			LOGGER.info("Inside insertActivationRecords Method");
			if(referenceNumber!=null){
				hostMDN=(String)centuryCIFTemplate.queryForObject(Constants.GET_HOST_MDN, new Object[] { referenceNumber } ,String.class);
				LOGGER.info("Inside insertActivationRecords Method referenceNumber"+referenceNumber);
				if(hostMDN!=null){
					LOGGER.info("Inside insertActivationRecords Method hostMDN"+hostMDN);
					input.addValue("HOSTMDN",hostMDN);
				
			     hostmdnlineDetails = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.HOSTMDN_LINE_DETAILS,
				new Object[] { hostMDN,hostMDN});
				if (hostmdnlineDetails != null && hostmdnlineDetails.size() > 0) {
					for (int j = 0; j < hostmdnlineDetails.size(); j++) {
						BigDecimal account_ID=(BigDecimal)hostmdnlineDetails.get(j).get("ACCT_ID");
						//BigDecimal acccountNumber=(String) hostmdnlineDetails.get(j).get("ACCOUNT_NUMBER");
						//BigDecimal LINESTATUS=(BigDecimal) hostmdnlineDetails.get(j).get("LINE_STATUS");
						//BigDecimal lineid=(BigDecimal) hostmdnlineDetails.get(j).get("LINE_ID");
						//BigDecimal billcycleday=(BigDecimal) hostmdnlineDetails.get(j).get("BILLCYCLEDAY");
						acct_id= account_ID.toString();
						ACCOUNT_NUMBER =(String) hostmdnlineDetails.get(j).get("ACCOUNT_NUMBER");;
						LINEID = (String) hostmdnlineDetails.get(j).get("LINE_ID");
					    LINE_STATUS =(String) hostmdnlineDetails.get(j).get("LINE_STATUS");
						BILLCYCLEDAY = (String) hostmdnlineDetails.get(j).get("BILLCYCLEDAY");
						SUBGROUPCD = (String)hostmdnlineDetails.get(j).get("SUBGROUPCD");
						LINETYPE =(String) hostmdnlineDetails.get(j).get("LINETYPE");
						DEVICE_TYPE =(String) hostmdnlineDetails.get(j).get("FIRST_ACTIVATED_NETWORK");
					}
				}
				}
			}
			input.addValue("ACCT_ID", acct_id);
			input.addValue("ACCOUNT_NUMBER", ACCOUNT_NUMBER);
			input.addValue("LINEID", LINEID);
			input.addValue("LINE_STATUS",LINE_STATUS);
			input.addValue("BILLCYCLEDAY", BILLCYCLEDAY);
			input.addValue("SUBGROUPCD", SUBGROUPCD);
			input.addValue("LINETYPE", LINETYPE);
			input.addValue("HOSTMDN",hostMDN);
			input.addValue("REFERENCENUMBER",referenceNumber);
			input.addValue("DEVICE_TYPE",DEVICE_TYPE);
			input.addValue("ACTIVATION_DATE", getTimeStamp());
			input.addValue("DEACTIVATION_DATE", null);
			input.addValue("TRANSACTION_TYPE", "AW");
			input.addValue("ORDER_TYPE", "Add Wearable");
			namedJdbcTemplate.update(Constants.INSERT_LINE_DATA, input);
			 List<Map<String, Object>> mdnlineDetails = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.HOSTMDN_LINE_DETAILS,
				new Object[] { asyncResponseBean.getMdn(),asyncResponseBean.getMdn()});
				LOGGER.info("mdnlineDetails"+mdnlineDetails);
			if(mdnlineDetails.size()>0){
				for (int i = 0; i < mdnlineDetails.size(); i++) {
					//LOGGER.info("mdnlineDetails:: " + mdnlineDetails.get(i).get("ID"));
					BigDecimal addwearableId=(BigDecimal)mdnlineDetails.get(i).get("ID");
					LOGGER.info("mdnlineDetails...addwearableId"+addwearableId);
					String addwearable_Id=addwearableId.toString();
					LOGGER.info("mdnlineDetails..addwearable_Id"+addwearable_Id);
					input.addValue("ID", addwearable_Id);
				}
			}
			
			List<Map<String, Object>> hostmdnlinehistoryDetails=null;
			 hostmdnlinehistoryDetails = (List<Map<String, Object>>) centuryCIFTemplate.queryForList(Constants.HOSTMDN_LINEHISTORY_DETAILS,
			new Object[] { LINEID});
			if (hostmdnlinehistoryDetails != null && hostmdnlinehistoryDetails.size() > 0) {
				for (int j = 0; j < hostmdnlinehistoryDetails.size(); j++) {
						input.addValue("ACC_STATUS", (String)hostmdnlinehistoryDetails.get(j).get("ACCT_STATUS"));
						input.addValue("LINE_STATUS", (String)hostmdnlinehistoryDetails.get(j).get("LINE_STATUS"));
						input.addValue("LTE_STATUS", (String)hostmdnlinehistoryDetails.get(j).get("LTE_STATUS"));
						input.addValue("OLD_VALUE", (String)hostmdnlinehistoryDetails.get(j).get("OLD_VALUE"));
						input.addValue("NEW_VALUE", (String)hostmdnlinehistoryDetails.get(j).get("NEW_VALUE"));
						input.addValue("FIELD_TYPE", (String)hostmdnlinehistoryDetails.get(j).get("FIELD_TYPE"));
						namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				}
			}
				
		} catch (Exception e) {
			LOGGER.error("Exception in insertActivationRecords:::"+e.getMessage());
			
		}
	}

public void updateDeactivationRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId) {
	String lineStatus="DEACTIVE";
	String accStatus= getActiveLinesCount(accountId); 
	String simStatus="DEACTIVATED";
	String transactionStatus = "";
	//transactionStatus = getTransactionStatus(lineId);
	int transactionCount = getCountTransactionStatus(lineId);
	if(transactionCount>0)
	{
	//if("INPROGRESS".equalsIgnoreCase(transactionStatus)) {
		transactionStatus="COMPLETED";
	}else {
		transactionStatus=null;
	}
	try {
		LOGGER.info("Inside updateDeactivationRecords Method");
		input.addValue("ACC_STATUS", accStatus);
		input.addValue("LINE_STATUS", lineStatus);
		input.addValue("SIM_STATUS", simStatus);
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("DEACTIVATION_DATE", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "DS");
		input.addValue("ORDER_TYPE", "DEACTIVATE");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("TRANSACTION_STATUS", transactionStatus);
		if ("DEACTIVE".equalsIgnoreCase(accStatus)) {
			namedJdbcTemplate.update(Constants.UPDATE_ACCOUNT_DS, input);
		}
		namedJdbcTemplate.update(Constants.UPDATE_LINE_DS, input);
		namedJdbcTemplate.update(Constants.UPDATE_SIM_DS, input);
		namedJdbcTemplate.update(Constants.UPDATE_DEVICE_DS, input);
		namedJdbcTemplate.update(Constants.UPDATE_LINE_PLAN_DS, input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateDeactivationRecords:::"+e.getMessage());
	}
}	

	public void updateRestoreServiceRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			RequestBean deviceDetailsBean, String accountId, String lineId) {
		String accStatus = getSuspendLinesCount(accountId);
		LOGGER.info("accStatus" +accStatus);
		//String transactionStatus = getTransactionStatus(lineId);
		int transactionCount = getCountTransactionStatus(lineId);
		try {
			if(transactionCount==0)
			{
			//if(!(transactionStatus.equalsIgnoreCase("INPROGRESS")) || transactionStatus.equalsIgnoreCase("null") || transactionStatus==null ) {
			if (accStatus.equalsIgnoreCase("SUSPEND")) {
				accStatus = "ACTIVE";
			} else {
				accStatus = "SUSPEND";
			}
			
			LOGGER.info("Inside updateRestoreServiceRecords Method");
			input.addValue("ACC_STATUS", accStatus);
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("SIM_STATUS", "ACTIVE");
			input.addValue("START_DATE", getTimeStamp());
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "RS");
			input.addValue("ORDER_TYPE", "RESTORE");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("TRANSACTION_STATUS", null);
			if ("ACTIVE".equalsIgnoreCase(accStatus)) {
				namedJdbcTemplate.update(Constants.UPDATE_ACCOUNT_SS, input);
			}
			namedJdbcTemplate.update(Constants.UPDATE_LINE_SS, input);
			namedJdbcTemplate.update(Constants.UPDATE_SIM_SS, input);
			namedJdbcTemplate.update(Constants.UPDATE_LINE_PLAN_RS, input);
		}} catch (Exception e) {
			LOGGER.error("Exception in updateRestoreServiceRecords:::"+e.getMessage());
		}
	}	
	
	public void updateSuspendedRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			RequestBean deviceDetailsBean, String accountId, String lineId) {
		String lineStatus = "SUSPEND";
		String accStatus = getSuspendLinesCount(accountId);
		String simStatus = "SUSPENDED";
		LOGGER.info("accStatus" +accStatus);
		String transactionStatus = "";
		//transactionStatus = getTransactionStatus(lineId);
		int transactionCount = getCountTransactionStatus(lineId);
		if(transactionCount>0)
		{
		//String transactionStatus = getTransactionStatus(lineId);
		//if("INPROGRESS".equalsIgnoreCase(transactionStatus)) {
			transactionStatus="COMPLETED";
		}else {
			transactionStatus=null;
		}
		try {
			LOGGER.info("Inside updateSuspendedRecords Method");
			input.addValue("ACC_STATUS", accStatus);
			input.addValue("LINE_STATUS", lineStatus);
			input.addValue("SIM_STATUS", simStatus);
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "SS");
			input.addValue("ORDER_TYPE", "SUSPEND");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("TRANSACTION_STATUS", transactionStatus);
			if ("SUSPEND".equalsIgnoreCase(accStatus)) {
				namedJdbcTemplate.update(Constants.UPDATE_ACCOUNT_SS, input);
			}
			namedJdbcTemplate.update(Constants.UPDATE_LINE_SS, input);
			namedJdbcTemplate.update(Constants.UPDATE_SIM_SS, input);
			LOGGER.info(" Suspend Line Status:::");
			input.addValue("OLD_VALUE", "ACTIVE");
			input.addValue("NEW_VALUE", "SUSPEND");
			input.addValue("FIELD_TYPE", "LINE_STATUS");
			namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			namedJdbcTemplate.update(Constants.UPDATE_LINE_PLAN_DS, input);

			
		} catch (Exception e) {
			LOGGER.error("Exception in updateSuspendedRecords:::"+e.getMessage());
		}
	}	

public void updateChangeMdnRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			 String accountId, String lineId) {
		Double oldMdn=getOldMdn(lineId);
		try {
			LOGGER.info("Inside updateChangeMdnRecords Method");
			if (obRequestBean.getMdn() != null) {
				input.addValue("MDN", obRequestBean.getMdn());
				input.addValue("NEW_VALUE", obRequestBean.getMdn());
			} else if (asyncResponseBean.getMdn() != null) {
				input.addValue("MDN", asyncResponseBean.getMdn());
				input.addValue("NEW_VALUE", asyncResponseBean.getMdn());
			} else {
				input.addValue("MDN", null);
				input.addValue("NEW_VALUE", null);
			}
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "CM");
			input.addValue("ORDER_TYPE", "MDN_CHG");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("FIELD_TYPE", "MDN");
			input.addValue("OLD_VALUE", oldMdn);

			namedJdbcTemplate.update(Constants.CHANGE_LINE_MDN, input);
			namedJdbcTemplate.update(Constants.CHANGE_HOST_MDN, input);
			namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
		} catch (Exception e) {
			LOGGER.error("Exception in updateChangeMdnRecords:::" + e.getMessage());
		}
	}

public void updateReconnectMdnRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId) {
	Double oldMdn=getOldMdn(lineId);
	try {
		LOGGER.info("Inside updateReconnectMdnRecords Method");
		if (obRequestBean.getMdn() != null) {
			input.addValue("MDN", obRequestBean.getMdn());
			input.addValue("NEW_VALUE", obRequestBean.getMdn());
		} else if (asyncResponseBean.getMdn() != null) {
			input.addValue("MDN", asyncResponseBean.getMdn());
			input.addValue("NEW_VALUE", asyncResponseBean.getMdn());
		} else {
			input.addValue("MDN", null);
			input.addValue("NEW_VALUE", null);
		}
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "RM");
		input.addValue("ORDER_TYPE", "RECONNECT");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("FIELD_TYPE", "MDN");
		input.addValue("OLD_VALUE", oldMdn);

		namedJdbcTemplate.update(Constants.UPDATE_RECONNECT, input);
		namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateReconnectMdnRecords:::" + e.getMessage());
	}
}

public void updateChangeDeviceRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
	 String oldDeviceId="";
//	Double oldDeviceId=getOldDeviceId(lineId);
	try {
		LOGGER.info("Inside updateChangeDeviceRecords Method");
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "OD");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("DEVICE_TYPE", null);
		input.addValue("TRANSACTION_STATUS", null);
			if (obRequestBean != null) {
				if (obRequestBean.getDeviceId() != null) {
					input.addValue("IMEI", obRequestBean.getDeviceId());
					input.addValue("NEW_VALUE", obRequestBean.getDeviceId());
				}  else {
					input.addValue("IMEI", null);
					input.addValue("NEW_VALUE", null);
				}
				if (secondObReqBean.getOldDeviceId() != null) {
					input.addValue("OLDIMEI", obRequestBean.getOldDeviceId());
					input.addValue("OLD_VALUE", obRequestBean.getOldDeviceId());
					oldDeviceId = obRequestBean.getOldDeviceId();
					input.addValue("FIELD_TYPE", "DEVICEID");
					input.addValue("OLD_VALUE", oldDeviceId);
					input.addValue("ORDER_TYPE", "DEV_CHG");// SIM_CHG
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				} else {
					input.addValue("OLDIMEI", null);
					input.addValue("OLD_VALUE", null);
				}
			
			}
			if(obRequestBean!=null &&obRequestBean.getnewRatePlan()!=null&&obRequestBean.getOldRatePlan()!=null) {
				input.addValue("FIELD_TYPE", "WHOLESALE_PLAN");
				input.addValue("MDN",ibRequestBean.getMdn() );
				input.addValue("OLD_VALUE", obRequestBean.getOldRatePlan());
				input.addValue("NEW_VALUE", obRequestBean.getnewRatePlan());
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS,input);
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.CHANGE_LINE_SIM, input);
			namedJdbcTemplate.update(Constants.UPDATE_ENDDATE_OD,input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateChangeDeviceRecords:::" + e.getMessage());
	}
}

public void managePromotionRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
	try {
		Map<String, String> fieldTypes = new HashMap<String, String>();
		LOGGER.info("Inside managePromotionRecords Method");
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "MP");
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("STATUS", "ACTIVE");
		input.addValue("EXPIRED_DATE", null);
		input.addValue("LINEID", lineId);
		input.addValue("DEVICE_TYPE", null);
		input.addValue("TRANSACTION_STATUS", null);
			
			if (obRequestBean != null && asyncResponseBean!=null) {
				if (obRequestBean.getMdn() != null) {
					input.addValue("MDN", obRequestBean.getMdn());
					fieldTypes.put("MDN", obRequestBean.getMdn());
				}else if (asyncResponseBean.getMdn() != null) {
					input.addValue("MDN", asyncResponseBean.getMdn());
					fieldTypes.put("MDN", asyncResponseBean.getMdn());
				}else {
					input.addValue("MDN", null);
				}
				if (obRequestBean.getAction() != null) {
					input.addValue("PROMO_TYPE", obRequestBean.getAction());
					fieldTypes.put("PROMO_TYPE", obRequestBean.getAction());
					if(obRequestBean.getAction().equalsIgnoreCase("ADD")) {
						input.addValue("ORDER_TYPE", "PROMO_ADD");
					}else {
						input.addValue("ORDER_TYPE", "PROMO_DEL");
					}
				} else {
					input.addValue("PROMO_TYPE", null);
				}if (obRequestBean.getPromotionId()!= null) {
					input.addValue("PROMO_ID", obRequestBean.getPromotionId());
					fieldTypes.put("PROMO_ID", obRequestBean.getPromotionId());
				} else {
					input.addValue("PROMO_ID", null);
				}if (obRequestBean.getPromotionAllowance()!= null) {
					input.addValue("PROMO_ALLOWANCE", obRequestBean.getPromotionAllowance());
				} else {
					input.addValue("PROMO_ALLOWANCE", null);
					
					
					
				}if (ibRequestBean.getStartDate()!= null) {				
					input.addValue("START_DATE", convertDateFormat(ibRequestBean.getStartDate()));
				//	input.addValue("START_DATE", null);					
					fieldTypes.put("START_DATE",convertDateFormat(ibRequestBean.getStartDate()).toString());
				} else {
					input.addValue("START_DATE", null);
				}
				
			if(obRequestBean.getAction().equalsIgnoreCase("DELETE")) {
					input.addValue("END_DATE", getTimeStamp());
					fieldTypes.put("END_DATE", getTimeStamp().toString());
				} else {
					input.addValue("END_DATE", null);
				}
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.INSERT_PROMOTION_DATA, input);
			for (Entry<String, String> field : fieldTypes.entrySet()) {
				input.addValue("FIELD_TYPE", field.getKey());
				input.addValue("NEW_VALUE", field.getValue());
				input.addValue("OLD_VALUE",null);
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			}
	//		namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
	} catch (Exception e) {
		LOGGER.error("Exception in managePromotionRecords:::" + e.getMessage());
	}
}

public void updatePortOutRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
		try {
			LOGGER.info("Inside updatePortOutRecords Method");
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "PO");
			input.addValue("ORDER_TYPE", "PORT_OUT_CN");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("FIELD_TYPE", "MDN");
			input.addValue("OLD_VALUE", null);
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);

			if (asyncResponseBean != null) {
				if (obRequestBean != null && asyncResponseBean != null) {
					if (obRequestBean.getMdn() != null) {
						input.addValue("MDN", obRequestBean.getMdn());
						input.addValue("NEW_VALUE", obRequestBean.getMdn());
					} else if (asyncResponseBean.getMdn() != null) {
						input.addValue("MDN", asyncResponseBean.getMdn());
						input.addValue("NEW_VALUE", obRequestBean.getMdn());
					} else {
						input.addValue("MDN", null);
					}
				}
				namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			}
		} catch (Exception e) {
		LOGGER.error("Exception in updatePortOutRecords:::" + e.getMessage());
	}
}

public void updateHotlineRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
			String accStatus = getHotlineLinesCount(accountId);
			//String transactionStatus = getTransactionStatus(lineId);
			LOGGER.info("accStatus" +accStatus);
			String transactionStatus = "";
		//transactionStatus = getTransactionStatus(lineId);
		int transactionCount = getCountTransactionStatus(lineId);
		
			if(transactionCount>0)
			{
			//if("INPROGRESS".equalsIgnoreCase(transactionStatus)) {
				transactionStatus="COMPLETED";
			}else {
				transactionStatus=null;
			}
		try {
			LOGGER.info("Inside updateHotlineRecords Method");
			input.addValue("ACC_STATUS", accStatus);
			input.addValue("HOTLINE_STATUS", "HOTLINE");
			input.addValue("LINE_STATUS", null);
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "HS");
			input.addValue("ORDER_TYPE", "HOTLINE");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("FIELD_TYPE", "MDN");
			input.addValue("OLD_VALUE", null);
			input.addValue("NEW_VALUE", null);
			input.addValue("TRANSACTION_STATUS", transactionStatus);
			input.addValue("DEVICE_TYPE", null);

			if (obRequestBean != null) {
				LOGGER.info("Inside obRequestBeanRecords Method " + obRequestBean.toString());
				if (obRequestBean.getHotlineType() != null) {
					input.addValue("HOTLINETYPE", obRequestBean.getHotlineType());
				} else {
					input.addValue("HOTLINETYPE", null);
				}
			}
			if (asyncResponseBean != null) {
				if (asyncResponseBean.getHotlineType() != null) {
					input.addValue("NEW_VALUE", asyncResponseBean.getMdn());
				} else {
					input.addValue("NEW_VALUE", null);
				}
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.UPDATE_HOTLINE, input);
			namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			LOGGER.info("Hotline Subscriber line Status:::");
			input.addValue("OLD_VALUE", null);
			input.addValue("NEW_VALUE", "ACTIVE");
			input.addValue("FIELD_TYPE", "LINE_STATUS");
			namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
		} catch (Exception e) {
		LOGGER.error("Exception in updateHotlineRecords:::" + e.getMessage());
	}
}


public void updateRemoveHotlineRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
		//String transactionStatus = getTransactionStatus(lineId);
		int transactionCount = getCountTransactionStatus(lineId);
		try {
			if(transactionCount==0)
			{
			//if(!(transactionStatus.equalsIgnoreCase("INPROGRESS"))) {
			LOGGER.info("Inside updateRemoveHotlineRecords Method");
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("HOTLINE_STATUS", null);
			input.addValue("LINE_STATUS", null);
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "RH");
			input.addValue("ORDER_TYPE", "REM_HOT");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("FIELD_TYPE", "MDN");
			input.addValue("OLD_VALUE", null);
			input.addValue("NEW_VALUE", null);
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);			
			if (obRequestBean != null) {
				LOGGER.info("Inside obRequestBeanRecords Method " + obRequestBean.toString());
				if (obRequestBean.getHotlineType() != null) {
					input.addValue("HOTLINETYPE", obRequestBean.getHotlineType());
				} else {
					input.addValue("HOTLINETYPE", null);
				}
			}
			if (asyncResponseBean != null) {
				if (asyncResponseBean.getHotlineType() != null) {
					input.addValue("NEW_VALUE", asyncResponseBean.getMdn());
				} else {
					input.addValue("NEW_VALUE", null);
				}
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.UPDATE_HOTLINE, input);
			namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
		} }catch (Exception e) {
		LOGGER.error("Exception in updateRemoveHotlineRecords:::" + e.getMessage());
	}
}

public void updateChangeSimAndDeviceRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean,Map<String, String> featMap,RequestBean deviceDetailsBean) {
	String oldIccId="";
	String oldDeviceId="";
	try {
		LOGGER.info("Inside updateChangeSimAndDeviceRecords Method");
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "DS");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("TRANSACTION_STATUS", null);
		if(featMap.size()>0) {
			LOGGER.info("Inside featMap:::"+featMap.toString());
		}
			if (secondObReqBean != null) {
				if (secondObReqBean.getDeviceId() != null) {
					input.addValue("IMEI", secondObReqBean.getDeviceId());
					input.addValue("NEW_VALUE", secondObReqBean.getDeviceId());

				} /*else if (asyncResponseBean.getDeviceId() != null) {
					input.addValue("IMEI", asyncResponseBean.getDeviceId());
					input.addValue("NEW_VALUE", asyncResponseBean.getDeviceId());
				}*/ else {
					input.addValue("IMEI", null);
					input.addValue("NEW_VALUE", null);
				}
				if (secondObReqBean.getOldDeviceId() != null) {
					input.addValue("OLDIMEI", secondObReqBean.getOldDeviceId());
					input.addValue("OLD_VALUE", secondObReqBean.getOldDeviceId());
					oldDeviceId = secondObReqBean.getOldDeviceId();
					input.addValue("FIELD_TYPE", "DEVICEID");
					input.addValue("OLD_VALUE", oldDeviceId);
					input.addValue("ORDER_TYPE", "DEV_CHG");// SIM_CHG
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				} else {
					input.addValue("OLDIMEI", null);
					input.addValue("OLD_VALUE", null);
				}
				if (secondObReqBean.getIccid() != null) {
					input.addValue("ICCID", secondObReqBean.getIccid());
					input.addValue("NEW_VALUE", secondObReqBean.getIccid());
				}/* else if (asyncResponseBean.getIccid() != null) {
					input.addValue("ICCID", asyncResponseBean.getIccid());
					input.addValue("NEW_VALUE", asyncResponseBean.getIccid());
				} */else {
					input.addValue("ICCID", null);
					input.addValue("NEW_VALUE", null);
				}
				if (secondObReqBean.getIccid() != null) {
					input.addValue("OLDICCID", secondObReqBean.getOldIccid());
					input.addValue("OLD_VALUE", secondObReqBean.getOldIccid());
					oldIccId = secondObReqBean.getOldIccid();
					input.addValue("FIELD_TYPE", "ICCID");
					input.addValue("OLD_VALUE", oldIccId);
					input.addValue("ORDER_TYPE", "SIM_CHG");
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				} else {
					input.addValue("OLDICCID", null);
					input.addValue("OLD_VALUE", null);
				}
				
				
				}
				
			
			LOGGER.info("DeviceDetails123:::"+deviceDetailsBean.getMode());
			if (deviceDetailsBean.getMode() != null && !"".equalsIgnoreCase(deviceDetailsBean.getMode()) && !"null".equalsIgnoreCase(deviceDetailsBean.getMode())) {
				input.addValue(Constants.DEVICE_TYPE, deviceDetailsBean.getMode().substring(0, 2));
				LOGGER.info("Inside DeviceDetails:::"+deviceDetailsBean.getMode());
			} else {
				input.addValue(Constants.DEVICE_TYPE, null);
			}  
			
			String oldFirstActivatedNetwork = this.getFirstActivatedNetwork(lineId);
			String firstActivatedNetwork = deviceDetailsBean.getMode().substring(0, 2);
			if((oldFirstActivatedNetwork != null && !oldFirstActivatedNetwork.isEmpty()) && (firstActivatedNetwork != null && !firstActivatedNetwork.isEmpty())) {
				if(oldFirstActivatedNetwork != firstActivatedNetwork) {
					input.addValue("FIELD_TYPE", "FIRST_ACTIVATED_NETWORK");
					input.addValue("OLD_VALUE", oldFirstActivatedNetwork);
					input.addValue("NEW_VALUE", firstActivatedNetwork);
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS,input);	
				}
			}
			
			if(obRequestBean!=null &&obRequestBean.getnewRatePlan()!=null&&obRequestBean.getOldRatePlan()!=null) {
				input.addValue("FIELD_TYPE", "WHOLESALE_PLAN");
				input.addValue("MDN",ibRequestBean.getMdn() );
				input.addValue("OLD_VALUE", obRequestBean.getOldRatePlan());
				input.addValue("NEW_VALUE", obRequestBean.getnewRatePlan());
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS,input);
			}
			
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.CHANGE_LINE_SIM, input);
			namedJdbcTemplate.update(Constants.CHANGE_LINE_DEVICE, input);
			namedJdbcTemplate.update(Constants.UPDATE_ENDDATE_OS,input);
			namedJdbcTemplate.update(Constants.UPDATE_ENDDATE_OD,input);
				
	} catch (Exception e) {
		LOGGER.error("Exception in updateChangeSimAndDeviceRecords:::" + e.getMessage());
	}
}

public String getFirstActivatedNetwork(String lineId) {
	 String	oldActivatedNetwork = centuryCIFTemplate.queryForObject(Constants.LINEID, new Object[] { lineId },
				String.class);
	 return oldActivatedNetwork;
	}

public void updateChangeSimRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
	String oldIccId="";
	try {
		LOGGER.info("Inside updateChangeSimRecords Method");
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "OS");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("DEVICE_TYPE", null);
		input.addValue("TRANSACTION_STATUS", null);
			if (obRequestBean != null) {
				if (obRequestBean.getIccid() != null) {
					input.addValue("ICCID", obRequestBean.getIccid());
					input.addValue("NEW_VALUE", obRequestBean.getIccid());
				}else {
					input.addValue("ICCID", null);
					input.addValue("NEW_VALUE", null);
				}
				if (obRequestBean.getOldIccid() != null) {
					input.addValue("OLDICCID", obRequestBean.getOldIccid());
					input.addValue("OLD_VALUE", obRequestBean.getOldIccid());
					oldIccId = obRequestBean.getOldIccid();
					input.addValue("FIELD_TYPE", "ICCID");
					input.addValue("OLD_VALUE", oldIccId);
					input.addValue("ORDER_TYPE", "SIM_CHG");
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				} else {
					input.addValue("OLDICCID", null);
					input.addValue("OLD_VALUE", null);
				}
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.CHANGE_LINE_SIM, input);
			namedJdbcTemplate.update(Constants.UPDATE_ENDDATE_OS,input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateChangeSimRecords:::" + e.getMessage());
	}
}

public void updatePortInRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,RequestBean secondObReqBean) {
	String oldIccId="";
	try {
		LOGGER.info("Inside updatePortInRecords Method");
			if (transactionName.equalsIgnoreCase("")) {
				input.addValue("TRANSACTION_TYPE", "Update Due-Date");
				input.addValue("ORDER_TYPE", "PORT_IN_CN");
			} else if (transactionName.equalsIgnoreCase("Update Customer Information")) {
				input.addValue("TRANSACTION_TYPE", "PU");
				input.addValue("ORDER_TYPE", "PORT_IN_PU");
			} else {
				input.addValue("TRANSACTION_TYPE", "PC");
				input.addValue("ORDER_TYPE", "PORT_IN_CN");
			}
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);
			if (obRequestBean != null) {
				if (obRequestBean.getIccid() != null) {
					input.addValue("ICCID", obRequestBean.getIccid());
					input.addValue("NEW_VALUE", obRequestBean.getIccid());
				}else {
					input.addValue("ICCID", null);
					input.addValue("NEW_VALUE", null);
				}
				if (obRequestBean.getOldIccid() != null) {
					input.addValue("OLDICCID", obRequestBean.getOldIccid());
					input.addValue("OLD_VALUE", obRequestBean.getOldIccid());
					oldIccId = obRequestBean.getOldIccid();
					input.addValue("FIELD_TYPE", "ICCID");
					input.addValue("OLD_VALUE", oldIccId);
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				} else {
					input.addValue("OLDICCID", null);
					input.addValue("OLD_VALUE", null);
				}
			}
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
			namedJdbcTemplate.update(Constants.CHANGE_LINE_SIM, input);
			namedJdbcTemplate.update(Constants.UPDATE_ENDDATE_OS,input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateChangeSimRecords:::" + e.getMessage());
	}
}

public void updateBillCycleRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		int bcd, String accountId, String lineId) {
	try {
		LOGGER.info("Inside updateBillCycleRecords Method");
		if (obRequestBean.getBillCycleResetDay() != null) {
			input.addValue("BILLCYCLEDAY", obRequestBean.getBillCycleResetDay());
			input.addValue("NEW_VALUE", obRequestBean.getBillCycleResetDay());
		}else if (ibRequestBean.getBillCycleResetDay() != null) {
			input.addValue("BILLCYCLEDAY", ibRequestBean.getBillCycleResetDay());
			input.addValue("NEW_VALUE", ibRequestBean.getBillCycleResetDay());
		}  else {
			input.addValue("BILLCYCLEDAY", null);
			input.addValue("NEW_VALUE",null);
		}
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", "CB");
		input.addValue("ORDER_TYPE", "BCD_CHG");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineId));
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("FIELD_TYPE", "BCD");
		input.addValue("OLD_VALUE",bcd);
		
		namedJdbcTemplate.update(Constants.UPDATE_LINE_CB, input);
		namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
	} catch (Exception e) {
		LOGGER.error("Exception in updateBillCycleRecords:::"+e.getMessage());
	}
}

 public void updateChangeFeatureRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			RequestBean deviceDetailsBean,String accountId, String lineId, String verifyAccount, String verifyLine,
			Map<String, String> featMap) {
	 int featCount=0;
		try {
			LOGGER.info("Inside updateChangeFeatureRecords Method");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "CF");
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("WHOLESALE_PLAN", getWHSCode(lineId));
			input.addValue("RETAIL_PLANCODE", getRetailCode(lineId));
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("LINEID", lineId);
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);
			input.addValue("ID", getIdfromLineId(lineId));
			for (Entry<String, String> feat : featMap.entrySet()) {
				if (feat.getValue().equalsIgnoreCase("N")) {
					input.addValue("ORDER_TYPE", "FEAT_DEL");
					input.addValue("FEAT_DEL", feat.getKey());
					featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_CF_FEATURES, input,Integer.class);
					if (featCount == 0) {
						input.addValue("FEATURECODES", feat.getKey());
						input.addValue("ISACTIVE", feat.getValue());
						namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					}else {
						input.addValue("ISACTIVE", feat.getValue());
						input.addValue("FEATURECODES", feat.getKey());
						namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
					}
				}else {
					input.addValue("ORDER_TYPE", "FEAT_ADD");
					input.addValue("FEAT_ADD", feat.getKey());
					input.addValue("FEATURECODES", feat.getKey());
					input.addValue("ISACTIVE", feat.getValue());
					featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_FEAT_ADD, input,Integer.class);
					if (featCount == 0) {
						input.addValue("FEATURECODES", feat.getKey());
						input.addValue("ISACTIVE", feat.getValue());
						namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					}else {
						input.addValue("ISACTIVE", feat.getValue());
						input.addValue("FEATURECODES", feat.getKey());
						namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
					}
					namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					input.addValue("FIELD_TYPE", "FEATURECODES");
					input.addValue("NEW_VALUE", feat.getKey());
					input.addValue("OLD_VALUE",null);
					namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				}
				
			}
		} catch (Exception e) {
			LOGGER.error("Exception in updateChangeFeatureRecords:::"+e.getMessage());
		}
	}
 
 public void updateChangeRatePlanRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			RequestBean deviceDetailsBean,String accountId, String lineId, String verifyAccount, String verifyLine,
			Map<String, String> featMap) {
	 int featCount=0;
		try {
			LOGGER.info("Inside updateChangeFeatureRecords Method");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "CR");
			input.addValue("ACC_STATUS", "ACTIVE");
			input.addValue("LINE_STATUS", "ACTIVE");
			input.addValue("ACCOUNT_NUMBER", accountId);
			input.addValue("WHOLESALE_PLAN", getWHSCode(lineId));
			input.addValue("RETAIL_PLANCODE", getRetailCode(lineId));
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("LINEID", lineId);
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);
			input.addValue("ID", getIdfromLineId(lineId));
			for (Entry<String, String> feat : featMap.entrySet()) {
				if (feat.getValue().equalsIgnoreCase("N")) {
					input.addValue("ORDER_TYPE", "FEAT_DEL");
					input.addValue("FEAT_DEL", feat.getKey());
					featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_CF_FEATURES, input, Integer.class);
					if (featCount == 0) {
						input.addValue("FEATURECODES", feat.getKey());
						input.addValue("ISACTIVE", feat.getValue());
						namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					} else {
						input.addValue("ISACTIVE", feat.getValue());
						input.addValue("FEATURECODES", feat.getKey());
						namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
					}
				} else {
					input.addValue("ORDER_TYPE", "FEAT_ADD");
					input.addValue("FEAT_ADD", feat.getKey());
					input.addValue("FEATURECODES", feat.getKey());
					input.addValue("ISACTIVE", feat.getValue());
					featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_FEAT_ADD, input, Integer.class);
					if (featCount == 0) {
						input.addValue("FEATURECODES", feat.getKey());
						input.addValue("ISACTIVE", feat.getValue());
						namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					} else {
						input.addValue("ISACTIVE", feat.getValue());
						input.addValue("FEATURECODES", feat.getKey());
						namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
					}
					namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
					input.addValue("FIELD_TYPE", "FEATURECODES");
					input.addValue("NEW_VALUE", feat.getKey());
					input.addValue("OLD_VALUE", null);
					namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
					namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception in updateChangeRatePlanRecords:::"+e.getMessage());
		}
	}
 
 public void updateResetFeatureRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
			 String accountId, String lineId) {
		try {
			LOGGER.info("Inside updateResetFeatureRecords Method");
			input.addValue("LAST_UPDATED", getTimeStamp());
			input.addValue("TRANSACTION_TYPE", "RF");
			input.addValue("ORDER_TYPE", "VM_RST");
			input.addValue("ACCT_ID", getAccountId(accountId));
			input.addValue("ID", getIdfromLineId(lineId));
			input.addValue("DEVICE_TYPE", null);
			input.addValue("TRANSACTION_STATUS", null);
			namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
		//	namedJdbcTemplate.update(Constants.UPDATE_LINE_CB, input);
		//	namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
		} catch (Exception e) {
			LOGGER.error("Exception in updateResetFeatureRecords:::"+e.getMessage());
		}
	}
	
 public void manageAccountRecords(String transactionName,MapSqlParameterSource input,NamedParameterJdbcTemplate namedJdbcTemplate,RequestBean asyncResponseBean,RequestBean ibRequestBean,RequestBean obRequestBean,
		 String accountId, String lineId,String action, String transId) {
	 String oldValue = "";
		String requestJson = getRequest(transId);
		ArrayList mdnList=new ArrayList();
		String mdn="";
		String lineid="";
		ArrayList LineIdList=new ArrayList();
		LineIdList=LineId(requestJson);
		mdnList=getMdn(requestJson);
	try {	
		
		if(mdnList.size()!=0){
			for(int i=0;i<mdnList.size();i++)
			{
				mdn =(String) mdnList.get(i);
			
				lineid =(String) LineIdList.get(i);
		
		if(action.equalsIgnoreCase("A")) {
			oldValue =getOldAccountValue(lineid);
			LOGGER.info("oldValue:::"+oldValue);
		LOGGER.info("Inside manageAccountRecords Method");
		input.addValue("ACCT_ID", getAccountId(accountId));
		input.addValue("ID", getIdfromLineId(lineid));
		input.addValue("LINE_ID", lineid);
		input.addValue("ACCOUNT_NUMBER", accountId);
		input.addValue("MDN",mdn);
		input.addValue("OLDACCT",oldValue);
		namedJdbcTemplate.update(Constants.UPDATE_ACC, input);
		namedJdbcTemplate.update(Constants.UPDATE_LINE_HIS, input);
	//	namedJdbcTemplate.update(Constants.UPDATE_LINE_CB, input);
	//	namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
		}}
		}
	}catch (Exception e) {
		LOGGER.error("Exception in manageAccountRecords:::"+e.getMessage());
	}
}
 
 public String getRequest(String transactionId) {
		String resMsg = (String) centuryCIFTemplate.queryForObject(Constants.GET_REQUEST, new Object[] { transactionId }, String.class);
		return resMsg;
	}
 
 
	
	public ArrayList getMdn(String request){
		JSONObject object3 = new JSONObject();
		JSONArray suborderArr = new JSONArray();
		JSONArray suborderArray = new JSONArray();
		String mdn="";
		ArrayList mdnValue = new ArrayList();
		try{
			JSONObject object1 = new JSONObject(request);
			if (object1.has("data")) {
				object1 = object1.getJSONObject("data");
		if (object1.has("subOrder")) {
						suborderArr= object1.getJSONArray("subOrder");
						object3 = suborderArr.getJSONObject(0);
						if(object3.has("mdns"))
						{
							suborderArr = object3.getJSONArray("mdns");
							int jsonLength=suborderArr.length();
							for(int i=0;i<jsonLength;i++)
							{
							object3 = suborderArr.getJSONObject(i);
							if(object3.has("mdn")){
								suborderArray = object3.getJSONArray("mdn");
								LOGGER.info("suborderArr mdn:::" + suborderArray.toString());
								object3 = suborderArray.getJSONObject(0);
							if (object3.has("value"))// mdn, oldMDN, newMDN, hostMDN
							{
								mdn = object3.getString("value");
								mdnValue.add(mdn);
								
							}
							}
						}
						}
			}
			}
					return mdnValue;
	}
	catch(Exception e){
		LOGGER.error(e.getMessage(), e);
	}return null;
	}
 
 
 
 public ArrayList LineId(String request){
		JSONObject object3 = new JSONObject();
		JSONArray suborderArr = new JSONArray();
		JSONArray suborderArray = new JSONArray();
		String lineId="";
		ArrayList lineIdValue = new ArrayList();
		try{
			JSONObject object1 = new JSONObject(request);
			if (object1.has("data")) {
				object1 = object1.getJSONObject("data");
		if (object1.has("subOrder")) {
						suborderArr= object1.getJSONArray("subOrder");
						object3 = suborderArr.getJSONObject(0);
						
						}if(object3.has("mdns"))
						{
							suborderArr = object3.getJSONArray("mdns");
							int jsonLength=suborderArr.length();
							for(int i=0;i<jsonLength;i++)
							{
							object3 = suborderArr.getJSONObject(i);
							if(object3.has("lineId")){
							
								lineId = object3.getString("lineId");
								lineIdValue.add(lineId);
								
							}
							
						}
						}
			}
			
					return lineIdValue;
	}
	catch(Exception e){
		LOGGER.error(e.getMessage(), e);
	}return null;
	}
 
 
 
 
	public int mnoStatusCount(String refNo) {
		return centuryCIFTemplate.queryForObject(Constants.GET_STATUS_COUNT, new Object[] { refNo },
				Integer.class);
				}
 
 
 
 public void updateMNOStatus(String refNo) {
	 MapSqlParameterSource input = new MapSqlParameterSource();
	 NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
	 input.addValue("REFERENCE_NUMBER", refNo);
	 namedJdbcTemplate.update(Constants.UPDATE_MNO_STATUS, input);
				}
 
 
 
 public List<Map<String, Object>> getActivateddatas(String refNo){
	 List<Map<String, Object>> activatedDatas = (List<Map<String, Object>>) centuryCIFTemplate
				.queryForList(Constants.GET_ACTIVATED_DATAS, new Object[] { refNo,refNo });
	 
	 return activatedDatas;
 }
 
 public void updatechangeMDNResponse(MapSqlParameterSource input) {
	 NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
	 namedJdbcTemplate.update(Constants.UPDATE_CHANGEMDN_RESPONSE, input);
				}
 
 public void updatechangeMDNRequest(MapSqlParameterSource input) {
	 NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
	 namedJdbcTemplate.update(Constants.UPDATE_CHANGEMDN_REQUEST, input);
				}

 public Timestamp convertDateFormat(String date) {
	 Timestamp startDate1=null;
	 try {
			Date date1 = (javax.xml.bind.DatatypeConverter.parseDateTime(date)).getTime();
			 startDate1 = new Timestamp(date1.getTime());
			 System.out.println("Insiade startdate1 " +startDate1);
			return startDate1;
			
		} catch (Exception e) {
			startDate1 = null;
		}	
	 return null;
 }
 

				

public String getLineResponse(String transId) {
		String response = null;
		try {
			System.out.println("inside getLineResponse::: ");
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("REL_ID", transId);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			response = namedJdbcTemplate.queryForObject(Constants.GET_LINE_RESPONSE, input, String.class);
			System.out.println("response:::" + response);
			
		} catch (Exception e) {
			LOGGER.error("Error::" + e.getMessage());
		}
		return response;
	}
public String getLineId(String mdn) {
	String lineId = centuryCIFTemplate.queryForObject(Constants.LINEID_NUM, new Object[] { mdn },
			String.class);
	return lineId;
}

public String getLineAccountId(String mdn) {
 String	accountNumber = centuryCIFTemplate.queryForObject(Constants.ACCOUNT_NUM, new Object[] { mdn },
			String.class);
 return accountNumber;
}

public String getResponseMsg(String transId) {
	String response = centuryCIFTemplate.queryForObject(Constants.RESPONSEMSG_FROMTRANSDEATILS, new Object[] { transId },
			String.class);
	return response;
}

public String getDeviceDetails(String deviceDetails) throws JSONException {
	JSONObject addtionalJsonRes = new JSONObject();
	JSONObject ipJsonObject = new JSONObject(deviceDetails);
	JSONObject data = ipJsonObject.getJSONObject(Constants.DATA);
	JSONArray subOrder=data.getJSONArray(Constants.SUBORDER);
	JSONObject deviceId=subOrder.getJSONObject(0).getJSONArray("deviceId").getJSONObject(0);
	addtionalJsonRes.put("deviceId",deviceId.getString("value"));
	JSONArray additionalData = ipJsonObject.getJSONObject(Constants.DATA).getJSONArray(Constants.ADDITIONAL_DATA);
	for (int a = 0; a < additionalData.length(); a++) {
		addtionalJsonRes.put(additionalData.getJSONObject(a).getString(Constants.NAME),
				additionalData.getJSONObject(a).getString(Constants.VALUE));
	}
	return validateDeviceDetails(addtionalJsonRes);
}

public String validateDeviceDetails(JSONObject addtionalJsonRes) throws JSONException {
	if(addtionalJsonRes.has("deviceType")) {
		addtionalJsonRes.put("deviceCategory",addtionalJsonRes.getString("deviceType")+" Smartphone");
		addtionalJsonRes.put("mode",addtionalJsonRes.getString("deviceType"));
		//addtionalJsonRes.put("model","SMG");
		if(!addtionalJsonRes.has("make")) {
			addtionalJsonRes.put("make","SAM");
		}
	}
	
	return addtionalJsonRes.toString();
	
}

public String insertIntoTransLineAssoc(String request, String transId, String serviceName) {
	LOGGER.info("request inside insertIntoTransLineAssoc::::" + request);
	
	JSONObject obj = new JSONObject();
	JSONObject subOrderObj = new JSONObject();
	JSONObject addAttrObj = null;
	String mdnAttrType = "";
	String mdnAttrValue = "";
	
	String channelId= "";
	String agentId="";
	String accountNumber ="";
	String lineId= "";
	String mdn ="";
	String deviceId =null;
	String simId=null;
	String phoneNumber = "";
	String firstName = "";
	String lastName = "";
	String emailId = "";
	String addressLine1 = null;
	String addressLine2 = null;
	String city = null;
	String state = null;
	String zip = null;
	String referenceNumber = null;
	String deviceValue="";
	String deviceType ="";
	String mdnValue="";
	String mdnType ="";
	String simValue="";
	String simType ="";
	String transactionType ="";
	try {
		
		LOGGER.info("serviceName::insertIntoTransLineAssoc::" + serviceName);
		
		if(request.contains("referenceNumber")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if(requestJsonObject.has(Constants.MESSAGEHEADER)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.MESSAGEHEADER);
					if(requestJsonObjectData.has("referenceNumber")) {
						referenceNumber=requestJsonObjectData.getString("referenceNumber");
						LOGGER.info("Inside insertTransaction method::referenceNumber:::" +referenceNumber);
					}	
				}
			}
			
			if(request.contains("transactionType")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					
					if(requestJsonObjectData.has("transactionType")) {
						transactionType = requestJsonObjectData.getString("transactionType");
						LOGGER.info("Inside insertTransaction method::transactionType::" +transactionType);
					}
					
				}
			}
			
			if(request.contains("channel")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					
					if(requestJsonObjectData.has("channel")) {
						channelId=requestJsonObjectData.getString("channel");
						LOGGER.info("Inside insertTransaction method::channel:::" +channelId);
					}
				}
			}
			
			if (request.contains("agentDetails")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if(requestJsonObjectData.has("agentDetails")) {
						LOGGER.info("Inside insertTransaction method::agentDetails:::" +requestJsonObjectData);
						requestJsonObjectData=requestJsonObjectData.getJSONObject("agentDetails");
							agentId=requestJsonObjectData.getString("agentId");
							phoneNumber=requestJsonObjectData.getString("phoneNumber");
							firstName=requestJsonObjectData.getString("firstName");
							lastName=requestJsonObjectData.getString("lastName");
							emailId=requestJsonObjectData.getString("emailId");
							addressLine1=requestJsonObjectData.getString("addressLine1");
							addressLine2=requestJsonObjectData.getString("addressLine2");
							city=requestJsonObjectData.getString("city");
							state=requestJsonObjectData.getString("state");
							zip=requestJsonObjectData.getString("zip");
							
					}
				}
			}
			
			if (request.contains("account")) {
				JSONObject requestJsonObject = new JSONObject(request);
				if(requestJsonObject.has(Constants.DATA)) {
					JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
					if(requestJsonObjectData.has("account")) {
						requestJsonObjectData=requestJsonObjectData.getJSONObject("account");
						if(requestJsonObjectData.has("accountNumber")) {
							accountNumber=requestJsonObjectData.getString("accountNumber");
							LOGGER.info("Insert::accountNumber:::" +accountNumber);
						}
						
					}
				}
			
			}
			addAttrObj = new JSONObject(request);
			if (addAttrObj.has("data")) {
				addAttrObj = addAttrObj.getJSONObject("data");
			if (addAttrObj.has("subOrder")) {
				String subOrder = addAttrObj.getString("subOrder");
				JSONArray subArray = new JSONArray(subOrder);
				JSONObject subJson = new JSONObject();
				subJson = subArray.getJSONObject(0);
						
				if (subJson.has("mdn")) {
					String mdn1 = subJson.getString("mdn");
					JSONArray submdn = new JSONArray(mdn1);
					JSONObject mdnJson = new JSONObject();
						
					for (int i = 0; i < submdn.length(); i++) {
						mdnJson = submdn.getJSONObject(i);
						if (mdnJson.has("type")) {
							mdnType = mdnJson.getString("type");
						}
						if (transactionType.equalsIgnoreCase("CM")) {
							if (mdnType.equalsIgnoreCase("oldMDN")) {
								if (mdnJson.has("value")) {
									mdnValue = mdnJson.getString("value");
								}
								
							}
						} else if (transactionType.equalsIgnoreCase("CP") || transactionType.equalsIgnoreCase("RS") || transactionType.equalsIgnoreCase("RM")) {
							if (mdnType.equalsIgnoreCase("newMDN")) {
								if (mdnJson.has("value")) {
									mdnValue = mdnJson.getString("value");
								}
								
							}
						}  else {
							if (mdnType.equalsIgnoreCase("mdn")) {
								if (mdnJson.has("value")) {
									mdnValue = mdnJson.getString("value");
								}
								
							}
						}
					}
						
					
					
					
				}
				if (subJson.has("deviceId")) {
					String deviceId1 = subJson.getString("deviceId");
					JSONArray subdeviceId1 = new JSONArray(deviceId1);
					JSONObject deviceJson = new JSONObject();
					
					for (int i = 0; i < subdeviceId1.length(); i++) {
						deviceJson = subdeviceId1.getJSONObject(i);
						if (deviceJson.has("type")) {
							deviceType = deviceJson.getString("type");
						}
						if (transactionType.equalsIgnoreCase("RM")) {
							if (deviceType.equalsIgnoreCase("IMEI")) {
								if (deviceJson.has("value")) {
									deviceValue = deviceJson.getString("value");
								}
								
							}
						} else if (transactionType.equalsIgnoreCase("OD") || transactionType.equalsIgnoreCase("DS")) {
							if (deviceType.equalsIgnoreCase("newIMEI")) {
								if (deviceJson.has("value")) {
									deviceValue = deviceJson.getString("value");
								}
								
							}
						}  else {
							if (deviceType.equalsIgnoreCase("IMEI")) {
								if (deviceJson.has("value")) {
									deviceValue = deviceJson.getString("value");
								}
								
							}
						}
					}
						
					LOGGER.info("::deviceValue:::" +deviceValue);
				} else {
					deviceValue = null;
				}
				if (subJson.has("simId")) {
					String simId1 = subJson.getString("simId");
					JSONArray subsimId1 = new JSONArray(simId1);
					JSONObject simJson = new JSONObject();
					for (int i = 0; i < subsimId1.length(); i++) {
						simJson = subsimId1.getJSONObject(i);
						if (simJson.has("type")) {
							simType = simJson.getString("type");
						}
						if (transactionType.equalsIgnoreCase("RM")) {
							if (simType.equalsIgnoreCase("oldICCID")) {
								if (simJson.has("value")) {
									simValue = simJson.getString("value");
								}
								
							}
						} else if (transactionType.equalsIgnoreCase("OS") || transactionType.equalsIgnoreCase("DS")) {
							if (simType.equalsIgnoreCase("ICCID")) {
								if (simJson.has("value")) {
									simValue = simJson.getString("value");
								}
								
							}
						}  else {
							if (simType.equalsIgnoreCase("ICCID")) {
								if (simJson.has("value")) {
									simValue = simJson.getString("value");
								}
								
							}
						}
					}
					
					
					
					LOGGER.info("::deviceValue:::" +simValue);
				} else {
					simValue = null;
				}
				if (subJson.has("lineId")) {
					 lineId = subJson.getString("lineId");
					 LOGGER.info("::lineId:::" +lineId);
				} else {
					lineId = null;
				}
				
				
			}
			}
				
			
			MapSqlParameterSource input = new MapSqlParameterSource();
			
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.CHANNEL, channelId);
			input.addValue(Constants.AGENT_ID, agentId);
			input.addValue(Constants.ACCOUNT_NUMBER, accountNumber);
			input.addValue(Constants.LINE_ID, lineId);
			input.addValue(Constants.MDN, mdnValue);
			input.addValue(Constants.IMEI, deviceValue); 
			input.addValue(Constants.ICCID,simValue);
			input.addValue(Constants.AGENT_PHONE_NUMBER, phoneNumber);
			input.addValue(Constants.AGENT_FIRST_NAME, firstName);
			input.addValue(Constants.AGENT_LAST_NAME, lastName);
			input.addValue(Constants.AGENT_EMAIL_ID, emailId);
			input.addValue(Constants.AGENT_ADDRESSLINE1, addressLine1);
			input.addValue(Constants.AGENT_ADDRESSLINE2, addressLine1);
			input.addValue(Constants.AGENT_CITY, city);
			input.addValue(Constants.AGENT_STATE, state);
			input.addValue(Constants.AGENT_ZIPCODE, zip);
			
			input.addValue(Constants.REFERENCENUMBER1, referenceNumber);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_TRANSACTION_LINE_ASSOC, input);
			
			
		
		
	} catch (Exception e) {

		LOGGER.error("Exception in handle method" + e.getMessage());
	}
	return null;
}

@Override
public int getLineMdn(String lineid, String mdn) {
	 int count=0;
		count= centuryNBOPTemplate.queryForObject(Constants.GET_LINE_MDN_COUNTS, new Object[] { lineid,mdn }, Integer.class);
		return count;
}

public String insertMNONBTransactionWithLoginId(String requestJson, String entityId, String transUId, String serviceName,
		String applicationName, String httpmethod, String source,String loginID) {
	LOGGER.info("Inside insertMNONBTransaction method::requestJson:::" + requestJson);
	String transId = null;
	String json = null;
	JSONObject inputJsonObj = null;
	String transactionTimeStamp = "";
	Timestamp transactionTs = null;
	String transactionType = "";
	String status = "";
	int count=0;
	String rootId="";
	String channelID="";
	String agentId="";

	
	
	try {
		if(serviceName.equalsIgnoreCase("Update Port-In")) {
			JSONArray jsonarr=new JSONArray(jsonFormatter(requestJson));
				/*
				 * String orgRefNo=jsonarr.getJSONObject(0).getString("originalRefNumber");
				 * LOGGER.info("orgRefNo:::"+orgRefNo); count=getTransIdCount(orgRefNo);
				 * if(count>0) { rootId=getTransId(orgRefNo); }
				 */
		} 
		else if (serviceName.equalsIgnoreCase("Reconnect Subscriber")
				|| serviceName.equalsIgnoreCase("Manage Subscriber")) {
			JSONArray jsonarr = new JSONArray(jsonFormatter(requestJson));
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if (requestJson.contains("transactionType")) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				transactionType = requestJsonObjectData.getString("transactionType").toString();
			}
			if (transactionType != null && !transactionType.isEmpty()) {
				if (transactionType.equalsIgnoreCase("RS")) {
					status = "Restore Suspend";
				} else if (transactionType.equalsIgnoreCase("SS")) {
					status = "Suspend";
				} else if (transactionType.equalsIgnoreCase("SD")) {
					status = "DEACTIVE";
				} else if (transactionType.equalsIgnoreCase("RM")) {
					status = "Reconnect";
				} else if (transactionType.equalsIgnoreCase("SH")) {
					status = "Hotline";
				} else if (transactionType.equalsIgnoreCase("RH")) {
					status = "Remove Hotline";
				}
			}
			String mdn = jsonarr.getJSONObject(0).getString("mdn");
			LOGGER.info("mdn:::" + mdn);
			count = getMdnCounts(mdn);
			LOGGER.info("count:::" + count);
			if (count == 0) {
				int mdnStatusCount=getMdnStatusCount(mdn);
				if(mdnStatusCount>0){
					String hostMdn = getHostMdnValue(mdn);
					LOGGER.info("HOST_MDN:::" + hostMdn);
					if(hostMdn!=null && !hostMdn.isEmpty()) {
						rootId = getMdnTransId(hostMdn, status);
						LOGGER.info("Root_ID:::" + rootId);
					}
				}
			}
		}
		transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
		LOGGER.info("Inside insertMNONBTransaction method::transId:::" + transId);
		LOGGER.info("Inside insertTransaction method::rootId:::" + rootId);
		MapSqlParameterSource input = new MapSqlParameterSource();
		if(rootId==null || rootId.equalsIgnoreCase("")) {
			input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
			input.addValue(Constants.REL_TRANSACTION_ID, null);
		}else {
			input.addValue(Constants.ROOT_TRANSACTION_ID, rootId);
			input.addValue(Constants.REL_TRANSACTION_ID, rootId);
		}
		input.addValue(Constants.TRANSACTION_ID, transId);
		input.addValue(Constants.APPLICATION_NAME, serviceName);
		input.addValue("APPLICATIONNAME", applicationName);
		input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
		input.addValue(Constants.TRANSACTION_UID, transUId);
		input.addValue("httpmethod", httpmethod);
		input.addValue("SOURCE_SYSTEM",source);
		input.addValue("TARGET_SYSTEM","NSL");
		if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
			input.addValue(Constants.ENTITY_ID, entityId);
		} else {
			input.addValue(Constants.ENTITY_ID, 0);
		}
		if (applicationName != null && applicationName.contains("NCM")) {
			input.addValue(Constants.TENANT_ID, "2");
		} else {
			input.addValue(Constants.TENANT_ID, "1");
		}
		boolean isValidrequest=isValidJson(requestJson);
		if(isValidrequest)
		{
		if (requestJson.contains("transactionTimeStamp")) {
			// requestJson = jsonFormatter(requestJson);
			// JSONArray jsonArray = new JSONArray(requestJson);
			// JSONObject requestJsonObject = jsonArray.getJSONObject(0);
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
			}
			if (transactionTimeStamp != null
					&& (transactionTimeStamp.contains("Z") || transactionTimeStamp.contains("z"))) {
				try {
					Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(transactionTimeStamp)).getTime();
					transactionTs = new Timestamp(date.getTime());
				} catch (Exception e) {
					transactionTs = null;
				}
			}
			if (transactionTs != null) {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, transactionTs);
			} else {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
			}
		} else {
			input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
		}
		

		if(requestJson.contains("channel")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				
				if(requestJsonObjectData.has("channel")) {
					channelID=requestJsonObjectData.getString("channel");
					LOGGER.info("Inside insertTransaction method::channel:::" +channelID);
				}
			}
		}
		
		if (requestJson.contains("agentDetails")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				if(requestJsonObjectData.has("agentDetails")) {
					LOGGER.info("Inside insertTransaction method::agentDetails:::" +requestJsonObjectData);
					requestJsonObjectData=requestJsonObjectData.getJSONObject("agentDetails");
					if(requestJsonObjectData.has("agentId")) {
						agentId=requestJsonObjectData.getString("agentId");
						LOGGER.info("Inside insertTransaction method::agentId:::" +agentId);
					}
				}
			}
		}
	

		if (requestJson.contains("account")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
				if(requestJsonObjectData.has("account")) {
					LOGGER.info("Inside insertTransaction method::account:::" +requestJsonObjectData);
					requestJsonObjectData=requestJsonObjectData.getJSONObject("account");
					if(requestJsonObjectData.has("channelId")) {
						channelID=requestJsonObjectData.getString("channelId");
						LOGGER.info("Inside insertTransaction method::channelID:::" +channelID);
					}
					
				}
			}
		
		}else if (requestJson.startsWith("[") || requestJson.startsWith("{")) {
			
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);		
					if(requestJsonObjectData.has("channel")) {
						channelID=requestJsonObjectData.getString("channel");
						LOGGER.info("Inside insertTransaction method::channel:::" +channelID);
					}						
			}
			
		
		}
		
		
		
		
			if (channelID != null) {
				input.addValue("CHANNEL", channelID);
			} else {
				input.addValue("CHANNEL", null);
			}
			if (agentId != null) {
				input.addValue("AGENT_ID", agentId);
			} else {
				input.addValue("AGENT_ID", null);
			}
			
			if(loginID != null) {
				input.addValue("USER_LOGIN_ID",loginID);
			}else {
				input.addValue("USER_LOGIN_ID", null);
			}
			LOGGER.info("Inside insertTransaction method::loginID:::" +loginID);
			
		input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
		if(serviceName.equals("line summary")) {
			if (channelID != null) {
				input.addValue("CHANNEL", null);
			}
			if (agentId != null) {
				input.addValue("AGENT_ID", null);
			}
		}
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
		namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION_LOGINID, input);
		}
		else
		{
			input.addValue(Constants.TRANSACTION_TIMESTAMP,null);
			input.addValue("REQUEST_MSG",requestJson);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			namedJdbcTemplate.update(Constants.INSERT_MNO_NORTH_BOUND_TRANSACTION_LOGINID, input);
		}
		if (serviceName.equals("Handle Download Progress Info")
				|| serviceName.equals("Unsolicited Port-Out")
				|| serviceName.equals("DPFO Event Notifications")) {
			String rel_id = "";
			String Transaction_Type = Constants.INBOUND;
			this.insertEvent_notification(rel_id, transId, Transaction_Type, serviceName, applicationName,
					requestJson);
		}
		return transId;
	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return transId;
}

public void updateDDChangeRatePlanRecords(String transactionName, MapSqlParameterSource input,
		NamedParameterJdbcTemplate namedJdbcTemplate, RequestBean asyncResponseBean, RequestBean ibRequestBean,
		RequestBean obRequestBean, RequestBean deviceDetailsBean, String accountId, String lineId,
		String verifyAccount, String verifyLine, Map<String, String> featMap) {
	int featCount = 0;
	try {
		Map<String, Object> lineDetails = getWHSCodeUsingMDN(obRequestBean.getMdn());
		LOGGER.info("Inside updateChangeFeatureRecords Method");
		input.addValue("LAST_UPDATED", getTimeStamp());
		input.addValue("TRANSACTION_TYPE", null);
		input.addValue("ACC_STATUS", "ACTIVE");
		input.addValue("LINE_STATUS", "ACTIVE");
		input.addValue("ACCOUNT_NUMBER", lineDetails.get("ACCOUNT_NUMBER"));
		input.addValue("WHOLESALE_PLAN", obRequestBean.getnewRatePlan());
		input.addValue("RETAIL_PLANCODE", lineDetails.get("NEW_RPC"));
		input.addValue("ACCT_ID", lineDetails.get("ACCT_ID"));
		input.addValue("LINEID", lineDetails.get("LINE_ID"));
		input.addValue("DEVICE_TYPE", null);
		input.addValue("TRANSACTION_STATUS", null);
		input.addValue("ID", lineDetails.get("ID"));
		for (Entry<String, String> feat : featMap.entrySet()) {
			if (feat.getValue().equalsIgnoreCase("N")) {
				input.addValue("ORDER_TYPE", "FEAT_DEL");
				input.addValue("FEAT_DEL", feat.getKey());
				featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_CF_FEATURES, input, Integer.class);
				if (featCount == 0) {
					input.addValue("FEATURECODES", feat.getKey());
					input.addValue("ISACTIVE", feat.getValue());
					namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
				} else {
					input.addValue("ISACTIVE", feat.getValue());
					input.addValue("FEATURECODES", feat.getKey());
					namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
				}
			} else {
				input.addValue("ORDER_TYPE", "FEAT_ADD");
				input.addValue("FEAT_ADD", feat.getKey());
				input.addValue("FEATURECODES", feat.getKey());
				input.addValue("ISACTIVE", feat.getValue());
				featCount = namedJdbcTemplate.queryForObject(Constants.VALIDATE_FEAT_ADD, input, Integer.class);
				if (featCount == 0) {
					input.addValue("FEATURECODES", feat.getKey());
					input.addValue("ISACTIVE", feat.getValue());
					namedJdbcTemplate.update(Constants.INSERT_LINE_PLAN_DATA, input);
				} else {
					input.addValue("ISACTIVE", feat.getValue());
					input.addValue("FEATURECODES", feat.getKey());
					namedJdbcTemplate.update(Constants.UPDATE_CF_FEATURES, input);
				}
				input.addValue("FIELD_TYPE", "FEATURECODES");
				input.addValue("NEW_VALUE", feat.getKey());
				input.addValue("OLD_VALUE", null);
				namedJdbcTemplate.update(Constants.UPDATE_REFNO, input);
				namedJdbcTemplate.update(Constants.INSERT_LINE_HISTORY_RECORDS, input);
			}
		}
		input.addValue("MDN", obRequestBean.getMdn());
		input.addValue("OLD_WHS", lineDetails.get("OLD_WHS"));
		namedJdbcTemplate.update(Constants.UPDATE_WHS, input);
		input.addValue("OLD_RPC", lineDetails.get("OLD_RPC"));
		input.addValue("NEW_RPC", lineDetails.get("NEW_RPC"));
		input.addValue("OLD_MAKE", lineDetails.get("MAKE"));
		input.addValue("NEW_MAKE", deviceDetailsBean.getMake());
		input.addValue("OLD_MODE_VALUE", lineDetails.get("MODE_VALUE"));
		input.addValue("NEW_MODE_VALUE", deviceDetailsBean.getMode());
		input.addValue("OLD_CDMALESS", lineDetails.get("CDMALESS"));
		input.addValue("NEW_CDMALESS", deviceDetailsBean.getCdmaLess());
		input.addValue("OLD_DEVICE_TYPE", lineDetails.get("DEVICE_TYPE"));
		input.addValue("NEW_DEVICE_TYPE", deviceDetailsBean.getMode());
		input.addValue("OLD_DEVICE_CATEGORY", lineDetails.get("DEVICE_CATEGORY"));
		input.addValue("NEW_DEVICE_CATEGORY", deviceDetailsBean.getDeviceCategory());
		input.addValue("OLD_PRODUCT_TYPE", lineDetails.get("PRODUCT_TYPE"));
		input.addValue("NEW_PRODUCT_TYPE", deviceDetailsBean.getProdType());
		if (!(lineDetails.get("OLD_RPC").toString().equalsIgnoreCase(lineDetails.get("NEW_RPC").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_RPC, input);
		}
		if (!(deviceDetailsBean.getMake().toString().equalsIgnoreCase(lineDetails.get("MAKE").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_MAKE, input);
		}
		if (!(deviceDetailsBean.getMode().toString().equalsIgnoreCase(lineDetails.get("MODE_VALUE").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_MODE_VALUE, input);
		}
		if (!(deviceDetailsBean.getCdmaLess().toString()
				.equalsIgnoreCase(lineDetails.get("CDMALESS").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_CDMALESS, input);
		}
		if (!(deviceDetailsBean.getMode().toString().equalsIgnoreCase(lineDetails.get("DEVICE_TYPE").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_DEVICE_TYPE, input);
		}
		if (!(deviceDetailsBean.getDeviceCategory().toString()
				.equalsIgnoreCase(lineDetails.get("DEVICE_CATEGORY").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_DEVICE_CATEGORY, input);
		}
		if (deviceDetailsBean.getProdType()!=null && lineDetails.get("PRODUCT_TYPE")!=null){
		if (!(deviceDetailsBean.getProdType().toString()
				.equalsIgnoreCase(lineDetails.get("PRODUCT_TYPE").toString()))) {

			namedJdbcTemplate.update(Constants.UPDATE_PRODUCT_TYPE, input);
		}
	}
		namedJdbcTemplate.update(Constants.UPDATE_WHS_RPC, input);
		namedJdbcTemplate.update(Constants.UPDATE_DEVICE_DETAILS, input);
	} catch (Exception e) {
		
		LOGGER.error("Exception in updateChangeRatePlanRecords:::" + e.getMessage());
	}
}

public Map<String,Object> getWHSCodeUsingMDN(String mdn) {
	return (Map<String,Object>)centuryCIFTemplate.queryForMap(Constants.GETWHSCODEUSINGMDN, new Object[] { mdn ,mdn,mdn,mdn,mdn});
}

public String insertNorthBoundTransactionWithLoginId(String requestJson, String entityId, String transUId, String serviceName,
		String applicationName, String loginId) {
	String transId = null;
	String json = null;
	JSONObject inputJsonObj = null;
	String transactionTimeStamp = null;
	Timestamp transactionTs = null;
	String requestMsg = "";
	String channelID = null;
	String agentId = null;
	try {
		transId = centuryCIFTemplate.queryForObject(Constants.GETTRANSACTIONID, String.class);
		LOGGER.info("Inside insertTransaction method::transId:::" + transId);
		MapSqlParameterSource input = new MapSqlParameterSource();
		input.addValue(Constants.TRANSACTION_ID, transId);
		input.addValue(Constants.ROOT_TRANSACTION_ID, transId);
		input.addValue(Constants.APPLICATION_NAME, serviceName);
		input.addValue("APPLICATIONNAME", applicationName);
		input.addValue(Constants.TRANSACTION_TYPE, Constants.INBOUND);
		input.addValue(Constants.TRANSACTION_UID, transUId);
		if (requestJson.contains("transactionTimeStamp")) {
			// requestJson = jsonFormatter(requestJson);
			// JSONArray jsonArray = new JSONArray(requestJson);
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				transactionTimeStamp = requestJsonObjectData.getString("transactionTimeStamp");
			}
			if (transactionTimeStamp != null
					&& (transactionTimeStamp.contains("Z") || transactionTimeStamp.contains("z"))) {
				try {
					Date date = (javax.xml.bind.DatatypeConverter.parseDateTime(transactionTimeStamp)).getTime();
					transactionTs = new Timestamp(date.getTime());
				} catch (Exception e) {
					transactionTs = null;
				}
			}
			if (transactionTs != null) {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, transactionTs);
			} else {
				input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
			}
		} else {
			input.addValue(Constants.TRANSACTION_TIMESTAMP, null);
		}
		if (entityId != null && !"".equalsIgnoreCase(entityId) && !"null".equalsIgnoreCase(entityId)) {
			input.addValue(Constants.ENTITY_ID, entityId);
		} else {
			input.addValue(Constants.ENTITY_ID, 0);
		}
		if (applicationName != null && applicationName.contains("NCM")) {
			input.addValue(Constants.TENANT_ID, "2");
		} else {
			input.addValue(Constants.TENANT_ID, "1");
		}
		if(requestJson.contains("channel")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				
				if(requestJsonObjectData.has("channel")) {
					channelID=requestJsonObjectData.getString("channel");
					LOGGER.info("Inside insertTransaction method::channel:::" +channelID);
				}
			}
		}
		
		if (requestJson.contains("agentDetails")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if(requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				if(requestJsonObjectData.has("agentDetails")) {
					LOGGER.info("Inside insertTransaction method::agentDetails:::" +requestJsonObjectData);
					requestJsonObjectData=requestJsonObjectData.getJSONObject("agentDetails");
					if(requestJsonObjectData.has("agentId")) {
						agentId=requestJsonObjectData.getString("agentId");
						LOGGER.info("Inside insertTransaction method::agentId:::" +agentId);
					}
				}
			}
		}
		
		if (requestJson.startsWith("[") || requestJson.startsWith("{")) {
			JSONObject requestJsonObject = new JSONObject(requestJson);
			if (requestJsonObject.has(Constants.DATA)) {
				JSONObject requestJsonObjectData = requestJsonObject.getJSONObject(Constants.DATA);
				if (requestJsonObjectData.has("channel")) {
					 channelID = requestJsonObjectData.getString("channel");
					LOGGER.info("Inside insertTransaction method::channel:::" + channelID);
					if (channelID != null) {
						input.addValue("CHANNEL", channelID);
					} else {
						input.addValue("CHANNEL", null);
					}
				}else
				{
					input.addValue("CHANNEL", null);
				}
			}

		}
		
		if (channelID != null) {
			input.addValue("CHANNEL", channelID);
		} else {
			input.addValue("CHANNEL", null);
		}
		if (agentId != null) {
			input.addValue("AGENT_ID", agentId);
		} else {
			input.addValue("AGENT_ID", null);
		}
		
		if(loginId != null) {
			input.addValue("USER_LOGIN_ID",loginId);
		}else {
			input.addValue("USER_LOGIN_ID", null);
		}
		LOGGER.info("Inside insertTransaction method::loginID:::" +loginId);
		
		input.addValue("REQUEST_MSG", new SqlLobValue(requestJson), Types.CLOB);
		LOGGER.info("REQUEST_MSG :: "+ input.toString());
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
				centuryCIFTemplate.getDataSource());
		namedJdbcTemplate.update(Constants.INSERT_NORTH_BOUND_TRANSACTION_LOGIN_ID, input);
		return transId;
	} catch (Exception e) {
		LOGGER.error(e.getMessage(), e);
	}
	return transId;
}

	public List<Map<String, Object>> getAccountNumberUsingIccid(String Iccid) {
		List<Map<String, Object>> response = centuryCIFTemplate.queryForList(Constants.ACCOUNTNUMBER_USING_ICCID, new Object[] { Iccid });
		return response;
	}
	public void updateSearchEnvNorthBoundTransaction(String transId, String responseJson) {
		String status = "";
		String code = "";
		try {
			LOGGER.info("updateNorthBoundTransaction transid:::" + transId);
			LOGGER.info("responseJson:::" + responseJson);
			status = "SUCCESS";
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue(Constants.TRANSACTION_ID, transId);
			input.addValue(Constants.STATUS, status);
			input.addValue("RESPONSE_MSG", new SqlLobValue(responseJson), Types.CLOB);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			LOGGER.info("Before search env response update:::");
			namedJdbcTemplate.update(Constants.UPDATE_SEARCHENV_SUCCESS_TRANSACTION, input);
			LOGGER.info("Before search env response update:::");
			}
		catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			
		}
	}


 }