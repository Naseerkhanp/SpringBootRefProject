/**
 * 
 */
package com.nsl.managelines.dao.cif.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nsl.managelines.dao.cif.entity.TransactionLog;
import com.nsl.managelines.dao.cif.repository.TransactionLogRepository;

import lombok.extern.log4j.Log4j2;

/**
 * @author Dhayanand.B
 *
 */
@Component
@Log4j2
public class TransactionLogDaoImpl implements TransactionLogDao {

	@Autowired
	private TransactionLogRepository transactionLogRepository;

	public int findCountByFileName(String fileName,String status){
		int count= 0;
		try {
			 count=transactionLogRepository.findCountByFileName(fileName,status);
		} catch (Exception e) {
			log.error("Error clearNotifiEntityStatus:", e);
		}
		return count;
	}
}
