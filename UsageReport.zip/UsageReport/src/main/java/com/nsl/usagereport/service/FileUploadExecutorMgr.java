package com.nsl.usagereport.service;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.core.env.Environment;

import com.nsl.usagereport.cif.dao.repository.TransactionFileLogDaoImpl;
import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.datahandler.NslDataHandler;
import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.nbos.dao.repository.WibInfoDaoImpl;
import com.nsl.usagereport.postgres.repository.NslDao;
import com.nsl.usagereport.transaction.dao.repository.RefFileUploadDaoImpl;
import com.nsl.usagereport.transaction.dao.repository.ResourceInfoDaoImpl;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslBeanManagerUtil;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class FileUploadExecutorMgr implements Runnable {
	private UsageReportDetails usageReportDetails = null;
	private Map<Long, List<Object>> detailsBuiler = null;
	private Map<Long, RefFileUpload> refFileUploadMap = null;
	private List<RefFileUpload> refFileUploadColumnsLST = null;
	private RefFileUpload refFileUpload = null;
	private Map<String, Map<Object, Long>> recordsStatus = null;
	private Set<String> existingRouterIds = null;
	private List<RefFileUpload> fileUploadLst = null;
	private NslDataHandler nslDataHandler = null;
	private RefFileUploadDaoImpl refFileUploadDaoImpl = null;
	private WibInfoDaoImpl wibInfoDaoImpl = null;
	private List<String> rowsLst = null;
	private Environment env;
	private TransactionFileLogDaoImpl transactionFileLogDaoImpl = null;
	private String fileName = null;
	private String extension = null;
	private NslBeanManagerUtil nslBeanManagerUtil = null;
	private ResourceInfoDaoImpl resourceInfoDaoImpl= null;

	public FileUploadExecutorMgr(UsageReportDetails usageReportDetails, Map<Long, List<Object>> detailsBuiler,
			Map<Long, RefFileUpload> refFileUploadMap, List<RefFileUpload> refFileUploadColumnsLST,
			RefFileUpload refFileUpload, Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds,
			List<RefFileUpload> fileUploadLst, NslDataHandler nslDataHandler, RefFileUploadDaoImpl refFileUploadDaoImpl,
			WibInfoDaoImpl wibInfoDaoImpl, List<String> rowsLst, Environment env,
			TransactionFileLogDaoImpl transactionFileLogDaoImpl, String fileName, String extension,
			NslBeanManagerUtil nslBeanManagerUtil,ResourceInfoDaoImpl resourceInfoDaoImpl) {
		this.usageReportDetails = usageReportDetails;
		this.detailsBuiler = detailsBuiler;
		this.refFileUploadMap = refFileUploadMap;
		this.refFileUploadColumnsLST = refFileUploadColumnsLST;
		this.refFileUpload = refFileUpload;
		this.recordsStatus = recordsStatus;
		this.existingRouterIds = existingRouterIds;
		this.fileUploadLst = fileUploadLst;
		this.nslDataHandler = nslDataHandler;
		this.refFileUploadDaoImpl = refFileUploadDaoImpl;
		this.wibInfoDaoImpl = wibInfoDaoImpl;
		this.rowsLst = rowsLst;
		this.env = env;
		this.transactionFileLogDaoImpl = transactionFileLogDaoImpl;
		this.fileName = fileName;
		this.extension = extension;
		this.nslBeanManagerUtil = nslBeanManagerUtil;
		this.resourceInfoDaoImpl = resourceInfoDaoImpl;
	}

	@Override
	public void run() {
		try {
			int count = 1;
			Long longValue = new Long(refFileUpload.getFilterColumnIndex());
			if (usageReportDetails.getFileType().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				existingRouterIds = wibInfoDaoImpl.getRouterIds();
			}else if (usageReportDetails.getFileType().equalsIgnoreCase("NBOP")) {
				existingRouterIds =  resourceInfoDaoImpl.getRouterIds();
			}
			for (String row : rowsLst) {
				if (count != 1) {
					nslDataHandler.buildData(usageReportDetails, detailsBuiler, row, longValue, refFileUploadMap,
							refFileUploadColumnsLST, count, refFileUpload, recordsStatus, existingRouterIds,
							fileUploadLst);
				}
				count++;
			}
			saveFileDataToDB(detailsBuiler, usageReportDetails, fileName, refFileUploadMap, extension, recordsStatus);
		} catch (Exception e) {
			log.error(this.getClass() + " error occured::", e);
			try {
				transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_FAILED,
						(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
								+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, null,
						e.getMessage(),usageReportDetails,null);
			} catch (Exception e1) {
			}
		}
	}

	public void saveFileDataToDB(Map<Long, List<Object>> detailsBuiler, UsageReportDetails usageReportDetails,
			String fileName, Map<Long, RefFileUpload> refFileUploadMap, String extension,
			Map<String, Map<Object, Long>> recordsStatus) throws Exception {
		log.info(this.getClass() + " saveFileDataToDB method called .");
		try {
			if (usageReportDetails.getSftpFolderPath().equalsIgnoreCase(env.getProperty(NslFileUploadConstants.SMB))) {
				RefFileUpload refFileUpload = refFileUploadDaoImpl
						.getRefFileUploadDetail(usageReportDetails.getFileType());
				for (Entry<Long, List<Object>> data : detailsBuiler.entrySet()) {
					uploadData(nslBeanManagerUtil.getDaoImpl(refFileUpload.getDescription()), data, fileName,usageReportDetails);
				}
				transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
						(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
								+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
						recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, recordsStatus,
						NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);

				return;
			}

			for (Entry<Long, List<Object>> dataDetails : detailsBuiler.entrySet()) {
				String id = dataDetails.getKey() + "";
				uploadData(nslBeanManagerUtil.getDaoImpl(refFileUploadMap.get(dataDetails.getKey()).getDescription()),
						dataDetails, fileName,usageReportDetails);
				System.out.println("completed inserting for id:-" + id);
			}
			transactionFileLogDaoImpl.updateTransactionDetails(NslFileUploadConstants.PARSED_STATUS_SUCCESS,
					(recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size()
							+ recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size()),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSPRCESSD).size(),
					recordsStatus.get(NslFileUploadConstants.TOTALRECORDSFAILED).size(), fileName, recordsStatus,
					NslFileUploadConstants.TOTALRECORDSFAILED,usageReportDetails,null);
		} catch (Exception e) {
			throw new Exception("  Internal Error: Unable to extract data from file ::", e.getCause());
		}
	}

	public void uploadData(NslDao nslDao, Entry<Long, List<Object>> data, String fileName, UsageReportDetails usageReportDetails) throws Exception {
		try {
			nslDao.save(data.getValue());
		} catch (Exception e) {
			log.error(this.getClass() + " Internal Error: Unable to save data into DB ", e);
			throw new Exception(" Internal Error: Unable to save data into DB ", e);
		}
	}
}
