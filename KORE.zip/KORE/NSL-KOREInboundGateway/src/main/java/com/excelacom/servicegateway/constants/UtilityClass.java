package com.excelacom.servicegateway.constants;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class UtilityClass {

	Logger LOGGER = LoggerFactory.getLogger(UtilityClass.class);

	public String invalidToken(String token) {
		String msg = "";
		// msg = Constants.INVALID_TOKEN_1 + token + Constants.INVALID_TOKEN_2;
		msg = Constants.INVALID_TOKEN_3;
		return msg;
	}

	public String unavailableToken() {
		String msg = Constants.INVALID_TOKEN_1 + Constants.TOKEN_UNAVAILABLE + Constants.INVALID_TOKEN_2;
		return msg;
	}

	/**
	 * This method is used for invoking the rest api
	 * @param request
	 * @param url
	 * @return String response
	 */
	public String callRestAPI(String request,String url){
		String outputString = Constants.EMPTYSTRING;
		HttpURLConnection conn = null;
		try {
			URL serviceUrl = new URL(url);
			conn = (HttpURLConnection) serviceUrl.openConnection();
			byte[] requestData = request.getBytes(StandardCharsets.UTF_8);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			conn.setRequestProperty("Content-Length", Integer.toString(requestData.length));
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod("POST");
			conn.setUseCaches(false);
			OutputStream os = conn.getOutputStream();
			os.write(requestData);
			InputStreamReader isr = new InputStreamReader(conn.getInputStream());
			BufferedReader in = new BufferedReader(isr);
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				outputString = outputString + responseString;
			}
			isr.close();
			os.close();
		 } catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			if(conn!=null) {
			conn.disconnect();
			conn = null;
			}
		}
		return outputString;
	}
	
	public String koreSchedulerResponseFromClient(String serviceUrl, String authUrl, String request2) throws IOException {

		String outputString = "";
		HttpURLConnection serviceConn = null;
		String tokenCode = "";
		String request = "grant_type=client_credentials";
		String finResponse = "";
		String soapAction = "";
		URL url = null;
		BufferedReader in = null;
		try {
			
			url = new URL(authUrl + "?" + request);
			System.out.println("OAUTH CONNECTION"+url);
			String username = "manage-subcriber-user";
			System.out.println("grant_type:::" + request);
			String encoded = Base64.getEncoder().encodeToString((username + ":" + "welcome123").getBytes("UTF-8"));
			serviceConn = (HttpURLConnection) url.openConnection();
			serviceConn.setRequestProperty("Authorization", "Basic " + encoded);
			serviceConn.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
			serviceConn.setRequestProperty("Accept", MediaType.APPLICATION_JSON);
			serviceConn.setRequestProperty("SOAPAction", soapAction);
			serviceConn.setRequestMethod("POST");
			serviceConn.setConnectTimeout(60000);
			serviceConn.setDoOutput(true);
			serviceConn.setDoInput(true);
			in = new BufferedReader(new InputStreamReader(serviceConn.getInputStream()));
			String responseString = null;
			while ((responseString = in.readLine()) != null) {
				finResponse = finResponse + responseString;
			}
			if (!"".equalsIgnoreCase(finResponse)) {
				JSONObject obj = new JSONObject(finResponse);
				tokenCode = obj.getString("access_token");
				System.out.println("tokenCode:::" + tokenCode);
			}			
			serviceConn = null;
			if (!"".equalsIgnoreCase(tokenCode)) {
				url = new URL(serviceUrl);
				byte[] requestData = request2.getBytes(StandardCharsets.UTF_8);
				serviceConn = (HttpURLConnection) url.openConnection();
				serviceConn.setRequestProperty("Content-Type", "application/json");
				//serviceConn.setRequestProperty("SOAPAction", soapAction);
				serviceConn.setRequestProperty("Authorization", tokenCode);
				//serviceConn.setRequestProperty("outboundNSLRequestActivate", request2);
				serviceConn.setRequestMethod("POST");
				serviceConn.setConnectTimeout(60000);
				serviceConn.setDoOutput(true);
				serviceConn.setDoInput(true);
				OutputStream os = serviceConn.getOutputStream();
				os.write(requestData);
				
				System.out.println("GET Response Code :: " + serviceConn.getResponseCode());
				if (serviceConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					in = new BufferedReader(new InputStreamReader(serviceConn.getInputStream()));
				} else {
					in = new BufferedReader(new InputStreamReader(serviceConn.getErrorStream()));
				}
				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					outputString = outputString + inputLine;
				}
				LOGGER.info("Response outputString::" + outputString);
			}
			
		} catch (Exception e) {
			LOGGER.error("Exception in koreSchedulerResponseFromClient method::" + e.getMessage());
		} finally {
			if (serviceConn != null) {
				serviceConn.disconnect();
			}
			if (in != null) {
				in.close();
			}
		}
		
		return outputString;
		
	}


}
