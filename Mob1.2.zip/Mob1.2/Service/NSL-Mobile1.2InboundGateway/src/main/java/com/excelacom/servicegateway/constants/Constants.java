package com.excelacom.servicegateway.constants;

public interface Constants {

	String INVALID_TOKEN_1 = "{\"status\":{\"code\":\"401\",\"reason\":\"Unauthorized\",\"message\":\"User account access privileges issue or Token is missing or invalid/expired\"},"
			+ "\"userProfile\":{\"userName\":\"hmnouser\",\"userRole\":\"API_USER\"},\"token\":\"";

	String INVALID_TOKEN_2 = "\"}";
	String TOKEN_UNAVAILABLE = "Not Available";
	/** The Constant ENDPOINTURL. */
	String ENDPOINTURL = "/nsl/provisioning/mno/v1/line-inquiry";

	/** The Constant EMPTYSTRING. */
	String EMPTYSTRING = "";

	/** The Constant SUCCESS. */
	String SUCCESS = "SUCCESS";

	String FAILURE = "FAILURE";

	public static final String Updateacancel_OPERATIONNAME = "MnoUpdateCancelPortWorkflow";

	/** The Constant SERVICENAME. */
	public static final String Updateacancel_SERVICENAME = "MnoUpdatePort";

	/** The Constant UPDATE_FAIL_TRANSACTION. */
	public static final String UPDATE_FAIL_TRANSACTION = "update transaction_details set status = :status,RESP_RECEIVED_DATE=systimestamp,ENTITY_ID = :ENTITY_ID , TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID,SERVICENAME = :SERVICENAME where transaction_uid = :TRANSACTION_ID";

	public static final String GET_TOKEN = "select count(*) from ACCESSTOKEN_INFO where TOKEN=:TOKEN";

	String HTTP_POST = "POST";

	/** The Constant TRANSGROUPID. */
	String TRANSGROUPID = "TRANSGROUPID";

	/** The Constant GROUPID. */
	String GROUPID = "GROUPID";

	/** The Constant STATUS. */
	String STATUS = "status";

	/** The Constant TRANSACTION_ID. */
	String TRANSACTION_ID = "TRANSACTION_ID";

	/** The Constant TRANSACTION_UID. */
	String TRANSACTION_UID = "TRANSACTION_UID";

	/** The Constant ENTITY_ID. */
	String ENTITY_ID = "ENTITY_ID";

	/** The Constant APPLICATION_NAME. */
	String APPLICATION_NAME = "APPLICATION_NAME";

	/** The Constant TRANSACTION_TYPE. */
	String TRANSACTION_TYPE = "TRANSACTION_TYPE";

	String INBOUND = "INBOUND";

	String GETTRANSACTIONID = "SELECT  nextval('SEQ_TRANSACTION_ID')";

	String TENANT_ID = "TENANT_ID";

	String DELTA = "~";

	String INSERT_TRANSACTION = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , " + "	  APPLICATION_NAME,"
			+ "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , " + "    REQ_SENT_DATE , "
			+ "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , " + "    MODIFIED_DATE , "
			+ "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ," + "    TRANSACTION_UID,"
			+ "    TENANT_ID" + "  ) " + "  VALUES " + "  ( " + "    :TRANSACTION_ID , " + "    NULL , "
			+ "    :APPLICATION_NAME , " + "	  :APPLICATIONNAME," + "    NULL, " + "    :TRANSACTION_TYPE , "
			+ "    'INITIATED', " + "    systimestamp , " + "    NULL , " + "    systimestamp , "
			+ "    'NSL' , " + "    NULL , " + "    NULL , " + "      NULL," + "    :REQUEST_MSG ," + "    :ENTITY_ID ,"
			+ "    :TRANSACTION_UID," + "    :TENANT_ID" + "  )";

	String INSERT_NORTH_BOUND_TRANSACTION = "INSERT " + "INTO transaction_details " + "  ( " + "    TRANSACTION_ID , "
			+ "    REL_TRANSACTION_ID , " + "    TRANSACTION_NAME , " + "	  APPLICATION_NAME,"
			+ "    EXT_TRANSACTION_ID , " + "    TRANSACTION_TYPE , " + "    STATUS , " + "    REQ_SENT_DATE , "
			+ "    RESP_RECEIVED_DATE , " + "    CREATED_DATE , " + "    CREATED_BY , " + "    MODIFIED_DATE , "
			+ "    MODIFIED_BY , " + "      ICC_VAL," + "    REQUEST_MSG ," + "    ENTITY_ID ," + "    TRANSACTION_UID,"
			+ "    TENANT_ID" + "  ) " + "  VALUES " + "  ( " + "     (SEQ_TRANSACTION_ID.nextval), " + "    NULL , "
			+ "    :APPLICATION_NAME , " + "	  :APPLICATIONNAME," + "    NULL, " + "    :TRANSACTION_TYPE , "
			+ "    'INITIATED', " + "    systimestamp , " + "    NULL , " + "    systimestamp , "
			+ "    'NSL' , " + "    NULL , " + "    NULL , " + "      NULL," + "    :REQUEST_MSG ," + "    :ENTITY_ID ,"
			+ "    :TRANSACTION_UID," + "    :TENANT_ID" + "  )";

	public static final String INSERT_REQUESTS ="INSERT " 
		    +"INTO rh_csr_request" 
		    +"  ( " 
		    +"    TRANSACTION_ID , " 
		    +"    CUSTOMER_ID , " 
		    +"    CUSTOMER_REQUEST_ID , " 
		    +"    MDN , " 
		    +"    IMEI , " 
		    +"    PICCID ,"
			+"    EID,"	
		    +"    CREATED_DATE , " 
		    +"    CREATED_BY , " 
		    +"    MODIFIED_DATE ,"
			+"    MODIFIED_BY, "
			+"    REFERENCE_NUMBER , " 
		    +"    ASYNC_URL , " 
		    +"    RETURN_URL ,"
			+"    ACCOUNT_NUMBER, "
			+"    SUBORDERID, "
			+"    RETAILPLANCODE, "
			+"    LINEID, "
			+"    CONTEXTID, "
			+"    ACCOUNTTYPE, "
			+"    BILLCYCLEDAY "
		    +"  ) " 
		    +"  VALUES " 
		    +"  ( " 
		    +"    :TRANSACTION_ID , " 
		    +"    :CUSTOMER_ID , " 
		    +"    :CUSTOMER_REQUEST_ID , " 
		    +"    :MDN, " 
		    +"    :IMEI , " 
		    +"    :PICCID, " 
			+"    :EID , " 
			+"    systimestamp, " 
		    +"    'NSL' , " 
		    +"    NULL, " 
			+"    NULL,  " 
			+"    :REFERENCENUMBER,  " 
			+"    :ASYNCURL,  " 
			+"    :RETURNURL,  " 
			+"    :ACCOUNTNUMBER , " 
			+"    :ID,  " 
			+"    :RETAILPLANCODE,  "
			+"    :LINEID,  "
			+"    :CONTEXTID,  "
			+"    :ACCOUNTTYPE,  "
			+"    :BILLCYCLEDAY  "
		    +"  )";
	String UPDATE_SUCCESS_TRANSACTION = "update transaction_details set status = :status , RESPONSE_MSG = :RESPONSE_MSG, HTTP_RESPONSE=:httpCode, NOTES = '' ,RESP_RECEIVED_DATE=systimestamp ,ENTITY_ID = :ENTITY_ID ,TRANS_GROUP_ID = :TRANSGROUPID , GROUP_ID = :GROUPID, SERVICENAME = :SERVICENAME where transaction_uid = :TRANSACTION_ID";

	// public static final String UPDATE_SUCCESS_TRANSACTION = "update
	// transaction_details set status = :status , RESPONSE_MSG = :RESPONSE_MSG,
	// HTTP_RESPONSE=:httpCode where transaction_uid = :TRANSACTION_ID";

	String JSON_FORMATTER = "jsonFormatter";

	String json = "[{\"description\":\"object\",\"parameterList\":[],\"groupParamList\":[{\"entityName\":\"Connection\",\"description\":\"\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"EndpointURL\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNOLineInquiry_URL\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"EndpointURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"122\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNOLineInquiry_URL\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"UserName\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"UserName\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"122\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"2\",\"defaultValue\":\"\"},{\"name\":\"Password\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"Password\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"40\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"3\",\"defaultValue\":\"\"},{\"name\":\"endpointServiceType\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"REST\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"endpointServiceType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"REST\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"},{\"name\":\"SSL\",\"description\":\"\",\"value\":\"No\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Reference\",\"editable\":\"no \",\"subType\":\"RadioButton\",\"columnName\":\"\",\"valueList\":[\"No\",\"Yes\"],\"tableType\":\"\",\"property\":\"single\",\"displayName\":\"SSL\",\"sequenceId\":\"\",\"minLength\":\"0\",\"maxLength\":\"\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"parameterCondition\":[],\"dependParameter\":[],\"name\":\"No\",\"default_value\":\"No\",\"defaultValues\":[{\"name\":\"No\",\"id\":\"1\"}]},{\"parameterCondition\":[],\"dependParameter\":[],\"name\":\"Yes\",\"default_value\":\"No\",\"defaultValues\":[{\"name\":\"No\",\"id\":\"1\"}]}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"5\",\"defaultValue\":\"No\"},{\"name\":\"EndpointOperation\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNOLineInquiry\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"EndpointOperation\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNOLineInquiry\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"6\",\"defaultValue\":\"\"},{\"name\":\"RetryLimit\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"3\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"RetryLimit\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"3\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"7\",\"defaultValue\":\"\"},{\"name\":\"AuthenticationType\",\"description\":\"\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"AuthenticationType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"8\",\"defaultValue\":\"\"},{\"name\":\"southboundurl\",\"description\":\"tag\",\"value\":\"\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"MNO_URL\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"southboundurl\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"MNO_URL\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"9\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"Connection\",\"sequence\":\"1\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false},{\"entityName\":\"MNOLineInquiry\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[],\"groupParamList\":[{\"entityName\":\"messageHeader\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"serviceId\",\"description\":\"tag\",\"value\":\"2323434\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"serviceId\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"requestType\",\"description\":\"tag\",\"value\":\"MNO\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"requestType\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"},{\"name\":\"referenceNumber\",\"description\":\"tag\",\"value\":\"QS.20191127161950416.ActivatePortIn.113240450.60226.R67.99\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"referenceNumber\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"100\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"6\",\"defaultValue\":\"\"},{\"name\":\"returnURL\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"returnURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"7\",\"defaultValue\":\"\"},{\"name\":\"asyncErrorURL\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"asyncErrorURL\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Ordering\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"8\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"messageHeader\",\"sequence\":\"1\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false},{\"entityName\":\"data\",\"description\":\"object\",\"entityIdValue\":\"\",\"queryId\":\"\",\"viewType\":\"Grid\",\"entitySequenceId\":\"\",\"type\":\"Provisioning\",\"parameterList\":[{\"name\":\"transactionType\",\"description\":\"tag\",\"value\":\"LIN\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"transactionType\",\"sequenceId\":\"\",\"minLength\":\"3\",\"maxLength\":\"3\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"1\",\"defaultValue\":\"\"},{\"name\":\"transactionTimeStamp\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"transactionTimeStamp\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"2\",\"defaultValue\":\"\"},{\"name\":\"mdn\",\"description\":\"tag\",\"value\":\"9876543210\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"no \",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"mdn\",\"sequenceId\":\"\",\"minLength\":\"10\",\"maxLength\":\"10\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"3\",\"defaultValue\":\"\"},{\"name\":\"min\",\"description\":\"tag\",\"value\":\"string\",\"tableName\":\"\",\"schemaName\":\"\",\"rule\":\"2\",\"valueType\":\"Input\",\"editable\":\"yes\",\"subType\":\"String\",\"columnName\":\"\",\"valueList\":[\"0\"],\"tableType\":\"\",\"property\":\"\",\"displayName\":\"min\",\"sequenceId\":\"\",\"minLength\":\"1\",\"maxLength\":\"20\",\"conditional\":\"false\",\"parameterType\":\"Provisioning\",\"content_id\":\"0\",\"paramValues\":[{\"name\":\"0\",\"default_value\":\"\"}],\"apiname\":\" \",\"lookup_type\":\" \",\"sequence\":\"4\",\"defaultValue\":\"\"}],\"groupParamList\":[],\"displayName\":\"data\",\"sequence\":\"2\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false}],\"displayName\":\"MNOLineInquiry\",\"sequence\":\"2\",\"legLevel\":\"\",\"condition\":\"Optional\",\"mergeFlag\":false}],\"displayName\":\"MNOLineInquiryRequest\",\"mergeFlag\":false}]&soapAction=SendRequest&destName=MNOLineInquiryRequest&entityId=1001814~5ba6e3b3-452b-4c70-8964-9ec853f487a6&destination=externalSystem&EndpointURL=MNOLineInquiry_URL&EndpointOperation=MNOLineInquiry&requestJson="
			+ "{ \"messageHeader\": {\"serviceId\": \"2323434\",\"requestType\": \"MNO\",\"referenceNumber\": \"QS.20191127161950416.ActivatePortIn.113240450.60226.R67.99\",\"returnURL\": \"string\",\"asyncErrorURL\": \"string\"},\"data\": {\"transactionType\": \"LIN\",\"transactionTimeStamp\": \"string\",\"mdn\": \"9876543210\",\"min\": \"string\"}}";

	
	
	public static final String DATA = "data";

	public static final String STATUSCODE = "statusCode";
	public static final String MESSAGE = "message";

	public static final String FAILED_SOUTH_BOUND = "Failed in Southbound System";

	public static final String SQUARE_BRACKET = "[";

	public static final String CURLY_BRACKET = "{";

	public static final String CODE = "code";

	public static final String UpdateModify_OPERATIONNAME = "MnoUpdateModifyWorkflow";

	public static final String UpdateModify_SERVICENAME = "MnoUpdatePort";

	public static final String INSERT_MNO_NORTH_BOUND_TRANSACTION = "INSERT " 
            +"INTO transaction_details " 
            +"  ( " 
            +"    TRANSACTION_ID , " 
            +"    ROOT_TRANSACTION_ID , "
            +"    REL_TRANSACTION_ID , " 
            +"    TRANSACTION_NAME , " 
            +"	  APPLICATION_NAME,"
            +"    EXT_TRANSACTION_ID , " 
            +"    TRANSACTION_TYPE , " 
            +"    STATUS , " 
            +"    REQ_SENT_DATE , " 
            +"    RESP_RECEIVED_DATE , " 
            +"    CREATED_DATE , " 
            +"    CREATED_BY , " 
            +"    MODIFIED_DATE , " 
            +"    MODIFIED_BY , " 
            +"    ICC_VAL,"
            +"    REQUEST_MSG ," 
            +"    ENTITY_ID ," 
			+"    HTTP_REQUEST,"
			+"    HTTP_RESPONSE ,"
            +"    SOURCE ," 
            +"    NOTES ,"
			+"    TENANT_ID,"
            +"    TRANSACTION_UID,"
			+"    ORDERTIMESTAMP"
            +"  ) " 
            +"  VALUES " 
            +"  ( " 
            +"    :TRANSACTION_ID , " 
            +"    :ROOT_TRANSACTION_ID , "
            +"    NULL , " 
            +"    :APPLICATION_NAME , " 
            +"	  :APPLICATIONNAME,"
            +"    NULL, " 
            +"    :TRANSACTION_TYPE , " 
            +"    'INITIATED', " 
            +"    systimestamp , " 
            +"    NULL , " 
            +"    systimestamp , " 
            +"    'NSL' , " 
            +"    NULL , " 
            +"    NULL , " 
            +"      NULL,"
            +"    :REQUEST_MSG ,"
            +"    :ENTITY_ID ,"
		    +"    :httpmethod , " 
            +"    NULL , " 
			+"    :source , " 
            +"    NULL, " 
            +"    :TENANT_ID,"
			+"    :TRANSACTION_UID,"
			+"    :TRANSACTION_TIMESTAMP"
            +"  )";

	public static final String HMNODEVICEINQUIRY_OPERATIONNAME = "deviceinquiryworkflow";

	public static final String HMNODEVICEINQUIRY_SERVICENAME = "deviceinquiryservice";

	public static final String GET_BASIC_COUNT="select count(*) from BASIC_AUTH_DETAILS where USER_NAME= ? and passcode=?";
	
	public static final String HMNOCHANGEPSIM_SERVICENAME = "hmnochangepSIM";
	
	public static final String HMNOCHANGEPSIM_OPERATIONNAME = "hmnochangepSIMworkflow";


	public static final String HMNOCHANGEFEATURE_OPERATIONNAME = "HMNOChangeFeatureWorkflow";

	public static final String HMNOCHANGEFEATURE_SERVICENAME = "HMNOChangeFeature";

	public static final String HMNOVALIDATESIM_SERVICENAME = "validatesimservice";

	public static final String HMNOVALIDATESIM_OPERATIONNAME = "validatesimserviceworkflow";

	public static final String HMNODEVICEINQUIRYASYNC_OPERATIONNAME = "deviceinquiryasynworkflow";

	public static final String HMNODEVICEINQUIRYASYNC_SERVICENAME = "deviceinquiryservice";
	
	public static final String HMNOlinehistoryinquiryservice_SERVICENAME = "linehistoryinquiryservice";

	public static final String HMNOlinehistoryinquiryservice_OPERATIONNAME = "linehistoryinquiryworkflow";
	
	public static final String MnoPortin_OPERATIONNAME = "MNOPortinInquiryWorkflow";
	
	public static final String MnoPortin_SERVICENAME = "MNOPortinInquiry";
	
	/** The Constant INSERT_REQUEST. */
	public static final String INSERT_REQUEST ="INSERT " 
    +"INTO rh_csr_request" 
    +"  ( " 
    +"    TRANSACTION_ID , " 
    +"    CUSTOMER_ID , " 
    +"    CUSTOMER_REQUEST_ID , " 
    +"    MDN , " 
    +"    IMEI , " 
    +"    EICCID ,"
	+"    EID,"	
    +"    CREATED_DATE , " 
    +"    CREATED_BY , " 
    +"    MODIFIED_DATE ,"
	+"    MODIFIED_BY, "
	+"    REFERENCE_NUMBER , " 
    +"    ASYNC_URL , " 
    +"    RETURN_URL ,"
	+"    ACCOUNT_NUMBER "
    +"  ) " 
    +"  VALUES " 
    +"  ( " 
    +"    :TRANSACTION_ID , " 
    +"    :CUSTOMER_ID , " 
    +"    :CUSTOMER_REQUEST_ID , " 
    +"    :MDN, " 
    +"    :IMEI , " 
    +"    :EICCID, " 
	+"    :EID , " 
	+"    systimestamp, " 
    +"    'NSL' , " 
    +"    NULL, " 
	+"    NULL,  " 
	+"    :REFERENCENUMBER,  " 
	+"    :ASYNCURL,  " 
	+"    :RETURNURL,  " 
	+"    :ACCOUNTNUMBER  " 
    +"  )";
	
	public static final String ACTIVATESUBSCRIBERPORTIN="Activate Subscriber Port-in";
	
	public static final String ACTIVATESUBSCRIBERMDN="Activate Subscriber";
	
	public static final String DEACTIVATESUBSCRIBER="Deactivate Subscriber";
	
	public static final String SUSPENDSUBSCRIBER="Suspend Subscriber";
	
	public static final String HOTLINESUBSCRIBER="Hotline Subscriber";
	
	public static final String REMOVEHOTLINE="Remove Hotline";
	
	public static final String RESTORESERVICE="Restore Service";
	
	public static final String RECONNECTSERVICE="Reconnect Service";
	
	public static final String UPDATEPORTOUT="Update Port-Out";
	
	public static final String CANCELPORTIN="Cancel Port-In";
	
	public static final String UPDATEDUEDATE="Update Due-Date";
	
	public static final String UPDATECUSTOMER_INFO="Update Customer Information";
	
	public static final String RETRIEVE_PSCODE = "RETRIEVE_PSCODE";
	
	public static final String TRANSACTION_TIMESTAMP = "TRANSACTION_TIMESTAMP";
	
    public static final String ROOT_TRANSACTION_ID ="ROOT_TRANSACTION_ID";
    
	public static final String INSERT_REF_ADD_DATA = "INSERT " 
            +"INTO ref_additional_data " 
            +"  ( " 
            +"    TRANSACTIONID , " 
            +"    REFNAME , " 
            +"    REFVALUE ,"
			+"    CREATED_DATE , " 
            +"    CREATED_BY , " 
            +"    MODIFIED_DATE , " 
            +"    MODIFIED_BY  " 			
            +"  ) " 
            +"  VALUES " 
            +"  ( " 
            +"    :TRANSACTION_ID , " 
            +"    :REFNAME, " 
            +"    :REFVALUE ,"
			+"    systimestamp , " 
            +"    'NSL' , " 
			+"    systimestamp , " 
            +"    'NSL'  " 			
            +"  )";
}
