package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.constants.NslFileUploadConstants;
import com.nsl.usagereport.dto.UsageReportDetails;

import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.transaction.entity.ResourceInfo;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("ResourceInfoHandler")
public class ResourceInfoHandler implements Handler {
	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst, UsageReportDetails usageReportDetails) throws Exception {
		if (column.length == 2 && ((column[0].isEmpty() || column[0].equalsIgnoreCase("null"))
				&& ((column[1].isEmpty() || column[1].equalsIgnoreCase("null"))))) {
			return detailsBuiler;
		}
		String routerId = NslFileUploadUtils.nullChecker(column[1]);
		try {
			ResourceInfo resourceInfo = new ResourceInfo();
			//wibInfo.setResourceId((long) 1);
			resourceInfo.setCreatedBy(usageReportDetails.getUserID());
			resourceInfo.setResourceSubtype(fileUploadLst.stream().findFirst().get().getDefaultValue());
			if (!validateFields(resourceInfo, routerId, column, fileUploadLst, recordsStatus, lineNumber)) {
				return detailsBuiler;
			}
				
			if (!existingRouterIds.contains(routerId)) {
				if (detailsBuiler.containsKey(NslFileUploadConstants.DEFAULT_LONG)) {
					List<Object> li = detailsBuiler.get(NslFileUploadConstants.DEFAULT_LONG);
					li.add(resourceInfo);
					detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
				} else {
					List<Object> li = new ArrayList<>();
					li.add(resourceInfo);
					detailsBuiler.put(NslFileUploadConstants.DEFAULT_LONG, li);
				}
				if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSPRCESSD)) {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSPRCESSD, lineNumber, resourceInfo, recordsStatus));
				} else {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSPRCESSD, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSPRCESSD, lineNumber, resourceInfo, recordsStatus));
				}
				existingRouterIds.add(routerId);
			} else {
				resourceInfo.setErrorCode(NslFileUploadConstants.DUPLICATE_ERROR_CODE);
				resourceInfo.setErrorMsg(NslFileUploadConstants.TOTALRECORDSFAILED);
				if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSFAILED)) {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, resourceInfo, recordsStatus));
				} else {
					recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
							NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, resourceInfo, recordsStatus));
				}

			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

	private Boolean validateFields(ResourceInfo resourceInfo, String routerId, String[] column, List<RefFileUpload> fileUploadLst,
			Map<String, Map<Object, Long>> recordsStatus, long lineNumber) throws Exception {
		Boolean flag = true;
		String errorCd = NslFileUploadConstants.EMPTY;
		String errorMsg = NslFileUploadConstants.EMPTY;
		if (routerId.isEmpty()) {
			resourceInfo.setResourceValue(null);
			flag = false;
			errorMsg = "resourceValue is missing";
			errorCd = "ERR06";
		} else if (routerId.length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			resourceInfo.setResourceValue(routerId);
			flag = false;
			errorMsg = "resourceValue is greater than maximum length 255";
			errorCd = "ERR13";
		} 
		else if (!regexCheck(NslFileUploadUtils.nullChecker(routerId), fileUploadLst, column)) {
			resourceInfo.setResourceValue(routerId);
			flag = false;
			errorMsg = "resourceValue is invalid";
			errorCd = "ERR13";
		}

		else {
			resourceInfo.setResourceValue(routerId);
		}

		if (NslFileUploadUtils.nullChecker(column[0]).isEmpty()) {
			//resourceInfo.setSerialNumber(null);
			flag = false;
			errorMsg = "resourceType is missing";
			errorCd = "ERR06";
		} else if (NslFileUploadUtils.nullChecker(column[0]).length() > NslFileUploadConstants.TWO_FIFTY_FIVE) {
			//wibInfo.setSerialNumber(null);
			flag = false;
			errorMsg = "resourceType is greater than maximum length 255";
			errorCd = "ERR13";
		} else {
			resourceInfo.setResourceType(NslFileUploadUtils.nullChecker(column[0]));
		}

		if (!flag) {
			if (recordsStatus.containsKey(NslFileUploadConstants.TOTALRECORDSFAILED)) {
				recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
						NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, resourceInfo, recordsStatus));
			} else {
				recordsStatus.put(NslFileUploadConstants.TOTALRECORDSFAILED, getRouterInfoMap(
						NslFileUploadConstants.TOTALRECORDSFAILED, lineNumber, resourceInfo, recordsStatus));
			}
			resourceInfo.setErrorCode(errorCd);
			resourceInfo.setErrorMsg(errorMsg);
		}
		return flag;
	}

	private boolean regexCheck(String nullChecker, List<RefFileUpload> fileUploadLst, String[] column) {
		return Pattern
				.matches(fileUploadLst.stream().filter(e -> e.getColumnIndex() == NslFileUploadConstants.RESOURCECOLUMN)
						.findFirst().get().getParamareRegex(), column[1]);
	}

	private Map<Object, Long> getRouterInfoMap(String key, Long lineNumber, ResourceInfo wibInfo,
			Map<String, Map<Object, Long>> recordsStatus) {
		Map<Object, Long> routerIdLineNumber = recordsStatus.get(key);
		routerIdLineNumber.put(wibInfo, lineNumber);
		return routerIdLineNumber;
	}
}
