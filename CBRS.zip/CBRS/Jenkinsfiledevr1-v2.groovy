pipeline {
    agent any
	
	tools { 
        maven 'Maven-3.3.9' 
        jdk 'jdk1.8.0_151' 
    }	
	
    stages {
        
		stage ('Build') {
            steps {
                echo 'Maven build is in progress.'
				sh '''
                    echo "PATH = ${PATH}"
                    echo "M2_HOME = ${M2_HOME}"
                '''
				sh 'mvn clean install -Dmaven.test.skip=true'
            }
}
		stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'NSL-DEVR1-CICD@excelacom.in',
			subject: "NSL DEVR1 CBRS Inbound Service Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
          )
      }
    }
        stage('Container Build') {
            steps {
			script{
                echo 'Contianer Build has been started...'
				docker.build('nsl-devr1' + ':cbrs_inbound_v$BUILD_NUMBER')
            }
			}
        }
        stage('Container Upload') {
            steps {
			script{
                echo 'Image Push has been started...'
				 
				docker.withRegistry('https://852563228231.dkr.ecr.us-east-1.amazonaws.com', 'ecr:us-east-1:AWS-ECR-Upload')
				{
               docker.image('nsl-devr1' + ':cbrs_inbound_v$BUILD_NUMBER').push('cbrs_inbound_v$BUILD_NUMBER')
            }
        }
		}
		}
        stage('Container Cleanup') {
            steps {
            	echo 'Image cleanup has been started...'
				sh "docker rmi nsl-devr1:cbrs_inbound_v${env.BUILD_NUMBER}"
				sh "docker rmi 852563228231.dkr.ecr.us-east-1.amazonaws.com/nsl-devr1:cbrs_inbound_v${env.BUILD_NUMBER}"
                  }
		}
		stage('NSL DEVR1 - Configmap Inject') {
			steps {
			echo 'Applying NSL DEVR1 Properties and Datasource Configurations...'
			sh 'kubectl create configmap devr1-cbrs-inbound-properties --from-file=propertiesdevr1 -n default -o yaml --dry-run | kubectl apply -f -'
			sh 'kubectl get configmaps devr1-cbrs-inbound-properties -o yaml -n default'
                  }
        }
		stage('NSL DEVR1 - EKS POD Deploy') {
			steps {
			echo 'CBRS Inbound Service POD Deployment has been started...'
			sh 'cat devr1-cbrs-inbound-deployment.yaml | sed "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" | kubectl apply -f -'
			sh 'kubectl apply -f devr1-cbrs-inbound-service.yaml'
			sh 'kubectl apply -f devr1-cbrs-inbound-service-apm.yaml'
			
                  }
        }
		stage('NSL DEVR1 - EKS POD Status') {
		    steps {
			echo 'CBRS Inbound Service POD Status is being monitored...'
			sleep(time: 60, unit: "SECONDS")
			sh 'kubectl get pods -A | grep cbrs-inbound-deployment'
			
			      }
		}
}
post {
    success {
      emailext (
          from: 'NSL-DEVR1-CICD@excelacom.in',
		  attachLog: true,
		  subject: "NSL DEVR1 CBRS Inbound Service Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Completion.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }

    failure {
      emailext (
          from: 'NSL-DEVR1-CICD@excelacom.in',
		  attachLog: true,
		  subject: "NSL DEVR1 CBRS Inbound Service Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
          body: '${FILE,path="Templates/Failure.html"}',
          recipientProviders: [[$class: 'RequesterRecipientProvider']]
        )
    }
  }
  }