package com.nsl.managelines.dao.cif.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.managelines.dao.cif.entity.TransactionDetails;

@Repository
public interface TransactionDetailsRepository extends CrudRepository<TransactionDetails, Long> {

	Page<TransactionDetails> findAllByTransactionIdOrRootTransactionIdOrExtTransactionIdOrderByCreatedDateDesc(
			Long transactionId, Long rootTransactionId, String extTransactionId, Pageable pageable);

	Page<TransactionDetails> findAllByTransactionIdOrderByCreatedDateDesc(Long transactionId, Pageable pageable);

	Page<TransactionDetails> findAllByRootTransactionIdOrderByCreatedDateDesc(Long rootTransactionId,
			Pageable pageable);

	Page<TransactionDetails> findAllByExtTransactionIdOrderByCreatedDateDesc(String extTransactionId,
			Pageable pageable);

	TransactionDetails findByTransactionId(Long transactionId);

	@Query("select d from TransactionDetails d, TransFailureLog f where f.errorCode=:errorCode and d.transactionId = f.transactionId order by d.createdDate")
	java.util.Set<TransactionDetails> findAllTransactionDetailsByErrorCode(
			@Param(value = "errorCode") String errorCode);

	java.util.Set<TransactionDetails> findAllByNotifiEntityStatusAndTransactionNameIn(String notifiEntityStatus,
			List<String> transactionName);

	java.util.List<TransactionDetails> findByExtTransactionIdAndTransactionTypeAndTransactionNameIn(
			String extTransactionId, String transactionType, java.util.List<String> transactionName);

	@Transactional
	@Modifying
	@Query("update TransactionDetails set notifiEntityStatus = :notifiEntityStatus where transactionId = :transactionId")
	void clearNotifiEntityStatus(@Param(value = "transactionId") Long transactionId,
			@Param(value = "notifiEntityStatus") String notifiEntityStatus);
}
