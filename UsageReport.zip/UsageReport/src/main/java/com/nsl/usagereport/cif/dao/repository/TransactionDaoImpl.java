
package com.nsl.usagereport.cif.dao.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j2;

@Log4j2

@Component
public class TransactionDaoImpl{
	
	@Autowired
	private JdbcTemplate centuryCIFTemplate;

	public String tokenCheck(String token) {
		String status = null;
		String count = null;
		try {
			System.out.println("inside tokenCheck:::" + token);
			MapSqlParameterSource input = new MapSqlParameterSource();
			input.addValue("TOKEN", token);
			NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(
					centuryCIFTemplate.getDataSource());
			//count = namedJdbcTemplate.queryForObject(NslFileUploadConstants.GET_TOKEN, input, String.class);
			System.out.println("count:::" + count);
			//Future if count db operation not used then remove following condition.
//			if (count!=null && !count.equalsIgnoreCase("0")) {
//				status = "success";
//			} else {
				status = "failure";
//			}
		} catch (Exception e) {
			log.error("Exception - {}" , e);
		}
		return status;
	}

	

}
