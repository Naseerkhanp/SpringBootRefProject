package com.nsl.usagereport.transaction.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name = "Sms_Details")
@Entity(name = "SMS_DETAILS")
public class SmsDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SMS_ID")
	private Integer id;
	@Column(name = "RECORD_ID")
	private Long recordId;
	@Column(name = "USAGE_SEQUENCE_ID")
	private Long usageSequenceId;
	@Column(name = "RERATE_IND")
	private String rerateInd;
	@Column(name = "RERATE_REASON_CODE")
	private Long rerateReasonCode;
	@Column(name = "BILLING_NUMBER")
	private String billingNumber;
	@Column(name = "IMSI")
	private String imsi;
	@Column(name = "MIN_NUM")
	private String minNum;
	@Column(name = "DEVICE_ID")
	private String deviceId;
	@Column(name = "SERVICE_PLAN")
	private String servicePlan;
	@Column(name = "TARIFF_PLAN")
	private String tariffPlan;
	@Column(name = "TIER_CD")
	private String tierCd;
	@Column(name = "EVENT_DATE_TIME")
	private Date eventDateTime;
	@Column(name = "GMT_OFFSET")
	private Long gmtOffset;
	@Column(name = "RECORD_TYPE")
	private Long recordType;
	@Column(name = "EVENT_TYPE")
	private Long eventType;
	@Column(name = "CALL_DIRECTION_IND")
	private String callDirectionInd;
	@Column(name = "OTHER_PARTY_ADDRESS")
	private String otherPartyAddress;
	@Column(name = "COUNTRY_CODE")
	private String countryCode;
	@Column(name = "RATE_TYPE")
	private String rateType;
	@Column(name = "TOTAL_UNITS")
	private Long totalUnits;
	@Column(name = "INCLUDED_UNITS")
	private Long includedUnits;
	@Column(name = "CHARGED_UNITS")
	private Long chargedUnits;
	@Column(name = "CHARGE_AMT")
	private Long chargeAmt;
	@Column(name = "ZONE")
	private String zone;
	@Column(name = "VAT_TAX")
	private Long vatTax;
	@Column(name = "EQUIVALENT_UNITS")
	private Long equivalentUnits;
	@Column(name = "BILLING_ID")
	private String billingId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public Long getUsageSequenceId() {
		return usageSequenceId;
	}

	public void setUsageSequenceId(Long usageSequenceId) {
		this.usageSequenceId = usageSequenceId;
	}

	public String getRerateInd() {
		return rerateInd;
	}

	public void setRerateInd(String rerateInd) {
		this.rerateInd = rerateInd;
	}

	public Long getRerateReasonCode() {
		return rerateReasonCode;
	}

	public void setRerateReasonCode(Long rerateReasonCode) {
		this.rerateReasonCode = rerateReasonCode;
	}

	public String getBillingNumber() {
		return billingNumber;
	}

	public void setBillingNumber(String billingNumber) {
		this.billingNumber = billingNumber;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getMinNum() {
		return minNum;
	}

	public void setMinNum(String minNum) {
		this.minNum = minNum;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}

	public String getTariffPlan() {
		return tariffPlan;
	}

	public void setTariffPlan(String tariffPlan) {
		this.tariffPlan = tariffPlan;
	}

	public String getTierCd() {
		return tierCd;
	}

	public void setTierCd(String tierCd) {
		this.tierCd = tierCd;
	}

	public Date getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(Date eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public Long getGmtOffset() {
		return gmtOffset;
	}

	public void setGmtOffset(Long gmtOffset) {
		this.gmtOffset = gmtOffset;
	}

	public Long getRecordType() {
		return recordType;
	}

	public void setRecordType(Long recordType) {
		this.recordType = recordType;
	}

	public Long getEventType() {
		return eventType;
	}

	public void setEventType(Long eventType) {
		this.eventType = eventType;
	}

	public String getCallDirectionInd() {
		return callDirectionInd;
	}

	public void setCallDirectionInd(String callDirectionInd) {
		this.callDirectionInd = callDirectionInd;
	}

	public String getOtherPartyAddress() {
		return otherPartyAddress;
	}

	public void setOtherPartyAddress(String otherPartyAddress) {
		this.otherPartyAddress = otherPartyAddress;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public Long getTotalUnits() {
		return totalUnits;
	}

	public void setTotalUnits(Long totalUnits) {
		this.totalUnits = totalUnits;
	}

	public Long getIncludedUnits() {
		return includedUnits;
	}

	public void setIncludedUnits(Long includedUnits) {
		this.includedUnits = includedUnits;
	}

	public Long getChargedUnits() {
		return chargedUnits;
	}

	public void setChargedUnits(Long chargedUnits) {
		this.chargedUnits = chargedUnits;
	}

	public Long getChargeAmt() {
		return chargeAmt;
	}

	public void setChargeAmt(Long chargeAmt) {
		this.chargeAmt = chargeAmt;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public Long getVatTax() {
		return vatTax;
	}

	public void setVatTax(Long vatTax) {
		this.vatTax = vatTax;
	}

	public Long getEquivalentUnits() {
		return equivalentUnits;
	}

	public void setEquivalentUnits(Long equivalentUnits) {
		this.equivalentUnits = equivalentUnits;
	}

	public String getBillingId() {
		return billingId;
	}

	public void setBillingId(String billingId) {
		this.billingId = billingId;
	}

}
