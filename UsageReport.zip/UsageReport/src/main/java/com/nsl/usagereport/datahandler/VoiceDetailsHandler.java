package com.nsl.usagereport.datahandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.nsl.usagereport.dto.UsageReportDetails;
import com.nsl.usagereport.postgres.entity.VoiceDetails;
import com.nsl.usagereport.transaction.entity.RefFileUpload;
import com.nsl.usagereport.util.NslFileUploadUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("VoiceDetailsHandler")
public class VoiceDetailsHandler implements Handler {

	@Override
	public Map<Long, List<Object>> buildData(String[] column, Map<Long, List<Object>> detailsBuiler,
			Map<String, Map<Object, Long>> recordsStatus, Set<String> existingRouterIds, long lineNumber,
			List<RefFileUpload> fileUploadLst,UsageReportDetails usageReportDetails) throws Exception {
		long id = NslFileUploadUtils.nullCheck(column[0]);
		try {
			VoiceDetails voiceDetails = new VoiceDetails();
			voiceDetails.setDsource(fileUploadLst.stream().findFirst().get().getDefaultValue());
			voiceDetails.setRecordId(id);
			voiceDetails.setUsageSequenceId(NslFileUploadUtils.nullCheck(column[1]));
			voiceDetails.setRerateInd(NslFileUploadUtils.nullChecker(column[2]));
			voiceDetails.setRerateReasonCode(NslFileUploadUtils.nullCheck(column[3]));
			voiceDetails.setBillingNumber(NslFileUploadUtils.nullCheck(column[4]));
			voiceDetails.setImsi(NslFileUploadUtils.nullCheck(column[5]));
			voiceDetails.setMinNum(NslFileUploadUtils.nullCheck(column[6]));
			voiceDetails.setDeviceId(NslFileUploadUtils.nullChecker(column[7]));
			voiceDetails.setRecordType(NslFileUploadUtils.nullChecker(column[8]));
			voiceDetails.setServicePlan(NslFileUploadUtils.nullChecker(column[9]));
			voiceDetails.setTariffPlan(NslFileUploadUtils.nullChecker(column[10]));
			voiceDetails.setTierCd(NslFileUploadUtils.nullChecker(column[11]));
			voiceDetails.setLocalCallStartDatetime(NslFileUploadUtils.convertIntToDate(column[12]));
			voiceDetails.setGmtOffset(NslFileUploadUtils.nullCheck(column[13]));
			voiceDetails.setOtherPartyNumber(NslFileUploadUtils.nullChecker(column[14]));
			voiceDetails.setCallType(NslFileUploadUtils.nullCheck(column[15]));// need to check with yokesh
			voiceDetails.setCallDirectionInd(NslFileUploadUtils.nullChecker(column[16]));
			voiceDetails.setServingBid(NslFileUploadUtils.nullChecker(column[17]));
			voiceDetails.setToCity(NslFileUploadUtils.nullChecker(column[18]));
			voiceDetails.setToState(NslFileUploadUtils.nullChecker(column[19]));
			voiceDetails.setToCountryCode(NslFileUploadUtils.nullChecker(column[20]));
			voiceDetails.setFromCity(NslFileUploadUtils.nullChecker(column[21]));
			voiceDetails.setFromState(NslFileUploadUtils.nullChecker(column[22]));
			voiceDetails.setFromCountryCode(NslFileUploadUtils.nullChecker(column[23]));
			voiceDetails.setInternationalTerminationPoint(NslFileUploadUtils.nullChecker(column[24]));
			voiceDetails.setPeakAirtime(NslFileUploadUtils.nullCheck(column[25]));
			voiceDetails.setOffPeakAirtime(NslFileUploadUtils.nullCheck(column[26]));
			voiceDetails.setTotalMinutes(NslFileUploadUtils.nullCheck(column[27]));
			voiceDetails.setTotalSecondsOfCall(NslFileUploadUtils.nullCheck(column[28]));
			voiceDetails.setIncludedMinutes(NslFileUploadUtils.nullCheck(column[29]));
			voiceDetails.setChargedMinutes(NslFileUploadUtils.nullCheck(column[30]));
			voiceDetails.setRateSpanInd(NslFileUploadUtils.nullChecker(column[31]));
			voiceDetails.setRateType(NslFileUploadUtils.nullChecker(column[32]));
			voiceDetails.setAirTimeCharge(NslFileUploadUtils.nullCheck(column[33]));
			voiceDetails.setTollCharge(NslFileUploadUtils.nullCheck(column[34]));
			voiceDetails.setSddCharge(NslFileUploadUtils.nullCheck(column[35]));
			voiceDetails.setRoamingTaxCharge(NslFileUploadUtils.nullCheck(column[36]));
			voiceDetails.setRoamerSurcharge(NslFileUploadUtils.nullCheck(column[37]));
			voiceDetails.setCallWaiting(NslFileUploadUtils.nullChecker(column[38]));
			voiceDetails.setCallerIdBlock(NslFileUploadUtils.nullChecker(column[39]));
			voiceDetails.setnWayCalling(NslFileUploadUtils.nullChecker(column[40]));
			voiceDetails.setCancelCallWaitingInd(NslFileUploadUtils.nullChecker(column[41]));
			voiceDetails.setFeatureSetupInd(NslFileUploadUtils.nullChecker(column[42]));
			voiceDetails.setCallForward(NslFileUploadUtils.nullChecker(column[43]));
			voiceDetails.setCallDelivery(NslFileUploadUtils.nullChecker(column[44]));
			voiceDetails.setBusyTransferInd(NslFileUploadUtils.nullChecker(column[45]));
			voiceDetails.setNoAnswerTransferInd(NslFileUploadUtils.nullChecker(column[46]));
			voiceDetails.setFootprintCode(NslFileUploadUtils.nullChecker(column[47]));
			voiceDetails.setZone(NslFileUploadUtils.nullChecker(column[48]));
			if (column.length > 49)
			 voiceDetails.setEquivalentUnits(NslFileUploadUtils.nullCheck(column[49]));			
			if (detailsBuiler.containsKey(id)) {
				List<Object> li = detailsBuiler.get(id);
				li.add(voiceDetails);
				detailsBuiler.put(id, li);
			} else {
				List<Object> li = new ArrayList<>();
				li.add(voiceDetails);
				detailsBuiler.put(id, li);
			}
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown :-", e);
		}
		return detailsBuiler;
	}

}
