
package com.nsl.usagereport.cif.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nsl.usagereport.cif.entity.FileDetails;

@Transactional
@Repository
public interface FileDetailsRepository extends JpaRepository<FileDetails, Integer> {

	@Modifying
	@Query("update FILE_DETAILS u set u.downloaded = :downloaded, u.parsed = :parsed where u.fileName = :fileName")
	void updateFileDataByName(@Param("downloaded") String downloaded, @Param("parsed") String parsed,
			@Param("fileName") String fileName);

	@Query("select d from FILE_DETAILS d where d.fileName = :fileName")
	FileDetails findByFileName(@Param("fileName") String fileName);
}
