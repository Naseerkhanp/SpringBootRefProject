package com.nsl.usagereport.transaction.dao.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nsl.usagereport.postgres.repository.NslDao;
import com.nsl.usagereport.transaction.entity.RouterInfo;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("RouterInfoDaoImpl")
public class RouterInfoDaoImpl implements NslDao {
	@Autowired
	RouterInfoRepository routerInfoRepository;

	// TODO added this duplicate check
	// @Transactional(noRollbackFor = {
	// org.springframework.dao.DataIntegrityViolationException.class,
	// org.hibernate.exception.ConstraintViolationException.class,
	// java.sql.SQLIntegrityConstraintViolationException.class })
	@Override
	public void save(List<Object> dataDetailsList) throws Exception {
		log.info(this.getClass() + " save method called .");
		try {
			List<RouterInfo> dataDetails = dataDetailsList.stream().map(s -> (RouterInfo) s)
					.collect(Collectors.toList());
			routerInfoRepository.saveAll(dataDetails);
		} catch (Exception e) {
			log.error(this.getClass() + " Exception thrown ::", e);
			throw new Exception("Exception thrown" + this.getClass() + "::" + e.getMessage());
		}
		log.info(this.getClass() + " save method end .");
	}

}
